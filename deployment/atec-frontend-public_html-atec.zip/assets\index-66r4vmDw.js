(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();function e(e,t=``,n=`asc`){let r=`${e}Sort`;return window[r]=window[r]||{key:t,direction:n},window[r]}function t(t,n,r,i=``,a=`asc`){let o=e(n,i,a),s=r[o.key||i];if(!s)return[...t];let c=o.direction===`desc`?-1:1;return[...t].sort((e,t)=>{let n=s(e),r=s(t),i=Number(n),a=Number(r);return n!==``&&r!==``&&!Number.isNaN(i)&&!Number.isNaN(a)?(i-a)*c:String(n||``).localeCompare(String(r||``),void 0,{numeric:!0,sensitivity:`base`})*c})}function n(t,n,r,i){let a=e(n,r),o=a.key===r,s=o?a.direction:``;return`
    <span class="user-table-heading">
      <span>${t}</span>
      <button
        type="button"
        class="user-sort-btn ${o?`active ${s}`:``}"
        onclick="sortTable('${n}', '${r}', '${i}')"
        aria-label="Sort ${t}"
        title="Sort ${t}"
      ></button>
    </span>
  `}window.sortTable=function(t,n,r){let i=e(t,n);window[`${t}Sort`]={key:n,direction:i.key===n&&i.direction===`asc`?`desc`:`asc`};let a=window[r];typeof a==`function`&&a()};function r(e,t,r,i,a){document.querySelector(`#page`).innerHTML=`

    <h2>Dashboard</h2>

    <div class="filter-card dashboard-quick-search">
      <div class="section-header">
        <h3>Quick Asset Search</h3>
      </div>

      <div class="dashboard-search-row">
        <input
          id="dashboardAssetSearch"
          class="search-box"
          type="text"
          placeholder="Scan QR / Asset ID / Tag No / Serial No..."
          onkeydown="handleDashboardSearchEnter(event)"
        >

        <button onclick="dashboardFindAsset()">Search</button>
        <button type="button" class="secondary-btn" onclick="startDashboardCameraScan()">Scan QR / Barcode</button>
      </div>

      <div id="dashboardCameraScanner" class="quick-camera-scanner dashboard-camera-scanner" hidden>
        <video id="dashboardCameraVideo" playsinline></video>
        <p id="dashboardScanStatus">Scanning... point the camera at the QR label or barcode.</p>
        <button type="button" class="secondary-btn" onclick="stopDashboardCameraScan()">Stop Scanning</button>
      </div>

      <div id="dashboardAssetSearchResult" class="dashboard-search-result"></div>
    </div>

    <div class="dashboard-cards">

      <div class="stat-card stat-blue">
        <div class="stat-icon">CU</div>
        <div>
          <h3>Customers</h3>
          <p>${a.customers||0}</p>
        </div>
      </div>

      <div class="stat-card stat-blue">
        <div class="stat-icon">SI</div>
        <div>
          <h3>Sites</h3>
          <p>${a.sites||0}</p>
        </div>
      </div>

      <div class="stat-card stat-blue">
        <div class="stat-icon">AS</div>
        <div>
          <h3>Assets</h3>
          <p>${a.assets||0}</p>
        </div>
      </div>

      <div class="stat-card stat-blue">
        <div class="stat-icon">ET</div>
        <div>
          <h3>Equipment Types</h3>
          <p>${a.equipmenttypes||0}</p>
        </div>
      </div>

      <div class="stat-card stat-orange">
        <div class="stat-icon">VI</div>
        <div>
          <h3>Visual Due</h3>
          <p>${a.visualdue||0}</p>
        </div>
      </div>

      <div class="stat-card stat-orange">
        <div class="stat-icon">LT</div>
        <div>
          <h3>Load Tests Due</h3>
          <p>${a.loadtestdue||0}</p>
        </div>
      </div>

      <div class="stat-card stat-green">
        <div class="stat-icon">CE</div>
        <div>
          <h3>Valid Certificates</h3>
          <p>${a.certificates||0}</p>
        </div>
      </div>

      <button type="button" class="stat-card stat-red stat-card-action" onclick="showDashboardReviewQueue('incomplete-inspections')">
        <div class="stat-icon">IC</div>
        <div>
          <h3>Incomplete Inspections</h3>
          <p>${a.incompleteinspections||0}</p>
        </div>
      </button>

      <button type="button" class="stat-card stat-red stat-card-action" onclick="showDashboardReviewQueue('certificate-metadata')">
        <div class="stat-icon">CM</div>
        <div>
          <h3>Certificate Metadata</h3>
          <p>${a.certificateintegrityalerts||0}</p>
        </div>
      </button>

      <button type="button" class="stat-card stat-orange stat-card-action" onclick="showDashboardReviewQueue('missing-section')">
        <div class="stat-icon">SC</div>
        <div>
          <h3>Assets Missing Section</h3>
          <p>${a.assetsmissingsection||0}</p>
        </div>
      </button>

      <button type="button" class="stat-card stat-orange stat-card-action" onclick="showDashboardReviewQueue('types-without-criteria')">
        <div class="stat-icon">CR</div>
        <div>
          <h3>Types Without Criteria</h3>
          <p>${a.equipmenttypeswithoutcriteria||0}</p>
        </div>
      </button>

      <button type="button" class="stat-card stat-red stat-card-action" onclick="showDashboardReviewQueue('overdue')">
        <div class="stat-icon">OD</div>
        <div>
          <h3>Overdue</h3>
          <p>${a.overdue||0}</p>
        </div>
      </button>

    </div>

    <div class="dashboard-section dashboard-review-queue" id="dashboardReviewQueue" hidden>
      <div class="section-header">
        <h2 id="dashboardReviewQueueTitle">Review Queue</h2>
        <div class="dashboard-review-actions">
          <button type="button" class="secondary-btn" onclick="exportDashboardReviewQueue()">Export CSV</button>
          <button type="button" class="secondary-btn" onclick="closeDashboardReviewQueue()">Close</button>
        </div>
      </div>

      <div id="dashboardReviewQueueBody">Select a dashboard card to review the items.</div>
    </div>

    <div class="dashboard-section dashboard-alerts">
      <div class="section-header">
        <h2>Operational Alerts</h2>
      </div>

      <div id="dashboardAlerts">Loading...</div>
    </div>

    <div class="dashboard-two-column">
      <div class="dashboard-section">
        <div class="section-header">
          <h2>Failed Equipment</h2>
        </div>

        <table class="dashboard-table">
          <thead>
            <tr>
              <th>${n(`Customer`,`dashboardFailed`,`clientname`,`showDashboard`)}</th>
              <th>${n(`Failed Assets`,`dashboardFailed`,`failed_assets`,`showDashboard`)}</th>
              <th>${n(`Latest Failed Date`,`dashboardFailed`,`latest_failed_date`,`showDashboard`)}</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody id="failedEquipmentTableBody">
            <tr>
              <td colspan="4">Loading...</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="dashboard-section">
        <div class="section-header">
          <h2>Upcoming Certificate Expiries</h2>
        </div>

        <table class="dashboard-table">
          <thead>
            <tr>
              <th>${n(`Customer`,`dashboardExpiries`,`clientname`,`showDashboard`)}</th>
              <th>${n(`Upcoming Assets`,`dashboardExpiries`,`upcoming_assets`,`showDashboard`)}</th>
              <th>${n(`Next Expiry Date`,`dashboardExpiries`,`next_expiry_date`,`showDashboard`)}</th>
              <th>${n(`Days Left`,`dashboardExpiries`,`days_remaining`,`showDashboard`)}</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody id="upcomingExpiriesTableBody">
            <tr>
              <td colspan="5">Loading...</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="dashboard-two-column dashboard-top-row">
      <div class="dashboard-section">
        <div class="section-header">
          <h2>Top Customers by Asset Count</h2>
        </div>

        <table class="dashboard-table">
          <thead>
            <tr>
              <th>${n(`Client`,`dashboardCustomers`,`clientname`,`showDashboard`)}</th>
              <th>${n(`Sites`,`dashboardCustomers`,`sites`,`showDashboard`)}</th>
              <th>${n(`Assets`,`dashboardCustomers`,`assets`,`showDashboard`)}</th>
            </tr>
          </thead>

          <tbody id="dashboardTopCustomersBody">
            <tr>
              <td colspan="3">Loading...</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="dashboard-section">
        <div class="section-header">
          <h2>Equipment by Type</h2>
        </div>

        <table class="dashboard-table">
          <thead>
            <tr>
              <th>${n(`Equipment Type`,`dashboardEquipment`,`equipmenttype`,`showDashboard`)}</th>
              <th>${n(`Total`,`dashboardEquipment`,`total`,`showDashboard`)}</th>
            </tr>
          </thead>

          <tbody id="dashboardEquipmentTypeBody">
            <tr>
              <td colspan="2">Loading...</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="dashboard-section dashboard-actions">
      <div class="section-header">
        <h2>Quick Actions</h2>
      </div>

      <div class="dashboard-buttons">
        <button onclick="showQuickInspection()">New Inspection</button>
        <button onclick="showQuickInspection()">Load Test</button>
        <button onclick="showAssetSetup()">Assets</button>
        <button onclick="showCertificateSearch()">Certificates</button>
      </div>
    </div>
  `}function i(e,t,n,r=25){let i=window[n]||r,a=Math.max(1,Math.ceil(e.length/i)),o=Math.min(window[t]||1,a),s=(o-1)*i,c=e.slice(s,s+i),l=e.length===0?0:s+c.length;return window[t]=o,window[n]=i,{currentPage:o,endIndex:l,pageSize:i,rows:c,startIndex:s,totalPages:a,totalRows:e.length}}function a({currentPage:e,endIndex:t,label:n,onPage:r,onPageSize:i,pageSize:a,startIndex:o,totalPages:c,totalRows:l}){return`
    <div class="report-pagination-bar">
      <div class="report-page-size">
        <label>Rows per page</label>
        <select onchange="${i}(this.value)">
          ${[25,50,100,250].map(e=>`
            <option value="${e}" ${e===a?`selected`:``}>
              ${e}
            </option>
          `).join(``)}
        </select>
      </div>

      <div class="report-page-controls">
        <button type="button" onclick="${r}(${e-1})" ${e<=1?`disabled`:``}>
          Previous
        </button>
        ${s(e,c,r)}
        <button type="button" onclick="${r}(${e+1})" ${e>=c?`disabled`:``}>
          Next
        </button>
        <span>Showing ${l===0?0:o+1} to ${t} of ${l} ${n} - Page ${e} of ${c}</span>
      </div>
    </div>
  `}function o(e,t){let n=[];if(t<=10){for(let e=1;e<=t;e+=1)n.push(e);return n}let r=Math.max(1,e-4),i=Math.min(t,r+9-1);i-r+1<9&&(r=Math.max(1,i-9+1)),r>1&&(n.push(1),r>2&&n.push(`...`));for(let e=r;e<=i;e+=1)n.push(e);return i<t&&(i<t-1&&n.push(`...`),n.push(t)),n}function s(e,t,n){return o(e,t).map(t=>t===`...`?`<span class="pagination-ellipsis">...</span>`:`
      <button
        type="button"
        class="pagination-page-btn ${t===e?`active`:``}"
        onclick="${n}(${t})"
        ${t===e?`disabled`:``}
      >
        ${t}
      </button>
    `).join(``)}function c(e){return String(e??``).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}function l(e){return c(e)}function u(e,r=`active`){let o=window.currentUser?.role===`ADMIN`,s=e.filter(e=>!(e.archived===!0||e.archived===`true`)&&!String(e.clientaddr||``).trim()).length,l=i(t(e.filter(e=>{let t=e.archived===!0||e.archived===`true`;return r===`active`?!t:r===`archived`?t:!0}),`customers`,{clientid:e=>e.clientid,clientname:e=>e.clientname,clientaddr:e=>e.clientaddr,archived:e=>e.archived?`Archived`:`Active`},`clientname`),`customerCurrentPage`,`customerRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h2>Customer Setup</h2>

    <div class="page-actions">
      <button onclick="addClient()">Add Client</button>
      ${o?`<button onclick="reviewMissingCustomerAddresses()">Missing Addresses (${s})</button>`:``}
      <button class="secondary-button" onclick="showCustomerSetup()">Refresh</button>
    </div>

    <div class="filter-card">
      <label>Show Customers</label>

      <div class="radio-row">
        <label>
          <input
            type="radio"
            name="customerArchiveFilter"
            value="active"
            ${r===`active`?`checked`:``}
            onchange="showCustomerSetup('active')"
          >
          Active
        </label>

        <label>
          <input
            type="radio"
            name="customerArchiveFilter"
            value="archived"
            ${r===`archived`?`checked`:``}
            onchange="showCustomerSetup('archived')"
          >
          Archived
        </label>

        <label>
          <input
            type="radio"
            name="customerArchiveFilter"
            value="all"
            ${r===`all`?`checked`:``}
            onchange="showCustomerSetup('all')"
          >
          All
        </label>
      </div>
    </div>
</div>

      <br>

      <input
        id="customerSearch"
        type="text"
        placeholder="Search Client ID, Client Name or Address..."
        onkeyup="filterCustomers(true)"
      />

      <br><br>

      ${a({...l,label:`customers`,onPage:`goToCustomerPage`,onPageSize:`setCustomerRowsPerPage`})}

      <table>
      <thead>
        <tr>
          <th>${n(`Client ID`,`customers`,`clientid`,`showCustomerSetup`)}</th>
          <th>${n(`Client Name`,`customers`,`clientname`,`showCustomerSetup`)}</th>
          <th>${n(`Address`,`customers`,`clientaddr`,`showCustomerSetup`)}</th>
          <th>${n(`Status`,`customers`,`archived`,`showCustomerSetup`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody id="customerTableBody">
        ${l.rows.map(e=>`
          <tr>
            <td>${c(e.clientid)}</td>
            <td>${c(e.clientname||``)}</td>
            <td>${c(e.clientaddr||``)}</td>
            <td>${e.archived?`Archived`:`Active`}</td>
            <td>
              <button onclick="editClient(${e.clientid})">Edit</button>

              ${o?`
              ${e.archived?`<button onclick="unarchiveClient(${e.clientid})">Unarchive</button>`:`<button onclick="archiveClient(${e.clientid})">Archive</button>`}
              `:``}
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `}function d(e,r=`active`){let o=window.currentUser?.role===`ADMIN`,s=e.filter(e=>{let t=e.archived===!0||e.archived===`true`;return r===`active`?!t:r===`archived`?t:!0}),l=i(t(s,`sites`,{siteid:e=>e.siteid,clientname:e=>e.clientname,sitename:e=>e.sitename,archived:e=>e.archived?`Archived`:`Active`},`clientname`),`siteCurrentPage`,`siteRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h2>Sites</h2>

    <button onclick="showAddSiteForm()">
      Add Site
    </button>

    <br><br>

    <p>Total Sites: <strong>${s.length}</strong></p>

    <div class="filter-card">
      <label>Show Sites</label>
      <div class="radio-row">
        ${[`active`,`archived`,`all`].map(e=>`
          <label>
            <input
              type="radio"
              name="siteArchiveFilter"
              value="${e}"
              ${r===e?`checked`:``}
              onchange="showSites('${e}')"
            >
            ${e[0].toUpperCase()+e.slice(1)}
          </label>
        `).join(``)}
      </div>
    </div>

    <label><strong>Search Sites</strong></label>
    <br>

    <input
      id="siteSearch"
      class="search-box"
      type="text"
      placeholder="Search Site ID, Client or Site Name..."
      onkeyup="filterSites(true)"
    />

    <br><br>

    ${a({...l,label:`sites`,onPage:`goToSitePage`,onPageSize:`setSiteRowsPerPage`})}

    <table>
    <thead>
      <tr>
        <th>${n(`Site ID`,`sites`,`siteid`,`showSites`)}</th>
        <th>${n(`Client`,`sites`,`clientname`,`showSites`)}</th>
        <th>${n(`Site Name`,`sites`,`sitename`,`showSites`)}</th>
        <th>${n(`Status`,`sites`,`archived`,`showSites`)}</th>
        <th>Actions</th>
      </tr>
    </thead>

      <tbody id="siteTableBody">
        ${l.rows.map(e=>`
         <tr>
          <td>${c(e.siteid)}</td>
          <td>${c(e.clientname||``)}</td>
          <td>${c(e.sitename||``)}</td>
          <td>${e.archived?`Archived`:`Active`}</td>
          <td>
            <button onclick="editSite(${e.siteid})">
              Edit
            </button>
            ${o?`
            ${e.archived?`<button onclick="unarchiveSite(${e.siteid})">Restore</button>`:`<button onclick="archiveSite(${e.siteid})">Archive</button>`}
            `:``}
          </td>
        </tr>
        `).join(``)}
      </tbody>
    </table>
  `}function f(e,r=`active`){let o=window.currentUser?.role===`ADMIN`,s=e.filter(e=>{let t=e.archived===!0||e.archived===`true`;return r===`active`?!t:r===`archived`?t:!0}),l=i(t(s,`responsible`,{personid:e=>e.personid,clientname:e=>e.clientname,sitename:e=>e.sitename,sectionname:e=>e.sectionname,name:e=>e.name,archived:e=>e.archived?`Archived`:`Active`},`name`),`responsibleCurrentPage`,`responsibleRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h2>Responsible Persons</h2>

    <div class="page-actions">
      <button onclick="showAddResponsiblePersonForm()">
        Add Responsible Person
      </button>
    </div>

    <div class="filter-card">
      <p>
        Total Responsible Persons:
        <strong>${s.length}</strong>
      </p>

      <label>Show Responsible Persons</label>
      <div class="radio-row">
        ${[`active`,`archived`,`all`].map(e=>`
          <label>
            <input
              type="radio"
              name="responsibleArchiveFilter"
              value="${e}"
              ${r===e?`checked`:``}
              onchange="showResponsiblePersons('${e}')"
            >
            ${e[0].toUpperCase()+e.slice(1)}
          </label>
        `).join(``)}
      </div>

      <label><strong>Search Responsible Persons</strong></label>

      <input
        id="responsibleSearch"
        class="search-box"
        type="text"
        placeholder="Search Customer Name or Responsible Person..."
        onkeyup="filterResponsiblePersons(true)"
      />
    </div>

    ${a({...l,label:`people`,onPage:`goToResponsiblePage`,onPageSize:`setResponsibleRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${n(`Person ID`,`responsible`,`personid`,`showResponsiblePersons`)}</th>
          <th>${n(`Customer`,`responsible`,`clientname`,`showResponsiblePersons`)}</th>
          <th>${n(`Linked Sites`,`responsible`,`sitename`,`showResponsiblePersons`)}</th>
          <th>${n(`Linked Sections`,`responsible`,`sectionname`,`showResponsiblePersons`)}</th>
          <th>${n(`Responsible Person`,`responsible`,`name`,`showResponsiblePersons`)}</th>
          <th>${n(`Status`,`responsible`,`archived`,`showResponsiblePersons`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody id="responsibleTableBody">
        ${l.rows.map(e=>`
          <tr>
            <td>${c(e.personid)}</td>
            <td>${c(e.clientname||``)}</td>
            <td>${c(e.sitename||`Not assigned`)}</td>
            <td>${c(e.sectionname||`Not assigned`)}</td>
            <td>${c(e.name||``)}</td>
            <td>${e.archived?`Archived`:`Active`}</td>
            <td>
              <button onclick="editResponsiblePerson(${e.personid})">
                Edit
              </button>
              ${o?`
              ${e.archived?`<button onclick="unarchiveResponsiblePerson(${e.personid})">Restore</button>`:`<button onclick="archiveResponsiblePerson(${e.personid})">Archive</button>`}
              `:``}
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `}function p(e){return e.responsiblename||`Not assigned`}function ee(e,r=`active`){let o=window.currentUser?.role===`ADMIN`,s=e.filter(e=>{let t=e.archived===!0||e.archived===`true`;return r===`active`?!t:r===`archived`?t:!0}),l=i(t(s,`sections`,{client_section:e=>`${e.clientname||``}\u0000${e.sectionname||``}`,sectionid:e=>e.sectionid,clientname:e=>e.clientname,sitename:e=>e.sitename,responsiblename:e=>p(e),sectionname:e=>e.sectionname,archived:e=>e.archived?`Archived`:`Active`},`client_section`),`sectionCurrentPage`,`sectionRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h2>Sections</h2>

    <div class="page-actions">
      <button onclick="showAddSectionForm()">
        Add Section
      </button>
    </div>

    <div class="filter-card">
      <p>
        Total Sections:
        <strong>${s.length}</strong>
      </p>

      <label>Show Sections</label>
      <div class="radio-row">
        ${[`active`,`archived`,`all`].map(e=>`
          <label>
            <input
              type="radio"
              name="sectionArchiveFilter"
              value="${e}"
              ${r===e?`checked`:``}
              onchange="showSections('${e}')"
            >
            ${e[0].toUpperCase()+e.slice(1)}
          </label>
        `).join(``)}
      </div>

      <label><strong><h2>Search Sections</h2></strong></label>

      <div class="form-row">
        <div class="form-group">
          <label>Search By</label>

          <select id="sectionSearchType" onchange="filterSections(true)">
            <option value="clientname">Customer</option>
            <option value="sitename">Site</option>
            <option value="responsiblename">Responsible Person</option>
            <option value="sectionname">Section</option>
          </select>
        </div>

        <div class="form-group">
          <label>Search Text</label>

          <input
            id="sectionSearch"
            class="search-box"
            type="text"
            placeholder="Type search text..."
            onkeyup="filterSections(true)"
          />
        </div>
      </div>
    </div>

    ${a({...l,label:`sections`,onPage:`goToSectionPage`,onPageSize:`setSectionRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${n(`ID`,`sections`,`sectionid`,`showSections`)}</th>
          <th>${n(`Client`,`sections`,`clientname`,`showSections`)}</th>
          <th>${n(`Site`,`sections`,`sitename`,`showSections`)}</th>
          <th>${n(`Responsible Person`,`sections`,`responsiblename`,`showSections`)}</th>
          <th>${n(`Section Name`,`sections`,`sectionname`,`showSections`)}</th>
          <th>${n(`Status`,`sections`,`archived`,`showSections`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody id="sectionTableBody">
        ${l.rows.map(e=>`
          <tr>
            <td>${c(e.sectionid)}</td>
            <td>${c(e.clientname||``)}</td>
            <td>${c(e.sitename||``)}</td>
            <td>${c(p(e))}</td>
            <td>${c(e.sectionname||``)}</td>
            <td>${e.archived?`Archived`:`Active`}</td>
            <td>
              <button onclick="editSection(${e.sectionid})">
                Edit
              </button>
              ${o?`
              ${e.archived?`<button onclick="unarchiveSection(${e.sectionid})">Restore</button>`:`<button onclick="archiveSection(${e.sectionid})">Archive</button>`}
              `:``}
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `}function m(e=``){return String(e).toLowerCase().replace(/\s+/g,` `).trim()}function h(e){return String(e?.criteriadescription||e?.criterianame||``)}function g(e){return String(e?.inspectioncategory||e?.inspection_category||``).toUpperCase()}function te(e){return e?.active!==!1&&e?.active!==`false`}function _(e=[],t={},n=``){return e.some(e=>String(e.equiptypeid)===String(t?.equiptypeid)&&g(e)===String(n||``).toUpperCase()&&te(e))}function v(e=[],t,n=`VISUAL`){let r=t.sections?.[n]||t.sections?.default||[],i=new Map;return r.forEach(e=>i.set(e,[])),e.forEach(e=>{let a=t.getCriteriaSection?t.getCriteriaSection(e,n):r[0]||`Inspection`;i.has(a)||i.set(a,[]),i.get(a).push(e)}),r.map(e=>[e,i.get(e)||[]]).filter(([,e])=>e.length)}var ne={id:`CHAIN_BLOCK_LEVER_HOIST`,displayName:`Chain Block / Lever Hoist`,supportedEquipmentTypes:[],supportedEquipmentGroups:[],supportedInspectionTypes:[`VISUAL`,`LOADTEST`],equipmentTextMatches:[`manual chain hoist`,`manual lever hoist`,`chain block`,`lever hoist`],genericFallback:!0,sections:{default:[`Identification`,`Hooks`,`Load Chain`,`Body / Casing`,`Brake / Load Holding`,`Markings`,`Functional Test`,`Final Result`]},getCriteriaSection(e){let t=m(h(e));return t.includes(`safe for continued operation`)||t.includes(`safe for service`)||t.includes(`defect`)||t.includes(`recommendation`)||t.includes(`comment`)?`Final Result`:t.includes(`hook`)||t.includes(`latch`)||t.includes(`throat`)?`Hooks`:t.includes(`chain`)||t.includes(`link`)?`Load Chain`:t.includes(`brake`)||t.includes(`load holding`)||t.includes(`proof load`)||t.includes(`load limiter`)||t.includes(`loadcell`)?`Brake / Load Holding`:t.includes(`marking`)||t.includes(`swl`)||t.includes(`wll`)||t.includes(`identification`)||t.includes(`serial`)?`Markings`:t.includes(`body`)||t.includes(`casing`)||t.includes(`cover`)||t.includes(`frame`)||t.includes(`structure`)?`Body / Casing`:t.includes(`function`)||t.includes(`operate`)||t.includes(`movement`)||t.includes(`raising`)||t.includes(`lowering`)||t.includes(`test`)?`Functional Test`:`Identification`}},re={id:`CRANE`,displayName:`Crane`,supportedEquipmentTypes:[`401`,`402`,`404`,`406`],supportedEquipmentGroups:[`400`],supportedInspectionTypes:[`VISUAL`,`LOADTEST`],requireCriteriaForGroupMatch:!0,genericFallback:!0,photoPrompts:[`Crane`,`Identification plate`,`Hook`,`Hoist`,`Rope or chain`,`Control station`,`Safety device`,`Defect`,`Load-test setup`],declarations:[`inspectorDeclaration`,`submitConfirmation`],sections:{VISUAL:[`Inspection Setup`,`Crane Structure`,`Hoist and Lifting Mechanism`,`Hooks and Load-Bearing Components`,`Ropes, Chains and Drums`,`Electrical and Control Systems`,`Safety Devices`,`Travel System and End Stops`,`Operational Checks`,`Defects and Final Safety`],LOADTEST:[`Pre/Post Test Inspection`,`Test Equipment and Calibration`,`Rated Capacity and Test Load`,`Static Test`,`Dynamic Test`,`Brake and Holding Test`,`Deflection Measurements`,`Defects and Final Safety`]},getCriteriaSection(e,t=`VISUAL`){let n=m(h(e));return n.includes(`safe for continued operation`)||n.includes(`safe for service`)||n.includes(`defect`)||n.includes(`recommendation`)||n.includes(`comment`)?`Defects and Final Safety`:t===`LOADTEST`?n.includes(`load mass`)||n.includes(`proof load`)||n.includes(`test load`)||n.includes(`loadcell`)?`Rated Capacity and Test Load`:n.includes(`deflection`)?`Deflection Measurements`:n.includes(`brake`)||n.includes(`hold`)?`Brake and Holding Test`:n.includes(`static`)?`Static Test`:n.includes(`dynamic`)||n.includes(`travel`)||n.includes(`function`)?`Dynamic Test`:n.includes(`visual`)||n.includes(`structure`)||n.includes(`hook`)||n.includes(`rope`)||n.includes(`chain`)?`Pre/Post Test Inspection`:`Test Equipment and Calibration`:n.includes(`structure`)||n.includes(`girder`)||n.includes(`carriage`)||n.includes(`rail`)||n.includes(`corrosion`)||n.includes(`crack`)||n.includes(`deformation`)?`Crane Structure`:n.includes(`hoist`)||n.includes(`motor`)||n.includes(`gearbox`)||n.includes(`brake`)?`Hoist and Lifting Mechanism`:n.includes(`hook`)||n.includes(`latch`)||n.includes(`load-bearing`)?`Hooks and Load-Bearing Components`:n.includes(`rope`)||n.includes(`chain`)||n.includes(`drum`)||n.includes(`sheave`)?`Ropes, Chains and Drums`:n.includes(`electrical`)||n.includes(`isolator`)||n.includes(`cable`)||n.includes(`earth`)||n.includes(`pendant`)||n.includes(`remote`)?`Electrical and Control Systems`:n.includes(`limit`)||n.includes(`emergency`)||n.includes(`warning`)||n.includes(`overload`)||n.includes(`safety`)?`Safety Devices`:n.includes(`travel`)||n.includes(`wheel`)||n.includes(`bearing`)||n.includes(`end stop`)||n.includes(`buffer`)?`Travel System and End Stops`:n.includes(`operate`)||n.includes(`function`)||n.includes(`raising`)||n.includes(`lowering`)?`Operational Checks`:`Inspection Setup`}},ie={id:`HARNESS_FALL_ARREST`,displayName:`Harness / Fall-Arrest`,supportedEquipmentTypes:[`601`,`339`],supportedEquipmentGroups:[`600`],supportedInspectionTypes:[`VISUAL`],requireCriteriaForExplicitType:!0,requireFamilyMatchForExplicitType:!1,genericFallback:!0,photoPrompts:[`General equipment view`,`Identification label`,`Serial or batch marking`,`Front webbing`,`Rear webbing`,`Stitching`,`D-rings`,`Buckles and adjusters`,`Connectors`,`Lanyard`,`Shock absorber`,`Defect`,`Quarantine or rejection marking`],declarations:[`inspectorDeclaration`,`submitConfirmation`],sections:{VISUAL:[`Identification and Traceability`,`Webbing and Textile Components`,`Stitching and Seams`,`Buckles, Adjusters and Connectors`,`D-rings and Attachment Points`,`Lanyards, Shock Absorbers and Fall-Arrest Components`,`Labels, Markings and Instructions`,`Contamination, Heat and Chemical Exposure`,`Previous Fall / Loading History`,`Defects and Rejection Decision`,`Final Safe For Service`]},setupQuestions:[{id:`harnessAvailableForFullExamination`,label:`Item available for full examination`},{id:`harnessCleanEnoughForInspection`,label:`Clean enough for a reliable inspection`},{id:`harnessInspectionHistoryAvailable`,label:`Inspection history available`},{id:`harnessInspectionIncompleteReason`,label:`Reason if inspection could not be completed`,type:`text`},{id:`harnessArrestedFall`,label:`Known to have arrested a fall`},{id:`harnessShockLoaded`,label:`Known to have been shock-loaded`},{id:`harnessHeatChemicalExposure`,label:`Exposed to fire, extreme heat or chemicals`},{id:`harnessUnknownHistory`,label:`History is unknown`}],getCriteriaSection(e){let t=m(h(e));return t.includes(`safe for service`)||t.includes(`safe for continued`)||t.includes(`confirm whether the equipment is safe`)?`Final Safe For Service`:t.includes(`serial`)||t.includes(`batch`)||t.includes(`identification`)||t.includes(`label`)||t.includes(`marking`)||t.includes(`traceability`)||t.includes(`manufacturer`)||t.includes(`instruction`)?`Identification and Traceability`:t.includes(`webbing`)||t.includes(`textile`)||t.includes(`cut`)||t.includes(`tear`)||t.includes(`abrasion`)||t.includes(`fray`)||t.includes(`fibre`)||t.includes(`knot`)?`Webbing and Textile Components`:t.includes(`stitch`)||t.includes(`seam`)||t.includes(`thread`)?`Stitching and Seams`:t.includes(`buckle`)||t.includes(`adjuster`)||t.includes(`connector`)||t.includes(`snap hook`)||t.includes(`karabiner`)||t.includes(`carabiner`)||t.includes(`gate`)||t.includes(`lock`)?`Buckles, Adjusters and Connectors`:t.includes(`d-ring`)||t.includes(`d ring`)||t.includes(`attachment point`)||t.includes(`eyelet`)||t.includes(`rivet`)?`D-rings and Attachment Points`:t.includes(`lanyard`)||t.includes(`shock absorber`)||t.includes(`energy absorber`)||t.includes(`lifeline`)||t.includes(`fall arrest`)||t.includes(`fall-arrest`)?`Lanyards, Shock Absorbers and Fall-Arrest Components`:t.includes(`contamination`)||t.includes(`chemical`)||t.includes(`heat`)||t.includes(`burn`)||t.includes(`uv`)||t.includes(`mould`)||t.includes(`glazing`)?`Contamination, Heat and Chemical Exposure`:t.includes(`fall`)||t.includes(`shock-load`)||t.includes(`shock load`)||t.includes(`history`)||t.includes(`quarantine`)?`Previous Fall / Loading History`:t.includes(`defect`)||t.includes(`reject`)||t.includes(`repair`)||t.includes(`alteration`)||t.includes(`modification`)?`Defects and Rejection Decision`:`Identification and Traceability`}},ae={id:`SLING`,displayName:`Sling`,supportedEquipmentTypes:[`201`],supportedEquipmentGroups:[`200`],supportedInspectionTypes:[`VISUAL`,`LOADTEST`],requireCriteriaForExplicitType:!0,requireFamilyMatchForExplicitType:!1,genericFallback:!0,photoPrompts:[`General sling view`,`Identification tag`,`Entire sling body`,`End eye`,`Master link`,`Hook`,`Safety latch`,`Chain links`,`Wire rope`,`Ferrule or splice`,`Textile damage`,`Defect`,`Load-test setup`],declarations:[`inspectorDeclaration`,`submitConfirmation`],setupQuestions:[{id:`slingCleanAvailable`,label:`Sling clean and available for complete examination`},{id:`slingIdentificationLegible`,label:`Identification / WLL marking legible`},{id:`slingHistoryAvailable`,label:`Sling history available`},{id:`slingKnownOverload`,label:`Known overload or shock loading`},{id:`slingInspectionIncompleteReason`,label:`Reason if inspection could not be completed`,type:`text`}],sections:{VISUAL:[`Identification and Traceability`,`Sling Body / Material Inspection`,`Wire Rope Condition`,`Chain Links and Components`,`Webbing / Round Sling Body`,`End Fittings and Connectors`,`Wear, Deformation and Damage`,`Heat, Chemical and Environmental Exposure`,`Load History and Misuse`,`Measurements`,`Defects and Rejection Decision`,`Final Safe For Service`],LOADTEST:[`Load-Test Setup`,`Rated Capacity and Test Load`,`Post-Test Examination`,`Defects and Rejection Decision`,`Final Safe For Service`]},getCriteriaSection(e,t=`VISUAL`){let n=m(h(e));return n.includes(`safe for service`)||n.includes(`safe for continued`)||n.includes(`confirm whether the equipment is safe`)?`Final Safe For Service`:t===`LOADTEST`?n.includes(`load`)||n.includes(`proof`)||n.includes(`test`)?`Rated Capacity and Test Load`:n.includes(`post`)||n.includes(`after`)?`Post-Test Examination`:n.includes(`defect`)||n.includes(`reject`)?`Defects and Rejection Decision`:`Load-Test Setup`:String(e?.fieldtype||``).toUpperCase()===`NUMBER`||String(e?.resulttype||``).toUpperCase()===`MEASURED`?`Measurements`:n.includes(`identification`)||n.includes(`serial`)||n.includes(`trace`)||n.includes(`tag`)||n.includes(`label`)||n.includes(`wll`)||n.includes(`swl`)||n.includes(`mark`)?`Identification and Traceability`:n.includes(`wire`)||n.includes(`rope`)||n.includes(`strand`)||n.includes(`birdcage`)||n.includes(`birdcaging`)||n.includes(`kink`)||n.includes(`crush`)?`Wire Rope Condition`:n.includes(`chain`)||n.includes(`link`)||n.includes(`grade`)||n.includes(`elongation`)||n.includes(`shortening`)?`Chain Links and Components`:n.includes(`webbing`)||n.includes(`round sling`)||n.includes(`textile`)||n.includes(`cover`)||n.includes(`core fibre`)||n.includes(`stitch`)||n.includes(`cut`)||n.includes(`tear`)?`Webbing / Round Sling Body`:n.includes(`hook`)||n.includes(`latch`)||n.includes(`master link`)||n.includes(`coupling`)||n.includes(`fitting`)||n.includes(`eye`)||n.includes(`ferrule`)||n.includes(`splice`)?`End Fittings and Connectors`:n.includes(`wear`)||n.includes(`deformation`)||n.includes(`crack`)||n.includes(`broken`)||n.includes(`stretch`)||n.includes(`distortion`)?`Wear, Deformation and Damage`:n.includes(`heat`)||n.includes(`chemical`)||n.includes(`corrosion`)||n.includes(`environment`)||n.includes(`burn`)?`Heat, Chemical and Environmental Exposure`:n.includes(`overload`)||n.includes(`shock`)||n.includes(`misuse`)||n.includes(`history`)?`Load History and Misuse`:n.includes(`defect`)||n.includes(`reject`)||n.includes(`repair`)||n.includes(`alteration`)?`Defects and Rejection Decision`:`Sling Body / Material Inspection`}},oe=[re,ie,ae,ne];function se(e={},t){let n=m([e?.equipmenttype,e?.equipmenttypedescription,e?.description].filter(Boolean).join(` `));return(t.equipmentTextMatches||[]).some(e=>n.includes(e))}function ce(e={},t=[],n=`VISUAL`,r={}){let i=String(n||``).toUpperCase();if(![`VISUAL`,`LOADTEST`].includes(i))return null;for(let n of oe)if(!r.disabledWizardIds?.includes(n.id)&&n.supportedInspectionTypes.includes(i)&&(n.supportedEquipmentTypes||[]).includes(String(e?.equiptypeid||``))&&r.enabledWizardIds?.includes(n.id)!==!1){let r=_(t,e,i),a=(n.supportedEquipmentGroups||[]).includes(String(e?.equipgroupid||``)),o=se(e,n);if(n.requireCriteriaForExplicitType&&!r||n.requireFamilyMatchForExplicitType&&!a&&!o)continue;return n}for(let n of oe){if(r.disabledWizardIds?.includes(n.id)||!n.supportedInspectionTypes.includes(i))continue;let a=_(t,e,i),o=(n.supportedEquipmentGroups||[]).includes(String(e?.equipgroupid||``)),s=se(e,n);if(a&&(o||s||n.matchAnyCriteria===!0)||s)return n}return null}function le(e={},t=[],n=`VISUAL`,r={}){return ce(e,t,n,r)?.id||`GENERIC`}function ue(e={},t=[],n=`VISUAL`){return ce(e,t,n)?.id===re.id}function de(e={},t=[],n=`VISUAL`){return ce(e,t,n)!==null}function fe(e={},t=[],n=`VISUAL`){let r=ce(e,t,n);return r?r.id===re.id?n===`LOADTEST`?`Wizard Load Test`:`Wizard Inspect`:r.id===ie.id?n===`LOADTEST`?`Load Test`:`Wizard Inspect`:r.id===ae.id?n===`LOADTEST`?`Wizard Load Test`:`Wizard Inspect`:n===`LOADTEST`?`Load Test`:`Wizard Inspect`:n===`LOADTEST`?`Load Test`:`Inspect`}function pe(e){return[`100`,`400`,`500`].includes(String(e.equipgroupid||``))?!0:(window.atecCriteria||[]).some(t=>String(t.equiptypeid)===String(e.equiptypeid)&&String(t.inspectioncategory||t.inspection_category||``).toUpperCase()===`LOADTEST`&&t.active!==!1&&t.active!==`false`)}function me(e){let t=e.serialno||e.hoistserialno||``,n=[`ADMIN`,`MANAGER`,`INSPECTOR`].includes(window.currentUser?.role),r=window.currentUser?.role===`ADMIN`,i=c(e.assetid),a=c(e.assettagno||``),o=c(t),s=c(e.hoistserialno||``),l=c(e.clientname||``),u=c(e.sitename||``),d=c(e.sectionname||``),f=c(e.equipmenttype||``),p=c(e.description||``);return`
    <tr>
      <td>${i}</td>
      <td>${a}</td>
      <td>
        ${o}
        ${e.serialno&&e.hoistserialno&&e.serialno!==e.hoistserialno?`
          <br><small>Hoist: ${s}</small>
        `:``}
      </td>
      <td>${l}</td>
      <td>${u}</td>
      <td>${d}</td>
      <td>${f}</td>
      <td>${p}</td>
      <td>
        <div class="action-buttons">
          ${n?`
            <button onclick="editAsset(${e.assetid})">Edit</button>

            ${de(e,window.atecCriteria||[],`VISUAL`)?`
              <button class="load-test-btn" onclick="startInspection(${e.assetid}, 'VISUAL', 'assets', 'wizard')">
                ${fe(e,window.atecCriteria||[],`VISUAL`)}
              </button>
            `:`
              <button onclick="startInspection(${e.assetid}, 'VISUAL', 'assets')">
                Inspect
              </button>
            `}

            ${pe(e)?`
              <button
                class="load-test-btn"
                onclick="startInspection(${e.assetid}, 'LOADTEST', 'assets', '${ue(e)?`wizard`:`auto`}')"
              >
                ${fe(e,window.atecCriteria||[],`LOADTEST`)}
              </button>
            `:``}
          `:``}

          <button class="history-btn" onclick="showAssetHistoryFromSetup(${e.assetid})">
            History
          </button>

          <button class="qr-label-btn" onclick="openAssetQrLabel(${e.assetid})">
            QR Label
          </button>

          ${r?`
            <button class="move-btn" onclick="showMoveAssetForm(${e.assetid})">
              Move
            </button>

            <button onclick="archiveAsset(${e.assetid})">
              Archive
            </button>
          `:``}
        </div>
      </td>
    </tr>
  `}function he(e,r={}){let i=r.serverPaged===!0,a=i?e:t(e,`assets`,{assetid:e=>e.assetid,assettagno:e=>e.assettagno,serialno:e=>e.serialno||e.hoistserialno,clientname:e=>e.clientname,sitename:e=>e.sitename,sectionname:e=>e.sectionname,equipmenttype:e=>e.equipmenttype,description:e=>e.description,qrcode:e=>e.qrcode},`assetid`),o=window.assetRowsPerPage||25,s=i?Number(r.total||0):a.length,c=Math.max(1,Math.ceil(s/o)),l=Math.min(window.assetCurrentPage||1,c),u=(l-1)*o,d=i?a:a.slice(u,u+o),f=s===0?0:u+d.length,p=_e(s,u,f,l,c,o,!0),ee=_e(s,u,f,l,c,o,!1);document.querySelector(`#page`).innerHTML=`
    <h1>Asset Setup</h1>

    ${[`ADMIN`,`MANAGER`,`INSPECTOR`].includes(window.currentUser?.role)?`
      <div class="page-actions">
        <button onclick="showAddAssetForm()">
          Add Asset
        </button>
      </div>
    `:``}

    <div class="filter-card">
      <p>
        Total Assets:
        <strong id="assetTotalCount">${s}</strong>
      </p>

      <h2>Search Assets</h2>

      <div class="form-row">
        <div class="form-group">
          <label>Search By</label>

          <select id="assetSearchType" onchange="filterAssets(true)">
            <option value="all">All Fields</option>
            <option value="assetid">Asset ID</option>
            <option value="assettagno">Asset Tag</option>
            <option value="serialno">Serial No</option>
            <option value="hoistserialno">Hoist Serial No</option>
            <option value="clientname">Client</option>
            <option value="sitename">Site</option>
            <option value="sectionname">Section</option>
            <option value="equipmenttype">Equipment Type</option>
            <option value="description">Description</option>
            <option value="qrcode">QR Code</option>
          </select>
        </div>

        <div class="form-group">
          <label>Search Text</label>

          <input
            id="assetSearch"
            class="search-box"
            type="text"
            placeholder="Type search text..."
            oninput="filterAssetsDebounced(true)"
          />
        </div>
      </div>

      <div class="filter-key-row">
        ${[[`all`,`All`],[`assetid`,`Asset ID`],[`assettagno`,`Asset Tag`],[`serialno`,`Serial No`],[`hoistserialno`,`Hoist Serial No`],[`clientname`,`Client`],[`sitename`,`Site`],[`sectionname`,`Section`],[`equipmenttype`,`Equipment Type`],[`description`,`Description`],[`qrcode`,`QR Code`]].map(([e,t])=>`
          <button type="button" class="filter-key-btn" onclick="setAssetFilterKey('${e}')">
            ${t}
          </button>
        `).join(``)}
      </div>
    </div>

    ${p}

    <table>
      <thead>
        <tr>
          <th>${n(`Asset ID`,`assets`,`assetid`,`showAssetSetup`)}</th>
          <th>${n(`Asset Tag`,`assets`,`assettagno`,`showAssetSetup`)}</th>
          <th>${n(`Serial No`,`assets`,`serialno`,`showAssetSetup`)}</th>
          <th>${n(`Client`,`assets`,`clientname`,`showAssetSetup`)}</th>
          <th>${n(`Site`,`assets`,`sitename`,`showAssetSetup`)}</th>
          <th>${n(`Section`,`assets`,`sectionname`,`showAssetSetup`)}</th>
          <th>${n(`Equipment Type`,`assets`,`equipmenttype`,`showAssetSetup`)}</th>
          <th>${n(`Description`,`assets`,`description`,`showAssetSetup`)}</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody id="assetTableBody">
        ${d.map(me).join(``)}
      </tbody>
    </table>

    ${ee}
  `}function ge(e,n={}){let r=document.querySelector(`#assetTableBody`);if(!r){he(e,n);return}let i=n.serverPaged===!0,a=i?e:t(e,`assets`,{assetid:e=>e.assetid,assettagno:e=>e.assettagno,serialno:e=>e.serialno||e.hoistserialno,clientname:e=>e.clientname,sitename:e=>e.sitename,sectionname:e=>e.sectionname,equipmenttype:e=>e.equipmenttype,description:e=>e.description,qrcode:e=>e.qrcode},`assetid`),o=window.assetRowsPerPage||25,s=i?Number(n.total||0):a.length,c=Math.max(1,Math.ceil(s/o)),l=Math.min(window.assetCurrentPage||1,c),u=(l-1)*o,d=i?a:a.slice(u,u+o),f=s===0?0:u+d.length,p=document.querySelector(`#assetTotalCount`),ee=_e(s,u,f,l,c,o,!0),m=_e(s,u,f,l,c,o,!1);p&&(p.textContent=String(s)),r.innerHTML=d.map(me).join(``);let h=document.querySelector(`#assetPaginationControls`),g=document.querySelector(`.asset-pagination-bottom`);h&&(h.outerHTML=ee),g&&(g.outerHTML=m)}function _e(e,t,n,r,i,a,o){let s=ye(r,i);return`
    <div ${o?`id="assetPaginationControls"`:``} class="report-pagination-bar asset-pagination-bar ${o?``:`asset-pagination-bottom`}">
      ${o?`
        <div class="report-page-size">
          <label for="assetRowsPerPage">Rows per page</label>
          <select id="assetRowsPerPage" onchange="setAssetRowsPerPage(this.value)">
            ${[25,50,100,250].map(e=>`
              <option value="${e}" ${e===a?`selected`:``}>
                ${e}
              </option>
            `).join(``)}
          </select>
        </div>
      `:`<div></div>`}

      <div class="report-page-controls">
        <button type="button" onclick="changeAssetPage(-1)" ${r<=1?`disabled`:``}>
          Previous
        </button>
        ${s}
        <button type="button" onclick="changeAssetPage(1)" ${r>=i?`disabled`:``}>
          Next
        </button>
        <span>Showing ${e===0?0:t+1} to ${n} of ${e} assets - Page ${r} of ${i}</span>
      </div>
    </div>
  `}function ve(e,t){let n=[];if(t<=10){for(let e=1;e<=t;e+=1)n.push(e);return n}let r=Math.max(1,e-4),i=Math.min(t,r+9-1);i-r+1<9&&(r=Math.max(1,i-9+1)),r>1&&(n.push(1),r>2&&n.push(`...`));for(let e=r;e<=i;e+=1)n.push(e);return i<t&&(i<t-1&&n.push(`...`),n.push(t)),n}function ye(e,t){return ve(e,t).map(t=>t===`...`?`<span class="pagination-ellipsis">...</span>`:`
      <button
        type="button"
        class="pagination-page-btn ${t===e?`active`:``}"
        onclick="goToAssetPage(${t})"
        ${t===e?`disabled`:``}
      >
        ${t}
      </button>
    `).join(``)}function be(e){return[`100`,`400`,`500`].includes(String(e.equipgroupid||``))?!0:(window.atecCriteria||[]).some(t=>String(t.equiptypeid)===String(e.equiptypeid)&&String(t.inspectioncategory||t.inspection_category||``).toUpperCase()===`LOADTEST`&&t.active!==!1&&t.active!==`false`)}function xe(e,t,n,r,i=25){let a=window[r]||i,o=Number(t.total||0),s=Math.max(1,Math.ceil(o/a)),c=Math.min(window[n]||1,s),l=(c-1)*a,u=o===0?0:l+e.length;return window[n]=c,window[r]=a,{currentPage:c,endIndex:u,pageSize:a,rows:e,startIndex:l,totalPages:s,totalRows:o}}function Se(e,r={}){let o=r.serverPaged===!0,s=o?e:t(e,`inspectionAssets`,{client_section_serial:e=>`${e.clientname||``}\u0000${e.sectionname||``}\u0000${e.serialno||``}`,assetid:e=>e.assetid,assettagno:e=>e.assettagno,serialno:e=>e.serialno,clientname:e=>e.clientname,sitename:e=>e.sitename,sectionname:e=>e.sectionname,description:e=>e.description,equipmenttype:e=>e.equipmenttype},`client_section_serial`),l=o?xe(s,r,`inspectionCurrentPage`,`inspectionRowsPerPage`):i(s,`inspectionCurrentPage`,`inspectionRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h1>Inspections/Load Tests</h1>

    <div class="filter-card">
      <label><strong><h2>Search Assets</h2></strong></label>

      <div class="form-row">
        <div class="form-group">
          <label>Search By</label>

          <select id="inspectionSearchType" onchange="filterInspectionAssets(true)">
            <option value="all">All Fields</option>
            <option value="assetid">Asset ID</option>
            <option value="assettagno">Asset Tag</option>
            <option value="serialno">Serial No</option>
            <option value="clientname">Client</option>
            <option value="sitename">Site</option>
            <option value="sectionname">Section</option>
            <option value="description">Description</option>
            <option value="equipmenttype">Equipment Type</option>
          </select>
        </div>

        <div class="form-group">
          <label>Search Text</label>

          <input
            id="inspectionAssetSearch"
            class="search-box"
            type="text"
            placeholder="Type search text..."
            onkeyup="filterInspectionAssets(true)"
          />
        </div>
      </div>

      <div class="filter-key-row">
        ${[[`all`,`All`],[`assetid`,`Asset ID`],[`assettagno`,`Asset Tag`],[`serialno`,`Serial No`],[`clientname`,`Client`],[`sitename`,`Site`],[`sectionname`,`Section`],[`equipmenttype`,`Equipment Type`],[`description`,`Description`]].map(([e,t])=>`
          <button type="button" class="filter-key-btn" onclick="setInspectionFilterKey('${e}')">
            ${t}
          </button>
        `).join(``)}
      </div>
    </div>

    ${a({...l,label:`assets`,onPage:`goToInspectionPage`,onPageSize:`setInspectionRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${n(`Asset ID`,`inspectionAssets`,`assetid`,`showInspections`)}</th>
          <th>${n(`Asset Tag`,`inspectionAssets`,`assettagno`,`showInspections`)}</th>
          <th>${n(`Serial No`,`inspectionAssets`,`serialno`,`showInspections`)}</th>
          <th>${n(`Client`,`inspectionAssets`,`clientname`,`showInspections`)}</th>
          <th>${n(`Site`,`inspectionAssets`,`sitename`,`showInspections`)}</th>
          <th>${n(`Section`,`inspectionAssets`,`sectionname`,`showInspections`)}</th>
          <th>${n(`Description`,`inspectionAssets`,`description`,`showInspections`)}</th>
          <th>${n(`Equipment Type`,`inspectionAssets`,`equipmenttype`,`showInspections`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody id="inspectionAssetTableBody">
        ${l.rows.map(e=>`
          <tr>
            <td>${c(e.assetid)}</td>
            <td>${c(e.assettagno||``)}</td>
            <td>${c(e.serialno||``)}</td>
            <td>${c(e.clientname||``)}</td>
            <td>${c(e.sitename||``)}</td>
            <td>${c(e.sectionname||``)}</td>
            <td>${c(e.description||``)}</td>
            <td>${c(e.equipmenttype||``)}</td>
            <td>
  <div class="action-buttons">

    ${de(e,window.atecCriteria||[],`VISUAL`)?`
      <button class="load-test-btn" onclick="startInspection(${e.assetid}, 'VISUAL', 'inspections', 'wizard')">
        ${fe(e,window.atecCriteria||[],`VISUAL`)}
      </button>
    `:`
      <button onclick="startInspection(${e.assetid}, 'VISUAL', 'inspections')">
        Inspection
      </button>
    `}

        ${be(e)?`
            <button
              class="load-test-btn"
              onclick="startInspection(${e.assetid}, 'LOADTEST', 'inspections', '${ue(e)?`wizard`:`auto`}')">
              ${fe(e,window.atecCriteria||[],`LOADTEST`)}
            </button>
          `:``}

      </div>
    </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>

    <br>

    <div id="inspectionFormContainer"></div>
  `}function Ce(e,r){let o=[...e].sort((e,t)=>(e.description||``).localeCompare(t.description||``)),s=window.criteriaEquipmentFilter||``,u=i(t(s?r.filter(e=>String(e.equiptypeid)===String(s)):r,`criteria`,{equipmenttype:e=>e.equipmenttype,inspectioncategory:e=>e.inspectioncategory,inspection_category:e=>e.inspection_category,severity:e=>e.severity,criterianame:e=>e.criterianame,resulttype:e=>e.resulttype,active:e=>e.active?`Active`:`Inactive`},`equipmenttype`),`criteriaCurrentPage`,`criteriaRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h1>Equipment Type Criteria Setup</h1>

    <div class="filter-card">
      <div class="form-row">
        <div class="form-group">
          <label>Show Criteria For</label>
          <select id="criteriaEquipmentFilter" onchange="filterEquipmentCriteria()">
            <option value="">All Equipment Types</option>
            ${o.map(e=>`
              <option
                value="${l(e.equiptypeid)}"
                ${String(e.equiptypeid)===String(s)?`selected`:``}
              >
                ${c(e.description)}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="form-group criteria-action-group">
          <button type="button" onclick="openCriteriaPopup()">
            Add Criteria
          </button>
        </div>
      </div>
    </div>

    ${a({...u,label:`criteria`,onPage:`goToCriteriaPage`,onPageSize:`setCriteriaRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${n(`Equipment Type`,`criteria`,`equipmenttype`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Type`,`criteria`,`inspectioncategory`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Category`,`criteria`,`inspection_category`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Severity`,`criteria`,`severity`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Criteria`,`criteria`,`criterianame`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Result Type`,`criteria`,`resulttype`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Status`,`criteria`,`active`,`showEquipmentTypeCriteria`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody>
        ${u.rows.map(e=>`
          <tr>
            <td>${c(e.equipmenttype||``)}</td>
            <td>${c(e.inspectioncategory||``)}</td>
            <td>${c(we(e.inspection_category))}</td>
            <td>${c(we(e.severity))}</td>
            <td>${c(e.criteriadescription||e.criterianame||``)}</td>
            <td>${c(we(e.resulttype||e.fieldtype))}</td>
            <td>${e.active===!1?`Inactive`:`Active`}</td>
            <td class="criteria-row-actions">
              <button type="button" onclick="editCriteria(${e.criteriaid})">
                Edit
              </button>
              <button type="button" onclick="deleteCriteria(${e.criteriaid})">
                Delete
              </button>
            </td>
          </tr>
        `).join(``)||`
          <tr>
            <td colspan="8">No criteria found for the selected equipment type.</td>
          </tr>
        `}
      </tbody>
    </table>
  `}function we(e){return String(e||``).replaceAll(`_`,` `).toLowerCase().replace(/\b\w/g,e=>e.toUpperCase())}function Te(){document.querySelector(`#page`).innerHTML=`
    <h2>Quick Inspection/Test</h2>

    <div class="filter-card">
      <h3>Scan / Search Asset</h3>

      <label>QR Code, Asset ID, Serial No, Hoist Serial No or Asset Tag</label>

      <input
        id="quickAssetSearch"
        class="quick-scan-box"
        type="text"
        placeholder="Scan or type here..."
        autofocus
        onkeydown="handleQuickInspectionEnter(event)"
      >

      <div class="quick-scan-actions">
        <button onclick="quickFindAsset()">
          Find Asset
        </button>

        <button type="button" class="qr-scan-btn" onclick="startQuickCameraScan()">
          Scan With Camera
        </button>
      </div>

      <div id="quickCameraScanner" class="quick-camera-scanner" hidden>
        <video id="quickCameraVideo" playsinline></video>
        <div class="quick-scan-actions">
          <button type="button" onclick="stopQuickCameraScan()">Stop Scan</button>
        </div>
        <p id="quickScanStatus">Point the camera at the ATEC QR label.</p>
      </div>
    </div>

    <div id="quickInspectionResult"></div>
  `}var y=`https://www.atecinspections.co.za/api`.replace(/\/$/,``);function Ee(e=``){return e?/^https?:\/\//i.test(e)?e.replace(/^http:\/\/localhost:5000/i,y):`${y}${e.startsWith(`/`)?e:`/${e}`}`:y}function De(e=``){return`/${String(e||``).replace(/^\/+/,``)}`}function b(e=``){if(!e)return``;let t=String(e).trim();if(/^https?:\/\//i.test(t))return Ee(t);t.startsWith(`/`)||(t=t.startsWith(`uploads/`)?`/${t}`:t.startsWith(`assets/`)?`/uploads/${t}`:`/uploads/assets/${t}`);let n=encodeURI(t);return t.startsWith(`/uploads/`)?`${window.location.origin}${n}`:Ee(n)}async function x(e){let t=await e.text();if(!t)return{};try{return JSON.parse(t)}catch{return{error:e.ok?`The server returned an unexpected certificate response.`:`The server returned an unexpected error while loading the certificate.`}}}async function Oe(e){let t=await e.text();return e.ok?{html:t,error:``}:{html:``,error:t||`The server returned an unexpected error while loading the certificate.`}}function ke(e){return`${y}/inspections/${encodeURIComponent(e)}/certificate.html?t=${Date.now()}`}function Ae(e=[],t=[],n=[]){e=e.filter(e=>e.archived!==!0&&e.archived!==`true`),t=t.filter(e=>e.archived!==!0&&e.archived!==`true`),n=n.filter(e=>e.archived!==!0&&e.archived!==`true`),document.querySelector(`#page`).innerHTML=`
    <h1>Certificates</h1>
    <p>Search, view and manage inspection and load test certificates.</p>

    <div class="filter-card">
      <h2>Search Certificates</h2>

      <div class="asset-form-grid">
        <div class="form-group">
          <label>Broad Search</label>
          <input
            id="certSearch"
            type="text"
            placeholder="Test ID, tag, serial, client, site, asset description..."
          >
        </div>

        <div class="form-group">
          <label>Inspection Type</label>
          <select id="certInspectionType">
            <option value="">All Types</option>
            <option value="VISUAL">Visual Inspection</option>
            <option value="LOADTEST">Load Test</option>
          </select>
        </div>

        <div class="form-group">
          <label>Status</label>
          <select id="certStatus">
            <option value="">All Statuses</option>
            <option value="SAFE">SAFE</option>
            <option value="NOT SAFE">NOT SAFE</option>
          </select>
        </div>

        <div class="form-group">
          <label>Client</label>
          <select id="certClient">
            <option value="">All Clients</option>
            ${e.map(e=>`
              <option value="${l(e.clientid)}">${c(e.clientname)}</option>
            `).join(``)}
          </select>
        </div>

        <div class="form-group">
          <label>Site</label>
          <select id="certSite">
            <option value="">All Sites</option>
          </select>
        </div>

        <div class="form-group">
          <label>Section</label>
          <select id="certSection">
            <option value="">All Sections</option>
          </select>
        </div>

        <div class="form-group">
          <label>Date From</label>
          <input id="certDateFrom" type="date">
        </div>

        <div class="form-group">
          <label>Date To</label>
          <input id="certDateTo" type="date">
        </div>
      </div>

      <div class="form-actions">
        <button id="certSearchBtn">Search</button>
        <button id="certClearBtn">Clear Filters</button>
      </div>
    </div>

    <div class="filter-card bulk-certificate-card">
      <h2>Bulk Print Certificates</h2>
      <p>Select a date range, then choose the certificates to print together. Customer is optional.</p>

      <div class="asset-form-grid">
        <div class="form-group">
          <label>Customer</label>
          <select id="bulkCertClient">
            <option value="">All Customers</option>
            ${e.map(e=>`
              <option value="${l(e.clientid)}">${c(e.clientname)}</option>
            `).join(``)}
          </select>
        </div>

        <div class="form-group">
          <label>Date From</label>
          <input id="bulkCertDateFrom" type="date">
        </div>

        <div class="form-group">
          <label>Date To</label>
          <input id="bulkCertDateTo" type="date">
        </div>

        <div class="form-group">
          <label>Site</label>
          <select id="bulkCertSite">
            <option value="">All Sites</option>
          </select>
        </div>

        <div class="form-group">
          <label>Inspection Type</label>
          <select id="bulkCertInspectionType">
            <option value="ALL">All Types</option>
            <option value="VISUAL">Visual Inspection</option>
            <option value="LOADTEST">Load Test</option>
          </select>
        </div>

        <div class="form-group">
          <label>Status</label>
          <select id="bulkCertStatus">
            <option value="ALL">All Statuses</option>
            <option value="SAFE">SAFE</option>
            <option value="NOT SAFE">NOT SAFE</option>
          </select>
        </div>
      </div>

      <div class="form-actions">
        <button id="bulkCertSearchBtn" type="button">Load Certificates</button>
        <button id="bulkCertPrintBtn" type="button" disabled>Print Selected Certificates</button>
        <button id="bulkCertDownloadSelectedBtn" type="button" disabled>Download Selected as PDF</button>
        <button id="bulkCertDownloadAllBtn" type="button" disabled>Download All Results as PDF</button>
      </div>

      <div id="bulkCertificateResults" class="bulk-certificate-results">
        <p>No bulk search loaded yet.</p>
      </div>
    </div>

    <div class="certificate-dashboard-grid">
      <div class="filter-card">
        <h2>Search Results</h2>
        <div id="certificateResults">
          <p>Loading certificates...</p>
        </div>
      </div>

      <div>
        <div class="filter-card">
          <h2>Quick Stats</h2>
          <div id="certificateStats">
            <p>No search loaded yet.</p>
          </div>
        </div>

        <div class="filter-card" id="certificatePreviewPanel">
          <h2>Certificate Preview</h2>
          <p>Select Preview on a certificate to view quick details here.</p>
        </div>
      </div>
    </div>

    ${window.currentUser?.role===`ADMIN`?`
      <div class="filter-card voided-certificates-card">
        <div class="voided-certificates-heading">
          <div>
            <h2>Voided Certificates</h2>
            <p>Certificates removed as entered in error. These records are retained for audit purposes.</p>
          </div>
          <button id="refreshVoidedCertificatesBtn" type="button">Refresh</button>
        </div>
        <div id="voidedCertificateResults"><p>Loading voided certificates...</p></div>
      </div>
    `:``}
  `,window.certificateCustomers=e,window.certificateSites=t,window.certificateSections=n,Me(),document.querySelector(`#certSearch`).addEventListener(`keydown`,e=>{e.key===`Enter`&&window.searchCertificates()}),document.querySelector(`#certClient`).addEventListener(`change`,window.filterCertificateSites),document.querySelector(`#certSite`).addEventListener(`change`,window.filterCertificateSections),document.querySelector(`#certSearchBtn`).addEventListener(`click`,window.searchCertificates),document.querySelector(`#certClearBtn`).addEventListener(`click`,window.clearCertificateSearch),document.querySelector(`#bulkCertClient`).addEventListener(`change`,window.filterBulkCertificateSites),document.querySelector(`#bulkCertSearchBtn`).addEventListener(`click`,window.searchBulkCertificates),document.querySelector(`#bulkCertPrintBtn`).addEventListener(`click`,window.printSelectedBulkCertificates),document.querySelector(`#bulkCertDownloadSelectedBtn`).addEventListener(`click`,window.downloadSelectedBulkCertificatesPdf),document.querySelector(`#bulkCertDownloadAllBtn`).addEventListener(`click`,window.downloadAllBulkCertificatesPdf),document.querySelector(`#refreshVoidedCertificatesBtn`)?.addEventListener(`click`,window.loadVoidedCertificates),window.filterBulkCertificateSites(),window.searchCertificates(),window.currentUser?.role===`ADMIN`&&window.loadVoidedCertificates()}window.loadVoidedCertificates=async function(){let e=document.querySelector(`#voidedCertificateResults`);if(!e||window.currentUser?.role!==`ADMIN`)return;e.innerHTML=`<p>Loading voided certificates...</p>`;let t=await fetch(`${y}/certificates/voided`),n=await x(t);if(!t.ok){e.innerHTML=`<p>${c(n.error||`Unable to load voided certificates.`)}</p>`;return}if(!n.length){e.innerHTML=`<p>No certificates have been voided.</p>`;return}e.innerHTML=`
    <div class="voided-bulk-actions">
      <button type="button" id="restoreSelectedVoidedBtn" disabled>Restore Selected</button>
      <button type="button" id="deleteSelectedVoidedBtn" class="danger-btn" disabled>Permanently Delete Selected</button>
      <span id="voidedSelectionCount">0 selected</span>
    </div>
    <div class="table-scroll">
      <table class="voided-certificates-table">
        <thead><tr>
          <th><input type="checkbox" id="selectAllVoidedCertificates" aria-label="Select all voided certificates"></th>
          <th>Test ID</th><th>Client</th><th>Asset</th><th>Serial No</th><th>Type</th>
          <th>Inspection Date</th><th>Removed By</th><th>Removed At</th><th>Reason</th><th>Action</th>
        </tr></thead>
        <tbody>${n.map(e=>`
          <tr>
            <td><input type="checkbox" class="voided-certificate-checkbox" value="${l(e.testid)}" aria-label="Select certificate ${l(e.testid)}"></td>
            <td>${c(e.testid)}</td>
            <td>${c(e.clientname||`-`)}</td>
            <td>${c(e.description||e.assettagno||`-`)}</td>
            <td>${c(e.serialno||`-`)}</td>
            <td>${c(e.inspectiontype||`-`)}</td>
            <td>${c(He(e.testdate))}</td>
            <td>${c(e.voided_by||`-`)}</td>
            <td>${c(e.voided_at||`-`)}</td>
            <td class="void-reason-cell">${c(e.void_reason||`-`)}</td>
            <td class="voided-row-actions">
              <button type="button" class="restore-certificate-btn" data-testid="${l(e.testid)}">Restore</button>
              <button type="button" class="permanent-delete-certificate-btn" data-testid="${l(e.testid)}">Delete</button>
            </td>
          </tr>`).join(``)}</tbody>
      </table>
    </div>`,e.querySelectorAll(`.restore-certificate-btn`).forEach(e=>{e.addEventListener(`click`,()=>window.restoreCertificate(e.dataset.testid))}),e.querySelectorAll(`.permanent-delete-certificate-btn`).forEach(e=>{e.addEventListener(`click`,()=>window.permanentlyDeleteCertificate(e.dataset.testid))}),e.querySelectorAll(`.voided-certificate-checkbox`).forEach(e=>{e.addEventListener(`change`,window.updateVoidedSelection)}),e.querySelector(`#selectAllVoidedCertificates`).addEventListener(`change`,t=>{e.querySelectorAll(`.voided-certificate-checkbox`).forEach(e=>{e.checked=t.target.checked}),window.updateVoidedSelection()}),e.querySelector(`#restoreSelectedVoidedBtn`).addEventListener(`click`,window.restoreSelectedVoidedCertificates),e.querySelector(`#deleteSelectedVoidedBtn`).addEventListener(`click`,window.deleteSelectedVoidedCertificates)};function je(){return[...document.querySelectorAll(`.voided-certificate-checkbox:checked`)].map(e=>e.value)}window.updateVoidedSelection=function(){let e=je(),t=[...document.querySelectorAll(`.voided-certificate-checkbox`)],n=document.querySelector(`#selectAllVoidedCertificates`);n&&(n.checked=t.length>0&&e.length===t.length,n.indeterminate=e.length>0&&e.length<t.length);let r=document.querySelector(`#voidedSelectionCount`);r&&(r.textContent=`${e.length} selected`);let i=document.querySelector(`#restoreSelectedVoidedBtn`),a=document.querySelector(`#deleteSelectedVoidedBtn`);i&&(i.disabled=e.length===0),a&&(a.disabled=e.length===0)},window.restoreCertificate=async function(e){if(!window.confirm(`Restore certificate ${e} to the active certificate list?`))return;let t=t=>fetch(`${y}/certificates/${encodeURIComponent(e)}/restore`,{method:`PATCH`,headers:{"Content-Type":`application/json`},body:JSON.stringify({force_restore:t})}),n=await t(!1),r=await x(n);if(n.status===409&&r.code===`RESTORE_DUPLICATE`){if(!window.confirm(`Active inspection ${r.existing_testid} already matches this record. Restore ${e} anyway?`))return;n=await t(!0),r=await x(n)}if(!n.ok){alert(r.error||`Unable to restore certificate ${e}.`);return}alert(`Certificate ${e} restored.`),await Promise.all([window.loadVoidedCertificates(),window.searchCertificates()])},window.permanentlyDeleteCertificate=async function(e){if(window.prompt(`Permanently delete certificate ${e}, including its results and photo records?\n\nThis cannot be undone. Type DELETE to continue.`)!==`DELETE`)return;let t=await fetch(`${y}/certificates/${encodeURIComponent(e)}/permanent`,{method:`DELETE`}),n=await x(t);if(!t.ok)return alert(n.error||`Unable to permanently delete certificate ${e}.`);alert(`Certificate ${e} permanently deleted.`),await window.loadVoidedCertificates()},window.restoreSelectedVoidedCertificates=async function(){let e=je();if(!e.length||!window.confirm(`Restore ${e.length} selected certificate${e.length===1?``:`s`}?`))return;let t=t=>fetch(`${y}/certificates/voided/bulk-restore`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({testids:e,force_restore:t})}),n=await t(!1),r=await x(n);if(n.status===409&&r.code===`RESTORE_DUPLICATES`){if(!window.confirm(`${r.conflicts?.length||`Some`} selected certificate(s) match active inspections. Restore them anyway?`))return;n=await t(!0),r=await x(n)}if(!n.ok)return alert(r.error||`Unable to restore the selected certificates.`);alert(`${r.restored?.length||0} certificate(s) restored.`),await Promise.all([window.loadVoidedCertificates(),window.searchCertificates()])},window.deleteSelectedVoidedCertificates=async function(){let e=je();if(!e.length||window.prompt(`Permanently delete ${e.length} selected certificate${e.length===1?``:`s`}, including results and photo records?\n\nThis cannot be undone. Type DELETE ${e.length} to continue.`)!==`DELETE ${e.length}`)return;let t=await fetch(`${y}/certificates/voided/bulk-delete`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({testids:e})}),n=await x(t);if(!t.ok)return alert(n.error||`Unable to permanently delete the selected certificates.`);alert(`${n.deleted?.length||0} certificate(s) permanently deleted.`),await window.loadVoidedCertificates()};function Me(){Object.assign(window,Ue)}window.filterCertificateSites=function(){let e=document.querySelector(`#certClient`).value,t=document.querySelector(`#certSite`),n=document.querySelector(`#certSection`);n.innerHTML=`<option value="">All Sections</option>`,t.innerHTML=`
    <option value="">All Sites</option>
    ${(e?window.certificateSites.filter(t=>String(t.clientid)===String(e)):window.certificateSites).map(e=>`
      <option value="${l(e.siteid)}">${c(e.sitename)}</option>
    `).join(``)}
  `},window.filterCertificateSections=function(){let e=document.querySelector(`#certSite`).value,t=document.querySelector(`#certSection`);t.innerHTML=`
    <option value="">All Sections</option>
    ${(e?window.certificateSections.filter(t=>String(t.siteid)===String(e)):window.certificateSections).map(e=>`
      <option value="${l(e.sectionid)}">${c(e.sectionname)}</option>
    `).join(``)}
  `},window.filterBulkCertificateSites=function(){let e=document.querySelector(`#bulkCertClient`).value,t=document.querySelector(`#bulkCertSite`);t.innerHTML=`
    <option value="">All Sites</option>
    ${(e?window.certificateSites.filter(t=>String(t.clientid)===String(e)):window.certificateSites).map(e=>`
      <option value="${l(e.siteid)}">${c(e.sitename)}</option>
    `).join(``)}
  `},window.clearCertificateSearch=function(){document.querySelector(`#certSearch`).value=``,document.querySelector(`#certInspectionType`).value=``,document.querySelector(`#certStatus`).value=``,document.querySelector(`#certClient`).value=``,document.querySelector(`#certSite`).innerHTML=`<option value="">All Sites</option>`,document.querySelector(`#certSection`).innerHTML=`<option value="">All Sections</option>`,document.querySelector(`#certDateFrom`).value=``,document.querySelector(`#certDateTo`).value=``,window.certCurrentPage=1,window.searchCertificates()},window.searchCertificates=async function(t=!0){t&&(window.certCurrentPage=1);let n=new URLSearchParams;n.append(`search`,document.querySelector(`#certSearch`)?.value||``),n.append(`inspectiontype`,document.querySelector(`#certInspectionType`)?.value||``),n.append(`status`,document.querySelector(`#certStatus`)?.value||``),n.append(`clientid`,document.querySelector(`#certClient`)?.value||``),n.append(`siteid`,document.querySelector(`#certSite`)?.value||``),n.append(`sectionid`,document.querySelector(`#certSection`)?.value||``),n.append(`datefrom`,document.querySelector(`#certDateFrom`)?.value||``),n.append(`dateto`,document.querySelector(`#certDateTo`)?.value||``),n.append(`page`,String(window.certCurrentPage||1)),n.append(`limit`,String(window.certRowsPerPage||25));let r=e(`certificates`,`testid`,`desc`);n.append(`sortKey`,r.key||`testid`),n.append(`sortDir`,r.direction||`desc`);let i=await fetch(`${y}/certificates/search?${n.toString()}`),a=await i.json();if(!i.ok){alert(`Error searching certificates: `+a.error);return}let o=Array.isArray(a)?a:a.rows||[];window.currentCertificateResults=o,window.currentCertificatePageInfo=Array.isArray(a)?null:{currentPage:Number(a.page||1),pageSize:Number(a.limit||window.certRowsPerPage||25),totalRows:Number(a.total||o.length),totalPages:Number(a.totalPages||1),startIndex:(Number(a.page||1)-1)*Number(a.limit||window.certRowsPerPage||25),endIndex:(Number(a.page||1)-1)*Number(a.limit||window.certRowsPerPage||25)+o.length},Ne(o,a.summary),Pe(o)};function Ne(e,t=null){let n=t?t.safe:e.filter(e=>e.status===`SAFE`).length,r=t?t.notSafe:e.filter(e=>e.status===`NOT SAFE`).length,i=t?t.loadTest:e.filter(e=>e.inspectiontype===`LOADTEST`).length,a=t?t.visual:e.filter(e=>e.inspectiontype===`VISUAL`).length,o=t?Number(t.total||window.currentCertificatePageInfo?.totalRows||e.length):e.length;document.querySelector(`#certificateStats`).innerHTML=`
    <p><strong>Total:</strong> ${o||window.currentCertificatePageInfo?.totalRows||e.length}</p>
    <p><strong>Safe:</strong> ${n}</p>
    <p><strong>Not Safe:</strong> ${r}</p>
    <p><strong>Visual:</strong> ${a}</p>
    <p><strong>Load Tests:</strong> ${i}</p>
  `}function S(t,n){let r=e(`certificates`,`testid`,`desc`),i=r.key===n,a=i?r.direction===`desc`?`v`:`^`:`^v`;return`
    <span class="certificate-sort-heading">
      <span>${t}</span>
      <button
        type="button"
        class="certificate-sort-btn ${i?`active`:``}"
        onclick="sortTable('certificates', '${n}', 'rerenderCertificateResults')"
        aria-label="Sort ${t}"
        title="Sort ${t}"
      >${a}</button>
    </span>
  `}function Pe(e){if(e.length===0){document.querySelector(`#certificateResults`).innerHTML=`<p>No certificates found.</p>`;return}let n=window.currentUser?.role===`ADMIN`,r=window.currentCertificatePageInfo?e:t(e,`certificates`,{testid:e=>e.testid,tagnumber:e=>e.tagnumber,clientname:e=>e.clientname,sitename:e=>e.sitename,description:e=>e.description,serialno:e=>e.serialno,inspectiontype:e=>e.inspectiontype,testdate:e=>e.testdate,status:e=>e.status,inspector:e=>e.inspector},`testid`,`desc`),o=window.currentCertificatePageInfo?{...window.currentCertificatePageInfo,rows:r}:i(r,`certCurrentPage`,`certRowsPerPage`);document.querySelector(`#certificateResults`).innerHTML=`
    ${a({...o,label:`certificates`,onPage:`goToCertificatePage`,onPageSize:`setCertificateRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${S(`Test ID`,`testid`)}</th>
          <th>${S(`Tag No`,`tagnumber`)}</th>
          <th>${S(`Client`,`clientname`)}</th>
          <th>${S(`Site`,`sitename`)}</th>
          <th>${S(`Asset`,`description`)}</th>
          <th>${S(`Serial No`,`serialno`)}</th>
          <th>${S(`Type`,`inspectiontype`)}</th>
          <th>${S(`Date`,`testdate`)}</th>
          <th>${S(`Status`,`status`)}</th>
          <th>${S(`Inspector`,`inspector`)}</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody>
        ${o.rows.map(e=>{let t=l(e.testid),r=c(e.status||``);return`
          <tr data-testid="${t}">
            <td>${c(e.testid)}</td>
            <td>${c(e.tagnumber||`-`)}</td>
            <td>${c(e.clientname||``)}</td>
            <td>${c(e.sitename||``)}</td>
            <td>${c(e.description||``)}</td>
            <td>${c(e.serialno||``)}</td>
            <td>${c(e.inspectiontype||``)}</td>
            <td>${c(He(e.testdate))}</td>
            <td>
              <strong class="${e.status===`SAFE`?`status-safe`:`status-unsafe`}">
                ${r}
              </strong>
            </td>
            <td>${c(e.inspector||`-`)}</td>
            <td>
              <button type="button" class="cert-preview-btn" data-testid="${t}">
                Preview
              </button>

              <button type="button" class="cert-view-btn" data-testid="${t}">
                View
              </button>

              <a
                class="cert-action-link cert-download-btn"
                href="${y}/inspections/${encodeURIComponent(e.testid)}/certificate.pdf?t=${Date.now()}"
                download="certificate-${t}.pdf"
                onclick="event.stopPropagation()"
              >
                Download PDF
              </a>

              <button type="button" class="cert-mail-btn" data-testid="${t}">
                Mail
              </button>

              ${n?`
                <button
                  type="button"
                  class="cert-delete-btn"
                  data-testid="${t}"
                  title="Remove this mistaken certificate from normal lists and retain it in the audit history"
                >
                  Remove Error
                </button>
              `:``}
            </td>
          </tr>
        `}).join(``)}
      </tbody>
    </table>
  `,Ve()}window.searchBulkCertificates=async function(){let e=document.querySelector(`#bulkCertClient`).value,t=document.querySelector(`#bulkCertDateFrom`).value,n=document.querySelector(`#bulkCertDateTo`).value,r=document.querySelector(`#bulkCertSite`).value,i=document.querySelector(`#bulkCertInspectionType`).value,a=document.querySelector(`#bulkCertStatus`).value;if(!t||!n){alert(`Please select Date From and Date To for bulk printing.`);return}let o=new URLSearchParams({datefrom:t,dateto:n});e&&o.set(`clientid`,e),r&&o.set(`siteid`,r),i&&i!==`ALL`&&o.set(`inspectiontype`,i),a&&a!==`ALL`&&o.set(`status`,a);let s=document.querySelector(`#bulkCertificateResults`),c=document.querySelector(`#bulkCertPrintBtn`),l=document.querySelector(`#bulkCertDownloadSelectedBtn`),u=document.querySelector(`#bulkCertDownloadAllBtn`);s.innerHTML=`<p>Loading matching certificates...</p>`,c.disabled=!0,l.disabled=!0,u.disabled=!0;let d=await fetch(`${y}/certificates/bulk-print?${o.toString()}`),f=await d.json();if(!d.ok){s.innerHTML=`<p>No bulk search loaded yet.</p>`,alert(`Error loading bulk certificates: `+(f.error||`Unable to load certificates`));return}window.bulkCertificateResults=f.certificates||[],window.bulkCertificateBlockedCount=Number(f.blockedCount||0),window.bulkCertificateTotalMatched=Number(f.totalMatched||window.bulkCertificateResults.length),Fe(window.bulkCertificateResults,{blockedCount:window.bulkCertificateBlockedCount,totalMatched:window.bulkCertificateTotalMatched})};function Fe(e,t={}){let n=document.querySelector(`#bulkCertificateResults`),r=document.querySelector(`#bulkCertPrintBtn`),i=document.querySelector(`#bulkCertDownloadSelectedBtn`),a=document.querySelector(`#bulkCertDownloadAllBtn`),o=Number(t.blockedCount||0),s=Number(t.totalMatched||e.length);if(!e.length){n.innerHTML=o?`<p>${c(s)} matching inspection${s===1?``:`s`} found, but none can produce certificates yet.</p>`:`<p>No certificates found for the selected customer and date range.</p>`,r.disabled=!0,i.disabled=!0,a.disabled=!0;return}let u=o?`<span>${c(o)} matching inspection${o===1?``:`s`} skipped because ${o===1?`it cannot`:`they cannot`} produce certificates yet.</span>`:``;n.innerHTML=`
    <div class="bulk-certificate-summary">
      <strong>${e.length}</strong> downloadable certificate${e.length===1?``:`s`} found.
      ${u}
    </div>

    <div class="table-scroll bulk-certificate-table-wrap">
      <table class="bulk-certificate-table">
        <thead>
          <tr>
            <th>
              <input
                type="checkbox"
                id="bulkCertSelectAll"
                checked
                aria-label="Select all certificates"
              >
            </th>
            <th>Certificate No</th>
            <th>Date</th>
            <th>Valid Date</th>
            <th>Type</th>
            <th>Status</th>
            <th>Asset</th>
            <th>Asset Tag</th>
            <th>Serial No</th>
            <th>Site</th>
            <th>Inspector</th>
          </tr>
        </thead>

        <tbody>
          ${e.map(e=>{let t=e.inspection||{};return`
              <tr>
                <td>
                  <input
                    type="checkbox"
                    class="bulk-cert-check"
                    value="${l(t.testid)}"
                    checked
                    aria-label="Select certificate ${l(t.testid)}"
                  >
                </td>
                <td>${c(t.testid||``)}</td>
                <td>${c(He(t.testdate))}</td>
                <td>${c(He(t.validdate))}</td>
                <td>${c(t.inspectiontype||``)}</td>
                <td>
                  <strong class="${t.status===`SAFE`?`status-safe`:`status-unsafe`}">
                    ${c(t.status||``)}
                  </strong>
                </td>
                <td>${c(t.description||``)}</td>
                <td>${c(t.assettagno||t.tagnumber||`-`)}</td>
                <td>${c(t.serialno||``)}</td>
                <td>${c(t.sitename||``)}</td>
                <td>${c(t.inspector||`-`)}</td>
              </tr>
            `}).join(``)}
        </tbody>
      </table>
    </div>
  `,document.querySelector(`#bulkCertSelectAll`).addEventListener(`change`,e=>{document.querySelectorAll(`.bulk-cert-check`).forEach(t=>{t.checked=e.target.checked}),Ie()}),document.querySelectorAll(`.bulk-cert-check`).forEach(e=>{e.addEventListener(`change`,Ie)}),Ie(),a.disabled=!1}function Ie(){let e=document.querySelectorAll(`.bulk-cert-check:checked`).length,t=document.querySelector(`#bulkCertPrintBtn`),n=document.querySelector(`#bulkCertDownloadSelectedBtn`),r=document.querySelector(`#bulkCertSelectAll`);if(t&&(t.disabled=e===0,t.textContent=e?`Print Selected Certificates (${e})`:`Print Selected Certificates`),n&&(n.disabled=e===0,n.textContent=e?`Download Selected as PDF (${e})`:`Download Selected as PDF`),r){let t=document.querySelectorAll(`.bulk-cert-check`).length;r.checked=e>0&&e===t,r.indeterminate=e>0&&e<t}}window.printSelectedBulkCertificates=function(){let e=Array.from(document.querySelectorAll(`.bulk-cert-check:checked`)).map(e=>String(e.value));if(!e.length){alert(`Select at least one certificate to print.`);return}let t=Le();t&&(t.set(`testids`,e.join(`,`)),t.set(`inline`,`1`),window.open(`${y}/certificates/bulk-pdf?${t.toString()}`,`_blank`))};function Le(){let e=document.querySelector(`#bulkCertClient`).value,t=document.querySelector(`#bulkCertDateFrom`).value,n=document.querySelector(`#bulkCertDateTo`).value,r=document.querySelector(`#bulkCertSite`).value,i=document.querySelector(`#bulkCertInspectionType`).value,a=document.querySelector(`#bulkCertStatus`).value;if(!t||!n)return alert(`Please select Date From and Date To before downloading PDFs.`),null;let o=new URLSearchParams({datefrom:t,dateto:n});return e&&o.set(`clientid`,e),r&&o.set(`siteid`,r),i&&i!==`ALL`&&o.set(`inspectiontype`,i),a&&a!==`ALL`&&o.set(`status`,a),o}function Re(){return Array.from(document.querySelectorAll(`.bulk-cert-check:checked`)).map(e=>String(e.value))}window.downloadSelectedBulkCertificatesPdf=async function(){let e=Re();if(!e.length){alert(`Select at least one certificate to download.`);return}let t=Le();t&&(t.set(`testids`,e.join(`,`)),await ze(t))},window.downloadAllBulkCertificatesPdf=async function(){let e=(window.bulkCertificateResults||[]).map(e=>e?.inspection?.testid).filter(Boolean).map(e=>String(e));if(!e.length){alert(`No certificates found to download. Load certificates first.`);return}let t=Le();t&&(t.set(`testids`,e.join(`,`)),await ze(t))};async function ze(e){let t=await fetch(`${y}/certificates/bulk-pdf?${e.toString()}`);if(!t.ok){let e=await t.json().catch(()=>({error:`Unable to download bulk certificates`})),n=Array.isArray(e.blocked)&&e.blocked.length?`\n\nFirst blocked certificate: ${e.blocked[0].testid||`Unknown`}`:``;alert((e.error||`Unable to download bulk certificates`)+n);return}let n=await t.blob(),r=Be(t.headers.get(`content-disposition`),`FB-Certificates.pdf`),i=window.URL.createObjectURL(n),a=document.createElement(`a`);a.href=i,a.download=r,document.body.appendChild(a),a.click(),a.remove(),window.URL.revokeObjectURL(i)}function Be(e,t){let n=String(e||``).match(/filename="?([^"]+)"?/i);return n?n[1]:t}window.setCertificateRowsPerPage=function(e){window.certRowsPerPage=Number(e)||25,window.certCurrentPage=1,window.searchCertificates(!1)},window.rerenderCertificateResults=function(){window.certCurrentPage=1,window.searchCertificates(!1)},window.goToCertificatePage=function(e){window.certCurrentPage=Math.max(1,Number(e)||1),window.searchCertificates(!1)};function Ve(){document.querySelectorAll(`#certificateResults tbody tr`).forEach(e=>{e.addEventListener(`click`,()=>{window.selectCertificateRow(e,e.dataset.testid)})}),document.querySelectorAll(`.cert-preview-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation(),window.previewCertificate(e.dataset.testid)})}),document.querySelectorAll(`.cert-view-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation(),window.openCertificateModal(e.dataset.testid)})}),document.querySelectorAll(`.cert-mail-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation(),window.mailCertificate(e.dataset.testid)})}),document.querySelectorAll(`.cert-delete-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation(),window.deleteCertificate(e.dataset.testid)})})}window.selectCertificateRow=function(e,t){document.querySelectorAll(`#certificateResults tbody tr`).forEach(e=>e.classList.remove(`selected-certificate-row`)),e.classList.add(`selected-certificate-row`),window.previewCertificate(t)},window.previewCertificate=async function(e){let t=document.querySelector(`#certificatePreviewPanel`);if(!t)return;t.innerHTML=`
    <h2>Certificate Preview</h2>
    <p>Loading certificate...</p>
  `;let n=await fetch(ke(e),{credentials:`include`}),{html:r,error:i}=await Oe(n);if(!n.ok){alert(`Error loading certificate preview: `+i),t.innerHTML=`
      <h2>Certificate Preview</h2>
      <p>Unable to load certificate preview.</p>
    `;return}t.innerHTML=`
    <h2>Certificate Preview</h2>

    <div class="certificate-preview-html-frame-wrap">
      <iframe
        class="certificate-preview-html-frame"
        title="Certificate ${c(e)} preview"
      ></iframe>
    </div>

    <div class="form-actions">
      <button type="button" id="previewOpenCertificateBtn">Open</button>
      <button type="button" id="previewPrintCertificateBtn">Print</button>
    </div>
  `;let a=t.querySelector(`iframe`);a.srcdoc=r,document.querySelector(`#previewOpenCertificateBtn`).addEventListener(`click`,()=>window.openCertificateModal(e)),document.querySelector(`#previewPrintCertificateBtn`).addEventListener(`click`,()=>{window.printCertificatePdf(e)})},window.openCertificateModal=async function(e){let t=await fetch(ke(e),{credentials:`include`}),{html:n,error:r}=await Oe(t);if(!t.ok){alert(`Error loading certificate: `+r);return}let i=document.querySelector(`#certificateModal`);i&&i.remove();let a=document.createElement(`div`);a.id=`certificateModal`,a.className=`certificate-modal-overlay`,a.innerHTML=`
    <div class="certificate-modal certificate-original-layout">

      <div class="certificate-modal-header screen-only">
        <h2>Certificate ${c(e)}</h2>
        <div class="form-actions">
          <a
            id="certificatePrintBtn"
            class="cert-action-link"
            href="${y}/inspections/${encodeURIComponent(e)}/certificate.pdf?inline=1&t=${Date.now()}"
            target="_blank"
          >
            Print
          </a>
          <a
            id="certificateDownloadPdfBtn"
            class="cert-action-link"
            href="${y}/inspections/${encodeURIComponent(e)}/certificate.pdf?t=${Date.now()}"
            download="certificate-${c(e)}.pdf"
          >
            Download PDF
          </a>
          <button type="button" id="certificateMailBtn">Mail</button>
          <button type="button" id="certificateCloseBtn">Close</button>
        </div>
      </div>

      <div class="certificate-modal-body" id="certificatePrintArea">
        <iframe
          class="certificate-modal-html-frame"
          title="Certificate ${c(e)}"
        ></iframe>
      </div>
    </div>
  `,document.body.appendChild(a),a.querySelector(`iframe`).srcdoc=n,document.querySelector(`#certificateCloseBtn`).addEventListener(`click`,window.closeCertificateModal),document.querySelector(`#certificateMailBtn`).addEventListener(`click`,()=>{window.mailCertificate(e)})},window.printCertificatePdf=function(e){window.open(`${y}/inspections/${e}/certificate.pdf?inline=1&t=${Date.now()}`,`_blank`)},window.downloadCertificatePdf=async function(e){let t=await fetch(`${y}/inspections/${e}/certificate.pdf?t=${Date.now()}`);if(!t.ok){let e=await t.json().catch(()=>({error:`Unable to download certificate PDF`}));alert(`Error downloading certificate PDF: `+e.error);return}let n=await t.blob(),r=URL.createObjectURL(n),i=document.createElement(`a`);i.href=r,i.download=`certificate-${e}.pdf`,document.body.appendChild(i),i.click(),i.remove(),URL.revokeObjectURL(r)},window.mailCertificate=async function(e){let t=window.prompt(`Enter recipient email address`);if(t)try{let n=await fetch(`${y}/certificates/${e}/email`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({to:t.trim()})}),r=await n.json().catch(()=>({error:`Unable to read the email error from the server.`}));if(!n.ok){alert(r.error||`Unable to email certificate`);return}alert(`Certificate emailed successfully`)}catch(e){alert(`Unable to email certificate: ${e.message}`)}},window.deleteCertificate=async function(e){if(window.currentUser?.role!==`ADMIN`){alert(`Only admins may void certificates.`);return}let t=window.prompt(`Why is certificate ${e} being voided?\n\nThe inspection will be removed from normal lists but retained in the audit history.`,`Entered in error`);if(t===null)return;if(t.trim().length<3){alert(`Please enter a reason for voiding the certificate.`);return}let n=await fetch(`${y}/certificates/${e}`,{method:`DELETE`,headers:{"Content-Type":`application/json`},body:JSON.stringify({reason:t.trim()})}),r=await x(n);if(!n.ok){alert(r.error||`Unable to void certificate ${e}.`);return}window.currentCertificateResults=(window.currentCertificateResults||[]).filter(t=>String(t.testid)!==String(e)),Pe(window.currentCertificateResults),Ne(window.currentCertificateResults);let i=document.querySelector(`#certificatePreviewPanel`);i&&(i.innerHTML=`
      <h2>Certificate Preview</h2>
      <p>Certificate ${e} was voided and retained in the audit history.</p>
    `),alert(`Certificate ${e} was marked as entered in error.`)},window.closeCertificateModal=function(){let e=document.querySelector(`#certificateModal`);e&&e.remove()};function He(e){return e?String(e).split(`T`)[0]:`-`}var Ue={filterCertificateSites:window.filterCertificateSites,filterCertificateSections:window.filterCertificateSections,filterBulkCertificateSites:window.filterBulkCertificateSites,clearCertificateSearch:window.clearCertificateSearch,searchCertificates:window.searchCertificates,rerenderCertificateResults:window.rerenderCertificateResults,goToCertificatePage:window.goToCertificatePage,setCertificateRowsPerPage:window.setCertificateRowsPerPage,previewCertificate:window.previewCertificate,openCertificateModal:window.openCertificateModal,closeCertificateModal:window.closeCertificateModal,downloadCertificatePdf:window.downloadCertificatePdf,mailCertificate:window.mailCertificate,searchBulkCertificates:window.searchBulkCertificates,printSelectedBulkCertificates:window.printSelectedBulkCertificates,downloadSelectedBulkCertificatesPdf:window.downloadSelectedBulkCertificatesPdf,downloadAllBulkCertificatesPdf:window.downloadAllBulkCertificatesPdf,toggleBulkCertificateSelection:window.toggleBulkCertificateSelection,updateBulkCertificateButtons:window.updateBulkCertificateButtons},We=null,C=1,Ge=25;function Ke(e=[],t=[],n=[],r=[],i=[],a={}){let o=e=>e.archived!==!0&&e.archived!==`true`;e=e.filter(o),n=n.filter(o),r=r.filter(o),i=i.filter(o);let s=[...e].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``)),u=[...n].sort((e,t)=>(e.sitename||``).localeCompare(t.sitename||``)),d=[...r].sort((e,t)=>(e.sectionname||``).localeCompare(t.sectionname||``)),f=new Set,p=[...i].filter(e=>{let t=String(e.personid);return f.has(t)?!1:(f.add(t),!0)}).sort((e,t)=>(e.name||``).localeCompare(t.name||``)),ee=[...t].sort((e,t)=>(e.description||``).localeCompare(t.description||``));if(document.querySelector(`#page`).innerHTML=`
    <div class="report-page">
      <div class="report-hero">
        <div>
          <h1>Customer Detailed Report</h1>
          <p>Review customer assets, latest inspection status and due items in one place.</p>
        </div>
      </div>

      <div class="report-toolbar">
        <div class="report-filter-control">
          <label for="customerReportClient">Customer</label>
          <select id="customerReportClient">
              <option value="">All Customers</option>
              ${s.map(e=>`
                <option value="${l(e.clientid)}">
                  ${c(e.clientname||`Customer ${e.clientid}`)}
                </option>
              `).join(``)}
            </select>
          </div>

        <div class="report-filter-control">
          <label for="customerReportSite">Site</label>
          <select id="customerReportSite">
            <option value="">All Sites</option>
            ${u.map(e=>`
              <option value="${l(e.siteid)}">
                ${c(e.sitename||`Site ${e.siteid}`)}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="report-filter-control">
          <label for="customerReportSection">Section</label>
          <select id="customerReportSection">
            <option value="">All Sections</option>
            ${d.map(e=>`
              <option value="${l(e.sectionid)}">
                ${c(e.sectionname||`Section ${e.sectionid}`)}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="report-filter-control">
          <label for="customerReportResponsible">Responsible Person</label>
          <select id="customerReportResponsible">
            <option value="">All Responsible Persons</option>
            ${p.map(e=>`
              <option value="${l(e.personid)}">
                ${c(e.name||`Person ${e.personid}`)}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="report-filter-control">
          <label for="customerReportEquipment">Equipment Type</label>
          <select id="customerReportEquipment">
            <option value="">All Equipment Types</option>
            ${ee.map(e=>`
              <option value="${l(e.equiptypeid)}">
                ${c(e.description||`Equipment ${e.equiptypeid}`)}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="report-filter-control">
          <label for="customerReportDateFrom">Inspection Date From</label>
          <input id="customerReportDateFrom" type="date">
        </div>

        <div class="report-filter-control">
          <label for="customerReportDateTo">Inspection Date To</label>
          <input id="customerReportDateTo" type="date">
        </div>

        <div class="report-toolbar-actions">
            <button id="customerReportPreviewBtn" type="button">
              Preview Report
            </button>

            <a
              id="customerReportPdfLink"
              class="cert-action-link"
              href="${y}/reports/customer-detailed.pdf"
              download
            >
              Download PDF
            </a>

            <a
              id="customerReportExcelLink"
              class="cert-action-link"
              href="${y}/reports/customer-detailed.xlsx"
              download
            >
              Export Excel
            </a>
          </div>
        </div>

      <div id="customerReportPreview" class="report-preview-empty">
        <h2>No report preview yet</h2>
        <p>Select a customer or leave it on All Customers, then preview the report.</p>
      </div>
    </div>
  `,qe(),a?.clientid){let e=document.querySelector(`#customerReportClient`);e&&(e.value=String(a.clientid))}w(),a?.autoLoad&&T()}function qe(){document.querySelectorAll(`#customerReportClient, #customerReportSite, #customerReportSection, #customerReportResponsible, #customerReportEquipment, #customerReportDateFrom, #customerReportDateTo`).forEach(e=>{e.addEventListener(`change`,()=>{C=1,w()})}),document.querySelector(`#customerReportPreviewBtn`)?.addEventListener(`click`,()=>{C=1,T()})}function w(){let e=Je(),t=document.querySelector(`#customerReportPdfLink`),n=document.querySelector(`#customerReportExcelLink`);t&&(t.href=`${y}/reports/customer-detailed.pdf${e}`),n&&(n.href=`${y}/reports/customer-detailed.xlsx${e}`)}async function T(){w();let e=Je({includePagination:!0}),t=document.querySelector(`#customerReportPreview`);t.className=`report-preview-empty`,t.innerHTML=`<div class="report-preview-empty">Loading report...</div>`;let n=await fetch(`${y}/reports/customer-detailed${e}`),r=await n.json();if(!n.ok){t.innerHTML=`
      <div class="report-preview-empty">
        Error loading report: ${c(r.error||`Unknown error`)}
      </div>
    `;return}We=null,t.className=`report-preview-loaded`,We=r,E()}window.updateCustomerReportLinks=w,window.loadCustomerDetailedReport=T;function Je(t={}){let n=new URLSearchParams,r=document.querySelector(`#customerReportClient`)?.value||``,i=document.querySelector(`#customerReportSite`)?.value||``,a=document.querySelector(`#customerReportSection`)?.value||``,o=document.querySelector(`#customerReportResponsible`)?.value||``,s=document.querySelector(`#customerReportEquipment`)?.value||``,c=document.querySelector(`#customerReportDateFrom`)?.value||``,l=document.querySelector(`#customerReportDateTo`)?.value||``;if(r&&n.append(`clientid`,r),i&&n.append(`siteid`,i),a&&n.append(`sectionid`,a),o&&n.append(`responsibleid`,o),s&&n.append(`equiptypeid`,s),c&&n.append(`datefrom`,c),l&&n.append(`dateto`,l),t.includePagination){let t=e(`customerReport`,`latestinspectiondate`,`desc`);n.append(`page`,String(C||1)),n.append(`limit`,String(Ge||25)),n.append(`sortKey`,t.key||`latestinspectiondate`),n.append(`sortDir`,t.direction||`desc`)}let u=n.toString();return u?`?${u}`:``}function Ye(e){let t=e.customers.length===1?c(e.customers[0].clientname):`All Customers`,r=Qe(),i=e.pagination||{page:C,limit:r,total:e.assets.length,totalPages:Math.max(1,Math.ceil(e.assets.length/r))},a=Math.max(1,Number(i.totalPages||1)),o=Math.min(Number(i.page||C||1),a),s=Number(i.total||e.assets.length),l=(o-1)*Number(i.limit||r),u=e.assets||[],d=s===0?0:l+u.length;return`
    <div class="report-summary-card">
      <div class="report-summary-heading">
        <div>
          <h2>${t}</h2>
          <p>Generated ${nt(e.generatedAt)}</p>
        </div>

        <div class="report-count-note">
          ${s} assets in report
        </div>
      </div>

      <div class="report-summary-grid">
        ${O(`Customers`,e.summary.customers)}
        ${O(`Assets`,e.summary.assets)}
        ${O(`Active Assets`,e.summary.activeAssets)}
        ${O(`OK`,e.summary.safeAssets)}
        ${O(`Not Safe`,e.summary.notSafeAssets)}
        ${O(`Incomplete`,e.summary.incompleteInspectionAssets)}
        ${O(`Missing Metadata`,e.summary.missingCertificateMetadataAssets)}
        ${O(`Visual Overdue`,e.summary.visualOverdueAssets)}
        ${O(`Load Overdue`,e.summary.loadOverdueAssets)}
        ${O(`No Visual`,e.summary.noVisualAssets)}
        ${O(`No Load Test`,e.summary.noLoadAssets)}
      </div>
    </div>

    <div class="report-detail-card">
      <div class="report-detail-heading">
        <div>
          <h2>Asset Detail Preview</h2>
          <p>Showing ${s===0?0:l+1} to ${d} of ${s} assets. Use PDF or Excel for the full detailed report.</p>
        </div>
      </div>

      <div class="report-pagination-bar">
        <div class="report-page-size">
          <label for="reportRowsPerPage">Rows per page</label>
          <select id="reportRowsPerPage">
            ${[25,50,100,250].map(e=>`
              <option value="${e}" ${e===r?`selected`:``}>
                ${e}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="report-page-controls">
          <button id="reportPrevPageBtn" type="button" ${o<=1?`disabled`:``}>
            Previous
          </button>
          ${Ze(o,a)}
          <button id="reportNextPageBtn" type="button" ${o>=a?`disabled`:``}>
            Next
          </button>
          <span>Page ${o} of ${a}</span>
        </div>
      </div>

      <div class="report-scroll-control">
        <span>Left</span>
        <input id="reportTableSlider" type="range" min="0" max="0" value="0" step="1">
        <span>Right</span>
      </div>

      <div class="report-table-wrap">
        <table class="report-table">
          <thead>
            <tr>
              <th>${n(`Customer`,`customerReport`,`clientname`,`rerenderCustomerReport`)}</th>
              <th>${n(`Asset ID`,`customerReport`,`assetid`,`rerenderCustomerReport`)}</th>
              <th>${n(`Asset Tag`,`customerReport`,`assettagno`,`rerenderCustomerReport`)}</th>
              <th>${n(`Serial No`,`customerReport`,`serialno`,`rerenderCustomerReport`)}</th>
              <th>${n(`Site`,`customerReport`,`sitename`,`rerenderCustomerReport`)}</th>
              <th>${n(`Section`,`customerReport`,`sectionname`,`rerenderCustomerReport`)}</th>
              <th>${n(`Responsible Person`,`customerReport`,`responsiblename`,`rerenderCustomerReport`)}</th>
              <th>${n(`Equipment Type`,`customerReport`,`equipmenttype`,`rerenderCustomerReport`)}</th>
              <th>${n(`Description`,`customerReport`,`description`,`rerenderCustomerReport`)}</th>
              <th>${n(`Latest Inspection`,`customerReport`,`latestinspectiondate`,`rerenderCustomerReport`)}</th>
              <th>${n(`Last Visual`,`customerReport`,`visualtestdate`,`rerenderCustomerReport`)}</th>
              <th>${n(`Visual Status`,`customerReport`,`visualstatus`,`rerenderCustomerReport`)}</th>
              <th>${n(`Last Load`,`customerReport`,`loadtestdate`,`rerenderCustomerReport`)}</th>
              <th>${n(`Load Status`,`customerReport`,`loadstatus`,`rerenderCustomerReport`)}</th>
              <th>${n(`Report Status`,`customerReport`,`reportstatus`,`rerenderCustomerReport`)}</th>
            </tr>
          </thead>
          <tbody>
            ${u.map(e=>`
              <tr>
                <td>${c(e.clientname||`-`)}</td>
                <td>${c(e.assetid||`-`)}</td>
                <td>${c(e.assettagno||`-`)}</td>
                <td>${c(e.serialno||`-`)}</td>
                <td>${c(e.sitename||`-`)}</td>
                <td>${c(e.sectionname||`-`)}</td>
                <td>${c(e.responsiblename||`-`)}</td>
                <td>${c(e.equipmenttype||`-`)}</td>
                <td>${c(e.description||`-`)}</td>
                <td>${nt(e.latestinspectiondate)}</td>
                <td>${nt(e.visualtestdate)}</td>
                <td class="${et(e.visualstatus)}">${c(e.visualstatus||`-`)}</td>
                <td>${nt(e.loadtestdate)}</td>
                <td class="${et(e.loadstatus)}">${c(e.loadstatus||`-`)}</td>
                <td>
                  <span class="report-status-pill ${tt(e.reportstatus)}">
                    ${c(e.reportstatus||`-`)}
                  </span>
                </td>
              </tr>
            `).join(``)||`
              <tr>
                <td colspan="15">No assets found for this report.</td>
              </tr>
            `}
          </tbody>
        </table>
      </div>
    </div>
  `}function E(){let e=document.querySelector(`#customerReportPreview`);!e||!We||(e.innerHTML=Ye(We),Xe(),$e())}function Xe(){document.querySelector(`#reportRowsPerPage`)?.addEventListener(`change`,e=>{Ge=Number(e.target.value)||25,C=1,T()}),document.querySelector(`#reportPrevPageBtn`)?.addEventListener(`click`,()=>{C=Math.max(1,C-1),T()}),document.querySelector(`#reportNextPageBtn`)?.addEventListener(`click`,()=>{let e=We?.pagination?.totalPages||1;C=Math.min(e,C+1),T()})}function D(e,t){let n=[];if(t<=10){for(let e=1;e<=t;e+=1)n.push(e);return n}let r=Math.max(1,e-4),i=Math.min(t,r+9-1);i-r+1<9&&(r=Math.max(1,i-9+1)),r>1&&(n.push(1),r>2&&n.push(`...`));for(let e=r;e<=i;e+=1)n.push(e);return i<t&&(i<t-1&&n.push(`...`),n.push(t)),n}function Ze(e,t){return D(e,t).map(t=>t===`...`?`<span class="pagination-ellipsis">...</span>`:`
      <button
        type="button"
        class="pagination-page-btn ${t===e?`active`:``}"
        onclick="goToCustomerReportPage(${t})"
        ${t===e?`disabled`:``}
      >
        ${t}
      </button>
    `).join(``)}window.goToCustomerReportPage=function(e){C=Math.max(1,Number(e)||1),T()},window.rerenderCustomerReport=function(){C=1,T()};function Qe(){return Ge||25}function $e(){let e=document.querySelector(`#reportTableSlider`),t=document.querySelector(`.report-table-wrap`);if(!e||!t)return;let n=()=>{let n=Math.max(0,t.scrollWidth-t.clientWidth);e.max=String(n),e.value=String(Math.min(t.scrollLeft,n)),e.disabled=n===0};n(),e.addEventListener(`input`,()=>{t.scrollLeft=Number(e.value)}),t.addEventListener(`scroll`,()=>{e.value=String(t.scrollLeft)}),window.addEventListener(`resize`,n,{once:!0})}function O(e,t){return`
    <div class="report-summary-tile">
      <span>${e}</span>
      <strong>${t??0}</strong>
    </div>
  `}function et(e){return e===`SAFE`||e===`OK`?`status-safe`:e===`NOT SAFE`?`status-unsafe`:``}function tt(e){return e===`OK`?`is-ok`:e===`NOT SAFE`?`is-danger`:(e||``).includes(`OVERDUE`)?`is-warning`:(e||``).includes(`NO `)?`is-muted`:``}function nt(e){return e?String(e).split(`T`)[0]:`-`}var rt=1,it=25;function k(e){return Number(e||0)}function at(e){return e?String(e).split(`T`)[0]:`-`}function ot(e){return e===`SAFE`?`status-safe`:e===`NOT SAFE`?`status-unsafe`:``}function A(e,t,n=``){return`
    <div class="portal-metric ${n}">
      <span>${c(e)}</span>
      <strong>${c(k(t))}</strong>
    </div>
  `}function st(e=[]){return e.length?`
    <table class="portal-certificate-table">
      <thead>
        <tr>
          <th>Certificate</th>
          <th>Asset</th>
          <th>Site</th>
          <th>Type</th>
          <th>Date</th>
          <th>Valid Until</th>
          <th>Status</th>
          <th>PDF</th>
        </tr>
      </thead>
      <tbody>
        ${e.map(e=>`
          <tr>
            <td>${c(e.testid)}</td>
            <td>
              <strong>${c(e.assettagno||e.assetid||`-`)}</strong>
              <span>${c(e.description||e.serialno||``)}</span>
            </td>
            <td>${c(e.sitename||`-`)}</td>
            <td>${c(e.inspectiontype||`-`)}</td>
            <td>${c(at(e.testdate))}</td>
            <td>${c(at(e.validdate))}</td>
            <td><strong class="${ot(e.status)}">${c(e.status||`-`)}</strong></td>
            <td>
              <a class="cert-action-link" href="${y}/inspections/${encodeURIComponent(e.testid)}/certificate.pdf" download>
                Download
              </a>
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `:`<p>No certificates found yet.</p>`}function ct(e){return e===`OK`?`is-ok`:e===`NOT SAFE`?`is-danger`:String(e||``).includes(`OVERDUE`)?`is-warning`:String(e||``).startsWith(`NO `)?`is-muted`:``}function j(e,t=`PDF`){return e?`
    <a class="cert-action-link" href="${y}/inspections/${encodeURIComponent(e)}/certificate.pdf" download>
      ${c(t)}
    </a>
  `:`-`}function lt(e=[]){return e.length?`
    <table class="portal-asset-table">
      <thead>
        <tr>
          <th>Asset</th>
          <th>Site</th>
          <th>Section</th>
          <th>Equipment</th>
          <th>Last Visual</th>
          <th>Last Load Test</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        ${e.map(e=>`
          <tr>
            <td>
              <strong>${c(e.assettagno||e.assetid||`-`)}</strong>
              <span>${c(e.description||``)}</span>
              <span>${c(e.serialno||``)}</span>
            </td>
            <td>${c(e.sitename||`-`)}</td>
            <td>${c(e.sectionname||`-`)}</td>
            <td>${c(e.equipmenttype||`-`)}</td>
            <td>
              <strong class="${ot(e.visual_status)}">${c(e.visual_status||`-`)}</strong>
              <span>${c(at(e.visual_testdate))} / valid ${c(at(e.visual_validdate))}</span>
              ${j(e.visual_testid)}
            </td>
            <td>
              <strong class="${ot(e.loadtest_status)}">${c(e.loadtest_status||`-`)}</strong>
              <span>${c(at(e.loadtest_testdate))} / valid ${c(at(e.loadtest_validdate))}</span>
              ${j(e.loadtest_testid)}
            </td>
            <td>
              <span class="report-status-pill ${ct(e.asset_status)}">
                ${c(e.asset_status||`-`)}
              </span>
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `:`<p>No assets match the selected filters.</p>`}function ut(){let e=new URLSearchParams,t=document.querySelector(`#portalAssetSearch`)?.value||``,n=document.querySelector(`#portalAssetStatus`)?.value||``;return t&&e.set(`search`,t),n&&e.set(`status`,n),e.set(`page`,String(rt)),e.set(`limit`,String(it)),e.toString()}async function M(){let e=document.querySelector(`#portalAssetResults`);if(e){e.innerHTML=`<p>Loading assets...</p>`;try{let t=await fetch(`${y}/customer-portal/assets?${ut()}`),n=await t.json();if(!t.ok){e.innerHTML=`<p class="login-error">${c(n.error||`Could not load assets.`)}</p>`;return}let r=Number(n.page||1),i=Number(n.totalPages||1);e.innerHTML=`
      <div class="portal-asset-summary">
        <span>${c(n.total||0)} assets</span>
        <span>Page ${c(r)} of ${c(i)}</span>
      </div>
      ${lt(n.rows||[])}
      <div class="form-actions portal-asset-pagination">
        <button type="button" ${r<=1?`disabled`:``} onclick="portalAssetPreviousPage()">Previous</button>
        <button type="button" ${r>=i?`disabled`:``} onclick="portalAssetNextPage()">Next</button>
      </div>
    `}catch{e.innerHTML=`<p class="login-error">Could not connect to the asset list.</p>`}}}async function dt(e=null){document.querySelector(`#page`).innerHTML=`
    <div class="customer-portal-page">
      <div class="customer-portal-hero">
        <div>
          <h1>Customer Portal</h1>
          <p>Certificates, asset status and reports for your ATEC account.</p>
        </div>
      </div>

      <div id="customerPortalContent" class="filter-card">
        <p>Loading portal...</p>
      </div>
    </div>
  `;let t=document.querySelector(`#customerPortalContent`);try{let n=await fetch(`${y}/customer-portal/summary`),r=await n.json();if(!n.ok){t.innerHTML=`<p class="login-error">${c(r.error||`Could not load the customer portal.`)}</p>`;return}let i=r.assetSummary||{},a=r.certificateSummary||{},o=r.visitSummary||{},s=r.customer||{};t.className=`customer-portal-content`,t.innerHTML=`
      <div class="customer-portal-heading">
        <div>
          <h2>${c(s.clientname||e?.full_name||`Customer`)}</h2>
          <p>${c(s.clientaddr||``)}</p>
        </div>
        <div class="form-actions">
          <button type="button" onclick="showCertificateSearch()">Certificates</button>
          <button type="button" onclick="showCustomerDetailedReport({ autoLoad: true })">Detailed Report</button>
        </div>
      </div>

      <div class="portal-metric-grid">
        ${A(`Active Assets`,i.active_assets)}
        ${A(`Sites`,i.active_sites)}
        ${A(`Certificates`,a.total_certificates)}
        ${A(`Not Safe Assets`,i.not_safe_assets,k(i.not_safe_assets)?`danger`:``)}
        ${A(`Visual Overdue`,i.visual_overdue_assets,k(i.visual_overdue_assets)?`warning`:``)}
        ${A(`Load Test Overdue`,i.loadtest_overdue_assets,k(i.loadtest_overdue_assets)?`warning`:``)}
        ${A(`Expiring Soon`,a.expiring_soon_certificates,k(a.expiring_soon_certificates)?`warning`:``)}
        ${A(`Visit Outstanding`,o.outstanding_visit_assets,k(o.outstanding_visit_assets)?`warning`:``)}
      </div>

      <div class="customer-portal-panels">
        <section class="filter-card">
          <h3>Certificate Status</h3>
          <div class="portal-mini-grid">
            ${A(`Safe`,a.safe_certificates)}
            ${A(`Not Safe`,a.not_safe_certificates,k(a.not_safe_certificates)?`danger`:``)}
            ${A(`Expired`,a.expired_certificates,k(a.expired_certificates)?`warning`:``)}
          </div>
        </section>

        <section class="filter-card">
          <h3>On-Site Visits</h3>
          <div class="portal-mini-grid">
            ${A(`Active Visits`,o.active_visits)}
            ${A(`Outstanding Items`,o.outstanding_visit_assets,k(o.outstanding_visit_assets)?`warning`:``)}
            ${A(`Completed 30 Days`,o.recently_completed_visits)}
          </div>
        </section>
      </div>

      <section class="filter-card">
        <div class="customer-portal-section-heading">
          <h3>Recent Certificates</h3>
          <button type="button" onclick="showCertificateSearch()">Search All</button>
        </div>
        ${st(r.recentCertificates||[])}
      </section>

      <section class="filter-card">
        <div class="customer-portal-section-heading">
          <h3>Assets</h3>
          <button type="button" onclick="loadPortalAssets()">Refresh</button>
        </div>
        <div class="portal-asset-filters">
          <input id="portalAssetSearch" type="search" placeholder="Search tag, serial, description, site...">
          <select id="portalAssetStatus">
            <option value="">All statuses</option>
            <option value="OK">OK</option>
            <option value="NOT SAFE">Not safe</option>
            <option value="VISUAL OVERDUE">Visual overdue</option>
            <option value="LOAD TEST OVERDUE">Load test overdue</option>
            <option value="NO VISUAL">No visual</option>
            <option value="NO LOAD TEST">No load test</option>
          </select>
          <select id="portalAssetPageSize">
            <option value="25">25 rows</option>
            <option value="50">50 rows</option>
            <option value="100">100 rows</option>
          </select>
          <button type="button" onclick="searchPortalAssets()">Search</button>
        </div>
        <div id="portalAssetResults">
          <p>Loading assets...</p>
        </div>
      </section>
    `,ft(),M()}catch{t.innerHTML=`<p class="login-error">Could not connect to the customer portal.</p>`}}function ft(){document.querySelector(`#portalAssetSearch`)?.addEventListener(`keydown`,e=>{e.key===`Enter`&&window.searchPortalAssets()}),document.querySelector(`#portalAssetStatus`)?.addEventListener(`change`,window.searchPortalAssets),document.querySelector(`#portalAssetPageSize`)?.addEventListener(`change`,e=>{it=Number(e.target.value)||25,window.searchPortalAssets()})}window.loadPortalAssets=M,window.searchPortalAssets=function(){rt=1,M()},window.portalAssetPreviousPage=function(){rt=Math.max(1,rt-1),M()},window.portalAssetNextPage=function(){rt+=1,M()};function pt(){return new Date().toISOString().split(`T`)[0]}function mt(e=``){return[1,2,3,4,5].map(t=>`
    <option value="${t}" ${String(e)===String(t)?`selected`:``}>
      ${t}
    </option>
  `).join(``)}function ht(e=`OPEN`){return[`OPEN`,`IN_PROGRESS`,`CLOSED`].map(t=>`
    <option value="${t}" ${t===e?`selected`:``}>
      ${t.replaceAll(`_`,` `)}
    </option>
  `).join(``)}var gt=[`Machine Mobile`,`Electrical`,`Object / Pressure`,`Machine Fixed`,`Thermal Stress`,`Slip / Trip / Strain`,`Chemical`,`Noise`],_t=[[`routine_task`,`Is this a routine task, done daily or weekly?`],[`team_fit`,`Is the team physically and mentally fit to safely execute the task?`],[`authorized`,`Does the team have the necessary authorization, area access or permit to do the task?`],[`tools_ppe_safe`,`Are all tools, equipment and PPE correctly selected, inspected and safe for use?`],[`energy_locked_out`,`Have all energy sources been de-energized and locked out where required?`],[`team_competent`,`Are all team members trained, competent and properly appointed for their roles?`],[`task_planned`,`Was the task carefully planned to avoid improvisation or unsafe last-minute solutions?`],[`stop_if_risk_changes`,`Are all team members aware they must stop, regroup, replan and escalate if risk increases?`],[`standard_understood`,`Is there a standard for this task, and does the team understand it?`]],vt=[[`task_completed_safely`,`Has the task been completed safely?`],[`team_accounted_for`,`Are all team members accounted for, safe and healthy?`],[`near_misses`,`Were near misses or incidents experienced during the task?`],[`ppe_worn`,`Did you wear the required PPE?`],[`housekeeping_done`,`Was good housekeeping practiced at the work site?`],[`reported_complete`,`Have you reported task completion to the appointed person?`],[`went_to_plan`,`Did the task go according to plan?`],[`extra_information`,`Would you like to communicate any additional information about the task?`]];function yt(e,t=``){return`
    <option value="">General / no asset</option>
    ${e.map(e=>`
      <option value="${l(e.assetid)}" ${String(t)===String(e.assetid)?`selected`:``}>
        ${c(e.assetid)} - ${c(e.assettagno||e.serialno||e.description||`Asset`)}
      </option>
    `).join(``)}
  `}function bt(e=``){return`
    <option value="">Select</option>
    <option value="YES" ${e===`YES`?`selected`:``}>YES</option>
    <option value="NO" ${e===`NO`?`selected`:``}>NO</option>
    <option value="N/A" ${e===`N/A`?`selected`:``}>N/A</option>
  `}function xt(e,t){return e.map(([e,n])=>`
    <div class="slamm-question-row">
      <span>${n}</span>
      <select class="${t}" data-key="${e}">
        ${bt(``)}
      </select>
    </div>
  `).join(``)}function St(){return Array.from({length:6},(e,t)=>`
    <div class="slamm-team-row" data-index="${t}">
      <span>${t+1}</span>
      <input class="slamm-team-name" type="text" placeholder="Name">
      <input class="slamm-team-surname" type="text" placeholder="Surname">
      <input class="slamm-team-signature" type="text" placeholder="Signature / initials">
    </div>
  `).join(``)}function Ct(e){return e?String(e).split(`T`)[0]:`-`}function wt(e){let t=Number(e||0);return t>=15?`danger`:t>=8?`warning`:`success`}async function Tt(e=[],t=!0){let n=document.querySelector(`#page`);n.innerHTML=`
    <h1>SLAMM</h1>
    <p>SLAMM - Stop, Look, Assess, Manage and Monitor before and after the task.</p>

    ${t?`<div class="filter-card">
      <h2>New SLAMM</h2>
      <input type="hidden" id="riskId" value="">

      <div class="risk-form-grid risk-form-grid--top">
        <div class="form-group">
          <label>Asset</label>
          <select id="riskAssetId">${yt(e)}</select>
        </div>

        <div class="form-group">
          <label>Assessment Date</label>
          <input id="riskAssessmentDate" type="date" value="${pt()}">
        </div>

        <div class="form-group">
          <label>Assessment Time</label>
          <input id="riskAssessmentTime" type="time">
        </div>

        <div class="form-group">
          <label>Status</label>
          <select id="riskStatus">${ht()}</select>
        </div>

        <div class="form-group risk-span-2">
          <label>Task Description</label>
          <input id="riskActivity" type="text">
        </div>

        <div class="form-group">
          <label>Responsible Person</label>
          <input id="riskResponsiblePerson" type="text">
        </div>
      </div>

      <div class="slamm-section">
        <h3>STOP and LOOK - Hazard Types</h3>
        <div class="slamm-check-grid">
          ${gt.map(e=>`
            <label class="slamm-check">
              <input type="checkbox" class="risk-hazard-category" value="${e}">
              <span>${e}</span>
            </label>
          `).join(``)}
        </div>
      </div>

      <div class="slamm-section">
        <h3>STOP Questions</h3>
        <p>If any answer is NO, stop and apply the required controls or escalate before continuing.</p>
        <div class="slamm-question-grid">
          ${xt(_t,`slamm-stop-question`)}
        </div>
      </div>

      <div class="risk-assessment-flow">
        <div class="form-group risk-full">
          <label>LOOK / ASSESS - Hazards and Risks</label>
          <textarea id="riskHazard" rows="2"></textarea>
        </div>

        <div class="form-group risk-full">
          <label>Consequence</label>
          <textarea id="riskConsequence" rows="2"></textarea>
        </div>

        <div class="risk-score-grid">
          <div class="form-group">
            <label>Initial Severity</label>
            <select id="riskInitialSeverity">${mt(3)}</select>
          </div>

          <div class="form-group">
            <label>Initial Likelihood</label>
            <select id="riskInitialLikelihood">${mt(3)}</select>
          </div>

          <div class="form-group">
            <label>Residual Severity</label>
            <select id="riskResidualSeverity">${mt(2)}</select>
          </div>

          <div class="form-group">
            <label>Residual Likelihood</label>
            <select id="riskResidualLikelihood">${mt(2)}</select>
          </div>
        </div>

        <div class="form-group risk-full">
          <label>Controls to Manage the Hazards and Risks</label>
          <textarea id="riskControls" rows="2"></textarea>
        </div>

        <div class="form-group risk-full">
          <label>MANAGE - Actions Required</label>
          <textarea id="riskActionRequired" rows="2"></textarea>
        </div>

        <div class="form-group risk-full">
          <label>Manage Plan</label>
          <textarea id="riskManagePlan" rows="2"></textarea>
        </div>

        <div class="form-group risk-full">
          <label>MONITOR - New Hazards / Changes During Task</label>
          <textarea id="riskMonitorNotes" rows="2"></textarea>
        </div>

        <div class="risk-due-row">
          <div class="form-group risk-due-field">
            <label>Due Date</label>
            <input id="riskDueDate" type="date">
          </div>
        </div>
      </div>

      <div class="slamm-section">
        <h3>After Task Review</h3>
        <div class="slamm-question-grid">
          ${xt(vt,`slamm-review-question`)}
        </div>
        <div class="form-group">
          <label>Additional Comments / Recommendations</label>
          <textarea id="riskAdditionalNotes" rows="3"></textarea>
        </div>
      </div>

      <div class="slamm-section">
        <h3>Team Members Involved in the Risk Assessment / SHE Process</h3>
        <div class="slamm-team-grid">
          ${St()}
        </div>
      </div>

      <div class="asset-form-grid">
        <div class="form-group">
          <label>After Task Sign-off by Responsible Person</label>
          <input id="riskResponsibleSignoffName" type="text" placeholder="Name and surname">
        </div>

        <div class="form-group">
          <label>After Task Sign-off by Supervisor</label>
          <input id="riskSupervisorSignoffName" type="text" placeholder="Name and surname">
        </div>
      </div>

      <div class="form-actions">
        <button onclick="saveRiskAssessment()">Save Risk Assessment</button>
        <button type="button" class="secondary-button" onclick="showRiskAssessments()">Clear Form</button>
      </div>
    </div>`:``}

    <div class="filter-card">
      <div class="form-row">
        <div class="form-group">
          <label>Search</label>
          <input id="riskSearch" type="text" placeholder="Asset, activity, hazard, status..." onkeyup="filterRiskAssessments()">
        </div>

        <div class="form-group">
          <label>Status</label>
          <select id="riskStatusFilter" onchange="filterRiskAssessments()">
            <option value="">All</option>
            ${ht(``)}
          </select>
        </div>
      </div>

      <div class="form-actions">
        <button type="button" onclick="downloadRiskAssessments('pdf')">
          Download PDF
        </button>
        <button type="button" onclick="downloadRiskAssessments('xlsx')">
          Export Excel
        </button>
      </div>
    </div>

    <div id="riskAssessmentTable"></div>
  `,await window.loadRiskAssessments()}function Et(e=[],r=!0){let i=document.querySelector(`#riskAssessmentTable`),a=document.querySelector(`#riskSearch`)?.value.toLowerCase().trim()||``,o=document.querySelector(`#riskStatusFilter`)?.value||``,s=t(e.filter(e=>{let t=!o||e.status===o,n=[e.riskid,e.assettagno,e.serialno,e.asset_description,e.clientname,e.sitename,e.activity,e.hazard,e.hazard_categories,e.status].join(` `).toLowerCase();return t&&n.includes(a)}),`riskAssessments`,{riskid:e=>e.riskid,assessment_date:e=>e.assessment_date,assettagno:e=>e.assettagno,activity:e=>e.activity,initial_rating:e=>e.initial_rating,residual_rating:e=>e.residual_rating,responsible_person:e=>e.responsible_person,status:e=>e.status,due_date:e=>e.due_date},`assessment_date`);i.innerHTML=`
    <table>
      <thead>
        <tr>
          <th>${n(`ID`,`riskAssessments`,`riskid`,`filterRiskAssessments`)}</th>
          <th>${n(`Date`,`riskAssessments`,`assessment_date`,`filterRiskAssessments`)}</th>
          <th>${n(`Asset`,`riskAssessments`,`assettagno`,`filterRiskAssessments`)}</th>
          <th>${n(`Activity`,`riskAssessments`,`activity`,`filterRiskAssessments`)}</th>
          <th>Hazard</th>
          <th>Hazard Types</th>
          <th>${n(`Initial Risk`,`riskAssessments`,`initial_rating`,`filterRiskAssessments`)}</th>
          <th>${n(`Residual Risk`,`riskAssessments`,`residual_rating`,`filterRiskAssessments`)}</th>
          <th>${n(`Responsible`,`riskAssessments`,`responsible_person`,`filterRiskAssessments`)}</th>
          <th>${n(`Status`,`riskAssessments`,`status`,`filterRiskAssessments`)}</th>
          <th>${n(`Due`,`riskAssessments`,`due_date`,`filterRiskAssessments`)}</th>
          ${r?`<th>Action</th>`:``}
        </tr>
      </thead>
      <tbody>
        ${s.length?s.map(e=>`
          <tr>
            <td>${c(e.riskid)}</td>
            <td>${Ct(e.assessment_date)}</td>
            <td>
              <strong>${c(e.assettagno||e.assetid||`-`)}</strong><br>
              <small>${c(e.asset_description||e.serialno||``)}</small>
            </td>
            <td>${c(e.activity||``)}</td>
            <td>${c(e.hazard||``)}</td>
            <td>${c(Array.isArray(e.hazard_categories)?e.hazard_categories.join(`, `):``)}</td>
            <td><span class="status-badge ${wt(e.initial_rating)}">${c(e.initial_rating||`-`)}</span></td>
            <td><span class="status-badge ${wt(e.residual_rating)}">${c(e.residual_rating||`-`)}</span></td>
            <td>${c(e.responsible_person||``)}</td>
            <td>${c(e.status||``)}</td>
            <td>${Ct(e.due_date)}</td>
            ${r?`<td>
              <div class="action-buttons">
                <button onclick="editRiskAssessment(${e.riskid})">Edit</button>
                <button onclick="archiveRiskAssessment(${e.riskid})">Archive</button>
              </div>
            </td>`:``}
          </tr>
        `).join(``):`
          <tr>
            <td colspan="${r?`12`:`11`}" class="empty-row">No risk assessments found</td>
          </tr>
        `}
      </tbody>
    </table>
  `}var Dt=`2026-07-18T07-54-47-402Z`,Ot=`2026-07-18T07:54:47.404Z`,kt=6e4;function At(){return localStorage.getItem(`currentPage`)===`system-health`}function jt(){window.systemHealthRefreshTimer&&(clearInterval(window.systemHealthRefreshTimer),window.systemHealthRefreshTimer=null)}function N(e){let t=Number(e);if(!Number.isFinite(t))return`Unknown`;let n=[`B`,`KB`,`MB`,`GB`,`TB`],r=Math.max(0,t),i=0;for(;r>=1024&&i<n.length-1;)r/=1024,i+=1;return`${r.toFixed(i===0?0:1)} ${n[i]}`}function Mt(e){let t=Number(e);if(!Number.isFinite(t))return`Unknown`;let n=Math.floor(t/86400),r=Math.floor(t%86400/3600),i=Math.floor(t%3600/60);return n?`${n}d ${r}h`:r?`${r}h ${i}m`:`${i}m`}function P(e){if(!e||e===`unavailable`)return`Unavailable`;let t=new Date(e);return Number.isNaN(t.getTime())?`Unavailable`:t.toLocaleString()}function Nt(e=``){let t=String(e).toLowerCase();return/healthy|connected|current/.test(t)?`health-good`:/critical|failed|offline|overdue|mismatch/.test(t)?`health-bad`:`health-warning`}function F(e,t){return`<span class="health-badge ${Nt(t)}">${c(e||t||`Unknown`)}</span>`}function I(e,t){return`
    <div class="health-info-row">
      <span>${c(e)}</span>
      <strong>${c(t??`Unknown`)}</strong>
    </div>
  `}function Pt(e){return e?`
    ${I(`Latest file`,e.filename)}
    ${I(`Modified`,P(e.modifiedAt))}
    ${I(`Size`,N(e.sizeBytes))}
    ${e.ageHours===void 0?``:I(`Age`,`${e.ageHours} hours`)}
  `:I(`Latest file`,`No file found`)}function Ft(e={}){return`
    ${I(`Latest backup set`,e.latestBackupSetId||`Unavailable`)}
    ${I(`Database backup timestamp`,P(e.latestSuccessfulDatabaseBackupAt))}
    ${I(`Media backup timestamp`,P(e.latestSuccessfulMediaBackupAt))}
    ${I(`Backup age`,e.backupAgeHours===null||e.backupAgeHours===void 0?`Unknown`:`${e.backupAgeHours} hours`)}
    ${I(`Validation`,`${e.validation?.status||`not-run`}${e.validation?.timestamp?` at ${P(e.validation.timestamp)}`:``}`)}
    ${I(`Restore verification`,`${e.restoreVerification?.status||`not-run`}${e.restoreVerification?.timestamp?` at ${P(e.restoreVerification.timestamp)}`:``}`)}
    ${I(`Checksum`,e.checksumStatus||`not-run`)}
    ${I(`Last job duration`,e.lastBackupDurationMs?Mt(Number(e.lastBackupDurationMs)/1e3):`Unknown`)}
    ${I(`Retention`,`${e.retention?.status||`not-run`}${e.retention?.timestamp?` at ${P(e.retention.timestamp)}`:``}`)}
    ${I(`Next scheduled backup`,P(e.nextScheduledBackup))}
    ${e.lastFailure?I(`Last failure`,e.lastFailure):``}
  `}function It(e={}){let t=Array.isArray(e.users)?e.users:[],n=e.windowMinutes||10;return t.length?`
    <div class="table-scroll">
      <table class="dashboard-table health-active-users-table">
        <thead>
          <tr>
            <th>User</th>
            <th>Role</th>
            <th>Last Seen</th>
            <th>Working On</th>
          </tr>
        </thead>
        <tbody>
          ${t.map(e=>`
            <tr>
              <td>
                <strong>${c(e.full_name||e.username||`User ${e.user_id}`)}</strong>
                <span>${c(e.username||``)}</span>
              </td>
              <td>${c(e.role||`-`)}</td>
              <td>${c(P(e.lastSeenAt))}</td>
              <td>${c(e.lastRoute||`-`)}</td>
            </tr>
          `).join(``)}
        </tbody>
      </table>
    </div>
  `:`<p class="health-empty-state">No active users in the last ${c(n)} minutes.</p>`}function Lt(e){let t=e.deployment.backendBuildIdentifier!==`unavailable`&&e.deployment.backendBuildIdentifier===`2026-07-18T07-54-47-402Z`?`Match`:`Unverified`;return`
    <div class="system-health-page">
      <div class="section-header system-health-header">
        <div>
          <h1>System Health</h1>
          <p>Last refreshed ${c(P(e.checkedAt))}</p>
        </div>
        <button type="button" onclick="refreshSystemHealth()">Refresh</button>
      </div>

      <div class="health-status-grid">
        <div class="health-status-card">
          <span>Backend</span>
          ${F(e.overallStatus,e.overallStatus)}
        </div>
        <div class="health-status-card">
          <span>Database</span>
          ${F(e.database.status,e.database.status)}
        </div>
        <div class="health-status-card">
          <span>Backup</span>
          ${F(e.backup.status,e.backup.status)}
        </div>
        <div class="health-status-card">
          <span>Disk</span>
          ${F(e.disk.status,e.disk.status)}
        </div>
        <div class="health-status-card">
          <span>Memory</span>
          ${F(e.server.systemMemory.status,e.server.systemMemory.status)}
        </div>
        <div class="health-status-card">
          <span>Deployment</span>
          ${F(e.deployment.status,e.deployment.status)}
        </div>
      </div>

      <div class="health-section-grid">
        <section class="dashboard-section">
          <div class="section-header"><h2>Deployment Information</h2></div>
          ${I(`Running commit`,e.deployment.runningGitCommit)}
          ${I(`Latest local commit`,e.deployment.latestLocalGitCommit)}
          ${I(`Git branch`,e.deployment.gitBranch)}
          ${I(`Working tree`,e.deployment.workingTreeClean===null?`Unverified`:e.deployment.workingTreeClean?`Clean`:`Local changes present`)}
          ${I(`Frontend build ID`,Dt)}
          ${I(`Frontend build timestamp`,Ot)}
          ${I(`Backend build ID`,e.deployment.backendBuildIdentifier)}
          ${I(`Frontend/backend match`,t)}
        </section>

        <section class="dashboard-section">
          <div class="section-header"><h2>Application</h2></div>
          ${I(`Application`,e.application.name)}
          ${I(`Version`,e.application.version)}
          ${I(`Environment`,e.application.environment)}
          ${I(`Node.js`,e.application.nodeVersion)}
          ${I(`Backend started`,P(e.application.backendStartTime))}
          ${I(`Backend uptime`,Mt(e.application.backendUptimeSeconds))}
          ${I(`Build/deployment date`,P(e.application.buildOrDeploymentDate))}
        </section>

        <section class="dashboard-section">
          <div class="section-header"><h2>Database</h2></div>
          ${I(`Status`,e.database.status)}
          ${I(`Database`,e.database.databaseName)}
          ${I(`Schema`,e.database.schemaName)}
          ${I(`Response time`,e.database.responseTimeMs===null?`Unavailable`:`${e.database.responseTimeMs} ms`)}
          ${I(`Pool max`,e.database.pool.max??`Unknown`)}
          ${I(`Pool total`,e.database.pool.total)}
          ${I(`Pool idle`,e.database.pool.idle)}
          ${I(`Pool waiting`,e.database.pool.waiting)}
          ${I(`PostgreSQL`,e.database.postgresVersion)}
        </section>

        <section class="dashboard-section">
          <div class="section-header"><h2>Server Resources</h2></div>
          ${I(`Platform`,e.server.platform)}
          ${I(`Hostname`,e.server.hostname)}
          ${I(`Process ID`,e.server.processId)}
          ${I(`Configured port`,e.server.configuredPort)}
          ${I(`Process memory`,N(e.server.processMemory.rss))}
          ${I(`System free memory`,N(e.server.systemMemory.freeBytes))}
          ${I(`System memory used`,`${e.server.systemMemory.usedPercent}%`)}
          ${I(`System uptime`,Mt(e.server.systemUptimeSeconds))}
          ${I(`CPU load`,e.server.cpuLoadAverage.map(e=>Number(e).toFixed(2)).join(` / `))}
        </section>

        <section class="dashboard-section">
          <div class="section-header"><h2>Performance</h2></div>
          ${I(`Slow threshold`,e.performance?.slowRequestThresholdMs?`${e.performance.slowRequestThresholdMs} ms`:`Unknown`)}
          ${I(`Recent requests`,e.performance?.recentRequestCount??0)}
          ${I(`Recent slow requests`,e.performance?.recentSlowRequestCount??0)}
          ${I(`Recent average`,`${e.performance?.recentAverageMs??0} ms`)}
          ${I(`Recent max`,`${e.performance?.recentMaxMs??0} ms`)}
          ${e.performance?.lastSlowRequest?I(`Last slow request`,`${e.performance.lastSlowRequest.method} ${e.performance.lastSlowRequest.route} - ${e.performance.lastSlowRequest.elapsedMs} ms`):I(`Last slow request`,`None`)}
        </section>

        <section class="dashboard-section health-active-users">
          <div class="section-header">
            <h2>Active Users</h2>
            ${F(`${e.activeUsers?.count??0} active`,(e.activeUsers?.count??0)>0?`Healthy`:`Unknown`)}
          </div>
          ${I(`Activity window`,`${e.activeUsers?.windowMinutes??10} minutes`)}
          ${It(e.activeUsers)}
        </section>

        <section class="dashboard-section">
          <div class="section-header"><h2>PDF Queue</h2></div>
          ${I(`Concurrency`,e.pdf?.concurrency??`Unknown`)}
          ${I(`Max bulk certificates`,e.pdf?.maxBulkCertificates??`Unknown`)}
          ${I(`Active`,e.pdf?.active??0)}
          ${I(`Queued`,e.pdf?.queued??0)}
          ${I(`Completed`,e.pdf?.completed??0)}
          ${I(`Failed`,e.pdf?.failed??0)}
        </section>

        <section class="dashboard-section">
          <div class="section-header"><h2>Disk Usage</h2></div>
          ${I(`Status`,e.disk.status)}
          ${I(`Filesystem`,e.disk.checkedPathLabel)}
          ${I(`Used`,N(e.disk.usedBytes))}
          ${I(`Available`,N(e.disk.availableBytes))}
          ${I(`Used percent`,e.disk.usedPercent===null?`Unknown`:`${e.disk.usedPercent}%`)}
          ${I(`Warning threshold`,`${e.thresholds.diskWarningPercent}%`)}
          ${I(`Critical threshold`,`${e.thresholds.diskCriticalPercent}%`)}
        </section>

        <section class="dashboard-section">
          <div class="section-header"><h2>Backup Status</h2></div>
          ${I(`Status`,e.backup.status)}
          ${I(`Directory`,e.backup.accessible?`Accessible`:`Not accessible`)}
          ${I(`Maximum expected age`,`${e.thresholds.backupMaxAgeHours} hours`)}
          ${I(`Message`,e.backup.message)}
          ${Ft(e.backup)}
          <h3>Database Backup</h3>
          ${Pt(e.backup.latestDatabaseBackup)}
          <h3>Uploads Backup</h3>
          ${Pt(e.backup.latestUploadsBackup)}
        </section>
      </div>
    </div>
  `}async function Rt(){if(!At()){jt();return}let e=document.querySelector(`#page`);if(e){e.innerHTML=`
    <h1>System Health</h1>
    <div class="filter-card">Loading system health...</div>
  `;try{let t=await fetch(`${y}/admin/system-info`),n=await t.json().catch(()=>({}));if(!t.ok){if(!At()){jt();return}e.innerHTML=`
        <h1>System Health</h1>
        <div class="filter-card">
          ${c(n.error||`Unable to load system health.`)}
        </div>
      `;return}if(!At()){jt();return}e.innerHTML=Lt(n)}catch{if(!At()){jt();return}e.innerHTML=`
      <h1>System Health</h1>
      <div class="filter-card">Unable to reach the system health endpoint.</div>
    `}}}function zt(){jt(),Rt(),window.systemHealthRefreshTimer=setInterval(Rt,kt)}window.refreshSystemHealth=Rt;function Bt(e){return String(e||``).trim()||`Not Issued`}window.location.pathname.toLowerCase().startsWith(`/atec/atec`)&&window.history.replaceState({},``,`/atec/`);var Vt=window.fetch.bind(window);window.fetch=function(e,t={}){let n=(typeof e==`string`?e:e?.url||``).startsWith(y);return Vt(e,{...t,credentials:n?`include`:t.credentials})};async function L(e){let t=await e.text();if(!t)return{};try{return JSON.parse(t)}catch{return{error:e.ok?`The server returned an unexpected response`:`The server returned an unexpected error. Please try again.`}}}var R=null,z=[],B=[],V=[],Ht=[],H=[],U=[],Ut={},W=[],Wt=null,Gt=!1,Kt=!1,qt=!1,Jt=!1,Yt=null,Xt=[],Zt=[],Qt=0,$t=`AIzaSyBFyADuLSmHwQd6eJUGEIZYtotZt6I8284`;function G(e){localStorage.setItem(`currentPage`,e),!(!qt||Jt)&&window.history.state?.atecPage!==e&&window.history.pushState({...window.history.state,atecPage:e},``,window.location.href)}function en(e){window.history.replaceState({...window.history.state,atecPage:e},``,window.location.href),qt=!0}var tn={portal:[`CUSTOMER`],dashboard:[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`],customers:[`ADMIN`,`MANAGER`,`INSPECTOR`],sites:[`ADMIN`,`MANAGER`,`INSPECTOR`],responsible:[`ADMIN`,`MANAGER`,`INSPECTOR`],sections:[`ADMIN`,`MANAGER`,`INSPECTOR`],assets:[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`],inspections:[`ADMIN`,`MANAGER`,`INSPECTOR`],visits:[`ADMIN`,`MANAGER`,`INSPECTOR`],"quick-inspection":[`ADMIN`,`MANAGER`,`INSPECTOR`],certificates:[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`,`CUSTOMER`],"customer-report":[`ADMIN`,`MANAGER`,`VIEWER`,`CUSTOMER`],she:[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`],criteria:[`ADMIN`],users:[`ADMIN`,`MANAGER`],"system-health":[`ADMIN`],profile:[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`,`CUSTOMER`]};function nn(e){return e===`portal`?R?.role===`CUSTOMER`:R?.role===`ADMIN`||(tn[e]||[]).includes(R?.role)}function rn(){document.querySelector(`#page`).innerHTML=`
    <div class="filter-card">
      <h2>Access denied</h2>
      <p>You do not have permission to view this page.</p>
    </div>
  `}function K(e){return nn(e)?!0:(rn(),!1)}function q(e,t,n){return nn(e)?`<button onclick="closeMobileMenu(); ${n}">${t}</button>`:``}function an(){return[`ADMIN`,`MANAGER`,`INSPECTOR`].includes(R?.role)}function on(){return R?.role===`ADMIN`}function sn(){if(Gt||document.querySelector(`#appUpdateNotice`))return;Gt=!0;let e=document.createElement(`div`);e.id=`appUpdateNotice`,e.className=`app-update-notice`,e.innerHTML=`
    <div>
      <strong>New version available</strong>
      <span>Refresh when you are ready to load the latest ATEC update.</span>
    </div>
    <button type="button" onclick="window.location.reload()">Refresh</button>
  `,document.body.appendChild(e)}async function cn(){try{let e=await Vt(`${`/`.replace(/\/$/,``)}/build-info.json?t=${Date.now()}`,{cache:`no-store`,credentials:`same-origin`});if(!e.ok)return;let t=await e.json();t.buildId&&t.buildId!==`2026-07-18T07-54-47-402Z`&&sn()}catch{}}function ln(){Kt||(Kt=!0,window.setTimeout(cn,3e4),window.setInterval(cn,6e4))}function un(){window.removePageScrollControls?.(),document.querySelector(`#pageScrollControls`)?.remove();let e=document.createElement(`div`);e.id=`pageScrollControls`,e.className=`page-scroll-controls`,e.setAttribute(`aria-label`,`Page navigation`),e.innerHTML=`
    <button type="button" class="page-scroll-button page-scroll-top" aria-label="Go to top of page" title="Go to top">
      <span aria-hidden="true">↑</span><span>Top</span>
    </button>
    <button type="button" class="page-scroll-button page-scroll-bottom" aria-label="Go to bottom of page" title="Go to bottom">
      <span aria-hidden="true">↓</span><span>Bottom</span>
    </button>
  `,document.body.appendChild(e);let t=e.querySelector(`.page-scroll-top`),n=e.querySelector(`.page-scroll-bottom`);t.addEventListener(`click`,()=>window.scrollTo({top:0,behavior:`smooth`})),n.addEventListener(`click`,()=>window.scrollTo({top:document.documentElement.scrollHeight,behavior:`smooth`}));let r=()=>{let r=window.scrollY||document.documentElement.scrollTop,i=document.documentElement.scrollHeight,a=i>window.innerHeight+240;e.classList.toggle(`is-visible`,a),t.disabled=r<80,n.disabled=r+window.innerHeight>=i-80};window.addEventListener(`scroll`,r,{passive:!0}),window.addEventListener(`resize`,r);let i=new ResizeObserver(r);i.observe(document.querySelector(`#page`)),window.removePageScrollControls=()=>{i.disconnect(),window.removeEventListener(`scroll`,r),window.removeEventListener(`resize`,r),e.remove(),window.removePageScrollControls=null},r()}function dn(){return[`ADMIN`,`MANAGER`].includes(R?.role)}function J(){return R?.role===`ADMIN`}function fn(){return[`ADMIN`,`MANAGER`,`INSPECTOR`].includes(R?.role)}function pn(e=``){window.removePageScrollControls?.(),document.querySelector(`#app`).innerHTML=`
    <div class="login-page">
      <div class="login-card">
        <img src="${De(`logo.jpg`)}" alt="ATEC Logo" class="login-logo">
        <h1>ATEC Login</h1>
        ${e?`<p class="login-error">${e}</p>`:``}
        <label>Username or Email</label>
        <input id="loginUsername" type="text" autocomplete="username">
        <label>Password</label>
        <input id="loginPassword" type="password" autocomplete="current-password">
        <button onclick="loginUser()">Login</button>
      </div>
    </div>
  `}window.loginUser=async function(){let e=document.querySelector(`#loginUsername`)?.value||``,t=document.querySelector(`#loginPassword`)?.value||``,n;try{n=await fetch(`${y}/auth/login`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({username:e,password:t})})}catch{pn(`Cannot connect to the ATEC backend. Please check that the backend is running.`);return}let r=await L(n);if(!n.ok){pn(r.error||`Login failed`);return}R=r.user,window.currentUser=R,G(R.role===`CUSTOMER`?`portal`:`dashboard`),await $()},window.logoutUser=async function(){await fetch(`${y}/auth/logout`,{method:`POST`}),R=null,window.currentUser=null,localStorage.removeItem(`currentPage`),pn()};var mn={username:e=>e.username,email:e=>e.email,full_name:e=>e.full_name,role:e=>e.role,lmi_number:e=>e.lmi_number,clientid:e=>gn(e.clientid),siteid:e=>_n(e.siteid),sectionid:e=>vn(e.sectionid),is_active:e=>+!!e.is_active,signature_image:e=>+!!e.signature_image};function hn(){return window.userManagementLookups||{customers:[],sites:[],sections:[]}}function gn(e){return hn().customers.find(t=>String(t.clientid)===String(e||``))?.clientname||``}function _n(e){return hn().sites.find(t=>String(t.siteid)===String(e||``))?.sitename||``}function vn(e){return hn().sections.find(t=>String(t.sectionid)===String(e||``))?.sectionname||``}function Y(e,t,n,r,i){return`
    <option value="">${c(i)}</option>
    ${e.map(e=>`
      <option value="${l(e[t])}" ${String(e[t])===String(r||``)?`selected`:``}>
        ${c(e[n]||`${i} ${e[t]}`)}
      </option>
    `).join(``)}
  `}function yn(){return window.userManagementSort=window.userManagementSort||{key:`username`,direction:`asc`},window.userManagementSort}function bn(e){let t=yn(),n=mn[t.key]||mn.username,r=t.direction===`desc`?-1:1;return[...e].sort((e,t)=>{let i=n(e),a=n(t),o=Number(i),s=Number(a);return i!==``&&a!==``&&!Number.isNaN(o)&&!Number.isNaN(s)?(o-s)*r:String(i||``).localeCompare(String(a||``),void 0,{numeric:!0,sensitivity:`base`})*r})}var xn=[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`],Sn=[`CUSTOMER`];function Cn(){return R?.role===`ADMIN`}function wn(){return[`ADMIN`,`MANAGER`].includes(R?.role)}function X(){return Cn()?(localStorage.getItem(`userManagementMode`)||`internal`)===`customers`?`customers`:`internal`:`customers`}function Tn(e){return e===`customers`?Sn:xn}function En(e,t){return t===`customers`?e.role===`CUSTOMER`:e.role!==`CUSTOMER`}function Dn(e=X()){let t=localStorage.getItem(`userStatusFilter:${e}`)||`both`;return[`active`,`inactive`].includes(t)?t:`both`}function On(e,t){if(t===`both`)return!0;let n=!!e.is_active;return t===`active`?n:!n}window.setUserStatusFilter=function(e){[`both`,`active`,`inactive`].includes(e)&&(localStorage.setItem(`userStatusFilter:${X()}`,e),showUserManagement())},window.showInternalUserManagement=function(){if(!Cn()){localStorage.setItem(`userManagementMode`,`customers`),showUserManagement();return}localStorage.setItem(`userManagementMode`,`internal`),showUserManagement()},window.showCustomerUserManagement=function(){localStorage.setItem(`userManagementMode`,`customers`),showUserManagement()},window.syncCustomerUsernameWithEmail=function(){if(X()!==`customers`)return;let e=document.querySelector(`#newUserEmail`),t=document.querySelector(`#newUserUsername`);e&&t&&(t.value=e.value.trim())};function Z(e,t){let n=yn(),r=n.key===t,i=r?n.direction:``;return`
    <span class="user-table-heading">
      <span>${e}</span>
      <button
        type="button"
        class="user-sort-btn ${r?`active ${i}`:``}"
        onclick="sortUserManagement('${t}')"
        aria-label="Sort ${e}"
        title="Sort ${e}"
      ></button>
    </span>
  `}window.sortUserManagement=function(e){let t=yn();window.userManagementSort={key:e,direction:t.key===e&&t.direction===`asc`?`desc`:`asc`},showUserManagement()},window.showUserManagement=async function(){if(!K(`users`))return;G(`users`);let[e,t,n,r]=await Promise.all([fetch(`${y}/users`),Q(`${y}/customers`,[]),Q(`${y}/sites`,[]),Q(`${y}/sections`,[])]),i=await e.json();if(!e.ok){alert(i.error||`Unable to load users`);return}window.userManagementLookups={customers:t,sites:n,sections:r};let a=X();localStorage.setItem(`userManagementMode`,a);let o=Tn(a),s=Dn(a),u=i.filter(e=>En(e,a)),d=bn(u.filter(e=>On(e,s))),f=a===`customers`?`Customer Portal Users`:`ATEC Users`,p=a===`customers`?`Create Customer Portal User`:`Create ATEC User`,ee=a===`customers`?`Customer login username is always the email address. Customer portal users are linked to the customer and site, not to one section.`:`Create ATEC staff login accounts here. Customer login accounts are managed separately under Customer Portal Users.`,m=a===`customers`?`This is where Kenny Naidoo and other customer logins will appear after you create them. Responsible Persons remain separate contact records.`:`This list is only for ATEC admins, managers, inspectors, and viewers.`;document.querySelector(`#page`).innerHTML=`
    <div class="user-management-page">
    <h1>${f}</h1>
    <p class="page-subtitle">${m}</p>

    <div class="filter-card user-management-mode-tabs">
      ${Cn()?`
        <button
          type="button"
          class="${a===`internal`?`active`:``}"
          onclick="showInternalUserManagement()"
        >
          ATEC Users
        </button>
      `:``}
      <button
        type="button"
        class="${a===`customers`?`active`:``}"
        onclick="showCustomerUserManagement()"
      >
        Customer Portal Users
      </button>
    </div>

    <div class="filter-card user-create-card">
      <h2>${p}</h2>
      <p>${ee}</p>
      <div class="asset-form-grid">
        <div class="form-group">
          <label>${a===`customers`?`Username (uses email)`:`Username`}</label>
          <input
            id="newUserUsername"
            type="text"
            ${a===`customers`?`readonly placeholder="Filled from email address"`:``}
          >
        </div>
        <div class="form-group">
          <label>Email</label>
          <input id="newUserEmail" type="email" ${a===`customers`?`oninput="syncCustomerUsernameWithEmail()"`:``}>
        </div>
        <div class="form-group">
          <label>Password</label>
          <input id="newUserPassword" type="password">
        </div>
        <div class="form-group">
          <label>Full Name</label>
          <input id="newUserFullName" type="text">
        </div>
        <div class="form-group">
          <label>Role</label>
          <select id="newUserRole">
            ${o.map(e=>`<option value="${e}">${e}</option>`).join(``)}
          </select>
        </div>
        <div class="form-group">
          <label>LMI Number</label>
          <input id="newUserLmi" type="text">
        </div>
        <div class="form-group">
          <label>Customer Name</label>
          <select id="newUserClientId">
            ${Y(t,`clientid`,`clientname`,``,`No customer selected`)}
          </select>
        </div>
        <div class="form-group">
          <label>Site Name</label>
          <select id="newUserSiteId">
            ${Y(n,`siteid`,`sitename`,``,`No site selected`)}
          </select>
        </div>
        ${a===`internal`?`
          <div class="form-group">
            <label>Section Name</label>
            <select id="newUserSectionId">
              ${Y(r,`sectionid`,`sectionname`,``,`No section selected`)}
            </select>
          </div>
        `:``}
      </div>
      <button onclick="createUser()">Create User</button>
    </div>

    <div class="filter-card user-signature-card">
      <div class="user-signature-copy">
        <h2>My Signature</h2>
        <p>Upload your inspector signature for new inspections saved under your login.</p>
      </div>
      <div class="user-signature-controls">
        <input id="mySignatureUpload" type="file" accept="image/*">
        <button onclick="uploadMySignature()">Upload Signature</button>
      </div>
    </div>

    <div class="user-management-table-wrap">
    <div class="user-list-toolbar">
      <p><strong>${d.length}</strong> of <strong>${u.length}</strong> ${a===`customers`?`customer portal user(s)`:`ATEC user(s)`} shown.</p>
      <div class="user-status-filter" role="group" aria-label="Filter users by active status">
        <span>Status:</span>
        ${[[`both`,`Both`],[`active`,`Active`],[`inactive`,`Inactive`]].map(([e,t])=>`
          <button
            type="button"
            class="${s===e?`active`:``}"
            onclick="setUserStatusFilter('${e}')"
            aria-pressed="${s===e}"
          >${t}</button>
        `).join(``)}
      </div>
    </div>
    <table class="user-management-table ${a===`customers`?`customer-users-table`:`internal-users-table`}">
      <thead>
        <tr>
          <th>${Z(`User`,`username`)}</th>
          <th>${Z(`Email`,`email`)}</th>
          <th>${Z(`Full Name`,`full_name`)}</th>
          <th>${Z(`Role`,`role`)}</th>
          <th>${Z(`LMI Number`,`lmi_number`)}</th>
          <th>${Z(`Customer Name`,`clientid`)}</th>
          <th>${Z(`Site Name`,`siteid`)}</th>
          ${a===`internal`?`<th>${Z(`Section Name`,`sectionid`)}</th>`:``}
          <th>${Z(`Active`,`is_active`)}</th>
          <th>${Z(`Signature`,`signature_image`)}</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ${d.length?d.map(e=>`
          <tr class="${e.is_active?``:`inactive-user-row`}">
            <td class="user-name-cell">${c(e.username)}</td>
            <td><input id="user-email-${l(e.user_id)}" value="${l(e.email||``)}"></td>
            <td><input id="user-name-${l(e.user_id)}" value="${l(e.full_name||``)}"></td>
            <td>
              <select id="user-role-${e.user_id}">
                ${o.map(t=>`
                  <option value="${t}" ${t===e.role?`selected`:``}>${t}</option>
                `).join(``)}
              </select>
            </td>
            <td><input id="user-lmi-${l(e.user_id)}" value="${l(e.lmi_number||``)}"></td>
            <td>
              <select id="user-client-${e.user_id}">
                ${Y(t,`clientid`,`clientname`,e.clientid,`No customer selected`)}
              </select>
            </td>
            <td>
              <select id="user-site-${e.user_id}">
                ${Y(n,`siteid`,`sitename`,e.siteid,`No site selected`)}
              </select>
            </td>
            ${a===`internal`?`
              <td>
                <select id="user-section-${e.user_id}">
                  ${Y(r,`sectionid`,`sectionname`,e.sectionid,`No section selected`)}
                </select>
              </td>
            `:``}
            <td class="user-active-cell">
              <input class="user-status-check" id="user-active-${e.user_id}" type="checkbox" ${e.is_active?`checked`:``}>
            </td>
            <td>
              <div class="user-signature-cell">
                <span class="${e.signature_image?`signature-status saved`:`signature-status`}">${e.signature_image?`Saved`:`-`}</span>
                <input id="user-signature-${e.user_id}" type="file" accept="image/*">
                <button type="button" class="secondary-small-btn" onclick="uploadUserSignature(${e.user_id})">Upload</button>
              </div>
            </td>
            <td class="user-row-actions">
              <div class="user-row-action-buttons">
                <button onclick="saveUser(${e.user_id})">Save</button>
                <button class="secondary-small-btn" onclick="resetUserPassword(${e.user_id})">Reset Password</button>
              </div>
            </td>
          </tr>
        `).join(``):`
          <tr>
            <td class="user-list-empty" colspan="${a===`internal`?11:10}">
              No ${s===`both`?``:`${s} `}${a===`customers`?`customer portal users`:`ATEC users`} found.
            </td>
          </tr>
        `}
      </tbody>
    </table>
    </div>
    </div>
  `},window.createUser=async function(){let e=X(),t=e===`customers`?`CUSTOMER`:document.querySelector(`#newUserRole`).value,n=document.querySelector(`#newUserClientId`).value,r=document.querySelector(`#newUserEmail`).value.trim(),i=e===`customers`?r:document.querySelector(`#newUserUsername`).value;if(e===`customers`&&!n){alert(`Please link this customer portal user to a customer.`);return}if(e===`customers`&&!r){alert(`Please enter the customer portal user email address.`);return}let a=await fetch(`${y}/users`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({username:i,email:r,password:document.querySelector(`#newUserPassword`).value,full_name:document.querySelector(`#newUserFullName`).value,role:t,lmi_number:document.querySelector(`#newUserLmi`).value,clientid:n,siteid:document.querySelector(`#newUserSiteId`).value,sectionid:e===`customers`?null:document.querySelector(`#newUserSectionId`)?.value||null})}),o=await a.json();if(!a.ok){alert(o.error||`Unable to create user`);return}alert(`User created successfully`),showUserManagement()},window.saveUser=async function(e){if(!e||e===`null`){alert(`This user record is missing an account ID. The list will refresh now.`),showUserManagement();return}let t=X(),n=await fetch(`${y}/users/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({email:document.querySelector(`#user-email-${e}`).value,full_name:document.querySelector(`#user-name-${e}`).value,role:document.querySelector(`#user-role-${e}`).value,lmi_number:document.querySelector(`#user-lmi-${e}`).value,clientid:document.querySelector(`#user-client-${e}`).value,siteid:document.querySelector(`#user-site-${e}`).value,sectionid:t===`customers`?null:document.querySelector(`#user-section-${e}`)?.value||null,is_active:document.querySelector(`#user-active-${e}`).checked})}),r=await n.json();if(!n.ok){alert(r.error||`Unable to save user`);return}alert(`User saved successfully`),showUserManagement()},window.uploadUserSignature=async function(e){if(!e||e===`null`){alert(`This user record is missing an account ID. The list will refresh now.`),showUserManagement();return}let t=document.querySelector(`#user-signature-${e}`)?.files[0];if(!t){alert(`Choose a signature image for this user`);return}let n=new FormData;n.append(`signature`,t);let r=await fetch(`${y}/users/${e}/signature`,{method:`POST`,body:n}),i=await L(r);if(!r.ok){alert(i.error||`Unable to upload signature`);return}alert(`Signature saved successfully`),showUserManagement()},window.resetUserPassword=async function(e){if(!e||e===`null`){alert(`This user record is missing an account ID. The list will refresh now.`),showUserManagement();return}let t=prompt(`Enter the new password for this user. It must be at least 8 characters.`);if(t===null)return;if(t.length<8){alert(`Password must be at least 8 characters`);return}let n=prompt(`Confirm the new password`);if(n===null)return;if(t!==n){alert(`Passwords do not match`);return}let r=await fetch(`${y}/users/${e}/reset-password`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({password:t})}),i=await L(r);if(!r.ok){alert(i.error||`Unable to reset password`);return}alert(`Password reset successfully`)},window.deleteUser=async function(e){if(!confirm(`Delete this user? This will deactivate the login and keep old records safe.`))return;let t=await fetch(`${y}/users/${e}`,{method:`DELETE`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to delete user`);return}showUserManagement()},window.uploadMySignature=async function(){let e=document.querySelector(`#mySignatureUpload`)?.files[0];if(!e){alert(`Choose a signature image`);return}let t=new FormData;t.append(`signature`,e);let n=await fetch(`${y}/users/me/signature`,{method:`POST`,body:t}),r=await n.json();if(!n.ok){alert(r.error||`Unable to upload signature`);return}R=r.user,window.currentUser=R,alert(`Signature saved successfully`),nn(`users`)&&localStorage.getItem(`currentPage`)===`users`?showUserManagement():showMyProfile()},window.showMyProfile=async function(){if(!K(`profile`))return;G(`profile`);let e=await fetch(`${y}/users/me`),t=await L(e);if(!e.ok){alert(t.error||`Unable to load your profile`);return}R=t.user,window.currentUser=R,document.querySelector(`#page`).innerHTML=`
    <h1>My Profile</h1>
    <div class="filter-card my-profile-card">
      <h2>Profile Details</h2>
      <div class="asset-form-grid">
        <div class="form-group">
          <label>Username</label>
          <input value="${l(R.username||``)}" disabled>
        </div>
        <div class="form-group">
          <label>Role</label>
          <input value="${l(R.role||``)}" disabled>
        </div>
        <div class="form-group">
          <label>Full Name</label>
          <input id="myProfileFullName" type="text" value="${l(R.full_name||``)}">
        </div>
        <div class="form-group">
          <label>Email</label>
          <input id="myProfileEmail" type="email" value="${l(R.email||``)}">
        </div>
        <div class="form-group">
          <label>LMI Number</label>
          <input id="myProfileLmi" type="text" value="${l(R.lmi_number||``)}">
        </div>
      </div>
      <button onclick="saveMyProfile()">Save Profile</button>
    </div>

    <div class="filter-card user-signature-card">
      <h2>My Signature</h2>
      <p>Your signature will be used on new inspection and load test certificates saved under your login.</p>
      <div class="profile-signature-status">
        Current signature: <strong>${R.signature_image?`Saved`:`Not uploaded yet`}</strong>
      </div>
      <input id="mySignatureUpload" type="file" accept="image/*">
      <button onclick="uploadMySignature()">Upload Signature</button>
    </div>
  `},window.saveMyProfile=async function(){let e=await fetch(`${y}/users/me`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({full_name:document.querySelector(`#myProfileFullName`)?.value||``,email:document.querySelector(`#myProfileEmail`)?.value||``,lmi_number:document.querySelector(`#myProfileLmi`)?.value||``})}),t=await L(e);if(!e.ok){alert(t.error||`Unable to save your profile`);return}R=t.user,window.currentUser=R,alert(`Profile saved successfully`),showMyProfile()};async function Q(e,t){let n=await fetch(e);if(!n.ok){if([401,403].includes(n.status))return t;let r=await n.json().catch(()=>({}));throw Error(r.error||`Unable to load ${e}`,{cause:{url:e,status:n.status}})}return n.json()}async function kn(e,t){try{return await Q(e,t)}catch(n){return console.error(`Unable to load optional data from ${e}:`,n),t}}async function An(e){let t=B.find(t=>String(t.assetid)===String(e));if(t)return t;let n=await fetch(`${y}/assets/${e}`),r=await n.json().catch(()=>({}));if(!n.ok)throw Error(r.error||`Asset not found`);return r}function jn(e,t={}){let n=t.url||``,r=[t.status?`Status ${t.status}`:``,n].filter(Boolean).join(` - `);document.querySelector(`#app`).innerHTML=`
    <div class="login-page">
      <div class="login-card">
        <img src="${De(`logo.jpg`)}" alt="ATEC Logo" class="login-logo">
        <h1>ATEC could not finish loading</h1>
        <p>${e}</p>
        ${r?`<p><strong>${c(r)}</strong></p>`:``}
        <button type="button" onclick="location.reload()">Reload</button>
      </div>
    </div>
  `}async function $(){ln();let n;try{n=await fetch(`${y}/auth/me`)}catch{pn(`Cannot connect to the ATEC backend. Please check that the backend is running.`);return}if(!n.ok){pn();return}R=(await n.json()).user,window.currentUser=R,B=[];try{let[e,t,n,r,i,a,o]=await Promise.all([Q(`${y}/customers`,[]),Q(`${y}/sites`,[]),Q(`${y}/responsible-persons`,[]),Q(`${y}/sections`,[]),Q(`${y}/equipment-types`,[]),kn(`${y}/dashboard/stats`,{}),Q(`${y}/equipment-type-criteria`,[])]);z=e,V=t,Ht=n,H=r,U=i,Ut=a,W=o,window.atecCriteria=W}catch(e){jn(e.message||`The app could not load its startup data.`,e.cause||{});return}document.querySelector(`#app`).innerHTML=`
    <div class="app">

     <div class="layout">

  <div class="sidebar">

          <div class="logo-container">
            <img src="${De(`logo.jpg`)}" alt="ATEC Logo" class="logo">
          </div>

          <div class="system-title">
            Inspection Platform
          </div>

    <div class="user-panel">
      <strong>${c(R.full_name)}</strong>
      <span>${c(R.role)}${R.lmi_number?` | LMI ${c(R.lmi_number)}`:``}</span>
    </div>

    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()" aria-expanded="false">
      Menu
    </button>

    <div class="mobile-menu-actions">
    ${q(`portal`,`Customer Portal`,`showCustomerPortal()`)}
    ${q(`dashboard`,`Dashboard`,`showDashboard()`)}
    ${q(`customers`,`Customer Setup`,`showCustomerSetup()`)}
    ${q(`sites`,`Sites`,`showSites()`)}
    ${q(`responsible`,`Responsible Persons`,`showResponsiblePersons()`)}
    ${q(`sections`,`Sections`,`showSections()`)}
    ${q(`assets`,`Assets`,`showAssetSetup()`)}
    ${q(`visits`,`On-Site Visits`,`showInspectionVisits()`)}
    ${q(`quick-inspection`,`Quick Inspection/Testing`,`showQuickInspection()`)}
    ${q(`certificates`,`Certificates`,`showCertificateSearch()`)}
    ${q(`customer-report`,`Reports`,`showCustomerDetailedReport()`)}
    ${q(`she`,`SLAMM`,`showRiskAssessments()`)}
    ${q(`criteria`,`Equipment Type Criteria`,`showEquipmentTypeCriteria()`)}
    ${Cn()?q(`users`,`ATEC Users`,`showInternalUserManagement()`):``}
    ${wn()?q(`users`,`Customer Portal Users`,`showCustomerUserManagement()`):``}
    ${q(`system-health`,`System Health`,`showSystemHealth()`)}
    ${q(`profile`,`My Profile`,`showMyProfile()`)}

    <button onclick="logoutUser()">Logout</button>
    </div>

  </div>

  <div class="content">
    <div id="page"></div>
  </div>

</div>

</div>

  `,un(),window.toggleMobileMenu=function(){let e=document.querySelector(`.sidebar`),t=document.querySelector(`.mobile-menu-toggle`),n=e?.classList.toggle(`mobile-menu-open`);t?.setAttribute(`aria-expanded`,n?`true`:`false`)},window.closeMobileMenu=function(){let e=document.querySelector(`.sidebar`),t=document.querySelector(`.mobile-menu-toggle`);e?.classList.remove(`mobile-menu-open`),t?.setAttribute(`aria-expanded`,`false`)},window.showDashboard=function(){K(`dashboard`)&&(G(`dashboard`),r(z,B,V,U,Ut),En())},window.showCustomerPortal=function(){K(`portal`)&&(G(`portal`),dt(R))};let o=localStorage.getItem(`customerArchiveMode`)||`active`;window.showCustomerSetup=function(e=o){K(`customers`)&&(o=e,G(`customers`),localStorage.setItem(`customerArchiveMode`,e),u(z,o))};function s(){return window.google?.maps?.importLibrary?Promise.resolve(window.google):Yt||(Yt=new Promise((e,t)=>{let n=`initAtecGoogleMaps${Date.now()}`;window[n]=()=>{delete window[n],e(window.google)};let r=document.createElement(`script`);r.src=`https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent($t)}&v=weekly&loading=async&libraries=places&callback=${n}`,r.async=!0,r.onerror=()=>t(Error(`Google Maps could not be loaded`)),document.head.appendChild(r)}),Yt)}function p(e=null){let t=!!e;document.querySelector(`#page`).innerHTML=`
    <div class="customer-form-page">
      <div class="customer-form-heading">
        <div>
          <h2>${t?`Edit Customer`:`Create Customer`}</h2>
          <p>${t?`Update the customer name or registered address.`:`Add the customer and their registered or head-office address.`}</p>
        </div>
        <button class="secondary-button" type="button" onclick="showCustomerSetup()">Back</button>
      </div>

      <form class="customer-form" onsubmit="saveCustomer(event, ${e?.clientid||`null`})">
        <div class="form-group customer-name-field">
          <label for="customerName">Customer name</label>
          <input id="customerName" type="text" value="${l(e?.clientname||``)}" required autofocus autocomplete="organization">
        </div>

        <div class="form-group customer-address-field">
          <label for="customerAddress">Registered or head-office address</label>
          <div id="customerAddressSearch">
            <input id="customerAddressManual" type="text" value="${l(e?.clientaddr||``)}" placeholder="Start typing a street address or business name" autocomplete="street-address" oninput="syncCustomerAddress(this.value)">
          </div>
          <input id="customerAddress" type="hidden" value="${l(e?.clientaddr||``)}">
          <p id="customerAddressStatus" class="field-note">Choose a suggestion to confirm the location, or enter the address manually.</p>
        </div>

        <div id="customerAddressMap" class="customer-address-map"  aria-label="Selected customer address map"></div>
        <p id="customerFormError" class="login-error" hidden></p>

        <div class="form-actions">
          <button id="saveCustomerButton" type="submit">${t?`Save Changes`:`Create Customer`}</button>
          <button class="secondary-button" type="button" onclick="showCustomerSetup()">Cancel</button>
        </div>
      </form>
    </div>
  `,g(e?.clientaddr||``)}async function g(e){let t=document.querySelector(`#customerAddress`),n=document.querySelector(`#customerAddressManual`),r=document.querySelector(`#customerAddressSearch`),i=document.querySelector(`#customerAddressMap`),a=document.querySelector(`#customerAddressStatus`);try{let o=await s();if(!t||!n||!r||!i||!o)return;let{PlaceAutocompleteElement:c}=await o.maps.importLibrary(`places`),l=new o.maps.Map(i,{center:{lat:-26.2041,lng:28.0473},zoom:10,mapTypeControl:!1,streetViewControl:!1,fullscreenControl:!1}),u=new o.maps.Circle({map:l,radius:24,strokeColor:`#ffffff`,strokeOpacity:1,strokeWeight:3,fillColor:`#2563eb`,fillOpacity:1,visible:!1}),d=new c;d.id=`customerAddressAutocomplete`,d.placeholder=`Start typing a street address or business name`,d.includedRegionCodes=[`za`],e&&(d.value=e),r.prepend(d),n.hidden=!0,d.addEventListener(`input`,()=>{t.value=d.value||``}),d.addEventListener(`gmp-select`,async({placePrediction:e})=>{let n=e.toPlace();if(await n.fetchFields({fields:[`formattedAddress`,`location`]}),!n.location){a.textContent=`No exact location was found. You can refine the address or keep it as entered.`;return}t.value=n.formattedAddress||d.value||``,d.value=t.value,l.setCenter(n.location),l.setZoom(16),u.setCenter(n.location),u.setVisible(!0),a.textContent=`Address confirmed from Google Maps.`})}catch{i.hidden=!0,a.textContent=`Address search is unavailable right now. You can still enter the address manually.`}}window.syncCustomerAddress=function(e){let t=document.querySelector(`#customerAddress`);t&&(t.value=e)};function te(){return Xt[Qt]||null}function _(){let e=te();if(!e){document.querySelector(`#page`).innerHTML=`
      <div class="address-review-complete">
        <h2>Address Review Complete</h2>
        <p>You have reached the end of this review list.</p>
        <button type="button" onclick="showCustomerSetup()">Return to Customer Setup</button>
      </div>
    `;return}Zt=[];let t=Xt.length-Qt;document.querySelector(`#page`).innerHTML=`
    <div class="address-review-page">
      <div class="customer-form-heading">
        <div>
          <h2>Find Missing Addresses</h2>
          <p>Reviewing ${Qt+1} of ${Xt.length}. ${t} customer${t===1?``:`s`} remaining in this pass.</p>
        </div>
        <button class="secondary-button" type="button" onclick="showCustomerSetup()">Close</button>
      </div>

      <div class="address-review-customer">
        <span>Customer</span>
        <strong>${c(e.clientname||`Customer ${e.clientid}`)}</strong>
        <small>Client ID ${c(e.clientid)}</small>
      </div>

      <div class="address-review-search">
        <div class="form-group">
          <label for="addressReviewQuery">Google search</label>
          <input id="addressReviewQuery" type="text" value="${l(`${e.clientname||``} South Africa`)}" onkeydown="if (event.key === 'Enter') { event.preventDefault(); searchAddressReview() }">
        </div>
        <button id="addressReviewSearchButton" type="button" onclick="searchAddressReview()">Search</button>
      </div>

      <p id="addressReviewMessage" class="field-note">Search by company name, then choose the correct branch or office.</p>
      <div id="addressReviewResults" class="address-review-results"></div>
      <div id="addressReviewMap" class="customer-address-map" hidden aria-label="Address result map"></div>

      <div class="form-actions address-review-footer">
        <button id="autoFillSingleAddressesButton" type="button" onclick="autoFillSingleCustomerAddresses()">Auto-fill Single Matches</button>
        <button class="secondary-button" type="button" onclick="skipAddressReviewCustomer()">Skip for Now</button>
        <button class="secondary-button" type="button" onclick="editClient(${e.clientid})">Enter Manually</button>
      </div>
    </div>
  `,window.searchAddressReview()}window.reviewMissingCustomerAddresses=function(){if(R?.role!==`ADMIN`){alert(`Only administrators can review and update missing customer addresses.`);return}if(Xt=z.filter(e=>!(e.archived===!0||e.archived===`true`)&&!String(e.clientaddr||``).trim()),Qt=0,!Xt.length){alert(`All active customers already have an address.`);return}_()},window.searchAddressReview=async function(){let e=document.querySelector(`#addressReviewQuery`)?.value.trim(),t=document.querySelector(`#addressReviewResults`),n=document.querySelector(`#addressReviewMessage`),r=document.querySelector(`#addressReviewSearchButton`);if(!(!e||!t||!n||!r)){r.disabled=!0,r.textContent=`Searching...`,n.textContent=`Searching Google Places...`,t.innerHTML=``,document.querySelector(`#addressReviewMap`).hidden=!0;try{let r=await s();if(!r)throw Error(`Google Maps is not configured`);let{Place:i}=await r.maps.importLibrary(`places`);if(Zt=((await i.searchByText({textQuery:e,fields:[`displayName`,`formattedAddress`,`location`,`businessStatus`],language:`en`,region:`za`,maxResultCount:5})).places||[]).filter(e=>e.formattedAddress&&e.location),!Zt.length){n.textContent=`No suitable matches were found. Refine the search or enter the address manually.`;return}n.textContent=`${Zt.length} possible match${Zt.length===1?``:`es`} found. Check the branch carefully before saving.`,t.innerHTML=Zt.map((e,t)=>`
      <div class="address-review-result">
        <button class="address-result-preview" type="button" onclick="previewAddressReviewResult(${t})">
          <strong>${c(e.displayName||`Google Maps result`)}</strong>
          <span>${c(e.formattedAddress)}</span>
          ${e.businessStatus&&e.businessStatus!==`OPERATIONAL`?`<small>${c(e.businessStatus.replaceAll(`_`,` `))}</small>`:``}
        </button>
        <button type="button" onclick="saveAddressReviewResult(${t})">Use Address</button>
      </div>
    `).join(``),window.previewAddressReviewResult(0)}catch(e){n.textContent=`Address search failed: ${e.message}`}finally{r.disabled=!1,r.textContent=`Search`}}},window.previewAddressReviewResult=async function(e){let t=Zt[e],n=document.querySelector(`#addressReviewMap`);if(!t?.location||!n)return;let r=await s();n.hidden=!1;let i=new r.maps.Map(n,{center:t.location,zoom:15,mapTypeControl:!1,streetViewControl:!1,fullscreenControl:!1});new r.maps.Circle({map:i,center:t.location,radius:24,strokeColor:`#ffffff`,strokeOpacity:1,strokeWeight:3,fillColor:`#2563eb`,fillOpacity:1}),document.querySelectorAll(`.address-result-preview`).forEach((t,n)=>{t.classList.toggle(`selected`,n===e)})},window.saveAddressReviewResult=async function(e){let t=te(),n=Zt[e],r=document.querySelector(`#addressReviewMessage`);if(!t||!n?.formattedAddress||!r)return;r.textContent=`Saving address...`;let i=await fetch(`${y}/customers/${t.clientid}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientname:t.clientname,clientaddr:n.formattedAddress})}),a=await L(i);if(!i.ok){r.textContent=a.error||`The address could not be saved.`;return}let o=z.find(e=>String(e.clientid)===String(t.clientid));o&&(o.clientaddr=a.clientaddr||n.formattedAddress),Qt+=1,_()},window.skipAddressReviewCustomer=function(){Qt+=1,_()};function oe(e){return String(e||``).toLowerCase().replace(/\b(pty|ltd|limited|incorporated|inc|cc|holdings|group|south africa|sa)\b/g,` `).replace(/[^a-z0-9]+/g,` `).trim()}function se(e,t){let n=oe(e),r=oe(t);if(!n||!r)return!1;if(n.includes(r)||r.includes(n))return!0;let i=n.split(` `).filter(e=>e.length>2),a=new Set(r.split(` `).filter(e=>e.length>2));return i.length?i.filter(e=>a.has(e)).length/i.length>=.75:!1}function ce(e){return new Promise(t=>window.setTimeout(t,e))}window.autoFillSingleCustomerAddresses=async function(){if(R?.role!==`ADMIN`){alert(`Only administrators can run automatic customer address matching.`);return}let e=document.querySelector(`#autoFillSingleAddressesButton`),t=document.querySelector(`#addressReviewMessage`);if(!e||!t)return;let n=z.filter(e=>!(e.archived===!0||e.archived===`true`)&&!String(e.clientaddr||``).trim());if(!n.length)return;e.disabled=!0;let{Place:r}=await(await s()).maps.importLibrary(`places`),i=0,a=0,o=0,c=0;for(let e=0;e<n.length;e+=1){let s=n[e];t.textContent=`Checking ${e+1} of ${n.length}: ${s.clientname}`;try{let e=((await r.searchByText({textQuery:`${s.clientname||``} South Africa`,fields:[`displayName`,`formattedAddress`,`location`,`businessStatus`],language:`en`,region:`za`,maxResultCount:2})).places||[]).filter(e=>e.formattedAddress&&e.location);if(e.length>1)a+=1;else if(e.length!==1||e[0].businessStatus===`CLOSED_PERMANENTLY`||!se(s.clientname,e[0].displayName))o+=1;else{let t=await fetch(`${y}/customers/${s.clientid}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientname:s.clientname,clientaddr:e[0].formattedAddress})}),n=await L(t);if(!t.ok)throw Error(n.error||`Address update failed`);s.clientaddr=n.clientaddr||e[0].formattedAddress,i+=1}}catch{c+=1}await ce(250)}Xt=z.filter(e=>!(e.archived===!0||e.archived===`true`)&&!String(e.clientaddr||``).trim()),Qt=0,_(),alert(`Automatic address pass complete.\n\n${i} single strong matches saved.\n${a} customers have multiple matches.\n${o} customers had no result or an uncertain name match.\n${c} searches or updates failed.\n\nThe remaining customers are ready for manual review.`)},window.addClient=function(){p()},window.editClient=function(e){let t=z.find(t=>String(t.clientid)===String(e));if(!t){alert(`Customer not found`);return}p(t)},window.saveCustomer=async function(e,t){e.preventDefault();let n=document.querySelector(`#customerName`)?.value.trim()||``,r=document.querySelector(`#customerAddress`)?.value.trim()||``,i=document.querySelector(`#saveCustomerButton`),a=document.querySelector(`#customerFormError`);if(n){i.disabled=!0,i.textContent=`Saving...`,a.hidden=!0;try{let e=await fetch(t?`${y}/customers/${t}`:`${y}/customers`,{method:t?`PUT`:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientname:n,clientaddr:r||null})}),i=await L(e);if(!e.ok)throw Error(i.error||`The customer could not be saved`);await $(),window.showCustomerSetup()}catch(e){a.textContent=e.message,a.hidden=!1,i.disabled=!1,i.textContent=t?`Save Changes`:`Create Customer`}}},window.saveClientChanges=function(e){document.querySelector(`.customer-form`)&&window.saveCustomer(new Event(`submit`,{cancelable:!0}),e)},window.filterCustomers=function(e=!1){e&&(window.customerCurrentPage=1);let t=document.querySelector(`#customerSearch`).value.toLowerCase(),n=i(z.filter(e=>{let n=e.archived===!0||e.archived===`true`,r=o===`all`||o===`active`&&!n||o===`archived`&&n,i=String(e.clientid||``).includes(t)||(e.clientname||``).toLowerCase().includes(t)||(e.clientaddr||``).toLowerCase().includes(t);return r&&i}),`customerCurrentPage`,`customerRowsPerPage`),r=document.querySelector(`.report-pagination-bar`);r&&(r.outerHTML=a({...n,label:`customers`,onPage:`goToCustomerPage`,onPageSize:`setCustomerRowsPerPage`}));let s=document.querySelector(`#customerTableBody`);s.innerHTML=n.rows.map(e=>{let t=e.archived===!0||e.archived===`true`;return`
      <tr>
        <td>${c(e.clientid)}</td>
        <td>${c(e.clientname||``)}</td>
        <td>${c(e.clientaddr||``)}</td>
        <td>${t?`Archived`:`Active`}</td>
        <td>
          <button onclick="editClient(${e.clientid})">Edit</button>

          ${J()?`
          ${t?`<button onclick="unarchiveClient(${e.clientid})">Restore</button>`:`<button onclick="archiveClient(${e.clientid})">Archive</button>`}
          `:``}
        </td>
      </tr>
    `}).join(``)},window.setCustomerRowsPerPage=function(e){window.customerRowsPerPage=Number(e)||25,window.customerCurrentPage=1,filterCustomers()},window.goToCustomerPage=function(e){window.customerCurrentPage=Math.max(1,Number(e)||1),filterCustomers()},window.archiveClient=async function(e){if(!J()){alert(`You do not have permission to archive customers.`);return}confirm(`Archive this client and all linked data?`)&&(await fetch(`${y}/customers/${e}/archive`,{method:`PUT`}),await $(),showCustomerSetup())},window.unarchiveClient=async function(e){if(!J()){alert(`You do not have permission to restore customers.`);return}await fetch(`${y}/customers/${e}/unarchive`,{method:`PUT`}),await $(),showCustomerSetup()};let pe=localStorage.getItem(`responsibleArchiveMode`)||`active`;function me(e){return e.filter(e=>!(e.archived===!0||e.archived===`true`))}function _e(e,t=``){let n=new Set;return Ht.filter(n=>String(n.clientid)===String(e)&&(!(n.archived===!0||n.archived===`true`)||String(n.personid)===String(t))).filter(e=>{let t=String(e.personid);return n.has(t)?!1:(n.add(t),!0)}).sort((e,t)=>(e.name||``).localeCompare(t.name||``))}function ve(e=``){return[...z].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``)).map(t=>`
      <option value="${l(t.clientid)}" ${String(t.clientid)===String(e)?`selected`:``}>
        ${c(t.clientname)}
      </option>
    `).join(``)}window.showResponsiblePersons=function(e=pe){K(`responsible`)&&(pe=e,G(`responsible`),localStorage.setItem(`responsibleArchiveMode`,e),f(Ht,pe))},window.showAddResponsiblePersonForm=function(){document.querySelector(`#page`).innerHTML=`
    <h2>Add Responsible Person</h2>

    <label>Customer</label>
    <select id="responsibleClient">
      <option value="">Select Customer</option>
      ${ve()}
    </select>

    <label>Responsible Person Name</label>
    <input id="responsibleName" type="text">

    <button onclick="saveResponsiblePerson()">
      Save
    </button>

    <button onclick="showResponsiblePersons()">
      Cancel
    </button>
  `},window.saveResponsiblePerson=async function(){let e=document.querySelector(`#responsibleClient`).value,t=document.querySelector(`#responsibleName`).value;if(!e||!t){alert(`Please complete all fields`);return}let n=await fetch(`${y}/responsible-persons`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:e,name:t})}),r=await n.json();if(!n.ok){alert(r.error);return}alert(`Responsible Person Saved`),await $(),showResponsiblePersons()},window.editResponsiblePerson=function(e){let t=Ht.find(t=>String(t.personid)===String(e));if(!t){alert(`Person not found`);return}document.querySelector(`#page`).innerHTML=`
    <h2>Edit Responsible Person</h2>

    <label>Customer</label>
    <select id="responsibleClient">
      <option value="">Select Customer</option>
      ${ve(t.clientid)}
    </select>

    <label>Name</label>
    <input
      id="editResponsibleName"
      type="text"
      value="${l(t.name||``)}"
    >

    <button onclick="saveResponsiblePersonChanges(${t.personid})">
      Save Changes
    </button>

    <button onclick="showResponsiblePersons()">
      Cancel
    </button>
  `},window.saveResponsiblePersonChanges=async function(e){Ht.find(t=>String(t.personid)===String(e));let t=document.querySelector(`#editResponsibleName`).value,n=document.querySelector(`#responsibleClient`).value;if(!n||!t){alert(`Please complete all fields`);return}let r=await fetch(`${y}/responsible-persons/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:n,name:t})}),i=await r.json();if(!r.ok){alert(i.error);return}alert(`Responsible Person Updated`),await $(),showResponsiblePersons()},window.filterResponsiblePersons=function(e=!1){e&&(window.responsibleCurrentPage=1);let t=document.querySelector(`#responsibleSearch`).value.toLowerCase().trim(),n=i(Ht.filter(e=>{let n=e.archived===!0||e.archived===`true`;return pe===`active`&&n||pe===`archived`&&!n?!1:String(e.personid||``).includes(t)||(e.clientname||``).toLowerCase().includes(t)||(e.sitename||``).toLowerCase().includes(t)||(e.sectionname||``).toLowerCase().includes(t)||(e.name||``).toLowerCase().includes(t)}),`responsibleCurrentPage`,`responsibleRowsPerPage`),r=document.querySelector(`.report-pagination-bar`);r&&(r.outerHTML=a({...n,label:`people`,onPage:`goToResponsiblePage`,onPageSize:`setResponsibleRowsPerPage`})),document.querySelector(`#responsibleTableBody`).innerHTML=n.rows.map(e=>`
      <tr>
        <td>${c(e.personid)}</td>
        <td>${c(e.clientname||``)}</td>
        <td>${c(e.sitename||`Not assigned`)}</td>
        <td>${c(e.sectionname||`Not assigned`)}</td>
        <td>${c(e.name||``)}</td>
        <td>${e.archived?`Archived`:`Active`}</td>
        <td>
          <button onclick="editResponsiblePerson(${e.personid})">
            Edit
          </button>
          ${J()?`
          ${e.archived?`<button onclick="unarchiveResponsiblePerson(${e.personid})">Restore</button>`:`<button onclick="archiveResponsiblePerson(${e.personid})">Archive</button>`}
          `:``}
        </td>
      </tr>
    `).join(``)},window.archiveResponsiblePerson=async function(e){if(!J()){alert(`You do not have permission to archive responsible persons.`);return}if(!confirm(`Archive this responsible person? Active sections and assets must be moved first.`))return;let t=await fetch(`${y}/responsible-persons/${e}/archive`,{method:`PUT`}),n=await L(t);if(!t.ok){alert(n.error||`Unable to archive responsible person.`);return}alert(`Responsible person archived`),await $(),showResponsiblePersons()},window.unarchiveResponsiblePerson=async function(e){if(!J()){alert(`You do not have permission to restore responsible persons.`);return}let t=await fetch(`${y}/responsible-persons/${e}/unarchive`,{method:`PUT`}),n=await L(t);if(!t.ok){alert(n.error||`Unable to restore responsible person.`);return}alert(`Responsible person restored`),await $(),showResponsiblePersons()},window.setResponsibleRowsPerPage=function(e){window.responsibleRowsPerPage=Number(e)||25,window.responsibleCurrentPage=1,filterResponsiblePersons()},window.goToResponsiblePage=function(e){window.responsibleCurrentPage=Math.max(1,Number(e)||1),filterResponsiblePersons()};let ye=localStorage.getItem(`sectionArchiveMode`)||`active`;window.showSections=function(e=ye){K(`sections`)&&(ye=e,G(`sections`),localStorage.setItem(`sectionArchiveMode`,e),ee(H,ye))},window.showAddSectionForm=function(){let e=[...z].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``));document.querySelector(`#page`).innerHTML=`
    <h2>Add Section</h2>

    <div class="form-row">

      <div class="form-group">
        <label>Client</label>
        <select id="sectionClient" onchange="filterSectionDropdowns()">
          <option value="">Select Client</option>
          ${e.map(e=>`
            <option value="${l(e.clientid)}">
              ${c(e.clientname)}
            </option>
          `).join(``)}
        </select>
      </div>

      <div class="form-group">
        <label>Site</label>
        <select id="sectionSite">
          <option value="">Select Client First</option>
        </select>
      </div>

      <div class="form-group">
        <label>Responsible Person</label>
        <select id="sectionResponsible">
          <option value="">Select Client First</option>
        </select>
      </div>

      <div class="form-group">
        <label>Section Name</label>
        <input id="sectionName" type="text" placeholder="Enter section name">
      </div>

    </div>

    <button onclick="saveSectionFromForm()">Save Section</button>
    <button onclick="showSections()">Cancel</button>
  `},window.filterSectionDropdowns=function(){let e=document.querySelector(`#sectionClient`).value,t=document.querySelector(`#sectionSite`),n=document.querySelector(`#sectionResponsible`);if(!e){t.innerHTML=`<option value="">Select Client First</option>`,n.innerHTML=`<option value="">Select Client First</option>`;return}let r=V.filter(t=>String(t.clientid)===String(e)&&!(t.archived===!0||t.archived===`true`)).sort((e,t)=>(e.sitename||``).localeCompare(t.sitename||``)),i=_e(e);t.innerHTML=`
    <option value="">Select Site</option>
    ${r.map(e=>`
      <option value="${l(e.siteid)}">
        ${c(e.sitename)}
      </option>
    `).join(``)}
  `,n.innerHTML=`
    <option value="">Select Responsible Person</option>
    ${i.map(e=>`
      <option value="${l(e.personid)}">
        ${c(e.name)}
      </option>
    `).join(``)}
  `},window.filterSections=function(e=!1){e&&(window.sectionCurrentPage=1);let n=document.querySelector(`#sectionSearchType`).value,r=document.querySelector(`#sectionSearch`).value.toLowerCase().trim(),o=i(t(H.filter(e=>{let t=e.archived===!0||e.archived===`true`;return ye===`active`&&t||ye===`archived`&&!t?!1:String(e[n]||``).toLowerCase().includes(r)}),`sections`,{client_section:e=>`${e.clientname||``}\u0000${e.sectionname||``}`,sectionid:e=>e.sectionid,clientname:e=>e.clientname,sitename:e=>e.sitename,responsiblename:e=>e.responsiblename,sectionname:e=>e.sectionname,archived:e=>e.archived?`Archived`:`Active`},`client_section`),`sectionCurrentPage`,`sectionRowsPerPage`),s=document.querySelector(`.report-pagination-bar`);s&&(s.outerHTML=a({...o,label:`sections`,onPage:`goToSectionPage`,onPageSize:`setSectionRowsPerPage`})),document.querySelector(`#sectionTableBody`).innerHTML=o.rows.map(e=>`
      <tr>
        <td>${c(e.sectionid)}</td>
        <td>${c(e.clientname||``)}</td>
        <td>${c(e.sitename||``)}</td>
        <td>${c(e.responsiblename||``)}</td>
        <td>${c(e.sectionname||``)}</td>
        <td>${e.archived?`Archived`:`Active`}</td>
        <td>
          <button onclick="editSection(${e.sectionid})">
            Edit
          </button>
          ${J()?`
          ${e.archived?`<button onclick="unarchiveSection(${e.sectionid})">Restore</button>`:`<button onclick="archiveSection(${e.sectionid})">Archive</button>`}
          `:``}
        </td>
      </tr>
    `).join(``)},window.setSectionRowsPerPage=function(e){window.sectionRowsPerPage=Number(e)||25,window.sectionCurrentPage=1,filterSections()},window.goToSectionPage=function(e){window.sectionCurrentPage=Math.max(1,Number(e)||1),filterSections()},window.editSection=function(e){let t=H.find(t=>String(t.sectionid)===String(e));if(!t){alert(`Section not found`);return}let n=_e(t.clientid,t.responsibleid);document.querySelector(`#page`).innerHTML=`
    <h2>Edit Section</h2>

    <label>Client</label>
    <input type="text" value="${l(t.clientname||``)}" disabled>

    <label>Site</label>
    <input type="text" value="${l(t.sitename||``)}" disabled>

    <label>Responsible Person</label>
    <select id="editSectionResponsible">
      <option value="" ${t.responsibleid?``:`selected`}>
        Select Responsible Person
      </option>
      ${n.map(e=>`
        <option
          value="${l(e.personid)}"
          ${String(e.personid)===String(t.responsibleid)?`selected`:``}
        >
          ${c(e.name)}
        </option>
      `).join(``)}
    </select>

    <label>Section Name</label>
    <input
      id="editSectionName"
      type="text"
      value="${l(t.sectionname||``)}"
    >

    <button onclick="saveSectionChanges(${t.sectionid})">
      Save Changes
    </button>

    <button onclick="showSections()">
      Cancel
    </button>
  `},window.saveSectionChanges=async function(e){let t=document.querySelector(`#editSectionResponsible`).value,n=document.querySelector(`#editSectionName`).value;if(!t||!n){alert(`Please complete all fields`);return}let r=await fetch(`${y}/sections/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({responsibleid:t,sectionname:n})}),i=await r.json();if(!r.ok){alert(`Error updating section: `+i.error);return}alert(`Section updated`),await $(),showSections()},window.saveSectionFromForm=async function(){let e=document.querySelector(`#sectionClient`).value,t=document.querySelector(`#sectionSite`).value,n=document.querySelector(`#sectionResponsible`).value,r=document.querySelector(`#sectionName`).value;if(!e||!t||!n||!r){alert(`Please complete all fields`);return}let i=await fetch(`${y}/sections`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:e,siteid:t,responsibleid:n,sectionname:r})}),a=await i.json();if(!i.ok){alert(`Error saving section: `+a.error);return}alert(`Section saved: `+a.sectionname),await $(),showSections()},window.archiveSection=async function(e){if(!J()){alert(`You do not have permission to archive sections.`);return}if(!confirm(`Archive this section? Active assets must be moved or archived first.`))return;let t=await fetch(`${y}/sections/${e}/archive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to archive section`);return}alert(`Section archived`),await $(),showSections()},window.unarchiveSection=async function(e){if(!J()){alert(`You do not have permission to restore sections.`);return}let t=await fetch(`${y}/sections/${e}/unarchive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to restore section`);return}alert(`Section restored`),await $(),showSections()};let be=localStorage.getItem(`siteArchiveMode`)||`active`;window.showSites=function(e=be){K(`sites`)&&(be=e,G(`sites`),localStorage.setItem(`siteArchiveMode`,e),d(V,be))},window.filterSites=function(e=!1){e&&(window.siteCurrentPage=1);let t=document.querySelector(`#siteSearch`).value.toLowerCase().trim(),n=i(V.filter(e=>{let n=e.archived===!0||e.archived===`true`,r=be===`all`||be===`active`&&!n||be===`archived`&&n,i=String(e.siteid||``).includes(t)||(e.clientname||``).toLowerCase().includes(t)||(e.sitename||``).toLowerCase().includes(t);return r&&i}),`siteCurrentPage`,`siteRowsPerPage`),r=document.querySelector(`.report-pagination-bar`);r&&(r.outerHTML=a({...n,label:`sites`,onPage:`goToSitePage`,onPageSize:`setSiteRowsPerPage`})),document.querySelector(`#siteTableBody`).innerHTML=n.rows.map(e=>`
      <tr>
        <td>${c(e.siteid)}</td>
        <td>${c(e.clientname||``)}</td>
        <td>${c(e.sitename||``)}</td>
        <td>${e.archived?`Archived`:`Active`}</td>
        <td>
          <button onclick="editSite(${e.siteid})">
            Edit
          </button>
          ${J()?`
          ${e.archived?`<button onclick="unarchiveSite(${e.siteid})">Restore</button>`:`<button onclick="archiveSite(${e.siteid})">Archive</button>`}
          `:``}
        </td>
      </tr>
    `).join(``)},window.setSiteRowsPerPage=function(e){window.siteRowsPerPage=Number(e)||25,window.siteCurrentPage=1,filterSites()},window.goToSitePage=function(e){window.siteCurrentPage=Math.max(1,Number(e)||1),filterSites()},window.editSite=function(e){let t=V.find(t=>String(t.siteid)===String(e));if(!t){alert(`Site not found`);return}document.querySelector(`#page`).innerHTML=`
    <h2>Edit Site</h2>

    <label>Client</label>
    <input
      type="text"
      value="${l(t.clientname||``)}"
      disabled
    >

    <label>Site Name</label>
    <input
      id="editSiteName"
      type="text"
      value="${l(t.sitename||``)}"
    >

    <button onclick="saveSiteChanges(${t.siteid})">
      Save Changes
    </button>

    <button onclick="showSites()">
      Cancel
    </button>
  `},window.saveSiteChanges=async function(e){let t=document.querySelector(`#editSiteName`).value;if(!t){alert(`Please enter a site name`);return}let n=await fetch(`${y}/sites/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({sitename:t})}),r=await n.json();if(!n.ok){alert(`Error updating site: `+r.error);return}alert(`Site updated`),await $(),showSites()},window.archiveSite=async function(e){if(!J()){alert(`You do not have permission to archive sites.`);return}if(!confirm(`Archive this site? Active assets must be moved or archived first.`))return;let t=await fetch(`${y}/sites/${e}/archive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to archive site`);return}alert(`Site archived`),await $(),showSites()},window.unarchiveSite=async function(e){if(!J()){alert(`You do not have permission to restore sites.`);return}let t=await fetch(`${y}/sites/${e}/unarchive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to restore site`);return}alert(`Site restored`),await $(),showSites()},window.showAddSiteForm=function(){let e=[...z].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``));document.querySelector(`#page`).innerHTML=`
    <h2>Add Site</h2>

    <label>Client</label>
    <select id="siteClient">
      <option value="">Select Client</option>
      ${e.map(e=>`
        <option value="${l(e.clientid)}">
          ${c(e.clientname)}
        </option>
      `).join(``)}
    </select>

    <label>Site Name</label>
    <input id="siteName" type="text" placeholder="Enter site name">

    <button onclick="saveSiteFromForm()">
      Save Site
    </button>

    <button onclick="showSites()">
      Cancel
    </button>
  `},window.saveSiteFromForm=async function(){let e=document.querySelector(`#siteClient`).value,t=document.querySelector(`#siteName`).value;if(!e||!t){alert(`Please complete all fields`);return}let n=await fetch(`${y}/sites`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:e,sitename:t})}),r=await n.json();if(!n.ok){alert(`Error saving site: `+r.error);return}alert(`Site saved: `+r.sitename),await $(),showSites()},window.showAssetSetup=async function(){if(!K(`assets`))return;G(`assets`);let e=window.assetListState||{};window.assetCurrentPage=e.currentPage||window.assetCurrentPage||1,window.assetRowsPerPage=e.rowsPerPage||window.assetRowsPerPage||25,await qe()},window.showRiskAssessments=async function(){K(`she`)&&(G(`she`),window.canWriteRiskAssessments=[`ADMIN`,`MANAGER`,`INSPECTOR`].includes(R?.role),await Tt(B,window.canWriteRiskAssessments))},window.loadRiskAssessments=async function(){let e=await fetch(`${y}/she/risk-assessments`),t=await e.json();if(!e.ok){alert(t.error||`Unable to load risk assessments`);return}window.riskAssessments=t,Et(window.riskAssessments,window.canWriteRiskAssessments)},window.filterRiskAssessments=function(){Et(window.riskAssessments||[],window.canWriteRiskAssessments)},window.downloadRiskAssessments=async function(e=`pdf`){let t=new URLSearchParams,n=document.querySelector(`#riskSearch`)?.value||``,r=document.querySelector(`#riskStatusFilter`)?.value||``;n&&t.append(`search`,n),r&&t.append(`status`,r);let i=e===`xlsx`?`xlsx`:`pdf`,a=await fetch(`${y}/she/risk-assessments.${i}?${t.toString()}`);if(!a.ok){let e=await L(a);alert(e.error||`Unable to download risk assessment register`);return}let o=await a.blob(),s=URL.createObjectURL(o),c=document.createElement(`a`);c.href=s,c.download=`ATEC-SHE-Risk-Register.${i}`,document.body.appendChild(c),c.click(),c.remove(),URL.revokeObjectURL(s)};function xe(e){return Array.from(document.querySelectorAll(e)).filter(e=>e.checked).map(e=>e.value)}function we(e,t=[]){let n=Array.isArray(t)?t:[];document.querySelectorAll(e).forEach(e=>{e.checked=n.includes(e.value)})}function Ee(e){return Array.from(document.querySelectorAll(e)).reduce((e,t)=>(e[t.dataset.key]=t.value||``,e),{})}function x(e,t={}){document.querySelectorAll(e).forEach(e=>{e.value=t?.[e.dataset.key]||``})}function Oe(){return Array.from(document.querySelectorAll(`.slamm-team-row`)).map(e=>({name:e.querySelector(`.slamm-team-name`)?.value?.trim()||``,surname:e.querySelector(`.slamm-team-surname`)?.value?.trim()||``,signature:e.querySelector(`.slamm-team-signature`)?.value?.trim()||``})).filter(e=>e.name||e.surname||e.signature)}function ke(e=[]){Array.from(document.querySelectorAll(`.slamm-team-row`)).forEach((t,n)=>{let r=Array.isArray(e)&&e[n]||{};t.querySelector(`.slamm-team-name`).value=r.name||``,t.querySelector(`.slamm-team-surname`).value=r.surname||``,t.querySelector(`.slamm-team-signature`).value=r.signature||``})}window.saveRiskAssessment=async function(){let e=document.querySelector(`#riskId`)?.value||``,t={assetid:document.querySelector(`#riskAssetId`)?.value||null,assessment_date:document.querySelector(`#riskAssessmentDate`)?.value,assessment_time:document.querySelector(`#riskAssessmentTime`)?.value||null,activity:document.querySelector(`#riskActivity`)?.value,hazard:document.querySelector(`#riskHazard`)?.value,hazard_categories:xe(`.risk-hazard-category`),stop_questions:Ee(`.slamm-stop-question`),consequence:document.querySelector(`#riskConsequence`)?.value,initial_severity:document.querySelector(`#riskInitialSeverity`)?.value,initial_likelihood:document.querySelector(`#riskInitialLikelihood`)?.value,controls:document.querySelector(`#riskControls`)?.value,residual_severity:document.querySelector(`#riskResidualSeverity`)?.value,residual_likelihood:document.querySelector(`#riskResidualLikelihood`)?.value,action_required:document.querySelector(`#riskActionRequired`)?.value,manage_plan:document.querySelector(`#riskManagePlan`)?.value,monitor_notes:document.querySelector(`#riskMonitorNotes`)?.value,review_questions:Ee(`.slamm-review-question`),additional_notes:document.querySelector(`#riskAdditionalNotes`)?.value,team_members:Oe(),responsible_signoff_name:document.querySelector(`#riskResponsibleSignoffName`)?.value,supervisor_signoff_name:document.querySelector(`#riskSupervisorSignoffName`)?.value,responsible_person:document.querySelector(`#riskResponsiblePerson`)?.value,due_date:document.querySelector(`#riskDueDate`)?.value||null,status:document.querySelector(`#riskStatus`)?.value||`OPEN`};if(!t.activity||!t.hazard){alert(`Activity and hazard are required`);return}let n=await fetch(e?`${y}/she/risk-assessments/${e}`:`${y}/she/risk-assessments`,{method:e?`PUT`:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(t)}),r=await n.json();if(!n.ok){alert(r.error||`Unable to save risk assessment`);return}alert(`Risk assessment saved successfully`),await showRiskAssessments()},window.editRiskAssessment=function(e){let t=(window.riskAssessments||[]).find(t=>String(t.riskid)===String(e));if(t){if(!document.querySelector(`#riskId`)){let e=document.createElement(`input`);e.type=`hidden`,e.id=`riskId`,document.querySelector(`.filter-card`).appendChild(e)}document.querySelector(`#riskId`).value=t.riskid,document.querySelector(`#riskAssetId`).value=t.assetid||``,document.querySelector(`#riskAssessmentDate`).value=t.assessment_date?t.assessment_date.split(`T`)[0]:``,document.querySelector(`#riskAssessmentTime`).value=t.assessment_time?String(t.assessment_time).slice(0,5):``,document.querySelector(`#riskStatus`).value=t.status||`OPEN`,document.querySelector(`#riskActivity`).value=t.activity||``,document.querySelector(`#riskHazard`).value=t.hazard||``,we(`.risk-hazard-category`,t.hazard_categories||[]),x(`.slamm-stop-question`,t.stop_questions||{}),document.querySelector(`#riskConsequence`).value=t.consequence||``,document.querySelector(`#riskInitialSeverity`).value=t.initial_severity||3,document.querySelector(`#riskInitialLikelihood`).value=t.initial_likelihood||3,document.querySelector(`#riskControls`).value=t.controls||``,document.querySelector(`#riskResidualSeverity`).value=t.residual_severity||2,document.querySelector(`#riskResidualLikelihood`).value=t.residual_likelihood||2,document.querySelector(`#riskActionRequired`).value=t.action_required||``,document.querySelector(`#riskManagePlan`).value=t.manage_plan||``,document.querySelector(`#riskMonitorNotes`).value=t.monitor_notes||``,x(`.slamm-review-question`,t.review_questions||{}),document.querySelector(`#riskAdditionalNotes`).value=t.additional_notes||``,ke(t.team_members||[]),document.querySelector(`#riskResponsibleSignoffName`).value=t.responsible_signoff_name||``,document.querySelector(`#riskSupervisorSignoffName`).value=t.supervisor_signoff_name||``,document.querySelector(`#riskResponsiblePerson`).value=t.responsible_person||``,document.querySelector(`#riskDueDate`).value=t.due_date?t.due_date.split(`T`)[0]:``,window.scrollTo({top:0,behavior:`smooth`})}},window.archiveRiskAssessment=async function(e){if(!confirm(`Archive this risk assessment?`))return;let t=await fetch(`${y}/she/risk-assessments/${e}/archive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to archive risk assessment`);return}await window.loadRiskAssessments()},window.openAssetQrLabel=function(e){window.open(`${y}/assets/${e}/qr-label.pdf`,`_blank`)};async function je(e){if(!dn())return null;let t=await fetch(`${y}/assets/${e}/nfc`);return t.ok?t.json():null}function Me(e,t){if(!dn())return``;if(!t)return`
      <div class="nfc-management-panel">
        <div class="nfc-management-header">
          <h4>NFC Tag</h4>
          <strong>Unavailable</strong>
        </div>
        <p class="nfc-writing-note">NFC management could not be loaded. Confirm the NFC database migration has been applied and try again.</p>
      </div>
    `;let n=!!(t.nfc_enabled&&t.nfc_url),r=t.nfc_issued_at?t.nfc_issued_at.split(`T`)[0]:`-`,i=t.nfc_last_scanned_at?t.nfc_last_scanned_at.split(`T`)[0]:`-`,a=Number(t.nfc_scan_count||0);return`
    <div class="nfc-management-panel">
      <div class="nfc-management-header">
        <h4>NFC Tag</h4>
        <strong>${n?`Enabled`:t.nfc_revoked_at?`Revoked`:`Not issued`}</strong>
      </div>
      <div class="quick-detail-grid">
        <p><span>Issue Date</span><strong>${c(r)}</strong></p>
        <p><span>Last Scanned</span><strong>${c(i)}</strong></p>
        <p><span>Scan Count</span><strong>${c(a)}</strong></p>
        <p class="quick-wide"><span>NFC URL</span><strong>${c(t.nfc_url||`Generate a token to create a URL`)}</strong></p>
      </div>
      <div class="form-actions quick-result-actions">
        ${n?`
          <button type="button" onclick="copyAssetNfcUrl('${l(t.nfc_url)}')">Copy NFC URL</button>
          <button type="button" onclick="window.open('${l(t.nfc_url)}', '_blank')">Preview Tap</button>
          <button type="button" onclick="rotateAssetNfcToken(${e.assetid})">Replace Token</button>
          <button type="button" class="danger-btn" onclick="revokeAssetNfcToken(${e.assetid})">Revoke NFC</button>
        `:`
          <button type="button" onclick="generateAssetNfcToken(${e.assetid})">Generate NFC URL</button>
        `}
      </div>
      <p class="nfc-writing-note">Write the copied HTTPS URL as an NDEF URI record. Test the tag before locking it read-only.</p>
    </div>
  `}async function Ne(e){let t=document.querySelector(`#editAssetNfcPanel`);if(t){t.innerHTML=Me(await An(e),await je(e));return}await quickOpenAsset(e)}window.copyAssetNfcUrl=async function(e){e&&(await navigator.clipboard.writeText(e),alert(`NFC URL copied.`))},window.generateAssetNfcToken=async function(e){let t=await fetch(`${y}/assets/${e}/nfc`,{method:`POST`}),n=await t.json();if(!t.ok){alert(n.error||`Could not generate NFC URL.`);return}await Ne(e)},window.rotateAssetNfcToken=async function(e){if(!confirm(`Replace this NFC token? Existing written NFC tags for this asset will stop working.`))return;let t=await fetch(`${y}/assets/${e}/nfc/rotate`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Could not replace NFC token.`);return}await Ne(e)},window.revokeAssetNfcToken=async function(e){if(!confirm(`Revoke NFC access for this asset? Existing written NFC tags will stop working.`))return;let t=await fetch(`${y}/assets/${e}/nfc`,{method:`DELETE`}),n=await t.json();if(!t.ok){alert(n.error||`Could not revoke NFC access.`);return}await Ne(e)};function S(){let e=new URLSearchParams(window.location.search||``),t=String(e.get(`nfc`)||``).trim(),n=String(e.get(`qr`)||``).trim();return t?{type:`nfc`,value:t}:n?{type:`qr`,value:n}:null}async function Pe(e){let t=document.querySelector(`#quickInspectionResult`);if(!e||!t)return!1;t.innerHTML=`<p>Opening asset...</p>`;let n=e.type===`nfc`?`/assets/nfc/${encodeURIComponent(e.value)}`:`/assets/qr/${encodeURIComponent(e.value)}`,r=await fetch(`${y}${n}`),i=await r.json();return r.ok?(quickOpenAsset(i.assetid),!0):(t.innerHTML=`
      <div class="filter-card">
        <h2>Asset tag unavailable</h2>
        <p>${c(i.error||`This asset tag could not be opened.`)}</p>
      </div>
    `,!1)}function Fe(){return[`ADMIN`,`MANAGER`].includes(R?.role)}function Ie(e){return!(e?.archived===!0||e?.archived===`true`)}window.showInspectionVisits=async function(){K(`visits`)&&(G(`visits`),document.querySelector(`#page`).innerHTML=`
    <h2>On-Site Inspection Visits</h2>

    ${Fe()?`
      <div class="filter-card visit-create-card">
        <h3>Create Visit</h3>
        <div class="form-row">
          <div class="form-group">
            <label>Customer</label>
            <select id="visitClientId" onchange="renderVisitSiteOptions()">
              <option value="">Select customer</option>
              ${me(z).map(e=>`<option value="${l(e.clientid)}">${c(e.clientname||``)}</option>`).join(``)}
            </select>
          </div>
          <div class="form-group">
            <label>Site</label>
            <select id="visitSiteId" onchange="renderVisitSectionOptions()">
              <option value="">Select site</option>
            </select>
          </div>
          <div class="form-group">
            <label>Section</label>
            <select id="visitSectionId">
              <option value="">All sections</option>
            </select>
          </div>
          <div class="form-group">
            <label>Scope</label>
            <select id="visitType">
              <option value="VISUAL">Visual inspection</option>
              <option value="LOADTEST">Load test</option>
              <option value="COMBINED" selected>Combined</option>
              <option value="SURVEY">Survey / asset verification</option>
            </select>
          </div>
          <div class="form-group">
            <label>Due Cutoff</label>
            <input id="visitDueCutoff" type="date" value="${j()}">
          </div>
        </div>
        <div class="form-actions">
          <button type="button" onclick="previewInspectionVisit()">Preview Due Assets</button>
          <button type="button" class="load-test-btn" onclick="createInspectionVisit()">Create Visit</button>
        </div>
        <div id="visitPreviewResult"></div>
      </div>
    `:``}

    <div class="filter-card">
      <h3>Open / Recent Visits</h3>
      <div id="inspectionVisitList"><p>Loading visits...</p></div>
    </div>
  `,renderVisitSiteOptions(),await ze())},window.renderVisitSiteOptions=function(){let e=document.querySelector(`#visitClientId`)?.value||``,t=document.querySelector(`#visitSiteId`);t&&(t.innerHTML=`<option value="">Select site</option>`+V.filter(t=>String(t.clientid)===String(e)&&Ie(t)).sort((e,t)=>(e.sitename||``).localeCompare(t.sitename||``)).map(e=>`<option value="${l(e.siteid)}">${c(e.sitename||``)}</option>`).join(``),renderVisitSectionOptions())},window.renderVisitSectionOptions=function(){let e=document.querySelector(`#visitClientId`)?.value||``,t=document.querySelector(`#visitSiteId`)?.value||``,n=document.querySelector(`#visitSectionId`);n&&(n.innerHTML=`<option value="">All sections</option>`+H.filter(n=>String(n.clientid)===String(e)&&String(n.siteid)===String(t)&&Ie(n)).sort((e,t)=>(e.sectionname||``).localeCompare(t.sectionname||``)).map(e=>`<option value="${l(e.sectionid)}">${c(e.sectionname||``)}</option>`).join(``))};function Le(){return{clientid:document.querySelector(`#visitClientId`)?.value||null,siteid:document.querySelector(`#visitSiteId`)?.value||null,sectionid:document.querySelector(`#visitSectionId`)?.value||null,visit_type:document.querySelector(`#visitType`)?.value||`COMBINED`,due_cutoff:document.querySelector(`#visitDueCutoff`)?.value||j(),visit_status:`DRAFT`}}window.previewInspectionVisit=async function(){let e=await fetch(`${y}/inspection-visits/preview`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(Le())}),t=await e.json(),n=document.querySelector(`#visitPreviewResult`);if(!n)return;if(!e.ok){n.innerHTML=`<p class="login-error">${c(t.error||`Preview failed`)}</p>`;return}let r=document.querySelector(`#visitType`)?.value===`SURVEY`,i=t.coverage_summary||{total:0,completed:0,outstanding:0},a=Number(i.total)?Math.round(Number(i.completed)/Number(i.total)*100):0;window.currentVisitPreviewReport={result:t,isSurvey:r,customer:document.querySelector(`#visitClientId`)?.selectedOptions?.[0]?.textContent||``,site:document.querySelector(`#visitSiteId`)?.selectedOptions?.[0]?.textContent||``,section:document.querySelector(`#visitSectionId`)?.selectedOptions?.[0]?.textContent||`All sections`,scope:document.querySelector(`#visitType`)?.selectedOptions?.[0]?.textContent||``,dueCutoff:document.querySelector(`#visitDueCutoff`)?.value||``},n.innerHTML=`
    <div class="form-actions visit-preview-actions">
      <button type="button" onclick="printVisitPreviewTables()">Print Tables</button>
      <button type="button" class="load-test-btn" onclick="exportVisitPreviewTables()">Export CSV</button>
    </div>
    ${r?``:`
      <h4>Current Inspection Coverage</h4>
      <div class="visit-count-grid">
        <div><span>Total Registered Assets</span><strong>${c(i.total||0)}</strong></div>
        <div><span>Current / Done</span><strong>${c(i.completed||0)}</strong></div>
        <div><span>Outstanding by Cutoff</span><strong>${c(i.outstanding||0)}</strong></div>
        <div><span>Coverage</span><strong>${c(a)}%</strong></div>
      </div>
      <div class="visit-progress-table-wrap">
        <table class="visit-progress-table visit-preview-table">
          <thead><tr><th>Equipment Type</th><th>Total Assets</th><th>Current / Done</th><th>Outstanding</th><th>Coverage</th></tr></thead>
          <tbody>
            ${(t.coverage_by_equipment_type||[]).map(e=>{let t=Number(e.total)?Math.round(Number(e.completed)/Number(e.total)*100):0;return`<tr><th scope="row">${c(e.equipment_type)}</th><td>${c(e.total)}</td><td>${c(e.completed)}</td><td>${c(e.outstanding)}</td><td>${c(t)}%</td></tr>`}).join(``)||`<tr><td colspan="5">No registered assets found.</td></tr>`}
            <tr class="visit-progress-total"><th scope="row">Overall Total</th><td>${c(i.total||0)}</td><td>${c(i.completed||0)}</td><td>${c(i.outstanding||0)}</td><td>${c(a)}%</td></tr>
          </tbody>
        </table>
      </div>
    `}
    <h4>${r?`Assets Included in Survey`:`Work Due for This Visit`}</h4>
    <div class="visit-count-grid">
      <div><span>Total</span><strong>${c(t.summary.total)}</strong></div>
      <div><span>Visual Due</span><strong>${c(t.summary.visual_due)}</strong></div>
      <div><span>Load Tests Due</span><strong>${c(t.summary.loadtest_due)}</strong></div>
      <div><span>Both Due</span><strong>${c(t.summary.both_due)}</strong></div>
      <div><span>Overdue</span><strong>${c(t.summary.overdue)}</strong></div>
    </div>
    <div class="visit-progress-table-wrap">
      <table class="visit-progress-table visit-preview-table">
        <thead>
          <tr><th>Equipment Type</th><th>Assets Included</th><th>Visual Due</th><th>Load Tests Due</th><th>Both Due</th><th>Overdue</th></tr>
        </thead>
        <tbody>
          ${(t.equipment_type_summary||[]).map(e=>`
            <tr>
              <th scope="row">${c(e.equipment_type)}</th>
              <td>${c(e.total||0)}</td>
              <td>${c(e.visual_due||0)}</td>
              <td>${c(e.loadtest_due||0)}</td>
              <td>${c(e.both_due||0)}</td>
              <td>${c(e.overdue||0)}</td>
            </tr>
          `).join(``)||`<tr><td colspan="6">No assets match this visit scope and cutoff date.</td></tr>`}
        </tbody>
      </table>
    </div>
  `};function Re(e){return`"${String(e??``).replace(/"/g,`""`)}"`}window.exportVisitPreviewTables=function(){let e=window.currentVisitPreviewReport;if(!e)return;let{result:t,isSurvey:n}=e,r=[[`On-Site Inspection Coverage Report`],[`Customer`,e.customer],[`Site`,e.site],[`Section`,e.section],[`Scope`,e.scope],[`Due Cutoff`,e.dueCutoff],[]];n||r.push([`Current Inspection Coverage`],[`Equipment Type`,`Total Assets`,`Current / Done`,`Outstanding`,`Coverage %`],...(t.coverage_by_equipment_type||[]).map(e=>[e.equipment_type,e.total,e.completed,e.outstanding,Number(e.total)?Math.round(Number(e.completed)/Number(e.total)*100):0]),[]),r.push([n?`Assets Included in Survey`:`Work Due for This Visit`],[`Equipment Type`,`Assets Included`,`Visual Due`,`Load Tests Due`,`Both Due`,`Overdue`],...(t.equipment_type_summary||[]).map(e=>[e.equipment_type,e.total,e.visual_due,e.loadtest_due,e.both_due,e.overdue]));let i=`﻿`+r.map(e=>e.map(Re).join(`,`)).join(`\r
`),a=new Blob([i],{type:`text/csv;charset=utf-8`}),o=document.createElement(`a`),s=(e.site||`site`).replace(/[^a-z0-9]+/gi,`-`).replace(/^-|-$/g,``);o.href=URL.createObjectURL(a),o.download=`inspection-coverage-${s}-${e.dueCutoff||j()}.csv`,document.body.appendChild(o),o.click(),o.remove(),URL.revokeObjectURL(o.href)},window.printVisitPreviewTables=function(){let e=window.currentVisitPreviewReport;if(!e)return;let{result:t,isSurvey:n}=e,r=(t.coverage_by_equipment_type||[]).map(e=>{let t=Number(e.total)?Math.round(Number(e.completed)/Number(e.total)*100):0;return`<tr><th>${c(e.equipment_type)}</th><td>${c(e.total)}</td><td>${c(e.completed)}</td><td>${c(e.outstanding)}</td><td>${c(t)}%</td></tr>`}).join(``),i=(t.equipment_type_summary||[]).map(e=>`
    <tr><th>${c(e.equipment_type)}</th><td>${c(e.total)}</td><td>${c(e.visual_due)}</td><td>${c(e.loadtest_due)}</td><td>${c(e.both_due)}</td><td>${c(e.overdue)}</td></tr>
  `).join(``),a=window.open(``,`_blank`);a.document.write(`
    <style>
      body { color: #172033; font-family: Arial, sans-serif; margin: 28px; }
      h1 { margin-bottom: 5px; } h2 { margin-top: 24px; }
      .details { color: #475569; line-height: 1.6; }
      table { border-collapse: collapse; font-size: 12px; width: 100%; }
      th, td { border: 1px solid #cbd5e1; padding: 8px; text-align: right; }
      th:first-child { text-align: left; } thead th { background: #e8f1fb; }
      @media print { body { margin: 10mm; } }
    </style>
    <h1>On-Site Inspection Coverage Report</h1>
    <div class="details">
      <strong>${c(e.customer)}</strong> / ${c(e.site)} / ${c(e.section)}<br>
      Scope: ${c(e.scope)} | Due cutoff: ${c(e.dueCutoff)}
    </div>
    ${n?``:`
      <h2>Current Inspection Coverage</h2>
      <table><thead><tr><th>Equipment Type</th><th>Total Assets</th><th>Current / Done</th><th>Outstanding</th><th>Coverage</th></tr></thead><tbody>${r||`<tr><td colspan="5">No registered assets found.</td></tr>`}</tbody></table>
    `}
    <h2>${n?`Assets Included in Survey`:`Work Due for This Visit`}</h2>
    <table><thead><tr><th>Equipment Type</th><th>Assets Included</th><th>Visual Due</th><th>Load Tests Due</th><th>Both Due</th><th>Overdue</th></tr></thead><tbody>${i||`<tr><td colspan="6">No assets match this selection.</td></tr>`}</tbody></table>
  `),a.document.close(),a.focus(),a.print()},window.createInspectionVisit=async function(){let e=await fetch(`${y}/inspection-visits`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(Le())}),t=await e.json();if(!e.ok){alert(t.error||`Could not create visit.`);return}await openInspectionVisit(t.visit.visitid)};async function ze(){let e=await fetch(`${y}/inspection-visits`),t=await e.json(),n=document.querySelector(`#inspectionVisitList`);if(n){if(!e.ok){n.innerHTML=`<p class="login-error">${c(t.error||`Could not load visits`)}</p>`;return}n.innerHTML=`
    <div class="visit-list">
      ${t.map(e=>`
        <button type="button" class="visit-list-item" onclick="openInspectionVisit(${e.visitid})">
          <strong>${c(e.visit_reference||`Visit ${e.visitid}`)}</strong>
          <span>${c(e.clientname||``)} / ${c(e.sitename||``)}</span>
          <span>${c(e.visit_type)} | ${c(e.visit_status)} | Outstanding ${c(e.outstanding_assets||0)}</span>
        </button>
      `).join(``)||`<p>No visits found.</p>`}
    </div>
  `}}window.openInspectionVisit=async function(e){G(`visits`);let[t,n]=await Promise.all([fetch(`${y}/inspection-visits/${e}`),fetch(`${y}/inspection-visits/${e}/assets?limit=250`)]),r=await t.json(),i=await n.json();if(!t.ok||!n.ok){alert(r.error||i.error||`Could not open visit.`);return}let a=[`COMPLETED`,`CANCELLED`].includes(r.visit_status),o=Number(i.counts.total||0),s=Number(i.counts.completed||0),l=o?Math.round(s/o*100):0;document.querySelector(`#page`).innerHTML=`
    <div class="visit-detail-header">
      <div>
        <h2>${c(r.visit_reference||`Visit ${r.visitid}`)}</h2>
        <p>${c(r.clientname||``)} / ${c(r.sitename||``)} ${r.sectionname?`/ ${c(r.sectionname)}`:``}</p>
      </div>
      <div class="form-actions">
        ${Fe()&&[`DRAFT`,`PAUSED`].includes(r.visit_status)?`<button onclick="startInspectionVisit(${r.visitid})">Start Visit</button>`:``}
        <button onclick="printInspectionVisitReport(${r.visitid})">Report</button>
        ${Fe()&&!a?`<button class="load-test-btn" onclick="closeInspectionVisit(${r.visitid})">Close Visit</button>`:``}
      </div>
    </div>

    <div class="visit-count-grid">
      <div><span>Total Assets in Visit</span><strong>${c(o)}</strong></div>
      <div><span>Done</span><strong>${c(s)}</strong></div>
      <div><span>Still Outstanding</span><strong>${c(i.counts.outstanding||0)}</strong></div>
      <div><span>Not Found</span><strong>${c(i.counts.not_found||0)}</strong></div>
      <div><span>Unable to Inspect</span><strong>${c(i.counts.inaccessible||0)}</strong></div>
      <div><span>Completion</span><strong>${c(l)}%</strong></div>
    </div>

    ${Ve(i.equipment_type_summary||[],i.counts)}

    <div class="filter-card">
      <h3>Worklist</h3>
      <div class="visit-worklist">
        ${i.rows.map(e=>He(r,e)).join(``)||`<p>No due assets in this visit scope.</p>`}
      </div>
    </div>

    ${a?``:`<div class="filter-card">
      <h3>Newly Discovered Asset</h3>
      <div class="form-row">
        <input id="visitDiscoveryDescription" placeholder="Description">
        <input id="visitDiscoverySerial" placeholder="Serial number">
        <input id="visitDiscoveryTag" placeholder="Asset tag">
        <input id="visitDiscoveryLocation" placeholder="Section / location">
      </div>
      <textarea id="visitDiscoveryNotes" placeholder="Notes"></textarea>
      <button onclick="addVisitDiscovery(${r.visitid})">Record Discovery</button>
    </div>`}
  `};function Be(e,t,n=!1){let r=Number(t.total||0),i=Number(t.completed||0),a=r?Math.round(i/r*100):0;return`
    <tr class="${n?`visit-progress-total`:``}">
      <th scope="row">${c(e)}</th>
      <td>${c(r)}</td>
      <td>${c(i)}</td>
      <td>${c(t.outstanding||0)}</td>
      <td>${c(t.not_found||0)}</td>
      <td>${c(t.inaccessible||0)}</td>
      <td>${c(t.deferred||0)}</td>
      <td>${c(t.other_resolved||0)}</td>
      <td>${c(a)}%</td>
    </tr>
  `}function Ve(e,t){let n=[`completed`,`outstanding`,`not_found`,`inaccessible`,`deferred`,`removed`].reduce((e,n)=>e+Number(t[n]||0),0),r={...t,other_resolved:Math.max(0,Number(t.total||0)-n+Number(t.removed||0))};return`
    <div class="filter-card visit-progress-card">
      <h3>Progress by Equipment Type</h3>
      <p class="muted-text">Done means all inspections required for this visit have been completed.</p>
      <div class="visit-progress-table-wrap">
        <table class="visit-progress-table">
          <thead>
            <tr>
              <th>Equipment Type</th>
              <th>Total</th>
              <th>Done</th>
              <th>Outstanding</th>
              <th>Not Found</th>
              <th>Unable to Inspect</th>
              <th>Deferred</th>
              <th>Other Resolved</th>
              <th>Completion</th>
            </tr>
          </thead>
          <tbody>
            ${e.map(e=>Be(e.equipment_type,e)).join(``)||`<tr><td colspan="9">No assets in this visit.</td></tr>`}
            ${Be(`Overall Total`,r,!0)}
          </tbody>
        </table>
      </div>
    </div>
  `}function He(e,t){let n=l(t.reconciliation_status||`OUTSTANDING`),r=[`COMPLETED`,`CANCELLED`].includes(e.visit_status)?`<span class="muted-text">Read-only completed visit</span>`:`
        ${t.assetid?`<button onclick="markVisitAssetScanned(${e.visitid}, ${t.assetid})">Scanned</button>`:``}
        ${t.visual_due_flag?`<button onclick="startInspection(${t.assetid}, 'VISUAL', 'visit:${e.visitid}', 'auto', ${e.visitid})">Visual</button>`:``}
        ${t.loadtest_due_flag?`<button class="load-test-btn" onclick="startInspection(${t.assetid}, 'LOADTEST', 'visit:${e.visitid}', 'auto', ${e.visitid})">Load Test</button>`:``}
        <select onchange="setVisitAssetDisposition(${e.visitid}, ${t.visitassetid}, this.value, '${n}')">
          <option value="">Disposition...</option>
          <option value="NOT_FOUND">Not found</option>
          <option value="OUT_OF_SERVICE">Out of service</option>
          <option value="REMOVED_FROM_SITE">Removed from site</option>
          <option value="INACCESSIBLE">Inaccessible</option>
          <option value="DEFERRED">Deferred</option>
          <option value="CUSTOMER_CONFIRMED_REMOVED">Customer confirmed removed</option>
          <option value="DUPLICATE_RECORD">Duplicate record</option>
          <option value="NOT_REQUIRED">Not required</option>
          <option value="OTHER">Other</option>
        </select>`;return`
    <div class="visit-asset-card ${l((t.reconciliation_status||``).toLowerCase())}">
      <div>
        <strong>${c(t.assettag_snapshot||t.assetid||`-`)}</strong>
        <span>${c(t.equipmenttype_snapshot||`-`)} | ${c(t.serial_snapshot||`-`)}</span>
        <span>${c(t.due_reason||``)}</span>
      </div>
      <div class="visit-asset-meta">
        <span>${c(t.required_inspection_scope)}</span>
        <strong>${c(t.reconciliation_status)}</strong>
      </div>
      <div class="form-actions">
        ${r}
      </div>
    </div>
  `}window.startInspectionVisit=async function(e){let t=await fetch(`${y}/inspection-visits/${e}/start`,{method:`POST`}),n=await t.json();if(!t.ok){alert(n.error||`Could not start visit.`);return}await openInspectionVisit(e)},window.markVisitAssetScanned=async function(e,t){let n=await fetch(`${y}/inspection-visits/${e}/scan`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({assetid:t})}),r=await n.json();if(!n.ok){alert(r.error||`Could not mark asset scanned.`);return}await openInspectionVisit(e)},window.setVisitAssetDisposition=async function(e,t,n){if(!n)return;let r=prompt(`Enter reconciliation comments:`)||``,i=n===`CUSTOMER_CONFIRMED_REMOVED`&&prompt(`Enter customer representative or confirmation note:`)||``,a=await fetch(`${y}/inspection-visits/${e}/assets/${t}/disposition`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({reconciliation_status:n,disposition_reason:n,disposition_comments:r,customer_confirmation:i})}),o=await a.json();if(!a.ok){alert(o.error||`Could not save disposition.`);return}await openInspectionVisit(e)},window.addVisitDiscovery=async function(e){let t=await fetch(`${y}/inspection-visits/${e}/discoveries`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({description:document.querySelector(`#visitDiscoveryDescription`)?.value||``,serialno:document.querySelector(`#visitDiscoverySerial`)?.value||``,assettagno:document.querySelector(`#visitDiscoveryTag`)?.value||``,section_location:document.querySelector(`#visitDiscoveryLocation`)?.value||``,notes:document.querySelector(`#visitDiscoveryNotes`)?.value||``})}),n=await t.json();if(!t.ok){alert(n.error||`Could not record discovery.`);return}await openInspectionVisit(e)},window.closeInspectionVisit=async function(e){let t={},n=await fetch(`${y}/inspection-visits/${e}/close`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(t)}),r=await n.json();if(n.status===409){let i=prompt(`Due assets still unaccounted for: ${r.unresolved}. Enter override reason or cancel:`);if(!i)return;t={override:!0,override_reason:i},n=await fetch(`${y}/inspection-visits/${e}/close`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(t)}),r=await n.json()}if(!n.ok){alert(r.error||`Could not close visit.`);return}await openInspectionVisit(e)},window.printInspectionVisitReport=async function(e){let t=await fetch(`${y}/inspection-visits/${e}/report`),n=await t.json();if(!t.ok){alert(n.error||`Could not load report.`);return}let r=window.open(``,`_blank`),i=n.equipment_type_summary||[],a=i.reduce((e,t)=>e+Number(t.total||0),0),o=i.reduce((e,t)=>e+Number(t.completed||0),0),s=i.reduce((e,t)=>e+Number(t.outstanding||0),0),l=i.reduce((e,t)=>e+Number(t.not_found||0),0),u=i.reduce((e,t)=>e+Number(t.inaccessible||0),0),d=i.reduce((e,t)=>e+Number(t.deferred||0),0),f=i.reduce((e,t)=>e+Number(t.other_resolved||0),0),p=a?Math.round(o/a*100):0;r.document.write(`
    <style>
      body { color: #172033; font-family: Arial, sans-serif; margin: 28px; }
      h1 { margin-bottom: 4px; }
      .summary { display: grid; gap: 10px; grid-template-columns: repeat(4, 1fr); margin: 20px 0; }
      .summary div { border: 1px solid #cbd5e1; border-radius: 6px; padding: 10px; }
      .summary span { color: #64748b; display: block; font-size: 12px; font-weight: 700; }
      .summary strong { display: block; font-size: 20px; margin-top: 4px; }
      table { border-collapse: collapse; font-size: 12px; width: 100%; }
      th, td { border: 1px solid #cbd5e1; padding: 7px; text-align: right; }
      th:first-child, td:first-child { text-align: left; }
      thead th, tfoot th, tfoot td { background: #e8f1fb; font-weight: 700; }
      @media print { body { margin: 10mm; } }
    </style>
    <h1>${c(n.visit.visit_reference||`Visit ${e}`)}</h1>
    <p>${c(n.visit.clientname||``)} / ${c(n.visit.sitename||``)}${n.visit.sectionname?` / ${c(n.visit.sectionname)}`:``}</p>
    <div class="summary">
      <div><span>Total Assets</span><strong>${c(a)}</strong></div>
      <div><span>Done</span><strong>${c(o)}</strong></div>
      <div><span>Outstanding</span><strong>${c(s)}</strong></div>
      <div><span>Completion</span><strong>${c(p)}%</strong></div>
    </div>
    <h2>Progress by Equipment Type</h2>
    <table>
      <thead><tr><th>Equipment Type</th><th>Total</th><th>Done</th><th>Outstanding</th><th>Not Found</th><th>Unable to Inspect</th><th>Deferred</th><th>Other Resolved</th><th>Completion</th></tr></thead>
      <tbody>
        ${i.map(e=>Be(e.equipment_type,e)).join(``)||`<tr><td colspan="9">No assets in this visit.</td></tr>`}
      </tbody>
      <tfoot>
        ${Be(`Overall Total`,{total:a,completed:o,outstanding:s,not_found:l,inaccessible:u,deferred:d,other_resolved:f},!0)}
      </tfoot>
    </table>
    <p><strong>Newly discovered assets:</strong> ${c(n.discoveries.length)}</p>
  `),r.document.close(),r.print()},window.showAddAssetForm=function(){if(!an()){rn();return}let e=[...z].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``)),t=[...U].sort((e,t)=>(e.description||``).localeCompare(t.description||``));document.querySelector(`#page`).innerHTML=`
    <h2>Add Asset</h2>

    <div class="filter-card">

     <div class="asset-form-grid">

  <div class="form-group">
    <label>Client</label>
    <select id="assetClient" onchange="filterAssetDropdowns()">
      <option value="">Select Client</option>
      ${e.map(e=>`
        <option value="${l(e.clientid)}">
          ${c(e.clientname)}
        </option>
      `).join(``)}
    </select>
  </div>

  <div class="form-group">
    <label>Site</label>
    <select id="assetSite" onchange="filterAssetSections()">
      <option value="">Select Client First</option>
    </select>
  </div>

  <div class="form-group">
    <label>Section</label>
    <select id="assetSection" onchange="autoFillResponsibleFromSection()">
      <option value="">Select Site First</option>
    </select>
  </div>

  <div class="form-group">
    <label>Responsible Person</label>
    <input id="assetResponsibleName" type="text" placeholder="Auto-filled from Section" disabled>
    <select id="assetResponsibleSelect" style="display:none;" onchange="syncAssetResponsibleFromSelect()">
      <option value="">Select Responsible Person</option>
    </select>
    <input id="assetResponsible" type="hidden">
  </div>

  <div class="form-group">
    <label>Equipment Type</label>
    <select id="assetEquipType" onchange="handleAssetEquipmentTypeChange()">
      <option value="">Select Equipment Type</option>
      ${t.map(e=>`
        <option value="${l(e.equiptypeid)}">
          ${c(e.description)}
        </option>
      `).join(``)}
    </select>
  </div>

  <div id="dynamicAssetFields" class="dynamic-asset-fields"></div>

    <div class="form-group">
    <label>Serial No</label>
    <input id="assetSerialNo" type="text">
  </div>

  <div class="form-group">
    <label>Asset Tag Number <span class="optional-label">(Optional)</span></label>
    <input id="assetTagNo" type="text" placeholder="Customer tag / plant number if available">
  </div>

  <div class="form-group">
    <label>Manufacturer</label>
    <input id="assetManufacturer" type="text">
  </div>

  <div class="form-group asset-description">
    <label>Description</label>
    <textarea id="assetDescription" rows="4" placeholder="Enter full asset description..."></textarea>
  </div>

  <div class="form-group" id="manufactureDateRow" style="display:none;">
    <label>Manufacture Date</label>
    <input id="assetManufactDate" type="date">
  </div>

  <div class="asset-photo-row">
    <div class="form-group">
      <label>Asset Photo 1</label>
      <input id="newAssetPhoto1" type="file" accept="image/*">
    </div>

    <div class="form-group">
      <label>Asset Photo 2</label>
      <input id="newAssetPhoto2" type="file" accept="image/*">
    </div>
  </div>

  <div class="form-actions">
    <button onclick="saveAssetFromForm()">Save Asset</button>
    <button onclick="showAssetSetup()">Cancel</button>
  </div>

</div>

  `},window.toggleManufactureDate=function(){let e=document.querySelector(`#assetEquipType`).value,t=U.find(t=>String(t.equiptypeid)===String(e)),n=document.querySelector(`#manufactureDateRow`),r=document.querySelector(`#assetManufactDate`);t&&String(t.equipgroupid)===`400`?n.style.display=`flex`:(n.style.display=`none`,r.value=``)},window.handleAssetEquipmentTypeChange=function(){toggleManufactureDate(),loadDynamicAssetFields()},window.loadDynamicAssetFields=function(){let e=document.querySelector(`#assetEquipType`).value,t=document.querySelector(`#dynamicAssetFields`);t.innerHTML=``;let n=U.find(t=>String(t.equiptypeid)===String(e));if(!n)return;let r=String(n.equipgroupid),i=``;r===`100`&&(i=`
      <div class="form-group"><label>WLL(kg)</label><input id="assetWLL" type="number"></div>
      <div class="form-group"><label>Height of Lift(mm)</label><input id="assetHeightOfLift" type="number"></div>
      <div class="form-group"><label>Number of Chain Falls</label><input id="assetNumberOfChainFalls" type="number"></div>
      <div class="form-group"><label>OEM Top Hook Size(mm)</label><input id="assetOEMTopHookSize" type="number"></div>
      <div class="form-group"><label>OEM Bottom Hook Size(mm)</label><input id="assetOEMBottomHookSize" type="number"></div>
      <div class="form-group"><label>Load Chain Diameter(mm)</label><input id="assetLoadChainDiameter" type="number"></div>
    `),r===`200`&&(i=`
      <div class="form-group"><label>WLL(kg)</label><input id="assetWLL" type="number"></div>
      <div class="form-group"><label>Effective Length(mm)</label><input id="assetEffectiveLength" type="number"></div>
    `),(r===`300`||r===`600`)&&(i=`
      <div class="form-group"><label>WLL(kg)</label><input id="assetWLL" type="number"></div>
    `),r===`400`&&(i=`
      <div class="form-group"><label>Main Hoist WLL(kg)</label><input id="assetWLL" type="number"></div>
      <div class="form-group"><label>Auxiliary Hoist WLL(kg)</label><input id="assetAuxHoistWLL" type="number"></div>
      <div class="form-group"><label>Span(mm)</label><input id="assetSpan" type="number"></div>
      <div class="form-group"><label>Permissible Deflection(mm)</label><input id="assetPermissibleDeflection" type="number"></div>
      <div class="form-group"><label>Main Hoist Description</label><input id="assetHoistDescription" type="text"></div>
      <div class="form-group"><label>Main Hoist Serial No</label><input id="assetHoistSerialNo" type="text"></div>
      <div class="form-group"><label>Auxiliary Hoist Description</label><input id="assetAuxHoistDescription" type="text"></div>
      <div class="form-group"><label>Auxiliary Hoist Serial No</label><input id="assetAuxHoistSerialNo" type="text"></div>
      <div class="form-group"><label>Main Hoist Hook Size(mm)</label><input id="assetHookSize" type="number"></div>
      <div class="form-group"><label>Auxiliary Hoist Hook Size(mm)</label><input id="assetAuxHoistHookSize" type="number"></div>
      <div class="form-group"><label>Height of Lift(mm)</label><input id="assetHeightOfLift" type="number"></div>
      <div class="form-group"><label>Main Hoist Steel Wire Rope(mm)</label><input id="assetSteelWireRopeMM" type="number"></div>
      <div class="form-group"><label>Auxiliary Hoist Steel Wire Rope(mm)</label><input id="assetAuxHoistRopeMM" type="number"></div>
    `),r===`500`&&(i=`
      <div class="form-group"><label>WLL(kg)</label><input id="assetWLL" type="number"></div>
      <div class="form-group"><label>Span(mm)</label><input id="assetSpan" type="number"></div>
      <div class="form-group"><label>Permissible Deflection(mm)</label><input id="assetPermissibleDeflection" type="number"></div>
      <div class="form-group"><label>Hook Size(mm)</label><input id="assetHookSize" type="number"></div>
      <div class="form-group"><label>Hoist Description</label><input id="assetHoistDescription" type="text"></div>
      <div class="form-group"><label>Hoist Serial No</label><input id="assetHoistSerialNo" type="text"></div>
    `),t.innerHTML=i},window.filterAssetDropdowns=function(){let e=document.querySelector(`#assetClient`).value,t=document.querySelector(`#assetSite`);if(document.querySelector(`#assetSection`).innerHTML=`<option value="">Select Site First</option>`,document.querySelector(`#assetResponsibleName`).value=``,document.querySelector(`#assetResponsible`).value=``,Ue(),!e){t.innerHTML=`<option value="">Select Client First</option>`;return}t.innerHTML=`
    <option value="">Select Site</option>

    ${V.filter(t=>String(t.clientid)===String(e)&&!(t.archived===!0||t.archived===`true`)).sort((e,t)=>(e.sitename||``).localeCompare(t.sitename||``)).map(e=>`
      <option value="${l(e.siteid)}">
        ${c(e.sitename)}
      </option>
    `).join(``)}
  `},window.filterAssetSections=function(){let e=document.querySelector(`#assetSite`).value,t=document.querySelector(`#assetSection`);if(document.querySelector(`#assetResponsibleName`).value=``,document.querySelector(`#assetResponsible`).value=``,Ue(),!e){t.innerHTML=`<option value="">Select Site First</option>`;return}t.innerHTML=`
    <option value="">Select Section</option>

    ${H.filter(t=>String(t.siteid)===String(e)&&!(t.archived===!0||t.archived===`true`)).sort((e,t)=>(e.sectionname||``).localeCompare(t.sectionname||``)).map(e=>`
      <option value="${l(e.sectionid)}">
        ${c(e.sectionname)}
      </option>
    `).join(``)}
  `};function Ue(){let e=document.querySelector(`#assetResponsibleName`),t=document.querySelector(`#assetResponsibleSelect`);e&&(e.style.display=``),t&&(t.style.display=`none`,t.innerHTML=`<option value="">Select Responsible Person</option>`)}function We(e=``){let t=document.querySelector(`#assetClient`)?.value||``,n=document.querySelector(`#assetResponsibleName`),r=document.querySelector(`#assetResponsibleSelect`);if(!r||!n)return;let i=_e(t);n.style.display=`none`,r.style.display=``,r.innerHTML=`
    <option value="">Select Responsible Person</option>
    ${i.map(t=>`
      <option value="${l(t.personid)}" ${String(t.personid)===String(e)?`selected`:``}>
        ${c(t.name||`Responsible Person ${t.personid}`)}
      </option>
    `).join(``)}
  `}window.syncAssetResponsibleFromSelect=function(){let e=document.querySelector(`#assetResponsibleSelect`),t=document.querySelector(`#assetResponsible`);t&&(t.value=e?.value||``)},window.autoFillResponsibleFromSection=function(){let e=document.querySelector(`#assetSection`).value,t=document.querySelector(`#assetResponsibleName`),n=document.querySelector(`#assetResponsible`);if(t.value=``,n.value=``,Ue(),!e)return;let r=H.find(t=>String(t.sectionid)===String(e));r&&(t.value=r.responsiblename||``,n.value=r.responsibleid||``,r.responsibleid||We())};let C=new Set([`image/jpeg`,`image/png`,`image/webp`]);function Ge(e){for(let t of e.filter(Boolean)){if(!C.has(t.type))return alert(`Asset photos must be JPG, PNG or WebP images.`),!1;if(t.size>15728640)return alert(`Asset photos must be 15 MB or smaller.`),!1}return!0}window.saveAssetFromForm=async function(){if(!an()){alert(`You do not have permission to add assets.`);return}let e=document.querySelector(`#assetClient`).value,t=document.querySelector(`#assetSite`).value,n=document.querySelector(`#assetSection`).value,r=document.querySelector(`#assetResponsible`).value,i=document.querySelector(`#assetEquipType`).value,a=document.querySelector(`#assetTagNo`)?.value||``,o=document.querySelector(`#assetSerialNo`).value,s=document.querySelector(`#assetManufacturer`).value,c=document.querySelector(`#assetDescription`).value,l=document.querySelector(`#assetManufactDate`)?.value||``;if(!e||!t||!n||!r||!i||!c){alert(`Please complete Client, Site, Section, Responsible Person, Equipment Type, and Description`);return}let u=document.querySelector(`#newAssetPhoto1`)?.files[0],d=document.querySelector(`#newAssetPhoto2`)?.files[0];if(!Ge([u,d]))return;let f=await fetch(`${y}/assets`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:e,siteid:t,sectionid:n,responsibleid:r,equiptypeid:i,assettagno:a,serialno:o,manufacturer:s,description:c,manufactdate:l,wll:document.querySelector(`#assetWLL`)?.value||null,heightoflift:document.querySelector(`#assetHeightOfLift`)?.value||null,numberofchainfalls:document.querySelector(`#assetNumberOfChainFalls`)?.value||null,oemtophooksize:document.querySelector(`#assetOEMTopHookSize`)?.value||null,oembottomhooksize:document.querySelector(`#assetOEMBottomHookSize`)?.value||null,loadchaindiameter:document.querySelector(`#assetLoadChainDiameter`)?.value||null,effectivelength:document.querySelector(`#assetEffectiveLength`)?.value||null,span:document.querySelector(`#assetSpan`)?.value||null,permissibledeflection:document.querySelector(`#assetPermissibleDeflection`)?.value||null,hooksize:document.querySelector(`#assetHookSize`)?.value||null,steelwireropemm:document.querySelector(`#assetSteelWireRopeMM`)?.value||null,hoistdescription:document.querySelector(`#assetHoistDescription`)?.value||null,hoistserialno:document.querySelector(`#assetHoistSerialNo`)?.value||null,auxhoistdescription:document.querySelector(`#assetAuxHoistDescription`)?.value||null,auxhoistserialno:document.querySelector(`#assetAuxHoistSerialNo`)?.value||null,auxhoistwll:document.querySelector(`#assetAuxHoistWLL`)?.value||null,auxhoisthooksize:document.querySelector(`#assetAuxHoistHookSize`)?.value||null,auxhoistropemm:document.querySelector(`#assetAuxHoistRopeMM`)?.value||null})}),p=await f.json();if(!f.ok){alert(`Error saving asset: `+p.error);return}if(u||d){let e=new FormData;u&&e.append(`photo1`,u),d&&e.append(`photo2`,d);let t=await fetch(`${y}/assets/${p.assetid}/photos`,{method:`POST`,body:e}),n=await t.json();if(!t.ok){alert(`Asset saved, but photo upload failed: `+n.error),await $(),showAssetSetup();return}}alert(`Asset saved successfully`),await $(),showAssetSetup()};async function qe(){w();let t=window.assetListState||{},n=e(`assets`,`assetid`,`desc`),r=await Q(`${y}/assets?${new URLSearchParams({page:String(window.assetCurrentPage||t.currentPage||1),limit:String(window.assetRowsPerPage||t.rowsPerPage||25),searchBy:t.searchType||`all`,search:t.search||``,sortKey:n.key||`assetid`,sortDir:n.direction||`desc`,archiveMode:t.archiveMode||`active`}).toString()}`,{rows:[],total:0,page:1,limit:Number(window.assetRowsPerPage||25)});B=r.rows||[],window.assetCurrentPage=Number(r.page||window.assetCurrentPage||1),window.assetRowsPerPage=Number(r.limit||window.assetRowsPerPage||25);let i={serverPaged:!0,total:r.total||0,page:window.assetCurrentPage,limit:window.assetRowsPerPage};document.querySelector(`#assetTableBody`)?ge(B,i):he(B,i),T()}window.filterAssets=async function(e=!1){e&&(window.assetCurrentPage=1),await qe()},window.filterAssetsDebounced=function(e=!1){w(),Wt&&clearTimeout(Wt),Wt=setTimeout(()=>{filterAssets(e)},350)};function w(){let e=document.querySelector(`#assetSearchType`),t=document.querySelector(`#assetSearch`),n=document.querySelector(`#assetRowsPerPage`);window.assetListState={searchType:e?e.value:window.assetListState?.searchType||`all`,search:t?t.value:window.assetListState?.search||``,currentPage:window.assetCurrentPage||window.assetListState?.currentPage||1,rowsPerPage:Number(n?.value||window.assetRowsPerPage||window.assetListState?.rowsPerPage||25)}}function T(){let e=window.assetListState||{},t=document.querySelector(`#assetSearchType`),n=document.querySelector(`#assetSearch`),r=document.querySelector(`#assetRowsPerPage`);window.assetRowsPerPage=Number(e.rowsPerPage||window.assetRowsPerPage||25),window.assetCurrentPage=Number(e.currentPage||window.assetCurrentPage||1),t&&(t.value=e.searchType||`all`),n&&(n.value=e.search||``),r&&(r.value=String(window.assetRowsPerPage))}window.setAssetRowsPerPage=function(e){window.assetRowsPerPage=Number(e)||25,window.assetCurrentPage=1,filterAssets()},window.changeAssetPage=function(e){window.assetCurrentPage=Math.max(1,(window.assetCurrentPage||1)+e),filterAssets()},window.goToAssetPage=function(e){window.assetCurrentPage=Math.max(1,Number(e)||1),filterAssets()},window.setAssetFilterKey=function(e){let t=document.querySelector(`#assetSearchType`);t&&(t.value=e,window.assetCurrentPage=1,filterAssets())},window.showMoveAssetForm=async function(e){if(!on()){rn();return}w();let t;try{t=await An(e)}catch(e){alert(e.message||`Asset not found`);return}let n=V.filter(e=>String(e.clientid)===String(t.clientid)&&!(e.archived===!0||e.archived===`true`)).sort((e,t)=>(e.sitename||``).localeCompare(t.sitename||``));document.querySelector(`#page`).innerHTML=`
    <h2>Move Asset ${c(t.assetid)}</h2>

    <div class="filter-card">
      <div class="asset-form-grid">
        <div class="form-group">
          <label>Customer</label>
          <input type="text" value="${l(t.clientname||``)}" disabled>
        </div>

        <div class="form-group">
          <label>Current Site</label>
          <input type="text" value="${l(t.sitename||`-`)}" disabled>
        </div>

        <div class="form-group">
          <label>Current Section</label>
          <input type="text" value="${l(t.sectionname||`-`)}" disabled>
        </div>

        <div class="form-group">
          <label>New Site</label>
          <select id="moveAssetSite" onchange="filterMoveAssetSections()">
            <option value="">Select Site</option>
            ${n.map(e=>`
              <option value="${l(e.siteid)}" ${String(e.siteid)===String(t.siteid)?`selected`:``}>
                ${c(e.sitename)}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="form-group">
          <label>New Section</label>
          <select id="moveAssetSection">
            <option value="">Select Site First</option>
          </select>
        </div>
      </div>

      <div class="form-actions">
        <button onclick="saveAssetMove(${t.assetid})">Move Asset</button>
        <button onclick="showAssetSetup()">Cancel</button>
      </div>
    </div>
  `,filterMoveAssetSections(t.sectionid)},window.filterMoveAssetSections=function(e=``){let t=document.querySelector(`#moveAssetSite`)?.value||``,n=document.querySelector(`#moveAssetSection`);if(n){if(!t){n.innerHTML=`<option value="">Select Site First</option>`;return}n.innerHTML=`
    <option value="">Select Section</option>
    ${H.filter(e=>String(e.siteid)===String(t)&&!(e.archived===!0||e.archived===`true`)).sort((e,t)=>(e.sectionname||``).localeCompare(t.sectionname||``)).map(t=>`
      <option value="${l(t.sectionid)}" ${String(t.sectionid)===String(e)?`selected`:``}>
        ${c(t.sectionname)}
      </option>
    `).join(``)}
  `}},window.saveAssetMove=async function(e){if(!on()){alert(`You do not have permission to move assets.`);return}let t=document.querySelector(`#moveAssetSite`)?.value||``,n=document.querySelector(`#moveAssetSection`)?.value||``;if(!t||!n){alert(`Please select the new site and section`);return}let r=await fetch(`${y}/assets/${e}/move`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({siteid:t,sectionid:n})}),i=await r.json();if(!r.ok){alert(i.error||`Unable to move asset`);return}alert(`Asset moved successfully`),await $(),showAssetSetup()};function Je(e,t={}){let n=``;return e===`100`&&(n=`
      <div class="form-group"><label>WLL(kg)</label><input id="editAssetWLL" type="number" value="${l(t.wll||``)}"></div>
      <div class="form-group"><label>Height of Lift(mm)</label><input id="editAssetHeightOfLift" type="number" value="${l(t.heightoflift||``)}"></div>
      <div class="form-group"><label>Number of Chain Falls</label><input id="editAssetNumberOfChainFalls" type="number" value="${l(t.numberofchainfalls||``)}"></div>
      <div class="form-group"><label>OEM Top Hook Size(mm)</label><input id="editAssetOEMTopHookSize" type="number" value="${l(t.oemtophooksize||``)}"></div>
      <div class="form-group"><label>OEM Bottom Hook Size(mm)</label><input id="editAssetOEMBottomHookSize" type="number" value="${l(t.oembottomhooksize||``)}"></div>
      <div class="form-group"><label>Load Chain Diameter(mm)</label><input id="editAssetLoadChainDiameter" type="number" value="${l(t.loadchaindiameter||``)}"></div>
    `),e===`200`&&(n=`
      <div class="form-group"><label>WLL(kg)</label><input id="editAssetWLL" type="number" value="${l(t.wll||``)}"></div>
      <div class="form-group"><label>Effective Length(mm)</label><input id="editAssetEffectiveLength" type="number" value="${l(t.effectivelength||``)}"></div>
    `),(e===`300`||e===`600`)&&(n=`
      <div class="form-group"><label>WLL(kg)</label><input id="editAssetWLL" type="number" value="${l(t.wll||``)}"></div>
    `),e===`400`&&(n=`
      <div class="form-group"><label>Main Hoist WLL(kg)</label><input id="editAssetWLL" type="number" value="${l(t.wll||``)}"></div>
      <div class="form-group"><label>Auxiliary Hoist WLL(kg)</label><input id="editAssetAuxHoistWLL" type="number" value="${l(t.auxhoistwll||``)}"></div>
      <div class="form-group"><label>Span(mm)</label><input id="editAssetSpan" type="number" value="${l(t.span||``)}"></div>
      <div class="form-group"><label>Permissible Deflection(mm)</label><input id="editAssetPermissibleDeflection" type="number" value="${l(t.permissibledeflection||``)}"></div>
      <div class="form-group"><label>Main Hoist Description</label><input id="editAssetHoistDescription" type="text" value="${l(t.hoistdescription||``)}"></div>
      <div class="form-group"><label>Main Hoist Serial No</label><input id="editAssetHoistSerialNo" type="text" value="${l(t.hoistserialno||``)}"></div>
      <div class="form-group"><label>Auxiliary Hoist Description</label><input id="editAssetAuxHoistDescription" type="text" value="${l(t.auxhoistdescription||``)}"></div>
      <div class="form-group"><label>Auxiliary Hoist Serial No</label><input id="editAssetAuxHoistSerialNo" type="text" value="${l(t.auxhoistserialno||``)}"></div>
      <div class="form-group"><label>Main Hoist Hook Size(mm)</label><input id="editAssetHookSize" type="number" value="${l(t.hooksize||``)}"></div>
      <div class="form-group"><label>Auxiliary Hoist Hook Size(mm)</label><input id="editAssetAuxHoistHookSize" type="number" value="${l(t.auxhoisthooksize||``)}"></div>
      <div class="form-group"><label>Height of Lift(mm)</label><input id="editAssetHeightOfLift" type="number" value="${l(t.heightoflift||``)}"></div>
      <div class="form-group"><label>Main Hoist Steel Wire Rope(mm)</label><input id="editAssetSteelWireRopeMM" type="number" value="${l(t.steelwireropemm||``)}"></div>
      <div class="form-group"><label>Auxiliary Hoist Steel Wire Rope(mm)</label><input id="editAssetAuxHoistRopeMM" type="number" value="${l(t.auxhoistropemm||``)}"></div>
    `),e===`500`&&(n=`
      <div class="form-group"><label>WLL(kg)</label><input id="editAssetWLL" type="number" value="${l(t.wll||``)}"></div>
      <div class="form-group"><label>Span(mm)</label><input id="editAssetSpan" type="number" value="${l(t.span||``)}"></div>
      <div class="form-group"><label>Permissible Deflection(mm)</label><input id="editAssetPermissibleDeflection" type="number" value="${l(t.permissibledeflection||``)}"></div>
      <div class="form-group"><label>Hook Size(mm)</label><input id="editAssetHookSize" type="number" value="${l(t.hooksize||``)}"></div>
      <div class="form-group"><label>Hoist Description</label><input id="editAssetHoistDescription" type="text" value="${l(t.hoistdescription||``)}"></div>
      <div class="form-group"><label>Hoist Serial No</label><input id="editAssetHoistSerialNo" type="text" value="${l(t.hoistserialno||``)}"></div>
    `),n}function Ye(e={}){let t=(t,n)=>document.querySelector(t)?.value??e[n]??``;return{manufactdate:((t,n)=>{let r=document.querySelector(t)?.value??e[n]??``;return String(r||``).slice(0,10)})(`#editAssetManufactDate`,`manufactdate`),wll:t(`#editAssetWLL`,`wll`),heightoflift:t(`#editAssetHeightOfLift`,`heightoflift`),numberofchainfalls:t(`#editAssetNumberOfChainFalls`,`numberofchainfalls`),oemtophooksize:t(`#editAssetOEMTopHookSize`,`oemtophooksize`),oembottomhooksize:t(`#editAssetOEMBottomHookSize`,`oembottomhooksize`),loadchaindiameter:t(`#editAssetLoadChainDiameter`,`loadchaindiameter`),effectivelength:t(`#editAssetEffectiveLength`,`effectivelength`),span:t(`#editAssetSpan`,`span`),permissibledeflection:t(`#editAssetPermissibleDeflection`,`permissibledeflection`),hooksize:t(`#editAssetHookSize`,`hooksize`),steelwireropemm:t(`#editAssetSteelWireRopeMM`,`steelwireropemm`),hoistdescription:t(`#editAssetHoistDescription`,`hoistdescription`),hoistserialno:t(`#editAssetHoistSerialNo`,`hoistserialno`),auxhoistdescription:t(`#editAssetAuxHoistDescription`,`auxhoistdescription`),auxhoistserialno:t(`#editAssetAuxHoistSerialNo`,`auxhoistserialno`),auxhoistwll:t(`#editAssetAuxHoistWLL`,`auxhoistwll`),auxhoisthooksize:t(`#editAssetAuxHoistHookSize`,`auxhoisthooksize`),auxhoistropemm:t(`#editAssetAuxHoistRopeMM`,`auxhoistropemm`)}}window.refreshEditAssetDynamicFields=function(){let e=document.querySelector(`#editAssetEquipType`)?.value,t=U.find(t=>String(t.equiptypeid)===String(e)),n=String(t?.equipgroupid||``),r=document.querySelector(`#editDynamicAssetFields`),i=document.querySelector(`#editManufactureDateRow`),a=document.querySelector(`#editAssetManufactDate`);r&&(r.innerHTML=Je(n,Ye()),i&&(i.style.display=n===`400`?`flex`:`none`),a&&n!==`400`&&(a.value=``))},window.editAsset=async function(e){if(!an()){rn();return}w();let t;try{t=await An(e)}catch(e){alert(e.message||`Asset not found`);return}let n=U.find(e=>String(e.equiptypeid)===String(t.equiptypeid)),r=String(n?.equipgroupid||``),i=Je(r,t),a=await je(t.assetid),o=r===`400`,s=[...U].sort((e,t)=>(e.description||``).localeCompare(t.description||``)).map(e=>`
      <option value="${l(e.equiptypeid)}" ${String(e.equiptypeid)===String(t.equiptypeid)?`selected`:``}>
        ${c(e.description)}
      </option>
    `).join(``);document.querySelector(`#page`).innerHTML=`
    <h2>Edit Asset ${c(t.assetid)}</h2>

    <div class="filter-card">
      <div class="asset-form-grid">

        <div class="form-group">
          <label>Equipment Type</label>
          <select id="editAssetEquipType" onchange="refreshEditAssetDynamicFields()">
            <option value="">Select Equipment Type</option>
            ${s}
          </select>
        </div>

        <div class="form-group">
          <label>Serial No</label>
          <input id="editAssetSerialNo" type="text" value="${l(t.serialno||``)}">
        </div>

        <div class="form-group">
          <label>Asset Tag Number <span class="optional-label">(Optional)</span></label>
          <input id="editAssetTagNo" type="text" value="${l(t.assettagno||``)}" placeholder="Customer tag / plant number if available">
        </div>

        <div class="form-group">
          <label>Manufacturer</label>
          <input id="editAssetManufacturer" type="text" value="${l(t.manufacturer||``)}">
        </div>

        <div class="form-group" id="editManufactureDateRow" style="${o?``:`display:none;`}">
          <label>Manufacture Date</label>
          <input id="editAssetManufactDate" type="date" value="${l(String(t.manufactdate||``).slice(0,10))}">
        </div>

        <div id="editDynamicAssetFields" class="dynamic-asset-fields">
          ${i}
        </div>

        <div class="form-group asset-description">
          <label>Description</label>
          <textarea id="editAssetDescription" rows="4">${c(t.description||``)}</textarea>
        </div>

        <div class="asset-photo-row">
          <div class="form-group">
            <label>Replace Photo 1</label>
            <input id="assetPhoto1" type="file" accept="image/*">
          </div>

          <div class="form-group">
            <label>Replace Photo 2</label>
            <input id="assetPhoto2" type="file" accept="image/*">
          </div>
        </div>

        <div class="form-actions">
          <button onclick="saveAssetChanges(${t.assetid})">
            Save Changes
          </button>

          <button onclick="uploadAssetPhotos(${t.assetid})">
            Upload Photos
          </button>

          <button onclick="showAssetSetup()">
            Cancel
          </button>

          ${on()?`
            <button class="danger-btn" onclick="archiveAsset(${t.assetid})">
              Archive
            </button>
          `:``}
        </div>

      </div>
    </div>

    ${dn()?`
      <div id="editAssetNfcPanel" class="filter-card">
        ${Me(t,a)}
      </div>
    `:``}

    <div class="photo-preview-grid">
      ${t.media1?`
        <div class="photo-card">
          <h3>Photo 1</h3>
          <img src="${l(b(t.media1))}">
          ${on()?`
            <button
              type="button"
              class="danger-btn photo-delete-btn"
              onclick="deleteAssetPhoto(${t.assetid}, 1)"
            >
              Delete Photo 1
            </button>
          `:``}
        </div>
      `:``}

      ${t.media2?`
        <div class="photo-card">
          <h3>Photo 2</h3>
          <img src="${l(b(t.media2))}">
          ${on()?`
            <button
              type="button"
              class="danger-btn photo-delete-btn"
              onclick="deleteAssetPhoto(${t.assetid}, 2)"
            >
              Delete Photo 2
            </button>
          `:``}
        </div>
      `:``}
    </div>
  `},window.saveAssetChanges=async function(e){if(!an()){alert(`You do not have permission to edit assets.`);return}let t=document.querySelector(`#editAssetEquipType`)?.value||null,n=document.querySelector(`#editAssetSerialNo`).value,r=document.querySelector(`#editAssetTagNo`)?.value||``,i=document.querySelector(`#editAssetManufacturer`).value,a=document.querySelector(`#editAssetManufactDate`)?.value||``,o=document.querySelector(`#editAssetDescription`).value,s=await fetch(`${y}/assets/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({equiptypeid:t,serialno:n,assettagno:r,manufacturer:i,manufactdate:a,description:o,wll:document.querySelector(`#editAssetWLL`)?.value||null,heightoflift:document.querySelector(`#editAssetHeightOfLift`)?.value||null,numberofchainfalls:document.querySelector(`#editAssetNumberOfChainFalls`)?.value||null,oemtophooksize:document.querySelector(`#editAssetOEMTopHookSize`)?.value||null,oembottomhooksize:document.querySelector(`#editAssetOEMBottomHookSize`)?.value||null,loadchaindiameter:document.querySelector(`#editAssetLoadChainDiameter`)?.value||null,effectivelength:document.querySelector(`#editAssetEffectiveLength`)?.value||null,span:document.querySelector(`#editAssetSpan`)?.value||null,permissibledeflection:document.querySelector(`#editAssetPermissibleDeflection`)?.value||null,hooksize:document.querySelector(`#editAssetHookSize`)?.value||null,steelwireropemm:document.querySelector(`#editAssetSteelWireRopeMM`)?.value||null,hoistdescription:document.querySelector(`#editAssetHoistDescription`)?.value||null,hoistserialno:document.querySelector(`#editAssetHoistSerialNo`)?.value||null,auxhoistdescription:document.querySelector(`#editAssetAuxHoistDescription`)?.value||null,auxhoistserialno:document.querySelector(`#editAssetAuxHoistSerialNo`)?.value||null,auxhoistwll:document.querySelector(`#editAssetAuxHoistWLL`)?.value||null,auxhoisthooksize:document.querySelector(`#editAssetAuxHoistHookSize`)?.value||null,auxhoistropemm:document.querySelector(`#editAssetAuxHoistRopeMM`)?.value||null})}),c=await s.json();if(!s.ok){alert(`Error updating asset: `+c.error);return}alert(`Asset updated: `+c.assetid),await $(),showAssetSetup()},window.archiveAsset=async function(e){if(!on()){alert(`You do not have permission to archive assets.`);return}if(!confirm(`Archive asset `+e+`? It will be hidden but its inspection history will remain.`))return;let t=await fetch(`${y}/assets/${e}/archive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(`Error archiving asset: `+n.error);return}alert(`Asset archived: `+n.assetid),await $(),showAssetSetup()},window.unarchiveAsset=async function(e){if(!on()){alert(`You do not have permission to restore assets.`);return}if(!confirm(`Restore asset `+e+`?`))return;let t=await fetch(`${y}/assets/${e}/unarchive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(`Error restoring asset: `+n.error);return}alert(`Asset restored: `+n.assetid),await $(),showAssetSetup()},window.uploadAssetPhotos=async function(e){if(!an()){alert(`You do not have permission to update asset photos.`);return}let t=document.querySelector(`#assetPhoto1`).files[0],n=document.querySelector(`#assetPhoto2`).files[0];if(!t&&!n){alert(`Please choose at least one photo`);return}if(!Ge([t,n]))return;let r=new FormData;t&&r.append(`photo1`,t),n&&r.append(`photo2`,n);let i=await fetch(`${y}/assets/${e}/photos`,{method:`POST`,body:r}),a=await L(i);if(!i.ok){alert(`Error uploading photos: `+a.error);return}alert(`Photos uploaded for asset `+a.assetid),await $(),editAsset(e)},window.deleteAssetPhoto=async function(e,t){if(!on()){alert(`You do not have permission to delete asset photos.`);return}if(!confirm(`Delete asset photo ${t}?`))return;let n=await fetch(`${y}/assets/${e}/photos/${t}`,{method:`DELETE`}),r=await L(n);if(!n.ok){alert(`Error deleting photo: `+r.error);return}alert(`Asset photo ${t} deleted successfully`),await $(),editAsset(e)},window.showEquipmentTypeCriteria=function(){K(`criteria`)&&(G(`criteria`),window.criteriaEquipmentFilter=window.criteriaEquipmentFilter||``,Ce(U,W))},window.filterEquipmentCriteria=function(){window.criteriaEquipmentFilter=document.querySelector(`#criteriaEquipmentFilter`)?.value||``,window.criteriaCurrentPage=1,showEquipmentTypeCriteria()},window.setCriteriaRowsPerPage=function(e){window.criteriaRowsPerPage=Number(e)||25,window.criteriaCurrentPage=1,showEquipmentTypeCriteria()},window.goToCriteriaPage=function(e){window.criteriaCurrentPage=Math.max(1,Number(e)||1),showEquipmentTypeCriteria()};function E(e){return l(e)}function Xe(e={}){let t=[...U].sort((e,t)=>(e.description||``).localeCompare(t.description||``)),n=e.equiptypeid||window.criteriaEquipmentFilter||t[0]?.equiptypeid||``,r=e.inspectioncategory||`VISUAL`,i=e.fieldtype||`PASS_FAIL`,a=e.resulttype||(i===`NUMBER`?`MEASURED`:`PASS_FAIL`),o=e.inspection_category||`PERIODIC_THOROUGH_INSPECTION`,s=e.severity||`MINOR`;document.querySelector(`#criteriaPopup`)?.remove(),document.body.insertAdjacentHTML(`beforeend`,`
    <div
      id="criteriaPopup"
      class="criteria-modal-overlay"
      onclick="closeCriteriaPopupOnBackdrop(event)"
    >
      <div class="criteria-modal" role="dialog" aria-modal="true" aria-labelledby="criteriaPopupTitle">
        <div class="criteria-modal-header">
          <h2 id="criteriaPopupTitle">
            ${e.criteriaid?`Edit Criteria`:`Add Criteria`}
          </h2>

          <button type="button" onclick="cancelCriteriaEdit()">
            Close
          </button>
        </div>

        <div class="criteria-modal-body">
          <input id="editingCriteriaId" type="hidden" value="${l(e.criteriaid||``)}">

          <div class="form-row">
            <div class="form-group">
              <label>Equipment Type</label>
              <select id="criteriaEquipType">
                ${t.map(e=>`
                  <option
                    value="${l(e.equiptypeid)}"
                    ${String(e.equiptypeid)===String(n)?`selected`:``}
                  >
                    ${c(e.description)}
                  </option>
                `).join(``)}
              </select>
            </div>

            <div class="form-group">
              <label>Inspection Type</label>
              <select id="criteriaCategory">
                <option value="VISUAL" ${r===`VISUAL`?`selected`:``}>
                  Visual Inspection
                </option>
                <option value="LOADTEST" ${r===`LOADTEST`?`selected`:``}>
                  Load Test
                </option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group form-group-wide">
              <label>Criteria Name</label>
              <input id="criteriaName" type="text" value="${E(e.criteriadescription||e.criterianame)}">
            </div>

            <div class="form-group">
              <label>Field Type</label>
              <select id="criteriaFieldType">
                <option value="PASS_FAIL" ${i===`PASS_FAIL`||i===`PASSFAIL`?`selected`:``}>Pass / Fail / N/A</option>
                <option value="TEXT" ${i===`TEXT`?`selected`:``}>Text Input</option>
                <option value="NUMBER" ${i===`NUMBER`?`selected`:``}>Number Input</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Result Type</label>
              <select id="criteriaResultType">
                <option value="PASS_FAIL" ${a===`PASS_FAIL`?`selected`:``}>PASS / FAIL</option>
                <option value="MEASURED" ${a===`MEASURED`?`selected`:``}>Measured</option>
                <option value="YES_NO" ${a===`YES_NO`?`selected`:``}>YES / NO</option>
              </select>
            </div>

            <div class="form-group">
              <label>Inspection Category</label>
              <select id="criteriaInspectionGroup">
                <option value="FREQUENT_INSPECTION" ${o===`FREQUENT_INSPECTION`?`selected`:``}>
                  Frequent Inspection
                </option>
                <option value="PERIODIC_THOROUGH_INSPECTION" ${o===`PERIODIC_THOROUGH_INSPECTION`?`selected`:``}>
                  Periodic Thorough Inspection
                </option>
              </select>
            </div>

            <div class="form-group">
              <label>Severity</label>
              <select id="criteriaSeverity">
                <option value="CRITICAL" ${s===`CRITICAL`?`selected`:``}>Critical</option>
                <option value="MAJOR" ${s===`MAJOR`?`selected`:``}>Major</option>
                <option value="MINOR" ${s===`MINOR`?`selected`:``}>Minor</option>
                <option value="OBSERVATION" ${s===`OBSERVATION`?`selected`:``}>Observation</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Display Order</label>
              <input id="criteriaDisplayOrder" type="number" min="1" value="${E(e.displayorder||e.sortorder||1)}">
            </div>

            <div class="form-group">
              <label>Active</label>
              <select id="criteriaActive">
                <option value="true" ${e.active===!1?``:`selected`}>Active</option>
                <option value="false" ${e.active===!1?`selected`:``}>Inactive</option>
              </select>
            </div>
          </div>
        </div>

        <div class="criteria-modal-footer">
          <button type="button" onclick="cancelCriteriaEdit()">
            Cancel
          </button>

          <button type="button" onclick="saveCriteria()">
            Save Criteria
          </button>
        </div>
      </div>
    </div>
  `),document.querySelector(`#criteriaName`)?.focus()}window.openCriteriaPopup=function(){Xe()},window.closeCriteriaPopupOnBackdrop=function(e){e.target.id===`criteriaPopup`&&cancelCriteriaEdit()},window.saveCriteria=async function(){let e=document.querySelector(`#editingCriteriaId`)?.value||``,t=document.querySelector(`#criteriaEquipType`).value,n=document.querySelector(`#criteriaCategory`).value,r=document.querySelector(`#criteriaName`).value;if(!r){alert(`Please enter a criteria name`);return}let i={equiptypeid:t,criterianame:r,criteriadescription:r,fieldtype:document.querySelector(`#criteriaFieldType`).value,resulttype:document.querySelector(`#criteriaResultType`).value,required:!0,sortorder:Number(document.querySelector(`#criteriaDisplayOrder`)?.value||1),displayorder:Number(document.querySelector(`#criteriaDisplayOrder`)?.value||1),inspectioncategory:n,inspection_category:document.querySelector(`#criteriaInspectionGroup`).value,severity:document.querySelector(`#criteriaSeverity`).value,active:document.querySelector(`#criteriaActive`).value===`true`},a=await fetch(e?`${y}/equipment-type-criteria/${e}`:`${y}/equipment-type-criteria`,{method:e?`PUT`:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(i)}),o=await a.json();if(!a.ok){alert(`Error saving criteria: `+o.error);return}alert(e?`Criteria updated`:`Criteria saved`),await $(),cancelCriteriaEdit(),showEquipmentTypeCriteria()},window.editCriteria=function(e){let t=W.find(t=>String(t.criteriaid)===String(e));if(!t){alert(`Criteria not found`);return}Xe(t)},window.cancelCriteriaEdit=function(){document.querySelector(`#criteriaPopup`)?.remove()},window.deleteCriteria=async function(e){let t=W.find(t=>String(t.criteriaid)===String(e));if(!t){alert(`Criteria not found`);return}if(!confirm(`Delete this criteria?\n\n${t.criterianame}\n\nThis removes it from future inspection/load test forms.`))return;let n=await fetch(`${y}/equipment-type-criteria/${e}`,{method:`DELETE`}),r=await n.json();if(!n.ok){alert(`Error deleting criteria: `+r.error);return}alert(`Criteria deleted`),await $(),showEquipmentTypeCriteria()},window.showInspections=async function(){K(`inspections`)&&(G(`inspections`),await at())},window.showCertificateSearch=function(){K(`certificates`)&&(G(`certificates`),Ae(z,V,H))},window.showCustomerDetailedReport=function(e={}){K(`customer-report`)&&(G(`customer-report`),Ke(z,U,V,H,Ht,e))},window.showSystemHealth=function(){K(`system-health`)&&(G(`system-health`),zt())},window.handleCertificateEnter=function(e){e.key===`Enter`&&searchCertificates()},window.filterCertificateSites=function(){let e=document.querySelector(`#certClient`).value,t=document.querySelector(`#certSite`),n=document.querySelector(`#certSection`);n.innerHTML=`<option value="">All Sections</option>`,t.innerHTML=`
    <option value="">All Sites</option>
    ${(e?V.filter(t=>String(t.clientid)===String(e)):V).map(e=>`
      <option value="${l(e.siteid)}">
        ${c(e.sitename)}
      </option>
    `).join(``)}
  `},window.filterCertificateSections=function(){let e=document.querySelector(`#certSite`).value,t=document.querySelector(`#certSection`);t.innerHTML=`
    <option value="">All Sections</option>
    ${(e?H.filter(t=>String(t.siteid)===String(e)):H).map(e=>`
      <option value="${l(e.sectionid)}">
        ${c(e.sectionname)}
      </option>
    `).join(``)}
  `},window.clearCertificateSearch=function(){document.querySelector(`#certSearch`).value=``,document.querySelector(`#certInspectionType`).value=``,document.querySelector(`#certStatus`).value=``,document.querySelector(`#certClient`).value=``,document.querySelector(`#certSite`).innerHTML=`<option value="">All Sites</option>`,document.querySelector(`#certSection`).innerHTML=`<option value="">All Sections</option>`,document.querySelector(`#certDateFrom`).value=``,document.querySelector(`#certDateTo`).value=``,window.certCurrentPage=1,searchCertificates()},window.searchCertificates=async function(t=!0){t&&(window.certCurrentPage=1);let n=new URLSearchParams;n.append(`search`,document.querySelector(`#certSearch`)?.value||``),n.append(`inspectiontype`,document.querySelector(`#certInspectionType`)?.value||``),n.append(`status`,document.querySelector(`#certStatus`)?.value||``),n.append(`clientid`,document.querySelector(`#certClient`)?.value||``),n.append(`siteid`,document.querySelector(`#certSite`)?.value||``),n.append(`sectionid`,document.querySelector(`#certSection`)?.value||``),n.append(`datefrom`,document.querySelector(`#certDateFrom`)?.value||``),n.append(`dateto`,document.querySelector(`#certDateTo`)?.value||``),n.append(`page`,String(window.certCurrentPage||1)),n.append(`limit`,String(window.certRowsPerPage||25));let r=e(`certificates`,`testid`,`desc`);n.append(`sortKey`,r.key||`testid`),n.append(`sortDir`,r.direction||`desc`);let i=await fetch(`${y}/certificates/search?${n.toString()}`),a=await i.json();if(!i.ok){alert(`Error searching certificates: `+a.error);return}let o=Array.isArray(a)?a:a.rows||[];window.currentCertificatePageInfo=Array.isArray(a)?null:{currentPage:Number(a.page||1),pageSize:Number(a.limit||window.certRowsPerPage||25),totalRows:Number(a.total||o.length),totalPages:Number(a.totalPages||1),startIndex:(Number(a.page||1)-1)*Number(a.limit||window.certRowsPerPage||25),endIndex:(Number(a.page||1)-1)*Number(a.limit||window.certRowsPerPage||25)+o.length};let s=a.summary||null,c=s?s.safe:o.filter(e=>e.status===`SAFE`).length,l=s?s.notSafe:o.filter(e=>e.status===`NOT SAFE`).length,u=s?s.loadTest:o.filter(e=>e.inspectiontype===`LOADTEST`).length,d=s?s.visual:o.filter(e=>e.inspectiontype===`VISUAL`).length,f=s?Number(s.total||window.currentCertificatePageInfo?.totalRows||o.length):o.length;if(document.querySelector(`#certificateStats`).innerHTML=`
    <p><strong>Total:</strong> ${f||window.currentCertificatePageInfo?.totalRows||o.length}</p>
    <p><strong>Safe:</strong> ${c}</p>
    <p><strong>Not Safe:</strong> ${l}</p>
    <p><strong>Visual:</strong> ${d}</p>
    <p><strong>Load Tests:</strong> ${u}</p>
  `,o.length===0){document.querySelector(`#certificateResults`).innerHTML=`
      <p>No certificates found.</p>
    `;return}window.currentCertificateResults=o,Ze(o)};function D(t,n){let r=e(`certificates`,`testid`,`desc`),i=r.key===n,a=i?r.direction===`desc`?`v`:`^`:`^v`;return`
    <span class="certificate-sort-heading">
      <span>${t}</span>
      <button
        type="button"
        class="certificate-sort-btn ${i?`active`:``}"
        onclick="sortTable('certificates', '${n}', 'rerenderCertificateResults')"
        aria-label="Sort ${t}"
        title="Sort ${t}"
      >${a}</button>
    </span>
  `}window.rerenderCertificateResults=function(){window.certCurrentPage=1,searchCertificates(!1)};function Ze(e){let n=window.currentCertificatePageInfo?e:t(e,`certificates`,{testid:e=>e.testid,tagnumber:e=>e.tagnumber,clientname:e=>e.clientname,sitename:e=>e.sitename,description:e=>e.description,serialno:e=>e.serialno,inspectiontype:e=>e.inspectiontype,testdate:e=>e.testdate,status:e=>e.status,inspector:e=>e.inspector},`testid`,`desc`),r=window.currentCertificatePageInfo?{...window.currentCertificatePageInfo,rows:n}:i(n,`certCurrentPage`,`certRowsPerPage`);document.querySelector(`#certificateResults`).innerHTML=`
    ${a({...r,label:`certificates`,onPage:`goToCertificatePage`,onPageSize:`setCertificateRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${D(`Test ID`,`testid`)}</th>
          <th>${D(`Tag No`,`tagnumber`)}</th>
          <th>${D(`Client`,`clientname`)}</th>
          <th>${D(`Site`,`sitename`)}</th>
          <th>${D(`Asset`,`description`)}</th>
          <th>${D(`Serial No`,`serialno`)}</th>
          <th>${D(`Type`,`inspectiontype`)}</th>
          <th>${D(`Date`,`testdate`)}</th>
          <th>${D(`Status`,`status`)}</th>
          <th>${D(`Inspector`,`inspector`)}</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody>
        ${r.rows.map(e=>`
          <tr>
            <td>${c(e.testid)}</td>
            <td>${c(e.tagnumber||`-`)}</td>
            <td>${c(e.clientname||``)}</td>
            <td>${c(e.sitename||``)}</td>
            <td>${c(e.description||``)}</td>
            <td>${c(e.serialno||``)}</td>
            <td>${c(e.inspectiontype||``)}</td>
            <td>${c(e.testdate?e.testdate.split(`T`)[0]:``)}</td>
            <td>
              <strong class="${e.status===`SAFE`?`status-safe`:`status-unsafe`}">
                ${c(e.status||``)}
              </strong>
            </td>
            <td>${c(e.inspector||`-`)}</td>
            <td>
              <button onclick="previewCertificate(${e.testid})">Preview</button>
              <button onclick="openCertificateModal(${e.testid})">View</button>
              <a
                class="cert-action-link"
                href="${l(`${y}/inspections/${encodeURIComponent(e.testid)}/certificate.pdf?t=${Date.now()}`)}"
                download="certificate-${l(e.testid)}.pdf"
              >
                Download PDF
              </a>
              <button onclick="mailCertificate(${e.testid})">Mail</button>
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `}window.setCertificateRowsPerPage=function(e){window.certRowsPerPage=Number(e)||25,window.certCurrentPage=1,searchCertificates(!1)},window.goToCertificatePage=function(e){window.certCurrentPage=Math.max(1,Number(e)||1),searchCertificates(!1)},window.openCertificateFromSearch=function(){let e=document.querySelector(`#certificateSearch`).value.trim();if(!e){alert(`Enter a certificate number`);return}openCertificateModal(e)},window.showQuickInspection=function(){K(`quick-inspection`)&&(G(`quick-inspection`),Te())},window.handleQuickInspectionEnter=function(e){e.key===`Enter`&&quickFindAsset()};function Qe(e=``){let t=String(e||``).trim(),n=t.toLowerCase(),r=t.match(/[?&]qr=([^&\s]+)/i);if(r)return decodeURIComponent(r[1]).trim();let i=t.match(/[?&]nfc=([^&\s]+)/i);if(i)return decodeURIComponent(i[1]).trim();let a=t.match(/ATEC-ASSET-\d+/i);if(a)return a[0].trim();let o=t.match(/(?:Asset ID|Serial No|Hoist Serial No|Asset Tag)\s*:\s*([^\n\r]+)/i);if(o){let e=o[1].replace(/^-$/,``).trim();if(e)return e}if(n.includes(`atec asset label`)){let e=t.split(/\r?\n/).map(e=>e.trim()).find(e=>e&&!/^(atec asset label|website|landline|equipment|status|inspection pdf|load test pdf|last |next )/i.test(e));if(e)return e.replace(/^[^:]+:\s*/,``).trim()}return t}window.quickFindAsset=async function(){let e=document.querySelector(`#quickAssetSearch`),t=Qe(e?.value||``),n=t.toLowerCase().trim();e&&t!==e.value.trim()&&(e.value=t);let r=document.querySelector(`#quickInspectionResult`);if(!n){r.innerHTML=`
      <p>Please scan or enter an asset number.</p>
    `;return}let i=B.filter(e=>String(e.assetid||``).toLowerCase().includes(n)||(e.assettagno||``).toLowerCase().includes(n)||(e.serialno||``).toLowerCase().includes(n)||(e.hoistserialno||``).toLowerCase().includes(n)||(e.auxhoistserialno||``).toLowerCase().includes(n)||(e.qrcode||``).toLowerCase().includes(n));if(i.length===0){try{let e=/^nfc_[A-Za-z0-9_-]{32,64}$/.test(t)?`/assets/nfc/${encodeURIComponent(t)}`:`/assets/qr/${encodeURIComponent(n)}`,i=await fetch(`${y}${e}`);if(i.ok){let e=await i.json();quickOpenAsset(e.assetid);return}let a=await fetch(`${y}/inspections/assets/search?q=${encodeURIComponent(n)}`);if(a.ok){let e=await a.json();if(e.length===1){quickOpenAsset(e[0].assetid);return}if(e.length>1){r.innerHTML=`
            <div class="filter-card">
              <h3>Multiple Assets Found</h3>
              <p>Please select the correct asset.</p>

              <table>
                <thead>
                  <tr>
                    <th>Asset ID</th>
                    <th>Asset Tag</th>
                    <th>Serial No</th>
                    <th>Description</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  ${e.map(e=>`
                    <tr>
                      <td>${c(e.assetid)}</td>
                      <td>${c(e.assettagno||``)}</td>
                      <td>${c(e.serialno||e.hoistserialno||e.auxhoistserialno||``)}</td>
                      <td>${c(e.description||``)}</td>
                      <td>
                        <button onclick="quickOpenAsset(${e.assetid})">
                          Select
                        </button>
                      </td>
                    </tr>
                  `).join(``)}
                </tbody>
              </table>
            </div>
          `;return}}}catch(e){console.error(`Asset lookup failed:`,e)}r.innerHTML=`
      <div class="filter-card">
        <h3>No Asset Found</h3>
        <p>No asset matched: <strong>${c(n)}</strong></p>
      </div>
    `;return}if(i.length>1){r.innerHTML=`
      <div class="filter-card">
        <h3>Multiple Assets Found</h3>
        <p>Please select the correct asset.</p>

        <table>
          <thead>
            <tr>
              <th>Asset ID</th>
              <th>Asset Tag</th>
              <th>Serial No</th>
              <th>Description</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            ${i.map(e=>`
              <tr>
                <td>${c(e.assetid)}</td>
                <td>${c(e.assettagno||``)}</td>
                <td>${c(e.serialno||``)}</td>
                <td>${c(e.description||``)}</td>
                <td>
                  <button onclick="quickOpenAsset(${e.assetid})">
                    Select
                  </button>
                </td>
              </tr>
            `).join(``)}
          </tbody>
        </table>
      </div>
    `;return}quickOpenAsset(i[0].assetid)};let $e=null,O=!1;window.startQuickCameraScan=async function(){let e=document.querySelector(`#quickCameraScanner`),t=document.querySelector(`#quickCameraVideo`),n=document.querySelector(`#quickScanStatus`);if(!(`BarcodeDetector`in window)){n&&(n.textContent=`Camera scanning is not supported by this browser. Use the scan/type box above.`),e?.removeAttribute(`hidden`);return}try{let r=await window.BarcodeDetector.getSupportedFormats(),i=[`qr_code`,`code_128`,`code_39`,`ean_13`].filter(e=>r.includes(e)),a=new window.BarcodeDetector({formats:i});$e=await navigator.mediaDevices.getUserMedia({video:{facingMode:`environment`},audio:!1}),t.srcObject=$e,e?.removeAttribute(`hidden`),await t.play(),O=!0,n&&(n.textContent=`Scanning... point the camera at the QR label or barcode.`);let o=async()=>{if(O){try{let e=await a.detect(t);if(e.length){let t=Qe(e[0].rawValue);document.querySelector(`#quickAssetSearch`).value=t,stopQuickCameraScan(),quickFindAsset();return}}catch(e){console.error(`Quick camera scan failed:`,e)}requestAnimationFrame(o)}};o()}catch(t){console.error(`Unable to start camera scanner:`,t),e?.removeAttribute(`hidden`),n&&(n.textContent=`Camera could not start. Please allow camera access or use the scan/type box.`)}},window.stopQuickCameraScan=function(){O=!1,$e&&=($e.getTracks().forEach(e=>e.stop()),null);let e=document.querySelector(`#quickCameraVideo`);e&&(e.srcObject=null),document.querySelector(`#quickCameraScanner`)?.setAttribute(`hidden`,``)},window.quickOpenAsset=async function(e){let t=document.querySelector(`#quickInspectionResult`)||document.querySelector(`#dashboardAssetSearchResult`);if(!t){alert(`No asset result panel found`);return}let n=(t.id,`quick`),r=await fetch(`${y}/assets/${e}/quick-details`),i=await r.json();if(!r.ok){alert(`Asset details not found: `+i.error);return}let a=await je(i.assetid),o=await et(i.assetid),s=!!i.archived,u=fn()&&!s;t.innerHTML=`
    <div class="filter-card quick-result-card">
      <div class="quick-result-header">
        <h3>${s?`Archived Asset`:`Asset Found`}</h3>
        <strong>${c(i.assetid)}</strong>
      </div>

      <div class="quick-asset-grid">

        <div class="quick-detail-grid">
          <p><span>Asset Tag</span><strong>${c(i.assettagno||`-`)}</strong></p>
          <p><span>Serial No</span><strong>${c(i.serialno||`-`)}</strong></p>
          <p><span>Equipment</span><strong>${c(i.equipmenttype||`-`)}</strong></p>
          <p class="quick-wide"><span>Description</span><strong>${c(i.description||`-`)}</strong></p>
          <p><span>Client</span><strong>${c(i.clientname||`-`)}</strong></p>
          <p><span>Site</span><strong>${c(i.sitename||`-`)}</strong></p>
          <p><span>Section</span><strong>${c(i.sectionname||`-`)}</strong></p>
        </div>

        <div class="quick-history-card">
          <h4>Inspection History</h4>
          <p><span>Last Visual</span><strong>${c(i.lastvisualdate?i.lastvisualdate.split(`T`)[0]:`No record`)}</strong><em>${c(i.lastvisualstatus||`-`)}</em></p>
          <p><span>Last Load Test</span><strong>${c(i.lastloadtestdate?i.lastloadtestdate.split(`T`)[0]:`No record`)}</strong><em>${c(i.lastloadteststatus||`-`)}</em></p>
        </div>

      </div>

      <div class="quick-result-bottom">
        <div class="quick-photo-grid">
        ${i.media1?`
          <div class="quick-photo-card">
            <img src="${l(b(i.media1))}">
            <span>Photo 1</span>
          </div>
        `:``}

        ${i.media2?`
          <div class="quick-photo-card">
            <img src="${l(b(i.media2))}">
            <span>Photo 2</span>
          </div>
        `:``}
        </div>

        ${s?`<p class="login-error">This asset is archived. Inspection and load test actions are disabled.</p>`:``}

        <div class="form-actions quick-result-actions">
          ${o.length===1?`
            <button type="button" onclick="openAssetInActiveVisit(${o[0].visitid}, ${i.assetid})">
              Open in Visit ${c(o[0].visit_reference||o[0].visitid)}
            </button>
          `:o.length>1?`
            <button type="button" onclick="showVisitChoicesForAsset(${i.assetid})">
              Choose Active Visit
            </button>
          `:``}

          ${u&&de(i,W,`VISUAL`)?`
            <button class="load-test-btn" onclick="startInspection(${i.assetid}, 'VISUAL', '${n}', 'wizard')">Wizard Inspect</button>
          `:u?`
            <button onclick="startInspection(${i.assetid}, 'VISUAL', '${n}')">Visual Inspection</button>
          `:``}

          ${u?`
            <button class="load-test-btn" onclick="startInspection(${i.assetid}, 'LOADTEST', '${n}', '${ue(i)?`wizard`:`auto`}')">${ue(i)?`Wizard Load Test`:`Load Test`}</button>
          `:``}

          <button onclick="openAssetQrLabel(${i.assetid})">QR Label</button>
        </div>

      </div>
      ${Me(i,a)}
    </div>
  `};async function et(e){try{let t=await fetch(`${y}/inspection-visits/active-match?assetid=${encodeURIComponent(e)}`);if(!t.ok)return[];let n=await t.json();return Array.isArray(n.visits)?n.visits:[]}catch{return[]}}window.openAssetInActiveVisit=async function(e,t){await markVisitAssetScanned(e,t),await openInspectionVisit(e)},window.showVisitChoicesForAsset=async function(e){let t=await et(e),n=prompt(`Choose visit ID:\n${t.map(e=>`${e.visitid}: ${e.visit_reference||``}`).join(`
`)}`),r=t.find(e=>String(e.visitid)===String(n));r&&await openAssetInActiveVisit(r.visitid,e)},window.startQuickInspection=function(e,t){startInspection(e,t,`quick`)};function tt(){let e=document.querySelector(`#inspectionSearchType`),t=document.querySelector(`#inspectionAssetSearch`);window.inspectionAssetListState={searchType:e?e.value:window.inspectionAssetListState?.searchType||`all`,search:t?t.value:window.inspectionAssetListState?.search||``,currentPage:window.inspectionCurrentPage||window.inspectionAssetListState?.currentPage||1,rowsPerPage:Number(window.inspectionRowsPerPage||window.inspectionAssetListState?.rowsPerPage||25)}}function nt(){let e=window.inspectionAssetListState||{},t=document.querySelector(`#inspectionSearchType`),n=document.querySelector(`#inspectionAssetSearch`);t&&(t.value=e.searchType||`all`),n&&(n.value=e.search||``)}function rt(){let e=document.activeElement;return!e||![`inspectionAssetSearch`,`inspectionSearchType`].includes(e.id)?null:{id:e.id,selectionStart:typeof e.selectionStart==`number`?e.selectionStart:null,selectionEnd:typeof e.selectionEnd==`number`?e.selectionEnd:null}}function it(e){if(!e?.id)return;let t=document.getElementById(e.id);t&&(t.focus(),typeof t.setSelectionRange==`function`&&typeof e.selectionStart==`number`&&typeof e.selectionEnd==`number`&&t.setSelectionRange(e.selectionStart,e.selectionEnd))}let k=0;async function at(){let t=rt();tt();let n=window.inspectionAssetListState||{},r=e(`inspectionAssets`,`client_section_serial`,`asc`),i=++k,a=await Q(`${y}/inspections/assets?${new URLSearchParams({page:String(window.inspectionCurrentPage||n.currentPage||1),limit:String(window.inspectionRowsPerPage||n.rowsPerPage||25),searchBy:n.searchType||`all`,search:n.search||``,sortKey:r.key||`client_section_serial`,sortDir:r.direction||`asc`,archiveMode:`active`}).toString()}`,{rows:[],total:0,page:1,limit:Number(window.inspectionRowsPerPage||25)});i===k&&(B=a.rows||[],window.inspectionCurrentPage=Number(a.page||window.inspectionCurrentPage||1),window.inspectionRowsPerPage=Number(a.limit||window.inspectionRowsPerPage||25),Se(B,{serverPaged:!0,total:a.total||0,page:window.inspectionCurrentPage,limit:window.inspectionRowsPerPage}),nt(),it(t))}window.filterInspectionAssets=async function(e=!1){e&&(window.inspectionCurrentPage=1),await at()},window.setInspectionFilterKey=function(e){let t=document.querySelector(`#inspectionSearchType`);t&&(t.value=e,filterInspectionAssets(!0))},window.setInspectionRowsPerPage=function(e){window.inspectionRowsPerPage=Number(e)||25,window.inspectionCurrentPage=1,filterInspectionAssets()},window.goToInspectionPage=function(e){window.inspectionCurrentPage=Math.max(1,Number(e)||1),filterInspectionAssets()};function ot(e){return e!=null&&String(e).trim()!==``&&String(e).trim()!==`-`}function A(e,t,n=``){if(!ot(t))return``;let r=n?` ${n}`:``;return`<div><span>${c(e)}</span><strong>${c(t)}${c(r)}</strong></div>`}let st={"Top Hook Dimensions":`oemtophooksize`,"Bottom Hook Dimensions":`oembottomhooksize`,"Load Chain Diameter":`loadchaindiameter`,"Hook Size mm":`hooksize`,"Hoist Serial Number":`hoistserialno`,"WLL Main Hoist - Load Mass kg":`wll`,"WLL Auxiliary Hoist - Load Mass kg":`auxhoistwll`,"SWL of Beam - Load Mass kg":`wll`,"SWL Installed Hoist - Load Mass kg":`wll`,"SWL of Beam - Length Span mm":`span`,"WLL Main Hoist - Length Span/Jib mm":`span`,"WLL Auxiliary Hoist - Length Span/Jib mm":`span`,"Permissible Deflection mm":`permissibledeflection`,"WLL Main Hoist - Deflection mm":`permissibledeflection`,"WLL Auxiliary Hoist - Deflection mm":`permissibledeflection`,"Steel Wire Rope mm":`steelwireropemm`};function ct(e){let t=Number(e);return Number.isFinite(t)?String(Number.isInteger(t)?t:Number(t.toFixed(2))):``}function j(e=new Date){let t=new Date(e);return t.setMinutes(t.getMinutes()-t.getTimezoneOffset()),t.toISOString().split(`T`)[0]}function lt(e,t=`VISUAL`,n=``){let r=e?new Date(`${e}T00:00:00`):new Date,i=new Date(r),a=String(n||``).toUpperCase();return t===`LOADTEST`||a===`ANNUAL`?i.setFullYear(i.getFullYear()+1):i.setMonth(i.getMonth()+3),j(i)}function ut(e,t=`VISUAL`){return t!==`LOADTEST`&&String(e?.equipgroupid||``)===`400`}function M(e,t=`VISUAL`){return t===`LOADTEST`?``:ut(e,t)?`ANNUAL`:`FREQUENT`}function ft(e,t=`VISUAL`){return t===`LOADTEST`?`<input id="inspectionFrequency" type="hidden" value="">`:ut(e,t)?`
    <div class="form-group">
      <label>Inspection Frequency</label>
      <select id="inspectionFrequency" onchange="updateInspectionValidDateFromTestDate('${t}')">
        <option value="ANNUAL" selected>Annual</option>
        <option value="FREQUENT">Frequent</option>
      </select>
    </div>
  `:`<input id="inspectionFrequency" type="hidden" value="FREQUENT">`}window.updateInspectionValidDateFromTestDate=function(e=`VISUAL`){let t=document.querySelector(`#inspectionTestDate`)?.value||``,n=document.querySelector(`#inspectionValidDate`),r=document.querySelector(`#inspectionFrequency`)?.value||``;!n||!t||(n.value=lt(t,e,r))},window.assetSupportsCraneWizard=ue;function pt(e){return m([e?.criterianame,e?.criteriadescription].filter(Boolean).join(` `)).includes(`proof load`)}function mt(e){let t=m([e?.criterianame,e?.criteriadescription].filter(Boolean).join(` `));return t.includes(`hook measured size`)||t.includes(`measured hook throat opening`)}let ht=new Set([`401`,`402`,`404`,`406`]);function gt(e){let t=Number(e?.wll);return!Number.isFinite(t)||t<=0?``:ct(t*(ht.has(String(e?.equiptypeid))?1:1.1))}function _t(e,t){let n=t?.criterianame||t?.criteriadescription||``,r=m(n),i=st[n],a=r.includes(`auxiliary hoist`);return i?e?.[i]||``:pt(t)||mt(t)?``:r.includes(`top hook`)?e?.oemtophooksize||e?.hooksize||``:r.includes(`bottom hook`)?e?.oembottomhooksize||e?.hooksize||``:r.includes(`load chain`)||r.includes(`chain diameter`)?e?.loadchaindiameter||``:r.includes(`load mass`)||r.includes(`swl installed hoist`)||r.includes(`swl of beam`)?a?e?.auxhoistwll||``:e?.wll||``:r.includes(`span`)||r.includes(`length span`)||r.includes(`span/jib`)?e?.span||``:r.includes(`deflection`)?e?.permissibledeflection||``:r.includes(`wire rope`)?a?e?.auxhoistropemm||``:e?.steelwireropemm||``:r.includes(`hook opening`)||r.includes(`hook size`)?a?e?.auxhoisthooksize||``:e?.hooksize||``:r.includes(`hoist serial`)?a?e?.auxhoistserialno||``:e?.hoistserialno||``:``}function vt(e,t,n){return pt(t)?gt(e):mt(t)?e?.hooksize||``:n||``}let yt=new Set([`WLL Main Hoist - Deflection mm`,`WLL Main Hoist - Length Span/Jib mm`,`WLL Auxiliary Hoist - Deflection mm`,`WLL Auxiliary Hoist - Length Span/Jib mm`]);function bt(e){return[`WLL Main Hoist - Load Mass kg`,`WLL Auxiliary Hoist - Load Mass kg`,`SWL of Beam - Load Mass kg`,`SWL Installed Hoist - Load Mass kg`,`Hoist Proof Load Test kg`].includes(e)}function xt(e){return[`100`,`400`,`500`].includes(String(e?.equipgroupid||``))?!0:(window.atecCriteria||[]).some(t=>String(t.equiptypeid)===String(e?.equiptypeid)&&String(t.inspectioncategory||t.inspection_category||``).toUpperCase()===`LOADTEST`&&t.active!==!1&&t.active!==`false`)}function St(e,t,n){if(n!==`LOADTEST`||!m(e?.equipmenttype||``).includes(`crawl beam`))return!1;let r=m([t?.criterianame,t?.criteriadescription].filter(Boolean).join(` `));return r.includes(`serial number`)&&r.includes(`hoist`)&&(r.includes(`trolley`)||r.includes(`beam`))}function Ct(e){let t=(e.criterianame||``).toLowerCase();return e.fieldtype===`TEXT`||t.includes(`defects and recommendations`)}function wt(e){if(String(e.fieldtype||``).toUpperCase()!==`TEXT`)return!1;let t=[e.criterianame,e.criteriadescription].filter(Boolean).join(` `).toLowerCase().trim();return t.includes(`any defects noted`)||t.includes(`comments`)||t.includes(`remarks`)}function Dt(e,t=``){let n=String(t??``);return n.trim()?n:wt(e)?`None`:``}function Ot(e){return N(e)}function kt(e){return m([e?.criterianame,e?.criteriadescription].filter(Boolean).join(` `)).includes(`hook wear does not exceed allowable limits`)}function At(e,t){return e.filter(e=>t!==`LOADTEST`||!yt.has(e.criterianame)).filter(e=>!kt(e)).sort((e,t)=>Ot(e)?1:Ot(t)?-1:0)}function jt(e=`quick`){if(String(e||``).startsWith(`visit:`)){let t=String(e).split(`:`)[1];if(t){window.currentInspectionVisitId=null,openInspectionVisit(t);return}}if(e===`quick`){showQuickInspection();return}if(e===`assets`){showAssetSetup();return}showInspections()}window.returnToInspectionOrigin=jt,window.toggleFailRemark=function(e){let t=document.querySelector(`#result-${e}`)?.value,n=document.querySelector(`#fail-remarks-${e}`);n&&(n.style.display=t===`FAIL`||t===`NO`?`block`:`none`)};function N(e){let t=String(e?.criteriadescription||e?.criterianame||``).trim().toUpperCase();return t===`SAFE FOR CONTINUED OPERATION`||t===`SAFE FOR SERVICE`}function Mt(e){return String(e?.result??e?.savedresult??e?.measuredvalue??e?.value??``).trim().toUpperCase()}function P(e){return Mt(e)||(e.resulttype===`YES_NO`||N(e)?`YES`:`PASS`)}function Nt(e,t,n){return`<option value="${e}" ${n===e?`selected`:``}>${t}</option>`}function F(e){return String(e?.severity||``).toUpperCase()===`CRITICAL`}function I(e){return[`FAIL`,`NO`,`NOT SAFE`,`UNSAFE`].includes(String(e||``).trim().toUpperCase())}window.updateInspectionSafetyWarning=function(){let e=window.currentInspectionCriteria||[],t=e.filter(e=>{let t=document.querySelector(`#result-${e.criteriaid}`)?.value;return F(e)&&!N(e)&&I(t)}),n=document.querySelector(`#inspectionCriticalWarning`),r=e.find(N);if(r&&t.length){let e=document.querySelector(`#result-${r.criteriaid}`);e&&(e.value=e.querySelector(`option[value="NO"]`)?`NO`:`FAIL`,e.disabled=!0,e.dataset.autoForcedSafety=`true`,toggleFailRemark(r.criteriaid))}if(r&&t.length===0){let e=document.querySelector(`#result-${r.criteriaid}`);e&&(e.disabled=!1,e.dataset.autoForcedSafety===`true`&&(e.value=e.querySelector(`option[value="YES"]`)?`YES`:`PASS`,delete e.dataset.autoForcedSafety,toggleFailRemark(r.criteriaid)))}n&&(n.style.display=t.length?`block`:`none`,n.innerHTML=t.length?`<strong>NOT SAFE rule applied:</strong> ${t.length} critical item failed. SAFE FOR CONTINUED OPERATION is forced to NO and the certificate will be NOT SAFE.`:``)};function Pt(e,t={}){return`
    <div class="crane-asset-detail-grid">
      ${[[`Asset ID`,e.assetid],[`Asset Tag`,e.assettagno],[`Customer`,e.clientname||t.clientname],[`Site`,e.sitename||t.sitename],[`Section`,e.sectionname||t.sectionname],[`Equipment Type`,e.equipmenttype||t.equipmenttype],[`Description`,e.description],[`Manufacturer`,e.manufacturer],[`Model`,e.model],[`Serial No`,e.serialno],[`WLL/SWL`,e.wll?`${e.wll} kg`:``],[`Span`,e.span?`${e.span} mm`:``],[`Height of Lift`,e.heightoflift?`${e.heightoflift} mm`:``],[`Hoist`,e.hoistdescription],[`Hoist Serial`,e.hoistserialno],[`Aux Hoist`,e.auxhoistdescription],[`Aux Hoist Serial`,e.auxhoistserialno],[`Previous Visual`,[t.lastvisualdate,t.lastvisualstatus].filter(Boolean).join(` / `)],[`Previous Load Test`,[t.lastloadtestdate,t.lastloadteststatus].filter(Boolean).join(` / `)],[`Previous Expiry`,t.lastinspectionvaliddate||t.lastvisualvaliddate||t.lastloadtestvaliddate]].map(([e,t])=>`
        <div>
          <span>${c(e)}</span>
          <strong>${c(t||`-`)}</strong>
        </div>
      `).join(``)}
    </div>
  `}function Ft(e,t={}){return`
    <div class="crane-asset-detail-grid">
      ${[[`Asset ID`,e.assetid],[`Asset Tag`,e.assettagno],[`Customer`,e.clientname||t.clientname],[`Site`,e.sitename||t.sitename],[`Section`,e.sectionname||t.sectionname],[`Equipment Type`,e.equipmenttype||t.equipmenttype],[`Description`,e.description],[`Manufacturer`,e.manufacturer],[`Model`,e.model],[`Serial / Batch No`,e.serialno],[`Size`,e.size],[`Manufacture Date`,e.manufactdate],[`Previous Inspection`,[t.lastvisualdate,t.lastvisualstatus].filter(Boolean).join(` / `)],[`Previous Valid Date`,t.lastinspectionvaliddate||t.lastvisualvaliddate]].map(([e,t])=>`
        <div>
          <span>${c(e)}</span>
          <strong>${c(t||`-`)}</strong>
        </div>
      `).join(``)}
    </div>
  `}function It(e,t={}){return`
    <div class="crane-asset-detail-grid">
      ${[[`Asset ID`,e.assetid],[`Asset Tag`,e.assettagno],[`Customer`,e.clientname||t.clientname],[`Site`,e.sitename||t.sitename],[`Section`,e.sectionname||t.sectionname],[`Equipment Type`,e.equipmenttype||t.equipmenttype],[`Description`,e.description],[`Manufacturer`,e.manufacturer],[`Model`,e.model],[`Serial / ID`,e.serialno],[`WLL/SWL`,e.wll?`${e.wll} kg`:``],[`Length`,e.effectivelength?`${e.effectivelength} mm`:``],[`Diameter`,e.steelwireropemm?`${e.steelwireropemm} mm`:``],[`Hook Size`,e.hooksize?`${e.hooksize} mm`:``],[`Previous Inspection`,[t.lastvisualdate,t.lastvisualstatus].filter(Boolean).join(` / `)],[`Previous Valid Date`,t.lastinspectionvaliddate||t.lastvisualvaliddate]].map(([e,t])=>`
        <div>
          <span>${c(e)}</span>
          <strong>${c(t||`-`)}</strong>
        </div>
      `).join(``)}
    </div>
  `}function Lt(e,t,n,r){let i=t.filter(e=>e.fieldtype===`NUMBER`),a=t.filter(e=>e.fieldtype!==`NUMBER`);return`
    <section class="crane-wizard-step" data-step-title="${E(e)}">
      <div class="inspection-section-title">${c(e)}</div>

      ${i.length?`
        <div class="inspection-header measurements ${r===`LOADTEST`?`loadtest-measurements`:``}">
          <div>Criteria</div>
          <div>Standard Dimension</div>
          <div>Measured Dimension</div>
          ${r===`LOADTEST`?`<div>Comments / Remarks</div>`:``}
        </div>
        ${i.map(e=>Jt(e,n,r)).join(``)}
      `:``}

      ${a.length?`
        <div class="inspection-header visual">
          <div>Criteria</div>
          <div>Result</div>
          <div>Reason for FAIL (required)</div>
        </div>
        ${a.map(e=>tn(e)).join(``)}
      `:``}
    </section>
  `}function Rt(){return`
    <div class="harness-setup-fields">
      ${ie.setupQuestions.map(e=>e.type===`text`?`
        <label class="harness-setup-field harness-setup-field-wide">${c(e.label)}
          <input id="${l(e.id)}" type="text">
        </label>
      `:`
        <label class="harness-setup-field">${c(e.label)}
          <select id="${l(e.id)}" class="harness-setup-answer">
            <option value="">Select</option>
            <option value="YES">YES</option>
            <option value="NO">NO</option>
            <option value="UNKNOWN">UNKNOWN</option>
          </select>
        </label>
      `).join(``)}
    </div>
  `}function Vt(){return`
    <div class="harness-setup-fields sling-setup-fields">
      ${ae.setupQuestions.map(e=>e.type===`text`?`
        <label class="harness-setup-field harness-setup-field-wide">${c(e.label)}
          <input id="${l(e.id)}" type="text">
        </label>
      `:`
        <label class="harness-setup-field">${c(e.label)}
          <select id="${l(e.id)}" class="sling-setup-answer">
            <option value="">Select</option>
            <option value="YES">YES</option>
            <option value="NO">NO</option>
            <option value="UNKNOWN">UNKNOWN</option>
          </select>
        </label>
      `).join(``)}
    </div>
  `}function Gt(e,t,n,r,i){let a=v(t,ie,n);return`
    <div class="crane-wizard harness-wizard" data-return-page="${l(i)}" data-wizard-name="harness" data-inspection-type="${l(n)}">
      <div class="inspection-wizard-banner crane-wizard-banner">
        <div>
          <span>Guided Harness / Fall-Arrest Inspection</span>
          <strong>${c(e.equipmenttype||`Harness / Fall-Arrest`)} - Asset ${c(e.assetid)}</strong>
        </div>
        <p>Uses live equipment criteria, the existing save route, photos, signature, and certificate renderer.</p>
      </div>

      <div class="crane-wizard-progress">
        <div><strong id="craneWizardStepLabel">Step 1</strong><span id="craneWizardStepTitle">Asset confirmation</span></div>
        <progress id="craneWizardProgress" value="1" max="${a.length+5}"></progress>
      </div>

      <section class="crane-wizard-step" data-step-title="Asset confirmation">
        ${Ft(e,r)}
        <div class="quick-photo-grid">
          ${e.media1?`<div class="quick-photo-card"><img src="${l(b(e.media1))}"></div>`:``}
          ${e.media2?`<div class="quick-photo-card"><img src="${l(b(e.media2))}"></div>`:``}
        </div>
        <label class="crane-confirm-check">
          <input id="craneAssetConfirmed" type="checkbox">
          I confirm this is the correct harness or fall-arrest item.
        </label>
      </section>

      <section class="crane-wizard-step" data-step-title="Inspection setup">
        <div class="inspection-tag-card">
          <div class="inspection-tag-title">INSPECTION SETUP</div>
          <div class="inspector-identity-card">
            <div><span>Logged-in Inspector</span><strong>${c(R?.full_name||`-`)}</strong></div>
            <div><span>Inspector ID</span><strong>${c(R?.user_id||`-`)}</strong></div>
            <div><span>Signature</span><strong>${R?.signature_image?`Saved`:`Not uploaded`}</strong></div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Inspection Date</label>
              <input id="inspectionTestDate" type="date" value="${j()}" onchange="updateInspectionValidDateFromTestDate('${n}')">
            </div>
            <div class="form-group">
              <label>Inspection Tag No <span class="optional-label">(Optional)</span></label>
              <input id="inspectionTagNo" class="inspection-tag-input" type="text" placeholder="Not issued yet" autocomplete="off">
            </div>
            <div class="form-group">
              <label>Certificate Expiry Date</label>
              <input id="inspectionValidDate" type="date" value="${lt(j(),n,M(e,n))}">
            </div>
            ${ft(e,n)}
          </div>
          ${Rt()}
          <label class="harness-setup-field harness-setup-field-wide">Defect / rejection summary<textarea id="inspectionComments" rows="3"></textarea></label>
        </div>
      </section>

      ${a.map(([t,r])=>Lt(t,r,e,n)).join(``)}

      <section class="crane-wizard-step" data-step-title="Photos">
        <h3>Photos</h3>
        <p class="muted-text">${c(ie.photoPrompts.join(`, `))}</p>
        <input id="inspectionPhotoFiles" type="file" accept="image/*" multiple onchange="handleInspectionPhotoSelection(event)">
        <div id="inspectionPhotoPreview" class="inspection-photo-preview-grid">
          <p class="muted-text">No inspection photos selected.</p>
        </div>
      </section>

      <section class="crane-wizard-step" data-step-title="Inspector declaration">
        <div id="inspectionCriticalWarning" class="inspection-critical-warning" style="display:none;"></div>
        <label class="crane-confirm-check">
          <input id="craneInspectorDeclaration" type="checkbox">
          I examined the relevant accessible components, recorded known defects and limitations, and confirm the final decision reflects this inspection.
        </label>
      </section>

      <section class="crane-wizard-step" data-step-title="Review and submit">
        <div id="craneWizardReview" class="crane-review-panel"></div>
        <label class="crane-confirm-check">
          <input id="craneSubmitConfirmed" type="checkbox">
          I confirm this harness / fall-arrest inspection is ready to save.
        </label>
      </section>

      <div class="crane-wizard-nav">
        <button type="button" class="secondary-btn" onclick="startInspection(${e.assetid}, '${n}', '${i}', 'generic')">Use Generic Form</button>
        <button type="button" class="secondary-btn" onclick="craneWizardBack()">Back</button>
        <button type="button" id="craneWizardNextButton" onclick="craneWizardNext()">Next</button>
        <button type="button" class="load-test-btn" id="craneWizardSubmit" onclick="saveInspection(${e.assetid}, '${n}', '${i}')" hidden>Save ${n}</button>
        <button type="button" onclick="returnToInspectionOrigin('${i}')">Cancel</button>
      </div>
    </div>
  `}function Kt(e,t,n,r,i){let a=n===`LOADTEST`?`Load-Test Setup`:`Inspection Setup`,o=v(t,ae,n);return`
    <div class="crane-wizard sling-wizard" data-return-page="${l(i)}" data-wizard-name="sling" data-inspection-type="${l(n)}">
      <div class="inspection-wizard-banner crane-wizard-banner">
        <div>
          <span>Guided Sling ${n===`LOADTEST`?`Load Test`:`Inspection`}</span>
          <strong>${c(e.equipmenttype||`Sling`)} - Asset ${c(e.assetid)}</strong>
        </div>
        <p>Uses live equipment criteria, the existing save route, photos, signature, and certificate renderer.</p>
      </div>

      <div class="crane-wizard-progress">
        <div><strong id="craneWizardStepLabel">Step 1</strong><span id="craneWizardStepTitle">Asset confirmation</span></div>
        <progress id="craneWizardProgress" value="1" max="${o.length+5}"></progress>
      </div>

      <section class="crane-wizard-step" data-step-title="Asset confirmation">
        ${It(e,r)}
        <div class="quick-photo-grid">
          ${e.media1?`<div class="quick-photo-card"><img src="${l(b(e.media1))}"></div>`:``}
          ${e.media2?`<div class="quick-photo-card"><img src="${l(b(e.media2))}"></div>`:``}
        </div>
        <label class="crane-confirm-check">
          <input id="craneAssetConfirmed" type="checkbox">
          I confirm this is the correct sling asset.
        </label>
      </section>

      <section class="crane-wizard-step" data-step-title="${E(a)}">
        <div class="inspection-tag-card">
          <div class="inspection-tag-title">${c(a.toUpperCase())}</div>
          <div class="inspector-identity-card">
            <div><span>Logged-in Inspector</span><strong>${c(R?.full_name||`-`)}</strong></div>
            <div><span>Inspector ID</span><strong>${c(R?.user_id||`-`)}</strong></div>
            <div><span>Signature</span><strong>${R?.signature_image?`Saved`:`Not uploaded`}</strong></div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>${n===`LOADTEST`?`Load Test Date`:`Inspection Date`}</label>
              <input id="inspectionTestDate" type="date" value="${j()}" onchange="updateInspectionValidDateFromTestDate('${n}')">
            </div>
            <div class="form-group">
              <label>Inspection Tag No <span class="optional-label">(Optional)</span></label>
              <input id="inspectionTagNo" class="inspection-tag-input" type="text" placeholder="Not issued yet" autocomplete="off">
            </div>
            <div class="form-group">
              <label>Certificate Expiry Date</label>
              <input id="inspectionValidDate" type="date" value="${lt(j(),n,M(e,n))}">
            </div>
            ${ft(e,n)}
          </div>
          ${n===`LOADTEST`?`
            <div class="crane-load-test-grid">
              <label>Rated WLL<input id="craneRatedCapacity" type="text" value="${E(e.wll||``)}" readonly></label>
              <label>Intended Test Load<input id="craneIntendedTestLoad" type="number" step="0.01" min="0" placeholder="Manual capture required"></label>
              <label>Actual Applied Load<input id="craneActualTestLoad" type="number" step="0.01" min="0"></label>
              <label>Test Duration<input id="craneTestDuration" type="text"></label>
              <label class="crane-wide-field">Reason if full test could not be completed<input id="craneLoadExceptionReason" type="text"></label>
            </div>
          `:``}
          ${Vt()}
          <label class="harness-setup-field harness-setup-field-wide">Defect / rejection summary<textarea id="inspectionComments" rows="3"></textarea></label>
        </div>
      </section>

      ${o.map(([t,r])=>Lt(t,r,e,n)).join(``)}

      <section class="crane-wizard-step" data-step-title="Photos">
        <h3>Photos</h3>
        <p class="muted-text">${c(ae.photoPrompts.join(`, `))}</p>
        <input id="inspectionPhotoFiles" type="file" accept="image/*" multiple onchange="handleInspectionPhotoSelection(event)">
        <div id="inspectionPhotoPreview" class="inspection-photo-preview-grid">
          <p class="muted-text">No inspection photos selected.</p>
        </div>
      </section>

      <section class="crane-wizard-step" data-step-title="Inspector declaration">
        <div id="inspectionCriticalWarning" class="inspection-critical-warning" style="display:none;"></div>
        <label class="crane-confirm-check">
          <input id="craneInspectorDeclaration" type="checkbox">
          I examined the accessible load-bearing components, recorded known defects and limitations, and confirm the final decision reflects this inspection.
        </label>
      </section>

      <section class="crane-wizard-step" data-step-title="Review and submit">
        <div id="craneWizardReview" class="crane-review-panel"></div>
        <label class="crane-confirm-check">
          <input id="craneSubmitConfirmed" type="checkbox">
          I confirm this sling ${n===`LOADTEST`?`load test`:`inspection`} is ready to save.
        </label>
      </section>

      <div class="crane-wizard-nav">
        <button type="button" class="secondary-btn" onclick="startInspection(${e.assetid}, '${n}', '${i}', 'generic')">Use Generic Form</button>
        <button type="button" class="secondary-btn" onclick="craneWizardBack()">Back</button>
        <button type="button" id="craneWizardNextButton" onclick="craneWizardNext()">Next</button>
        <button type="button" class="load-test-btn" id="craneWizardSubmit" onclick="saveInspection(${e.assetid}, '${n}', '${i}')" hidden>Save ${n}</button>
        <button type="button" onclick="returnToInspectionOrigin('${i}')">Cancel</button>
      </div>
    </div>
  `}function qt(e,t,n,r,i){let a=n===`LOADTEST`?`Test Setup`:`Inspection Setup`,o=v(t,re,n);return`
    <div class="crane-wizard" data-return-page="${l(i)}">
      <div class="inspection-wizard-banner crane-wizard-banner">
        <div>
          <span>Guided Crane ${n===`LOADTEST`?`Load Test`:`Inspection`}</span>
          <strong>${c(e.equipmenttype||`Crane`)} - Asset ${c(e.assetid)}</strong>
        </div>
        <p>Uses live equipment criteria, the existing save route, photos, signature, and certificate renderer.</p>
      </div>

      <div class="crane-wizard-progress">
        <div><strong id="craneWizardStepLabel">Step 1</strong><span id="craneWizardStepTitle">Asset confirmation</span></div>
        <progress id="craneWizardProgress" value="1" max="${o.length+5}"></progress>
      </div>

      <section class="crane-wizard-step" data-step-title="Asset confirmation">
        ${Pt(e,r)}
        <div class="quick-photo-grid">
          ${e.media1?`<div class="quick-photo-card"><img src="${l(b(e.media1))}"></div>`:``}
          ${e.media2?`<div class="quick-photo-card"><img src="${l(b(e.media2))}"></div>`:``}
        </div>
        <label class="crane-confirm-check">
          <input id="craneAssetConfirmed" type="checkbox">
          I confirm this is the correct crane asset.
        </label>
      </section>

      <section class="crane-wizard-step" data-step-title="${E(a)}">
        <div class="inspection-tag-card">
          <div class="inspection-tag-title">${c(a.toUpperCase())}</div>
          <div class="inspector-identity-card">
            <div><span>Logged-in Inspector</span><strong>${c(R?.full_name||`-`)}</strong></div>
            <div><span>LMI Number</span><strong>${c(R?.lmi_number||`-`)}</strong></div>
            <div><span>Signature</span><strong>${R?.signature_image?`Saved`:`Not uploaded`}</strong></div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>${n===`LOADTEST`?`Load Test Date`:`Inspection Date`}</label>
              <input id="inspectionTestDate" type="date" value="${j()}" onchange="updateInspectionValidDateFromTestDate('${n}')">
            </div>
            <div class="form-group">
              <label>Inspection Tag No <span class="optional-label">(Optional)</span></label>
              <input id="inspectionTagNo" class="inspection-tag-input" type="text" placeholder="Not issued yet" autocomplete="off">
            </div>
            <div class="form-group">
              <label>Certificate Expiry Date</label>
              <input id="inspectionValidDate" type="date" value="${lt(j(),n,M(e,n))}">
            </div>
            ${ft(e,n)}
          </div>
          ${n===`LOADTEST`?`
            <div class="crane-load-test-grid">
              <label>Rated Capacity<input id="craneRatedCapacity" type="text" value="${E(e.wll||``)}" readonly></label>
              <label>Intended Test Load<input id="craneIntendedTestLoad" type="number" step="0.01" min="0" placeholder="Manual capture required"></label>
              <label>Actual Applied Load<input id="craneActualTestLoad" type="number" step="0.01" min="0"></label>
              <label>Test Duration<input id="craneTestDuration" type="text" placeholder="e.g. 10 min"></label>
              <label class="crane-wide-field">Reason if full prescribed load could not be applied<input id="craneLoadExceptionReason" type="text"></label>
            </div>
          `:``}
          <label class="crane-wide-field">Defect summary / inspection notes<textarea id="inspectionComments" rows="3"></textarea></label>
        </div>
      </section>

      ${o.map(([t,r])=>Lt(t,r,e,n)).join(``)}

      <section class="crane-wizard-step" data-step-title="Photos">
        <h3>Photos</h3>
        <p class="muted-text">Add crane, identification plate, hook, hoist, rope/chain, control station, safety-device, defect, or load-test setup photos where needed.</p>
        <input id="inspectionPhotoFiles" type="file" accept="image/*" multiple onchange="handleInspectionPhotoSelection(event)">
        <div id="inspectionPhotoPreview" class="inspection-photo-preview-grid">
          <p class="muted-text">No inspection photos selected.</p>
        </div>
      </section>

      <section class="crane-wizard-step" data-step-title="Inspector declaration">
        <div id="inspectionCriticalWarning" class="inspection-critical-warning" style="display:none;"></div>
        <label class="crane-confirm-check">
          <input id="craneInspectorDeclaration" type="checkbox">
          I conducted or supervised this inspection, recorded known defects, and confirm the final status reflects the result.
        </label>
      </section>

      <section class="crane-wizard-step" data-step-title="Review and submit">
        <div id="craneWizardReview" class="crane-review-panel"></div>
        <label class="crane-confirm-check">
          <input id="craneSubmitConfirmed" type="checkbox">
          I confirm this crane ${n===`LOADTEST`?`load test`:`inspection`} is ready to save.
        </label>
      </section>

      <div class="crane-wizard-nav">
        <button type="button" class="secondary-btn" onclick="startInspection(${e.assetid}, '${n}', '${i}', 'generic')">Use Generic Form</button>
        <button type="button" class="secondary-btn" onclick="craneWizardBack()">Back</button>
        <button type="button" id="craneWizardNextButton" onclick="craneWizardNext()">Next</button>
        <button type="button" class="load-test-btn" id="craneWizardSubmit" onclick="saveInspection(${e.assetid}, '${n}', '${i}')" hidden>Save ${n}</button>
        <button type="button" onclick="returnToInspectionOrigin('${i}')">Cancel</button>
      </div>
    </div>
  `}function Jt(e,t,n){let r=_t(t,e),i=vt(t,e,r);return`
    <div class="inspection-row compact-row ${n===`LOADTEST`?`loadtest-measurement-row`:``}">
      <div class="inspection-criteria">
        ${c(h(e))}
        ${e.severity?`<span class="inspection-criteria-badge ${l(String(e.severity).toLowerCase())}">${c(e.severity)}</span>`:``}
      </div>

      <div class="comparison-grid">
        ${r?`
          <input
            type="text"
            value="${E(r)}"
            readonly
            class="readonly-value"
          >
        `:`
          <div class="readonly-value readonly-value-empty"></div>
        `}

        <input
          id="measured-${e.criteriaid}"
          type="text"
          value="${E(i)}"
        >
      </div>

      ${n===`LOADTEST`&&bt(e.criterianame)?`
        <div class="inspection-remarks">
          <input
            id="remarks-${e.criteriaid}"
            type="text"
            placeholder="Comments / Remarks"
          >
        </div>
      `:n===`LOADTEST`?`<div></div>`:``}
    </div>
  `}function tn(e){let t=P(e);return Ct(e)?`
      <div class="inspection-row compact-row">
        <div class="inspection-criteria">
          ${c(h(e))}
          ${e.severity?`<span class="inspection-criteria-badge ${l(String(e.severity).toLowerCase())}">${c(e.severity)}</span>`:``}
        </div>

        <div class="inspection-result inspection-text-result">
          <textarea
            id="remarks-${e.criteriaid}"
            rows="3"
            placeholder="${E(e.criterianame)}"
          >${E(Dt(e))}</textarea>
        </div>
      </div>
    `:`
    <div class="inspection-row compact-row">
      <div class="inspection-criteria">
        ${c(h(e))}
        ${e.severity?`<span class="inspection-criteria-badge ${l(String(e.severity).toLowerCase())}">${c(e.severity)}</span>`:``}
      </div>

      <div class="inspection-result">
        <select
          id="result-${e.criteriaid}"
          onchange="toggleFailRemark(${e.criteriaid}); updateInspectionSafetyWarning()"
        >
          ${e.resulttype===`YES_NO`||N(e)?`
                ${Nt(`YES`,`YES`,t)}
                ${Nt(`NO`,`NO`,t)}
                ${Nt(`N/A`,`N/A`,t)}
              `:`
                ${Nt(`PASS`,`PASS`,t)}
                ${Nt(`FAIL`,`FAIL`,t)}
                ${Nt(`N/A`,`N/A`,t)}
              `}
        </select>
      </div>

      <div
        class="inspection-remarks"
        id="fail-remarks-${e.criteriaid}"
        style="display:none;"
      >
        <input
          id="remarks-${e.criteriaid}"
          type="text"
          placeholder="Reason for FAIL"
        >
      </div>
    </div>
  `}function sn(e,t,n,r){return`
    ${t.length?`
      <div class="inspection-section-title">
        Measurements
      </div>

      <div class="inspection-header measurements ${r===`LOADTEST`?`loadtest-measurements`:``}">
        <div>Criteria</div>
        <div>Standard Dimension</div>
        <div>Measured Dimension</div>
        ${r===`LOADTEST`?`<div>Comments / Remarks</div>`:``}
      </div>

      ${t.map(t=>Jt(t,e,r)).join(``)}
    `:``}

    <div class="inspection-section-title">
      Visual Inspection
    </div>

    <div class="inspection-header visual">
      <div>Criteria</div>
      <div>Result</div>
      <div>Reason for FAIL (required)</div>
    </div>

    ${n.map(e=>tn(e)).join(``)}
  `}function cn(e,t,n){return`
    <div class="inspection-wizard-banner">
      <div>
        <span>Inspection Wizard</span>
        <strong>Chain Block / Lever Hoist</strong>
      </div>
      <p>Guided sections use the same saved criteria and certificate output as the normal inspection form.</p>
    </div>

    ${v(t,ne,n).map(([t,r])=>{let i=r.filter(e=>e.fieldtype===`NUMBER`),a=r.filter(e=>e.fieldtype!==`NUMBER`);return`
        <div class="inspection-wizard-section">
          <div class="inspection-section-title">${t}</div>

          ${i.length?`
            <div class="inspection-header measurements ${n===`LOADTEST`?`loadtest-measurements`:``}">
              <div>Criteria</div>
              <div>Standard Dimension</div>
              <div>Measured Dimension</div>
              ${n===`LOADTEST`?`<div>Comments / Remarks</div>`:``}
            </div>
            ${i.map(t=>Jt(t,e,n)).join(``)}
          `:``}

          ${a.length?`
            <div class="inspection-header visual">
              <div>Criteria</div>
              <div>Result</div>
              <div>Reason for FAIL (required)</div>
            </div>
            ${a.map(e=>tn(e)).join(``)}
          `:``}
        </div>
      `}).join(``)}
  `}function mn(e,t,n,r,i){let a=le(e,t,i);return a===`CRANE`?sn(e,n,r,i):a===`CHAIN_BLOCK_LEVER_HOIST`?cn(e,t,i):sn(e,n,r,i)}window.pendingInspectionPhotos=[],window.craneWizardCurrentStep=0,window.inspectionSaveInProgress=!1;function hn(){return Array.from(document.querySelectorAll(`.crane-wizard-step`))}function gn(){return(window.currentInspectionCriteria||[]).filter(e=>{let t=document.querySelector(`#result-${e.criteriaid}`)?.value;return F(e)&&!N(e)&&I(t)})}function _n(e){let t=hn()[e];if(!t)return!0;if(t.querySelector(`#craneAssetConfirmed`)&&!document.querySelector(`#craneAssetConfirmed`)?.checked)return alert(`Confirm the correct asset before continuing.`),!1;let n=t.querySelector(`#inspectionTestDate`),r=t.querySelector(`#inspectionValidDate`);if(n&&!n.value)return alert(`Select an inspection date before continuing.`),n.focus(),!1;if(r&&!r.value)return alert(`Select a valid date before continuing.`),r.focus(),!1;if(n?.value&&r?.value&&new Date(r.value)<new Date(n.value))return alert(`Valid date cannot be before the inspection date.`),r.focus(),!1;let i=Array.from(t.querySelectorAll(`.harness-setup-answer`)).find(e=>!e.value);if(i)return alert(`Complete the harness inspection setup questions before continuing.`),i.focus(),!1;let a=document.querySelector(`#harnessInspectionIncompleteReason`),o=[`#harnessAvailableForFullExamination`,`#harnessCleanEnoughForInspection`].some(e=>document.querySelector(e)?.value===`NO`);if(t.querySelector(`#harnessInspectionIncompleteReason`)&&o&&!a?.value.trim())return alert(`Enter a reason when the harness inspection could not be fully completed.`),a?.focus(),!1;let s=Array.from(t.querySelectorAll(`.sling-setup-answer`)).find(e=>!e.value);if(s)return alert(`Complete the sling inspection setup questions before continuing.`),s.focus(),!1;let c=document.querySelector(`#slingInspectionIncompleteReason`),l=document.querySelector(`#slingCleanAvailable`)?.value===`NO`;if(t.querySelector(`#slingInspectionIncompleteReason`)&&l&&!c?.value.trim())return alert(`Enter a reason when the sling inspection could not be fully completed.`),c?.focus(),!1;let u=Array.from(t.querySelectorAll(`input[type="number"], input[id^="measured-"]`)).find(e=>e.value.trim()&&!Number.isFinite(Number(e.value)));if(u)return alert(`Enter a valid numeric measurement.`),u.focus(),!1;let d=Array.from(t.querySelectorAll(`select[id^="result-"]`)).find(e=>{if(![`FAIL`,`NO`].includes(e.value))return!1;let t=e.id.replace(`result-`,``);return N((window.currentInspectionCriteria||[]).find(e=>String(e.criteriaid)===t))&&e.dataset.autoForcedSafety===`true`?!1:!document.querySelector(`#remarks-${t}`)?.value.trim()});if(d){let e=d.id.replace(`result-`,``);return document.querySelector(`#fail-remarks-${e}`)?.style.removeProperty(`display`),alert(`Enter a reason/comment for every failed crane criterion.`),document.querySelector(`#remarks-${e}`)?.focus(),!1}return t.querySelector(`#craneInspectorDeclaration`)&&!document.querySelector(`#craneInspectorDeclaration`)?.checked?(alert(`Confirm the inspector declaration before review.`),!1):t.querySelector(`#craneSubmitConfirmed`)&&!document.querySelector(`#craneSubmitConfirmed`)?.checked?(alert(`Confirm the review before saving.`),!1):!0}function vn(){return document.querySelector(`.harness-wizard`)?ie.setupQuestions.map(e=>{let t=document.querySelector(`#${e.id}`)?.value||``;return[e.label,t||`-`]}):[]}function Y(){return document.querySelector(`.sling-wizard`)?ae.setupQuestions.map(e=>{let t=document.querySelector(`#${e.id}`)?.value||``;return[e.label,t||`-`]}):[]}function yn(){let e=document.querySelector(`#craneWizardReview`);if(!e)return;updateInspectionSafetyWarning();let t=(window.currentInspectionCriteria||[]).filter(e=>{let t=document.querySelector(`#result-${e.criteriaid}`)?.value;return I(t)}),n=(window.currentInspectionCriteria||[]).filter(e=>document.querySelector(`#measured-${e.criteriaid}`)?.value),r=gn(),i=t.length||r.length?`NOT SAFE`:`SAFE`,a=(window.pendingInspectionPhotos||[]).length,o=vn(),s=Y();e.innerHTML=`
    <div class="crane-review-grid">
      <div><span>Inspection Type</span><strong>${c(document.querySelector(`#inspectionTestDate`)&&document.querySelector(`.crane-wizard`)?.dataset.inspectionType||``)}</strong></div>
      <div><span>Test Date</span><strong>${c(document.querySelector(`#inspectionTestDate`)?.value||`-`)}</strong></div>
      <div><span>Valid Date</span><strong>${c(document.querySelector(`#inspectionValidDate`)?.value||`-`)}</strong></div>
      <div><span>Inspection Tag Number</span><strong>${c(Bt(document.querySelector(`#inspectionTagNo`)?.value))}</strong></div>
      <div><span>Inspector</span><strong>${c(R?.full_name||`-`)}</strong></div>
      <div><span>Signature</span><strong>${R?.signature_image?`Saved`:`Not uploaded`}</strong></div>
      <div><span>Photos</span><strong>${a}</strong></div>
      <div><span>Final Status</span><strong class="${i===`SAFE`?`status-safe`:`status-unsafe`}">${i}</strong></div>
    </div>
    ${o.length?`<h3>Fall-Arrest History / Inspection Conditions</h3><ul>${o.map(([e,t])=>`<li>${c(e)}: ${c(t)}</li>`).join(``)}</ul>`:``}
    ${s.length?`<h3>Sling Setup / Load History</h3><ul>${s.map(([e,t])=>`<li>${c(e)}: ${c(t)}</li>`).join(``)}</ul>`:``}
    ${r.length?`<div class="inspection-critical-warning"><strong>Forced NOT SAFE:</strong> ${r.map(h).map(c).join(`; `)}</div>`:``}
    ${t.length?`<h3>Failed / Not Safe Criteria</h3><ul>${t.map(e=>`<li>${c(h(e))}</li>`).join(``)}</ul>`:`<p>No failed criteria recorded.</p>`}
    ${n.length?`<h3>Measured Values</h3><ul>${n.map(e=>`<li>${c(h(e))}: ${c(document.querySelector(`#measured-${e.criteriaid}`)?.value||``)}</li>`).join(``)}</ul>`:``}
    <h3>Defect Summary</h3>
    <p>${c(document.querySelector(`#inspectionComments`)?.value||`-`)}</p>
  `}function bn(){let e=hn();if(!e.length)return;window.craneWizardCurrentStep=Math.max(0,Math.min(window.craneWizardCurrentStep||0,e.length-1)),e.forEach((e,t)=>{e.hidden=t!==window.craneWizardCurrentStep});let t=e[window.craneWizardCurrentStep]?.dataset.stepTitle||``,n=document.querySelector(`#craneWizardStepLabel`),r=document.querySelector(`#craneWizardStepTitle`),i=document.querySelector(`#craneWizardProgress`),a=document.querySelector(`#craneWizardSubmit`),o=document.querySelector(`#craneWizardNextButton`);n&&(n.textContent=`Step ${window.craneWizardCurrentStep+1} of ${e.length}`),r&&(r.textContent=t),i&&(i.max=e.length,i.value=window.craneWizardCurrentStep+1),window.craneWizardCurrentStep===e.length-1&&yn(),a&&(a.hidden=window.craneWizardCurrentStep!==e.length-1),o&&(o.hidden=window.craneWizardCurrentStep===e.length-1),window.scrollTo({top:0,behavior:`smooth`})}window.craneWizardNext=function(){_n(window.craneWizardCurrentStep||0)&&(window.craneWizardCurrentStep=(window.craneWizardCurrentStep||0)+1,bn())},window.craneWizardBack=function(){window.craneWizardCurrentStep=Math.max(0,(window.craneWizardCurrentStep||0)-1),bn()};function xn(e=`GENERAL`){return[`GENERAL`,`DEFECT`,`REPAIR`,`LOAD_TEST`,`NAMEPLATE`,`HOOK`,`WIRE_ROPE`,`STRUCTURE`,`ELECTRICAL`].map(t=>`
    <option value="${t}" ${e===t?`selected`:``}>
      ${t.replaceAll(`_`,` `)}
    </option>
  `).join(``)}window.handleInspectionPhotoSelection=function(e){Array.from(e.target.files||[]).forEach(e=>{window.pendingInspectionPhotos.push({id:`${Date.now()}-${Math.random()}`,file:e,caption:``,photoType:`GENERAL`,previewUrl:URL.createObjectURL(e)})}),e.target.value=``,Sn()},window.updateInspectionPhotoMeta=function(e,t,n){let r=window.pendingInspectionPhotos.find(t=>t.id===e);r&&(r[t]=n)},window.removeInspectionPhoto=function(e){let t=window.pendingInspectionPhotos.find(t=>t.id===e);t?.previewUrl&&URL.revokeObjectURL(t.previewUrl),window.pendingInspectionPhotos=window.pendingInspectionPhotos.filter(t=>t.id!==e),Sn()};function Sn(){let e=document.querySelector(`#inspectionPhotoPreview`);if(e){if(!window.pendingInspectionPhotos.length){e.innerHTML=`<p class="muted-text">No inspection photos selected.</p>`;return}e.innerHTML=window.pendingInspectionPhotos.map(e=>`
    <div class="inspection-photo-preview-card">
      <img src="${e.previewUrl}" alt="Inspection photo preview">
      <div class="inspection-photo-preview-fields">
        <label>
          Photo Type
          <select onchange="updateInspectionPhotoMeta('${e.id}', 'photoType', this.value)">
            ${xn(e.photoType)}
          </select>
        </label>
        <label>
          Caption
          <input
            type="text"
            value="${E(e.caption)}"
            placeholder="Optional caption"
            oninput="updateInspectionPhotoMeta('${e.id}', 'caption', this.value)"
          >
        </label>
        <button type="button" class="secondary-btn" onclick="removeInspectionPhoto('${e.id}')">
          Remove
        </button>
      </div>
    </div>
  `).join(``)}}window.startInspection=async function(e,t=`VISUAL`,n=`quick`,r=`auto`,i=null){if(!fn()){alert(`You do not have permission to create inspections or load tests.`);return}window.currentInspectionVisitId=i||null,n===`assets`&&w();let a;try{a=await An(e)}catch(e){alert(e.message||`Asset not found`);return}let o=await fetch(`${y}/assets/${e}/quick-details`),s=j(),u=await o.json();window.scrollTo(0,0),window.pendingInspectionPhotos=[];let d=At(W.filter(e=>String(e.equiptypeid)===String(a.equiptypeid)&&String(e.inspectioncategory)===String(t)&&e.active!==!1),t);d=d.filter(e=>!St(a,e,t));let f=d.filter(e=>e.fieldtype===`NUMBER`),p=d.filter(e=>e.fieldtype!==`NUMBER`);window.currentInspectionCriteria=d,window.currentInspectionType=t;let ee=String(a.equipgroupid||``)===`400`,m=lt(s,t,M(a,t)),h=le(a,d,t);if(r!==`generic`&&h===`CRANE`){document.querySelector(`#page`).innerHTML=qt(a,d,t,u,n),document.querySelector(`.crane-wizard`)?.setAttribute(`data-inspection-type`,t),window.craneWizardCurrentStep=0,bn();return}if(r!==`generic`&&h===`HARNESS_FALL_ARREST`){document.querySelector(`#page`).innerHTML=Gt(a,d,t,u,n),window.craneWizardCurrentStep=0,bn();return}if(r!==`generic`&&h===`SLING`){document.querySelector(`#page`).innerHTML=Kt(a,d,t,u,n),window.craneWizardCurrentStep=0,bn();return}document.querySelector(`#page`).innerHTML=`
    <h2>${c(t)} - Asset ${c(a.assetid)}</h2>

    <div class="filter-card">
      <div class="inspection-asset-summary">
        <div class="inspection-asset-title">
          <strong>${c(a.description||``)}</strong>
          <span>Asset ${c(a.assetid)}</span>
        </div>

        <div class="inspection-asset-details">
          <div><span>Serial No</span><strong>${c(a.serialno||`-`)}</strong></div>
          <div><span>Equipment Type</span><strong>${c(a.equipmenttype||`-`)}</strong></div>
          <div><span>WLL</span><strong>${c(a.wll||`-`)} kg</strong></div>
          ${A(`Span/Jib`,a.span,`mm`)}
          ${A(`Permissible Deflection`,a.permissibledeflection,`mm`)}
        </div>

        <div class="inspection-asset-actions">
          ${de(a,d,t)?`
            <button class="load-test-btn" onclick="startInspection(${a.assetid}, '${t}', '${n}', 'wizard')">
              ${c(fe(a,d,t))}
            </button>
          `:``}

          <button onclick="passAllCriteria(${a.assetid}, '${t}', '${n}')">
            Pass All & Save
          </button>

          <button onclick="returnToInspectionOrigin('${n}')">
            Cancel
          </button>
        </div>
      </div>
    </div>

    <div class="quick-photo-grid">

  ${a.media1?`
    <div class="quick-photo-card">
      <img src="${l(b(a.media1))}">
    </div>
  `:``}

  ${a.media2?`
    <div class="quick-photo-card">
      <img src="${l(b(a.media2))}">
    </div>
  `:``}

</div>

<div class="filter-card">

  <h3>Replace Asset Photos</h3>

  <p class="muted-text">
    Choose a replacement only when the asset master photo should be updated on save.
  </p>

  <div class="asset-photo-row inspection-asset-photo-row">
    <div class="form-group">
      <label>Replace Asset Photo 1</label>
      <input id="inspectionAssetPhoto1" type="file" accept="image/*">
    </div>

    <div class="form-group">
      <label>Replace Asset Photo 2</label>
      <input id="inspectionAssetPhoto2" type="file" accept="image/*">
    </div>
  </div>

  ${ee?`
    <hr>

    <h3>Inspection Photos</h3>

    <input
      id="inspectionPhotoFiles"
      type="file"
      accept="image/*"
      multiple
      onchange="handleInspectionPhotoSelection(event)"
    >

    <div id="inspectionPhotoPreview" class="inspection-photo-preview-grid">
      <p class="muted-text">No inspection photos selected.</p>
    </div>
  `:``}

</div>

<div id="inspectionCriticalWarning" class="inspection-critical-warning" style="display:none;"></div>

<div class="inspection-tag-card">

  <div class="inspection-tag-title">
    INSPECTION DETAILS
  </div>

  <div class="inspector-identity-card">
    <div>
      <span>Logged-in Inspector</span>
      <strong>${c(R?.full_name||`-`)}</strong>
    </div>
    <div>
      <span>LMI Number</span>
      <strong>${c(R?.lmi_number||`-`)}</strong>
    </div>
  </div>

  <div class="form-row">

    <div class="form-group">
      <label>${t===`LOADTEST`?`Load Test Date`:`Inspection Date`}</label>
      <input
        id="inspectionTestDate"
        type="date"
        value="${s}"
        onchange="updateInspectionValidDateFromTestDate('${t}')"
      >
    </div>

    <div class="form-group">
      <label>Inspection Tag No</label>
      <input
        id="inspectionTagNo"
        class="inspection-tag-input"
        type="text"
        autocomplete="off"
        placeholder="ENTER TAG NUMBER"
      >
    </div>

    <div class="form-group">
      <label>Certificate Expiry Date</label>
      <input
        id="inspectionValidDate"
        type="date"
        value="${m}"
      >
    </div>

    ${ft(a,t)}

  </div>

</div>
      <div class="inspection-history-card">

        <div class="inspection-history-title">
          LAST INSPECTION
        </div>

        <div class="inspection-history-grid">

          <div>
            <strong>Date:</strong><br>
            ${c(u.lastinspectiondate||`Never Inspected`)}
          </div>

          <div>
            <strong>Tag Number:</strong><br>
            ${c(u.lastinspectiontag||`-`)}
          </div>

          <div>
            <strong>Type:</strong><br>
            ${c(u.lastinspectiontype||`-`)}
          </div>

          <div>
            <strong>Status:</strong><br>
           <span class="${u.lastinspectionstatus===`SAFE`?`status-safe`:`status-unsafe`}">
              ${c(u.lastinspectionstatus||`-`)}
            </span>
          </div>

          <div>
            <strong>Inspector:</strong><br>
            ${c(u.lastinspector||`-`)}
          </div>

        </div>

      </div>

<div class="inspection-list">
  ${mn(a,d,f,p,t)}
</div>

    <div class="filter-card">
      <button type="button" onclick="window.saveInspection(${a.assetid}, '${t}', '${n}')">
        Save ${t}
      </button>

      <button onclick="returnToInspectionOrigin('${n}')">
        Cancel
      </button>
    </div>

        <div class="filter-card">

        <button onclick="showInspectionHistory(${a.assetid})">
          Show Inspection History
        </button>

        <div id="inspectionHistoryPanel"></div>

      </div>

  `},window.showInspectionHistory=async function(e){let t=await fetch(`${y}/assets/${e}/inspection-history`),n=await t.json();if(!t.ok){alert(`Error loading inspection history: `+n.error);return}let r=n.map(e=>`
    <tr>
      <td>${c(e.testdate||``)}</td>
      <td>${c(e.inspectiontype||``)}</td>
      <td><strong>${c(e.tagnumber||`-`)}</strong></td>
      <td>${c(e.status||``)}</td>
      <td>${c(e.inspector||`-`)}</td>
      <td>
          <button onclick="openCertificateModal(${e.testid})">
            View Certificate
          </button>
      </td>
    </tr>
  `).join(``);document.querySelector(`#inspectionHistoryPanel`).innerHTML=`
    <h3>Inspection History</h3>

    <table>
      <thead>
        <tr>
          <th>Date</th>
          <th>Type</th>
          <th>Tag No</th>
          <th>Status</th>
          <th>Inspector</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ${r||`
          <tr>
            <td colspan="5">No inspection history found</td>
          </tr>
        `}
      </tbody>
    </table>
  `},window.showAssetHistoryFromSetup=async function(e){w();let t=await fetch(`${y}/assets/${e}/inspection-history`),n=await t.json();if(!t.ok){alert(`Error loading inspection history: `+n.error);return}document.querySelector(`#page`).innerHTML=`
    <h2>Inspection History - Asset ${e}</h2>

    <div class="filter-card">
      <button onclick="showAssetSetup()">Back to Asset Setup</button>
    </div>

    <div class="filter-card">
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Type</th>
            <th>Tag No</th>
            <th>Status</th>
            <th>Inspector</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          ${n.length?n.map(e=>`
            <tr>
              <td>${c(e.testdate||``)}</td>
              <td>${c(e.inspectiontype||``)}</td>
              <td><strong>${c(e.tagnumber||`-`)}</strong></td>
              <td>${c(e.status||``)}</td>
              <td>${c(e.inspector||`-`)}</td>
              <td>
              <button onclick="openCertificateModal(${e.testid})">
                View Certificate
              </button>
              </td>
            </tr>
          `).join(``):`
            <tr>
              <td colspan="6">No inspection history found</td>
            </tr>
          `}
        </tbody>
      </table>
    </div>
  `},window.passAllCriteria=function(e,t,n=`quick`){confirm(`Are you sure you want to mark all visual criteria as PASS and save this inspection?`)&&(document.querySelectorAll(`select[id^="result-"]`).forEach(e=>{e.value=Array.from(e.options).some(e=>e.value===`YES`)?`YES`:`PASS`}),updateInspectionSafetyWarning(),document.querySelectorAll(`input[id^="measured-"]`).forEach(e=>{e.value||=e.defaultValue||``}),saveInspection(e,t,n))},window.handleDashboardSearchEnter=function(e){e.key===`Enter`&&dashboardFindAsset()},window.dashboardFindAsset=async function(){let e=document.querySelector(`#dashboardAssetSearch`),t=Qe(e?.value||``),n=t.trim(),r=document.querySelector(`#dashboardAssetSearchResult`);if(e&&t!==e.value.trim()&&(e.value=t),!n){r.innerHTML=`<p>Please enter or scan an asset number, tag, serial number or QR code.</p>`;return}r.innerHTML=`<p>Searching...</p>`;try{let e=await fetch(`${y}/inspections/assets/search?q=${encodeURIComponent(n)}`);if(!e.ok)throw Error(`Asset search failed`);let t=await e.json();if(!t.length){r.innerHTML=`
        <p>No asset found for <strong>${c(n)}</strong>.</p>
      `;return}if(t.length===1){quickOpenAsset(t[0].assetid);return}r.innerHTML=`
      <div class="dashboard-result-table">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th>Asset ID</th>
              <th>Tag No</th>
              <th>Serial No</th>
              <th>Hoist Serial No</th>
              <th>Description</th>
              <th>Equipment Type</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            ${t.slice(0,10).map(e=>`
              <tr>
                <td>${c(e.assetid)}</td>
                <td>${c(e.assettagno||`-`)}</td>
                <td>${c(e.serialno||`-`)}</td>
                <td>${c(e.hoistserialno||`-`)}</td>
                <td>${c(e.description||``)}</td>
                <td>${c(e.equipmenttype||``)}</td>
                <td class="dashboard-search-actions">
                  ${de(e,W,`VISUAL`)?`<button class="load-test-btn" onclick="startInspection(${e.assetid}, 'VISUAL', 'quick', 'wizard')">${c(fe(e,W,`VISUAL`))}</button>`:`<button onclick="startInspection(${e.assetid}, 'VISUAL', 'quick')">Inspect</button>`}
                  ${xt(e)?`<button class="load-test-btn" onclick="startInspection(${e.assetid}, 'LOADTEST', 'quick', '${ue(e)?`wizard`:`auto`}')">${ue(e)?`Wizard Load Test`:`Load Test`}</button>`:``}
                </td>
              </tr>
            `).join(``)}
          </tbody>
        </table>
      </div>
    `}catch(e){console.error(`Dashboard asset search error:`,e),r.innerHTML=`<p>Unable to search assets. Please try again.</p>`}};let X=null,Tn=!1;window.startDashboardCameraScan=async function(){let e=document.querySelector(`#dashboardCameraScanner`),t=document.querySelector(`#dashboardCameraVideo`),n=document.querySelector(`#dashboardScanStatus`);if(!(`BarcodeDetector`in window)){n&&(n.textContent=`Camera scanning is not supported by this browser. Use the scan/type box above.`),e?.removeAttribute(`hidden`);return}try{let r=await window.BarcodeDetector.getSupportedFormats(),i=[`qr_code`,`code_128`,`code_39`,`ean_13`].filter(e=>r.includes(e)),a=new window.BarcodeDetector({formats:i});X=await navigator.mediaDevices.getUserMedia({video:{facingMode:`environment`},audio:!1}),t.srcObject=X,e?.removeAttribute(`hidden`),await t.play(),Tn=!0,n&&(n.textContent=`Scanning... point the camera at the QR label or barcode.`);let o=async()=>{if(Tn){try{let e=await a.detect(t);if(e.length){let t=Qe(e[0].rawValue);document.querySelector(`#dashboardAssetSearch`).value=t,stopDashboardCameraScan(),dashboardFindAsset();return}}catch(e){console.error(`Dashboard camera scan failed:`,e)}requestAnimationFrame(o)}};o()}catch(t){console.error(`Unable to start dashboard camera scanner:`,t),e?.removeAttribute(`hidden`),n&&(n.textContent=`Camera could not start. Please allow camera access or use the scan/type box.`)}},window.stopDashboardCameraScan=function(){Tn=!1,X&&=(X.getTracks().forEach(e=>e.stop()),null);let e=document.querySelector(`#dashboardCameraVideo`);e&&(e.srcObject=null),document.querySelector(`#dashboardCameraScanner`)?.setAttribute(`hidden`,``)};async function En(){try{let e=await fetch(`${y}/dashboard/summary`);if(!e.ok)throw Error(`Failed to load dashboard summary`);let t=await e.json();Pn(t.alerts||{}),Fn(t.failedEquipmentByCustomer||[]),In(t.upcomingExpiriesByCustomer||[]),Ln(t.topCustomers||[]),Rn(t.equipmentByType||[])}catch(e){console.error(`Failed to load dashboard summary:`,e),Pn(),Fn(),In(),Ln(),Rn()}}let Dn={"incomplete-inspections":{title:`Incomplete Inspections`,empty:`No incomplete inspections found.`,columns:[[`Inspection`,e=>e.testid],[`Asset`,e=>e.assetid],[`Customer`,e=>e.clientname],[`Site`,e=>e.sitename],[`Type`,e=>e.inspectiontype],[`Date`,e=>Z(e.testdate)],[`Inspector`,e=>e.inspector],[`Issue`,e=>e.issue]],action:e=>`<button class="small-btn" onclick="showDashboardCustomerReport(${l(e.clientid)})">View Report</button>`},"certificate-metadata":{title:`Certificate Metadata Review`,empty:`No certificate metadata issues found.`,columns:[[`Asset`,e=>e.assetid],[`Customer`,e=>e.clientname],[`Site`,e=>e.sitename],[`Equipment`,e=>e.equipmenttype],[`Issue`,e=>e.issue],[`Visual Date`,e=>Z(e.visualtestdate)],[`Load Date`,e=>Z(e.loadtestdate)]],action:e=>`<button class="small-btn" onclick="showDashboardCustomerReport(${l(e.clientid)})">View Report</button>`},"missing-section":{title:`Assets Missing Section`,empty:`No assets are missing a section.`,columns:[[`Asset`,e=>e.assetid],[`Customer`,e=>e.clientname],[`Site`,e=>e.sitename],[`Asset Tag`,e=>e.assettagno],[`Serial No`,e=>e.serialno],[`Equipment`,e=>e.equipmenttype],[`Issue`,e=>e.issue]],action:e=>`<button class="small-btn" onclick="editAsset(${l(e.assetid)})">Edit Asset</button>`},"types-without-criteria":{title:`Types Without Criteria`,empty:`Every active equipment type in use has active criteria.`,columns:[[`Equipment Type`,e=>e.equipmenttype],[`Assets`,e=>e.assets],[`Customers`,e=>e.customers],[`Sample Asset`,e=>e.sampleassetid],[`Issue`,e=>e.issue]],action:e=>`<button class="small-btn" onclick="openCriteriaForEquipmentType(${l(e.equiptypeid)})">Open Criteria</button>`},overdue:{title:`Overdue Assets`,empty:`No overdue assets found.`,columns:[[`Asset`,e=>e.assetid],[`Customer`,e=>e.clientname],[`Site`,e=>e.sitename],[`Section`,e=>e.sectionname],[`Equipment`,e=>e.equipmenttype],[`Issue`,e=>e.issue],[`Visual Due`,e=>Z(e.nextvisualdue)],[`Load Due`,e=>Z(e.nextloaddue)]],action:e=>`<button class="small-btn" onclick="showDashboardCustomerReport(${l(e.clientid)})">View Report</button>`}};window.showDashboardReviewQueue=async function(e){let t=Dn[e],n=document.querySelector(`#dashboardReviewQueue`),r=document.querySelector(`#dashboardReviewQueueTitle`),i=document.querySelector(`#dashboardReviewQueueBody`);if(!(!t||!n||!r||!i)){n.hidden=!1,r.textContent=t.title,i.innerHTML=`<div class="report-preview-empty">Loading review queue...</div>`,n.scrollIntoView({behavior:`smooth`,block:`start`});try{let n=await fetch(`${y}/dashboard/review-queue/${e}`),r=await n.json();if(!n.ok)throw Error(r.error||`Failed to load review queue`);window.dashboardReviewQueueState={key:e,title:t.title,rows:r.rows||[]},i.innerHTML=On(t,r.rows||[])}catch(e){console.error(`Failed to load dashboard review queue:`,e),i.innerHTML=`
      <div class="alert-card warning">
        Unable to load this review queue.
      </div>
    `}}},window.closeDashboardReviewQueue=function(){let e=document.querySelector(`#dashboardReviewQueue`);e&&(e.hidden=!0)},window.showDashboardCustomerReport=function(e){showCustomerDetailedReport({clientid:e,autoLoad:!0})},window.openCriteriaForEquipmentType=function(e){window.criteriaEquipmentFilter=String(e||``),window.criteriaCurrentPage=1,showEquipmentTypeCriteria()},window.exportDashboardReviewQueue=function(){let e=window.dashboardReviewQueueState,t=Dn[e?.key];if(!e||!t||!e.rows?.length){alert(`There is no review queue data to export.`);return}let n=[t.columns.map(([e])=>e),...e.rows.map(e=>t.columns.map(([,t])=>Mn(t(e))))].map(e=>e.map(Nn).join(`,`)).join(`
`),r=new Blob([n],{type:`text/csv;charset=utf-8`}),i=document.createElement(`a`);i.href=URL.createObjectURL(r),i.download=`${e.key}-review-queue.csv`,i.click(),URL.revokeObjectURL(i.href)};function On(e,t){return t.length?`
    <p class="dashboard-review-summary">
      Showing ${c(t.length)} items. Use the action column to open the relevant cleanup screen.
    </p>
    <div class="dashboard-review-table-wrap">
      <table class="dashboard-table">
        <thead>
          <tr>
            ${e.columns.map(([e])=>`<th>${c(e)}</th>`).join(``)}
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          ${t.map(t=>`
            <tr>
              ${e.columns.map(([,e])=>`<td>${c(e(t)||`-`)}</td>`).join(``)}
              <td>${e.action(t)}</td>
            </tr>
          `).join(``)}
        </tbody>
      </table>
    </div>
  `:`
      <div class="alert-card success">
        ${c(e.empty)}
      </div>
    `}function Z(e){return e?String(e).split(`T`)[0]:`-`}function Mn(e){return e==null||e===``?`-`:String(e)}function Nn(e){return`"${Mn(e).replace(/"/g,`""`)}"`}async function Pn(e=null){try{let t=e;if(!t){let e=await fetch(`${y}/dashboard/alerts`);if(!e.ok)throw Error(`Failed to load dashboard alerts`);t=await e.json()}let n=document.querySelector(`#dashboardAlerts`);if(!n)return;let r=``;Number(t.overdue)>0&&(r+=`
        <div class="alert-card danger">
          ALERT: ${t.overdue} Assets Overdue
        </div>
      `),Number(t.expiring)>0&&(r+=`
        <div class="alert-card warning">
          WARNING: ${t.expiring} Certificates Expiring Within 30 Days
        </div>
      `),Number(t.failed)>0&&(r+=`
        <div class="alert-card danger">
          ALERT: ${t.failed} Failed Assets
        </div>
      `),r===``&&(r=`
        <div class="alert-card success">
          OK: No operational alerts
        </div>
      `),n.innerHTML=r}catch(e){console.error(`Failed to load dashboard alerts:`,e);let t=document.querySelector(`#dashboardAlerts`);t&&(t.innerHTML=`
        <div class="alert-card warning">
          Unable to load dashboard alerts
        </div>
      `)}}async function Fn(e=null){let n=document.querySelector(`#failedEquipmentTableBody`);if(n)try{let r=e;if(!r){let e=await fetch(`${y}/dashboard/failed-equipment-by-customer`);if(!e.ok)throw Error(`Failed to load failed equipment`);r=await e.json()}if(!Array.isArray(r)||!r.length){n.innerHTML=`
        <tr>
          <td colspan="4" class="empty-row">
            No failed equipment found
          </td>
        </tr>
      `;return}n.innerHTML=t(r,`dashboardFailed`,{clientname:e=>e.clientname,failed_assets:e=>e.failed_assets,latest_failed_date:e=>e.latest_failed_date},`failed_assets`).map(e=>{let t=l(JSON.stringify({clientid:e.clientid,autoLoad:!0}));return`
      <tr>
        <td>${c(e.clientname||``)}</td>
        <td><strong>${c(e.failed_assets||0)}</strong></td>
        <td>${c(e.latest_failed_date?e.latest_failed_date.split(`T`)[0]:``)}</td>
        <td>
          <button
            class="small-btn"
            onclick="showCustomerDetailedReport(${t})"
          >
            View Assets
          </button>
        </td>
      </tr>
    `}).join(``)}catch(e){console.error(`Failed to load failed equipment:`,e),n.innerHTML=`
      <tr>
        <td colspan="4" class="empty-row">Unable to load failed equipment data</td>
      </tr>
    `}}async function In(e=null){let n=document.querySelector(`#upcomingExpiriesTableBody`);if(n)try{let r=e;if(!r){let e=await fetch(`${y}/dashboard/upcoming-expiries-by-customer`);if(!e.ok)throw Error(`Failed to load upcoming certificate expiries`);r=await e.json()}if(!Array.isArray(r)||!r.length){n.innerHTML=`
        <tr>
          <td colspan="5" class="empty-row">
            No upcoming certificate expiries
          </td>
        </tr>
      `;return}n.innerHTML=t(r,`dashboardExpiries`,{clientname:e=>e.clientname,upcoming_assets:e=>e.upcoming_assets,next_expiry_date:e=>e.next_expiry_date,days_remaining:e=>e.days_remaining},`days_remaining`).map(e=>{let t=l(JSON.stringify({clientid:e.clientid,autoLoad:!0}));return`
      <tr>
        <td>${c(e.clientname||``)}</td>
        <td><strong>${c(e.upcoming_assets||0)}</strong></td>
        <td>${c(e.next_expiry_date?e.next_expiry_date.split(`T`)[0]:``)}</td>
        <td><strong>${c(e.days_remaining??``)}</strong></td>
        <td>
          <button
            class="small-btn"
            onclick="showCustomerDetailedReport(${t})"
          >
            View Assets
          </button>
        </td>
      </tr>
    `}).join(``)}catch(e){console.error(`Failed to load upcoming expiries:`,e),n.innerHTML=`
      <tr>
        <td colspan="5" class="empty-row">Unable to load upcoming certificate expiry data</td>
      </tr>
    `}}async function Ln(e=null){let n=document.querySelector(`#dashboardTopCustomersBody`);if(n)try{let r=e;if(!r){let e=await fetch(`${y}/dashboard/top-customers`);if(!e.ok)throw Error(`Failed to load top customers`);r=await e.json()}if(!Array.isArray(r)||!r.length){n.innerHTML=`
        <tr>
          <td colspan="3" class="empty-row">No customer asset data found</td>
        </tr>
      `;return}n.innerHTML=t(r,`dashboardCustomers`,{clientname:e=>e.clientname,sites:e=>e.sites,assets:e=>e.assets},`assets`).slice(0,10).map(e=>`
      <tr>
        <td>${c(e.clientname||``)}</td>
        <td>${c(e.sites||0)}</td>
        <td><strong>${c(e.assets||0)}</strong></td>
      </tr>
    `).join(``)}catch(e){console.error(`Failed to load top customers:`,e),n.innerHTML=`
      <tr>
        <td colspan="3" class="empty-row">Unable to load customer asset data</td>
      </tr>
    `}}async function Rn(e=null){let n=document.querySelector(`#dashboardEquipmentTypeBody`);if(n)try{let r=e;if(!r){let e=await fetch(`${y}/dashboard/equipment-by-type`);if(!e.ok)throw Error(`Failed to load equipment by type`);r=await e.json()}if(!Array.isArray(r)||!r.length){n.innerHTML=`
        <tr>
          <td colspan="2" class="empty-row">No equipment type data found</td>
        </tr>
      `;return}n.innerHTML=t(r,`dashboardEquipment`,{equipmenttype:e=>e.equipmenttype,total:e=>e.total},`total`).slice(0,10).map(e=>`
      <tr>
        <td>${c(e.equipmenttype||`Unknown`)}</td>
        <td><strong>${c(e.total||0)}</strong></td>
      </tr>
    `).join(``)}catch(e){console.error(`Failed to load equipment by type:`,e),n.innerHTML=`
      <tr>
        <td colspan="2" class="empty-row">Unable to load equipment type data</td>
      </tr>
    `}}window.saveInspection=async function(e,t=`VISUAL`,n=`quick`){if(window.inspectionSaveInProgress)return;if(document.querySelector(`.crane-wizard`)){let e=hn(),t=Math.max(0,e.length-1);if((window.craneWizardCurrentStep||0)!==t){alert(`Review the crane inspection before saving.`),window.craneWizardCurrentStep=t,bn();return}if(!_n(t))return}let r=document.querySelector(`#inspectionTagNo`)?.value.trim()||``,i=document.querySelector(`#inspectionTestDate`)?.value||j(),a;try{a=await An(e)}catch(e){alert(e.message||`Asset not found`);return}let o=At(W.filter(e=>String(e.equiptypeid)===String(a.equiptypeid)&&String(e.inspectioncategory)===String(t)&&e.active!==!1),t);o=o.filter(e=>!St(a,e,t));let s=[],c=`SAFE`,l=null;for(let e of o){let n=document.querySelector(`#result-${e.criteriaid}`),r=document.querySelector(`#measured-${e.criteriaid}`),i=n?n.value:`RECORDED`,o=document.querySelector(`#remarks-${e.criteriaid}`),u=Ct(e)||t===`LOADTEST`?o?.value||``:[`FAIL`,`NO`].includes(i)&&o?.value||``,d=N(e)&&n?.dataset.autoForcedSafety===`true`;if(!Ct(e)&&[`FAIL`,`NO`].includes(i)&&!d&&!String(u||``).trim()){l=e;break}I(i)&&(c=`NOT SAFE`);let f=_t(a,e)||null,p=r?r.value:null;if(p&&!Number.isFinite(Number(p))){alert(`Please enter a valid numeric value for: ${h(e)}`),r?.focus();return}s.push({criteriaid:e.criteriaid,criterianame:e.criterianame,assetvalue:f,measuredvalue:p,result:i,remarks:u})}if(l){alert(`Please enter a reason/comment for the failed item: ${h(l)}`);let e=document.querySelector(`#remarks-${l.criteriaid}`),t=document.querySelector(`#fail-remarks-${l.criteriaid}`);t&&(t.style.display=`block`),e&&e.focus();return}let u=new FormData,d=t===`LOADTEST`&&document.querySelector(`.crane-wizard`)?[`Rated capacity: ${document.querySelector(`#craneRatedCapacity`)?.value||`-`}`,`Intended test load: ${document.querySelector(`#craneIntendedTestLoad`)?.value||`-`}`,`Actual applied load: ${document.querySelector(`#craneActualTestLoad`)?.value||`-`}`,`Test duration: ${document.querySelector(`#craneTestDuration`)?.value||`-`}`,`Load exception reason: ${document.querySelector(`#craneLoadExceptionReason`)?.value||`-`}`].join(`
`):``,f=document.querySelector(`.harness-wizard`)?vn().map(([e,t])=>`${e}: ${t||`-`}`).join(`
`):``,p=document.querySelector(`.sling-wizard`)?Y().map(([e,t])=>`${e}: ${t||`-`}`).join(`
`):``,ee=[document.querySelector(`#inspectionComments`)?.value||``,d,f,p].filter(e=>String(e||``).trim()).join(`

`);u.append(`assetid`,e),u.append(`testdate`,i),u.append(`validdate`,document.querySelector(`#inspectionValidDate`)?.value||``),u.append(`comments`,ee),u.append(`status`,c),u.append(`inspectiontype`,t),window.currentInspectionVisitId&&u.append(`visitid`,window.currentInspectionVisitId),u.append(`inspectionfrequency`,document.querySelector(`#inspectionFrequency`)?.value||``),u.append(`tagnumber`,r),u.append(`results`,JSON.stringify(s));let m=document.querySelector(`#inspectionAssetPhoto1`)?.files?.[0]||null,g=document.querySelector(`#inspectionAssetPhoto2`)?.files?.[0]||null;if(!Ge([m,g]))return;let te=!!(m||g);u.append(`updateassetphotos`,te),m&&u.append(`photo1`,m),g&&u.append(`photo2`,g),(String(a.equipgroupid||``)===`400`&&window.pendingInspectionPhotos||[]).forEach(e=>{u.append(`inspectionPhotos`,e.file),u.append(`photoCaptions`,e.caption||``),u.append(`photoTypes`,e.photoType||`GENERAL`)});let _,v;try{if(window.inspectionSaveInProgress=!0,document.querySelectorAll(`.crane-wizard-nav button, .filter-card button`).forEach(e=>{/save/i.test(e.textContent||``)&&(e.disabled=!0)}),_=await fetch(`${y}/inspections`,{method:`POST`,body:u}),v=await _.json(),_.status===409&&v.code===`DUPLICATE_INSPECTION`){let e=v.existing?.testid||`unknown`;window.confirm(`Inspection ${e} already exists for this asset, inspection type and date.\n\nOnly continue if this is genuinely a separate inspection.`)&&(u.set(`force_duplicate`,`true`),_=await fetch(`${y}/inspections`,{method:`POST`,body:u}),v=await _.json())}}catch(e){alert(`Error saving inspection: `+e.message),window.inspectionSaveInProgress=!1,document.querySelectorAll(`.crane-wizard-nav button, .filter-card button`).forEach(e=>{e.disabled=!1});return}if(!_.ok){let e=v.error||`An unexpected server error occurred`,t=v.referenceId?`\nReference: ${v.referenceId}`:``;alert(`Error saving inspection: `+e+t),window.inspectionSaveInProgress=!1,document.querySelectorAll(`.crane-wizard-nav button, .filter-card button`).forEach(e=>{e.disabled=!1});return}alert(`Inspection saved. Status: `+(v.status||c)),await $(),window.inspectionSaveInProgress=!1,jt(n)};let zn=S();if(zn){G(`quick-inspection`),en(`quick-inspection`),showQuickInspection(),await Pe(zn);return}let Bn=localStorage.getItem(`currentPage`)||`dashboard`;switch(nn(Bn)||(Bn=R.role===`CUSTOMER`?`portal`:`dashboard`,G(Bn)),en(Bn),Bn){case`portal`:showCustomerPortal();break;case`dashboard`:showDashboard();break;case`customers`:showCustomerSetup();break;case`sites`:showSites();break;case`responsible`:showResponsiblePersons();break;case`sections`:showSections();break;case`assets`:showAssetSetup();break;case`inspections`:showInspections();break;case`visits`:showInspectionVisits();break;case`quick-inspection`:showQuickInspection();break;case`criteria`:showEquipmentTypeCriteria();break;case`certificates`:showCertificateSearch();break;case`customer-report`:showCustomerDetailedReport();break;case`she`:showRiskAssessments();break;case`users`:showUserManagement();break;case`system-health`:showSystemHealth();break;case`profile`:showMyProfile();break;default:showDashboard();break}}window.addEventListener(`popstate`,e=>{if(!R)return;let t=e.state?.atecPage,n=R.role===`CUSTOMER`?`portal`:`dashboard`,r=t&&nn(t)?t:n,i={portal:window.showCustomerPortal,dashboard:window.showDashboard,customers:window.showCustomerSetup,sites:window.showSites,responsible:window.showResponsiblePersons,sections:window.showSections,assets:window.showAssetSetup,inspections:window.showInspections,visits:window.showInspectionVisits,"quick-inspection":window.showQuickInspection,criteria:window.showEquipmentTypeCriteria,certificates:window.showCertificateSearch,"customer-report":window.showCustomerDetailedReport,she:window.showRiskAssessments,users:window.showUserManagement,"system-health":window.showSystemHealth,profile:window.showMyProfile};Jt=!0;try{G(r),(i[r]||window.showDashboard)?.()}finally{Jt=!1}}),$();