(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();function e(e,t=``,n=`asc`){let r=`${e}Sort`;return window[r]=window[r]||{key:t,direction:n},window[r]}function t(t,n,r,i=``,a=`asc`){let o=e(n,i,a),s=r[o.key||i];if(!s)return[...t];let c=o.direction===`desc`?-1:1;return[...t].sort((e,t)=>{let n=s(e),r=s(t),i=Number(n),a=Number(r);return n!==``&&r!==``&&!Number.isNaN(i)&&!Number.isNaN(a)?(i-a)*c:String(n||``).localeCompare(String(r||``),void 0,{numeric:!0,sensitivity:`base`})*c})}function n(t,n,r,i){let a=e(n,r),o=a.key===r,s=o?a.direction:``;return`
    <span class="user-table-heading">
      <span>${t}</span>
      <button
        type="button"
        class="user-sort-btn ${o?`active ${s}`:``}"
        onclick="sortTable('${n}', '${r}', '${i}')"
        aria-label="Sort ${t}"
        title="Sort ${t}"
      ></button>
    </span>
  `}window.sortTable=function(t,n,r){let i=e(t,n);window[`${t}Sort`]={key:n,direction:i.key===n&&i.direction===`asc`?`desc`:`asc`};let a=window[r];typeof a==`function`&&a()};function r(e,t,r,i,a){document.querySelector(`#page`).innerHTML=`

    <h2>Dashboard</h2>

    <div class="filter-card dashboard-quick-search">
      <div class="section-header">
        <h3>Quick Asset Search</h3>
      </div>

      <div class="dashboard-search-row">
        <input
          id="dashboardAssetSearch"
          class="search-box"
          type="text"
          placeholder="Scan QR / Asset ID / Tag No / Serial No..."
          onkeydown="handleDashboardSearchEnter(event)"
        >

        <button onclick="dashboardFindAsset()">Search</button>
        <button type="button" class="secondary-btn" onclick="startDashboardCameraScan()">Scan QR / Barcode</button>
      </div>

      <div id="dashboardCameraScanner" class="quick-camera-scanner dashboard-camera-scanner" hidden>
        <video id="dashboardCameraVideo" playsinline></video>
        <p id="dashboardScanStatus">Scanning... point the camera at the QR label or barcode.</p>
        <button type="button" class="secondary-btn" onclick="stopDashboardCameraScan()">Stop Scanning</button>
      </div>

      <div id="dashboardAssetSearchResult" class="dashboard-search-result"></div>
    </div>

    <div class="dashboard-cards">

      <div class="stat-card stat-blue">
        <div class="stat-icon">CU</div>
        <div>
          <h3>Customers</h3>
          <p>${a.customers||0}</p>
        </div>
      </div>

      <div class="stat-card stat-blue">
        <div class="stat-icon">SI</div>
        <div>
          <h3>Sites</h3>
          <p>${a.sites||0}</p>
        </div>
      </div>

      <div class="stat-card stat-blue">
        <div class="stat-icon">AS</div>
        <div>
          <h3>Assets</h3>
          <p>${a.assets||0}</p>
        </div>
      </div>

      <div class="stat-card stat-blue">
        <div class="stat-icon">ET</div>
        <div>
          <h3>Equipment Types</h3>
          <p>${a.equipmenttypes||0}</p>
        </div>
      </div>

      <div class="stat-card stat-orange">
        <div class="stat-icon">VI</div>
        <div>
          <h3>Visual Due</h3>
          <p>${a.visualdue||0}</p>
        </div>
      </div>

      <div class="stat-card stat-orange">
        <div class="stat-icon">LT</div>
        <div>
          <h3>Load Tests Due</h3>
          <p>${a.loadtestdue||0}</p>
        </div>
      </div>

      <div class="stat-card stat-green">
        <div class="stat-icon">CE</div>
        <div>
          <h3>Certificates</h3>
          <p>${a.certificates||0}</p>
        </div>
      </div>

      <div class="stat-card stat-red">
        <div class="stat-icon">OD</div>
        <div>
          <h3>Overdue</h3>
          <p>${a.overdue||0}</p>
        </div>
      </div>

    </div>

    <div class="dashboard-section dashboard-alerts">
      <div class="section-header">
        <h2>Operational Alerts</h2>
      </div>

      <div id="dashboardAlerts">Loading...</div>
    </div>

    <div class="dashboard-two-column">
      <div class="dashboard-section">
        <div class="section-header">
          <h2>Failed Equipment</h2>
        </div>

        <table class="dashboard-table">
          <thead>
            <tr>
              <th>${n(`Customer`,`dashboardFailed`,`clientname`,`showDashboard`)}</th>
              <th>${n(`Failed Assets`,`dashboardFailed`,`failed_assets`,`showDashboard`)}</th>
              <th>${n(`Latest Failed Date`,`dashboardFailed`,`latest_failed_date`,`showDashboard`)}</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody id="failedEquipmentTableBody">
            <tr>
              <td colspan="4">Loading...</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="dashboard-section">
        <div class="section-header">
          <h2>Upcoming Certificate Expiries</h2>
        </div>

        <table class="dashboard-table">
          <thead>
            <tr>
              <th>${n(`Customer`,`dashboardExpiries`,`clientname`,`showDashboard`)}</th>
              <th>${n(`Upcoming Assets`,`dashboardExpiries`,`upcoming_assets`,`showDashboard`)}</th>
              <th>${n(`Next Expiry Date`,`dashboardExpiries`,`next_expiry_date`,`showDashboard`)}</th>
              <th>${n(`Days Left`,`dashboardExpiries`,`days_remaining`,`showDashboard`)}</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody id="upcomingExpiriesTableBody">
            <tr>
              <td colspan="5">Loading...</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="dashboard-two-column dashboard-top-row">
      <div class="dashboard-section">
        <div class="section-header">
          <h2>Top Customers by Asset Count</h2>
        </div>

        <table class="dashboard-table">
          <thead>
            <tr>
              <th>${n(`Client`,`dashboardCustomers`,`clientname`,`showDashboard`)}</th>
              <th>${n(`Sites`,`dashboardCustomers`,`sites`,`showDashboard`)}</th>
              <th>${n(`Assets`,`dashboardCustomers`,`assets`,`showDashboard`)}</th>
            </tr>
          </thead>

          <tbody id="dashboardTopCustomersBody">
            <tr>
              <td colspan="3">Loading...</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="dashboard-section">
        <div class="section-header">
          <h2>Equipment by Type</h2>
        </div>

        <table class="dashboard-table">
          <thead>
            <tr>
              <th>${n(`Equipment Type`,`dashboardEquipment`,`equipmenttype`,`showDashboard`)}</th>
              <th>${n(`Total`,`dashboardEquipment`,`total`,`showDashboard`)}</th>
            </tr>
          </thead>

          <tbody id="dashboardEquipmentTypeBody">
            <tr>
              <td colspan="2">Loading...</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="dashboard-section dashboard-actions">
      <div class="section-header">
        <h2>Quick Actions</h2>
      </div>

      <div class="dashboard-buttons">
        <button onclick="showQuickInspection()">New Inspection</button>
        <button onclick="showInspections()">Load Test</button>
        <button onclick="showAssetSetup()">Assets</button>
        <button onclick="showCertificateSearch()">Certificates</button>
      </div>
    </div>
  `}function i(e,t,n,r=25){let i=window[n]||r,a=Math.max(1,Math.ceil(e.length/i)),o=Math.min(window[t]||1,a),s=(o-1)*i,c=e.slice(s,s+i),l=e.length===0?0:s+c.length;return window[t]=o,window[n]=i,{currentPage:o,endIndex:l,pageSize:i,rows:c,startIndex:s,totalPages:a,totalRows:e.length}}function a({currentPage:e,endIndex:t,label:n,onPage:r,onPageSize:i,pageSize:a,startIndex:o,totalPages:c,totalRows:l}){return`
    <div class="report-pagination-bar">
      <div class="report-page-size">
        <label>Rows per page</label>
        <select onchange="${i}(this.value)">
          ${[25,50,100,250].map(e=>`
            <option value="${e}" ${e===a?`selected`:``}>
              ${e}
            </option>
          `).join(``)}
        </select>
      </div>

      <div class="report-page-controls">
        <button type="button" onclick="${r}(${e-1})" ${e<=1?`disabled`:``}>
          Previous
        </button>
        ${s(e,c,r)}
        <button type="button" onclick="${r}(${e+1})" ${e>=c?`disabled`:``}>
          Next
        </button>
        <span>Showing ${l===0?0:o+1} to ${t} of ${l} ${n} - Page ${e} of ${c}</span>
      </div>
    </div>
  `}function o(e,t){let n=[];if(t<=10){for(let e=1;e<=t;e+=1)n.push(e);return n}let r=Math.max(1,e-4),i=Math.min(t,r+9-1);i-r+1<9&&(r=Math.max(1,i-9+1)),r>1&&(n.push(1),r>2&&n.push(`...`));for(let e=r;e<=i;e+=1)n.push(e);return i<t&&(i<t-1&&n.push(`...`),n.push(t)),n}function s(e,t,n){return o(e,t).map(t=>t===`...`?`<span class="pagination-ellipsis">...</span>`:`
      <button
        type="button"
        class="pagination-page-btn ${t===e?`active`:``}"
        onclick="${n}(${t})"
        ${t===e?`disabled`:``}
      >
        ${t}
      </button>
    `).join(``)}function c(e){return String(e??``).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}function l(e){return c(e)}function u(e,r=`active`){let o=window.currentUser?.role===`ADMIN`,s=i(t(e.filter(e=>{let t=e.archived===!0||e.archived===`true`;return r===`active`?!t:r===`archived`?t:!0}),`customers`,{clientid:e=>e.clientid,clientname:e=>e.clientname,clientaddr:e=>e.clientaddr,archived:e=>e.archived?`Archived`:`Active`},`clientname`),`customerCurrentPage`,`customerRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h2>Customer Setup</h2>

    <button onclick="addClient()">Add Client</button>
    <button onclick="showCustomerSetup()">Refresh</button>

    <br><br>

    <div class="filter-card">
      <label>Show Customers</label>

      <div class="radio-row">
        <label>
          <input
            type="radio"
            name="customerArchiveFilter"
            value="active"
            ${r===`active`?`checked`:``}
            onchange="showCustomerSetup('active')"
          >
          Active
        </label>

        <label>
          <input
            type="radio"
            name="customerArchiveFilter"
            value="archived"
            ${r===`archived`?`checked`:``}
            onchange="showCustomerSetup('archived')"
          >
          Archived
        </label>

        <label>
          <input
            type="radio"
            name="customerArchiveFilter"
            value="all"
            ${r===`all`?`checked`:``}
            onchange="showCustomerSetup('all')"
          >
          All
        </label>
      </div>
    </div>
</div>

      <br>

      <input
        id="customerSearch"
        type="text"
        placeholder="Search Client ID, Client Name or Address..."
        onkeyup="filterCustomers(true)"
      />

      <br><br>

      ${a({...s,label:`customers`,onPage:`goToCustomerPage`,onPageSize:`setCustomerRowsPerPage`})}

      <table>
      <thead>
        <tr>
          <th>${n(`Client ID`,`customers`,`clientid`,`showCustomerSetup`)}</th>
          <th>${n(`Client Name`,`customers`,`clientname`,`showCustomerSetup`)}</th>
          <th>${n(`Address`,`customers`,`clientaddr`,`showCustomerSetup`)}</th>
          <th>${n(`Status`,`customers`,`archived`,`showCustomerSetup`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody id="customerTableBody">
        ${s.rows.map(e=>`
          <tr>
            <td>${c(e.clientid)}</td>
            <td>${c(e.clientname||``)}</td>
            <td>${c(e.clientaddr||``)}</td>
            <td>${e.archived?`Archived`:`Active`}</td>
            <td>
              <button onclick="editClient(${e.clientid})">Edit</button>

              ${o?`
              ${e.archived?`<button onclick="unarchiveClient(${e.clientid})">Unarchive</button>`:`<button onclick="archiveClient(${e.clientid})">Archive</button>`}
              `:``}
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `}function d(e,r=`active`){let o=window.currentUser?.role===`ADMIN`,s=e.filter(e=>{let t=e.archived===!0||e.archived===`true`;return r===`active`?!t:r===`archived`?t:!0}),l=i(t(s,`sites`,{siteid:e=>e.siteid,clientname:e=>e.clientname,sitename:e=>e.sitename,archived:e=>e.archived?`Archived`:`Active`},`clientname`),`siteCurrentPage`,`siteRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h2>Sites</h2>

    <button onclick="showAddSiteForm()">
      Add Site
    </button>

    <br><br>

    <p>Total Sites: <strong>${s.length}</strong></p>

    <div class="filter-card">
      <label>Show Sites</label>
      <div class="radio-row">
        ${[`active`,`archived`,`all`].map(e=>`
          <label>
            <input
              type="radio"
              name="siteArchiveFilter"
              value="${e}"
              ${r===e?`checked`:``}
              onchange="showSites('${e}')"
            >
            ${e[0].toUpperCase()+e.slice(1)}
          </label>
        `).join(``)}
      </div>
    </div>

    <label><strong>Search Sites</strong></label>
    <br>

    <input
      id="siteSearch"
      class="search-box"
      type="text"
      placeholder="Search Site ID, Client or Site Name..."
      onkeyup="filterSites(true)"
    />

    <br><br>

    ${a({...l,label:`sites`,onPage:`goToSitePage`,onPageSize:`setSiteRowsPerPage`})}

    <table>
    <thead>
      <tr>
        <th>${n(`Site ID`,`sites`,`siteid`,`showSites`)}</th>
        <th>${n(`Client`,`sites`,`clientname`,`showSites`)}</th>
        <th>${n(`Site Name`,`sites`,`sitename`,`showSites`)}</th>
        <th>${n(`Status`,`sites`,`archived`,`showSites`)}</th>
        <th>Actions</th>
      </tr>
    </thead>

      <tbody id="siteTableBody">
        ${l.rows.map(e=>`
         <tr>
          <td>${c(e.siteid)}</td>
          <td>${c(e.clientname||``)}</td>
          <td>${c(e.sitename||``)}</td>
          <td>${e.archived?`Archived`:`Active`}</td>
          <td>
            <button onclick="editSite(${e.siteid})">
              Edit
            </button>
            ${o?`
            ${e.archived?`<button onclick="unarchiveSite(${e.siteid})">Restore</button>`:`<button onclick="archiveSite(${e.siteid})">Archive</button>`}
            `:``}
          </td>
        </tr>
        `).join(``)}
      </tbody>
    </table>
  `}function f(e,r=`active`){let o=window.currentUser?.role===`ADMIN`,s=e.filter(e=>{let t=e.archived===!0||e.archived===`true`;return r===`active`?!t:r===`archived`?t:!0}),l=i(t(s,`responsible`,{personid:e=>e.personid,clientname:e=>e.clientname,name:e=>e.name,archived:e=>e.archived?`Archived`:`Active`},`name`),`responsibleCurrentPage`,`responsibleRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h2>Responsible Persons</h2>

    <div class="page-actions">
      <button onclick="showAddResponsiblePersonForm()">
        Add Responsible Person
      </button>
    </div>

    <div class="filter-card">
      <p>
        Total Responsible Persons:
        <strong>${s.length}</strong>
      </p>

      <label>Show Responsible Persons</label>
      <div class="radio-row">
        ${[`active`,`archived`,`all`].map(e=>`
          <label>
            <input
              type="radio"
              name="responsibleArchiveFilter"
              value="${e}"
              ${r===e?`checked`:``}
              onchange="showResponsiblePersons('${e}')"
            >
            ${e[0].toUpperCase()+e.slice(1)}
          </label>
        `).join(``)}
      </div>

      <label><strong>Search Responsible Persons</strong></label>

      <input
        id="responsibleSearch"
        class="search-box"
        type="text"
        placeholder="Search Customer Name or Responsible Person..."
        onkeyup="filterResponsiblePersons(true)"
      />
    </div>

    ${a({...l,label:`people`,onPage:`goToResponsiblePage`,onPageSize:`setResponsibleRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${n(`Person ID`,`responsible`,`personid`,`showResponsiblePersons`)}</th>
          <th>${n(`Client`,`responsible`,`clientname`,`showResponsiblePersons`)}</th>
          <th>${n(`Name`,`responsible`,`name`,`showResponsiblePersons`)}</th>
          <th>${n(`Status`,`responsible`,`archived`,`showResponsiblePersons`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody id="responsibleTableBody">
        ${l.rows.map(e=>`
          <tr>
            <td>${c(e.personid)}</td>
            <td>${c(e.clientname||``)}</td>
            <td>${c(e.name||``)}</td>
            <td>${e.archived?`Archived`:`Active`}</td>
            <td>
              <button onclick="editResponsiblePerson(${e.personid})">
                Edit
              </button>
              ${o?`
              ${e.archived?`<button onclick="unarchiveResponsiblePerson(${e.personid})">Restore</button>`:`<button onclick="archiveResponsiblePerson(${e.personid})">Archive</button>`}
              `:``}
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `}function p(e){return e.responsiblename||`Not assigned`}function m(e,r=`active`){let o=window.currentUser?.role===`ADMIN`,s=e.filter(e=>{let t=e.archived===!0||e.archived===`true`;return r===`active`?!t:r===`archived`?t:!0}),l=i(t(s,`sections`,{client_section:e=>`${e.clientname||``}\u0000${e.sectionname||``}`,sectionid:e=>e.sectionid,clientname:e=>e.clientname,sitename:e=>e.sitename,responsiblename:e=>p(e),sectionname:e=>e.sectionname,archived:e=>e.archived?`Archived`:`Active`},`client_section`),`sectionCurrentPage`,`sectionRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h2>Sections</h2>

    <div class="page-actions">
      <button onclick="showAddSectionForm()">
        Add Section
      </button>
    </div>

    <div class="filter-card">
      <p>
        Total Sections:
        <strong>${s.length}</strong>
      </p>

      <label>Show Sections</label>
      <div class="radio-row">
        ${[`active`,`archived`,`all`].map(e=>`
          <label>
            <input
              type="radio"
              name="sectionArchiveFilter"
              value="${e}"
              ${r===e?`checked`:``}
              onchange="showSections('${e}')"
            >
            ${e[0].toUpperCase()+e.slice(1)}
          </label>
        `).join(``)}
      </div>

      <label><strong><h2>Search Sections</h2></strong></label>

      <div class="form-row">
        <div class="form-group">
          <label>Search By</label>

          <select id="sectionSearchType" onchange="filterSections(true)">
            <option value="clientname">Customer</option>
            <option value="sitename">Site</option>
            <option value="responsiblename">Responsible Person</option>
            <option value="sectionname">Section</option>
          </select>
        </div>

        <div class="form-group">
          <label>Search Text</label>

          <input
            id="sectionSearch"
            class="search-box"
            type="text"
            placeholder="Type search text..."
            onkeyup="filterSections(true)"
          />
        </div>
      </div>
    </div>

    ${a({...l,label:`sections`,onPage:`goToSectionPage`,onPageSize:`setSectionRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${n(`ID`,`sections`,`sectionid`,`showSections`)}</th>
          <th>${n(`Client`,`sections`,`clientname`,`showSections`)}</th>
          <th>${n(`Site`,`sections`,`sitename`,`showSections`)}</th>
          <th>${n(`Responsible Person`,`sections`,`responsiblename`,`showSections`)}</th>
          <th>${n(`Section Name`,`sections`,`sectionname`,`showSections`)}</th>
          <th>${n(`Status`,`sections`,`archived`,`showSections`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody id="sectionTableBody">
        ${l.rows.map(e=>`
          <tr>
            <td>${c(e.sectionid)}</td>
            <td>${c(e.clientname||``)}</td>
            <td>${c(e.sitename||``)}</td>
            <td>${c(p(e))}</td>
            <td>${c(e.sectionname||``)}</td>
            <td>${e.archived?`Archived`:`Active`}</td>
            <td>
              <button onclick="editSection(${e.sectionid})">
                Edit
              </button>
              ${o?`
              ${e.archived?`<button onclick="unarchiveSection(${e.sectionid})">Restore</button>`:`<button onclick="archiveSection(${e.sectionid})">Archive</button>`}
              `:``}
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `}function h(e){return[`100`,`400`,`500`].includes(String(e.equipgroupid||``))?!0:(window.atecCriteria||[]).some(t=>String(t.equiptypeid)===String(e.equiptypeid)&&String(t.inspectioncategory||t.inspection_category||``).toUpperCase()===`LOADTEST`&&t.active!==!1&&t.active!==`false`)}function ee(e){let t=e.serialno||e.hoistserialno||``,n=[`ADMIN`,`MANAGER`,`INSPECTOR`].includes(window.currentUser?.role),r=window.currentUser?.role===`ADMIN`,i=c(e.assetid),a=c(e.assettagno||``),o=c(t),s=c(e.hoistserialno||``),l=c(e.clientname||``),u=c(e.sitename||``),d=c(e.sectionname||``),f=c(e.equipmenttype||``),p=c(e.description||``);return`
    <tr>
      <td>${i}</td>
      <td>${a}</td>
      <td>
        ${o}
        ${e.serialno&&e.hoistserialno&&e.serialno!==e.hoistserialno?`
          <br><small>Hoist: ${s}</small>
        `:``}
      </td>
      <td>${l}</td>
      <td>${u}</td>
      <td>${d}</td>
      <td>${f}</td>
      <td>${p}</td>
      <td>
        <div class="action-buttons">
          ${n?`
            <button onclick="editAsset(${e.assetid})">
              Edit
            </button>

            <button onclick="startInspection(${e.assetid}, 'VISUAL', 'assets')">
              Inspect
            </button>

            ${h(e)?`
              <button
                class="load-test-btn"
                onclick="startInspection(${e.assetid}, 'LOADTEST', 'assets')"
              >
                Load Test
              </button>
            `:``}
          `:``}

          <button class="history-btn" onclick="showAssetHistoryFromSetup(${e.assetid})">
            History
          </button>

          <button class="qr-label-btn" onclick="openAssetQrLabel(${e.assetid})">
            QR Label
          </button>

          ${r?`
            <button class="move-btn" onclick="showMoveAssetForm(${e.assetid})">
              Move
            </button>

            <button onclick="archiveAsset(${e.assetid})">
              Archive
            </button>
          `:``}
        </div>
      </td>
    </tr>
  `}function te(e,r={}){let i=r.serverPaged===!0,a=i?e:t(e,`assets`,{assetid:e=>e.assetid,assettagno:e=>e.assettagno,serialno:e=>e.serialno||e.hoistserialno,clientname:e=>e.clientname,sitename:e=>e.sitename,sectionname:e=>e.sectionname,equipmenttype:e=>e.equipmenttype,description:e=>e.description,qrcode:e=>e.qrcode},`assetid`),o=window.assetRowsPerPage||25,s=i?Number(r.total||0):a.length,c=Math.max(1,Math.ceil(s/o)),l=Math.min(window.assetCurrentPage||1,c),u=(l-1)*o,d=i?a:a.slice(u,u+o),f=s===0?0:u+d.length,p=re(s,u,f,l,c,o,!0),m=re(s,u,f,l,c,o,!1);document.querySelector(`#page`).innerHTML=`
    <h1>Asset Setup</h1>

    ${[`ADMIN`,`MANAGER`,`INSPECTOR`].includes(window.currentUser?.role)?`
      <div class="page-actions">
        <button onclick="showAddAssetForm()">
          Add Asset
        </button>
      </div>
    `:``}

    <div class="filter-card">
      <p>
        Total Assets:
        <strong id="assetTotalCount">${s}</strong>
      </p>

      <h2>Search Assets</h2>

      <div class="form-row">
        <div class="form-group">
          <label>Search By</label>

          <select id="assetSearchType" onchange="filterAssets(true)">
            <option value="all">All Fields</option>
            <option value="assetid">Asset ID</option>
            <option value="assettagno">Asset Tag</option>
            <option value="serialno">Serial No</option>
            <option value="hoistserialno">Hoist Serial No</option>
            <option value="clientname">Client</option>
            <option value="sitename">Site</option>
            <option value="sectionname">Section</option>
            <option value="equipmenttype">Equipment Type</option>
            <option value="description">Description</option>
            <option value="qrcode">QR Code</option>
          </select>
        </div>

        <div class="form-group">
          <label>Search Text</label>

          <input
            id="assetSearch"
            class="search-box"
            type="text"
            placeholder="Type search text..."
            oninput="filterAssetsDebounced(true)"
          />
        </div>
      </div>

      <div class="filter-key-row">
        ${[[`all`,`All`],[`assetid`,`Asset ID`],[`assettagno`,`Asset Tag`],[`serialno`,`Serial No`],[`hoistserialno`,`Hoist Serial No`],[`clientname`,`Client`],[`sitename`,`Site`],[`sectionname`,`Section`],[`equipmenttype`,`Equipment Type`],[`description`,`Description`],[`qrcode`,`QR Code`]].map(([e,t])=>`
          <button type="button" class="filter-key-btn" onclick="setAssetFilterKey('${e}')">
            ${t}
          </button>
        `).join(``)}
      </div>
    </div>

    ${p}

    <table>
      <thead>
        <tr>
          <th>${n(`Asset ID`,`assets`,`assetid`,`showAssetSetup`)}</th>
          <th>${n(`Asset Tag`,`assets`,`assettagno`,`showAssetSetup`)}</th>
          <th>${n(`Serial No`,`assets`,`serialno`,`showAssetSetup`)}</th>
          <th>${n(`Client`,`assets`,`clientname`,`showAssetSetup`)}</th>
          <th>${n(`Site`,`assets`,`sitename`,`showAssetSetup`)}</th>
          <th>${n(`Section`,`assets`,`sectionname`,`showAssetSetup`)}</th>
          <th>${n(`Equipment Type`,`assets`,`equipmenttype`,`showAssetSetup`)}</th>
          <th>${n(`Description`,`assets`,`description`,`showAssetSetup`)}</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody id="assetTableBody">
        ${d.map(ee).join(``)}
      </tbody>
    </table>

    ${m}
  `}function ne(e,n={}){let r=document.querySelector(`#assetTableBody`);if(!r){te(e,n);return}let i=n.serverPaged===!0,a=i?e:t(e,`assets`,{assetid:e=>e.assetid,assettagno:e=>e.assettagno,serialno:e=>e.serialno||e.hoistserialno,clientname:e=>e.clientname,sitename:e=>e.sitename,sectionname:e=>e.sectionname,equipmenttype:e=>e.equipmenttype,description:e=>e.description,qrcode:e=>e.qrcode},`assetid`),o=window.assetRowsPerPage||25,s=i?Number(n.total||0):a.length,c=Math.max(1,Math.ceil(s/o)),l=Math.min(window.assetCurrentPage||1,c),u=(l-1)*o,d=i?a:a.slice(u,u+o),f=s===0?0:u+d.length,p=document.querySelector(`#assetTotalCount`),m=re(s,u,f,l,c,o,!0),h=re(s,u,f,l,c,o,!1);p&&(p.textContent=String(s)),r.innerHTML=d.map(ee).join(``);let ne=document.querySelector(`#assetPaginationControls`),ie=document.querySelector(`.asset-pagination-bottom`);ne&&(ne.outerHTML=m),ie&&(ie.outerHTML=h)}function re(e,t,n,r,i,a,o){let s=ae(r,i);return`
    <div ${o?`id="assetPaginationControls"`:``} class="report-pagination-bar asset-pagination-bar ${o?``:`asset-pagination-bottom`}">
      ${o?`
        <div class="report-page-size">
          <label for="assetRowsPerPage">Rows per page</label>
          <select id="assetRowsPerPage" onchange="setAssetRowsPerPage(this.value)">
            ${[25,50,100,250].map(e=>`
              <option value="${e}" ${e===a?`selected`:``}>
                ${e}
              </option>
            `).join(``)}
          </select>
        </div>
      `:`<div></div>`}

      <div class="report-page-controls">
        <button type="button" onclick="changeAssetPage(-1)" ${r<=1?`disabled`:``}>
          Previous
        </button>
        ${s}
        <button type="button" onclick="changeAssetPage(1)" ${r>=i?`disabled`:``}>
          Next
        </button>
        <span>Showing ${e===0?0:t+1} to ${n} of ${e} assets - Page ${r} of ${i}</span>
      </div>
    </div>
  `}function ie(e,t){let n=[];if(t<=10){for(let e=1;e<=t;e+=1)n.push(e);return n}let r=Math.max(1,e-4),i=Math.min(t,r+9-1);i-r+1<9&&(r=Math.max(1,i-9+1)),r>1&&(n.push(1),r>2&&n.push(`...`));for(let e=r;e<=i;e+=1)n.push(e);return i<t&&(i<t-1&&n.push(`...`),n.push(t)),n}function ae(e,t){return ie(e,t).map(t=>t===`...`?`<span class="pagination-ellipsis">...</span>`:`
      <button
        type="button"
        class="pagination-page-btn ${t===e?`active`:``}"
        onclick="goToAssetPage(${t})"
        ${t===e?`disabled`:``}
      >
        ${t}
      </button>
    `).join(``)}function oe(e,t,n,r,i=25){let a=window[r]||i,o=Number(t.total||0),s=Math.max(1,Math.ceil(o/a)),c=Math.min(window[n]||1,s),l=(c-1)*a,u=o===0?0:l+e.length;return window[n]=c,window[r]=a,{currentPage:c,endIndex:u,pageSize:a,rows:e,startIndex:l,totalPages:s,totalRows:o}}function se(e,r={}){let o=r.serverPaged===!0,s=o?e:t(e,`inspectionAssets`,{client_section_serial:e=>`${e.clientname||``}\u0000${e.sectionname||``}\u0000${e.serialno||``}`,assetid:e=>e.assetid,assettagno:e=>e.assettagno,serialno:e=>e.serialno,clientname:e=>e.clientname,sitename:e=>e.sitename,sectionname:e=>e.sectionname,description:e=>e.description,equipmenttype:e=>e.equipmenttype},`client_section_serial`),l=o?oe(s,r,`inspectionCurrentPage`,`inspectionRowsPerPage`):i(s,`inspectionCurrentPage`,`inspectionRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h1>Inspections/Load Tests</h1>

    <div class="filter-card">
      <label><strong><h2>Search Assets</h2></strong></label>

      <div class="form-row">
        <div class="form-group">
          <label>Search By</label>

          <select id="inspectionSearchType" onchange="filterInspectionAssets(true)">
            <option value="all">All Fields</option>
            <option value="assetid">Asset ID</option>
            <option value="assettagno">Asset Tag</option>
            <option value="serialno">Serial No</option>
            <option value="clientname">Client</option>
            <option value="sitename">Site</option>
            <option value="sectionname">Section</option>
            <option value="description">Description</option>
            <option value="equipmenttype">Equipment Type</option>
          </select>
        </div>

        <div class="form-group">
          <label>Search Text</label>

          <input
            id="inspectionAssetSearch"
            class="search-box"
            type="text"
            placeholder="Type search text..."
            onkeyup="filterInspectionAssets(true)"
          />
        </div>
      </div>

      <div class="filter-key-row">
        ${[[`all`,`All`],[`assetid`,`Asset ID`],[`assettagno`,`Asset Tag`],[`serialno`,`Serial No`],[`clientname`,`Client`],[`sitename`,`Site`],[`sectionname`,`Section`],[`equipmenttype`,`Equipment Type`],[`description`,`Description`]].map(([e,t])=>`
          <button type="button" class="filter-key-btn" onclick="setInspectionFilterKey('${e}')">
            ${t}
          </button>
        `).join(``)}
      </div>
    </div>

    ${a({...l,label:`assets`,onPage:`goToInspectionPage`,onPageSize:`setInspectionRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${n(`Asset ID`,`inspectionAssets`,`assetid`,`showInspections`)}</th>
          <th>${n(`Asset Tag`,`inspectionAssets`,`assettagno`,`showInspections`)}</th>
          <th>${n(`Serial No`,`inspectionAssets`,`serialno`,`showInspections`)}</th>
          <th>${n(`Client`,`inspectionAssets`,`clientname`,`showInspections`)}</th>
          <th>${n(`Site`,`inspectionAssets`,`sitename`,`showInspections`)}</th>
          <th>${n(`Section`,`inspectionAssets`,`sectionname`,`showInspections`)}</th>
          <th>${n(`Description`,`inspectionAssets`,`description`,`showInspections`)}</th>
          <th>${n(`Equipment Type`,`inspectionAssets`,`equipmenttype`,`showInspections`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody id="inspectionAssetTableBody">
        ${l.rows.map(e=>`
          <tr>
            <td>${c(e.assetid)}</td>
            <td>${c(e.assettagno||``)}</td>
            <td>${c(e.serialno||``)}</td>
            <td>${c(e.clientname||``)}</td>
            <td>${c(e.sitename||``)}</td>
            <td>${c(e.sectionname||``)}</td>
            <td>${c(e.description||``)}</td>
            <td>${c(e.equipmenttype||``)}</td>
            <td>
  <div class="action-buttons">

    <button
          onclick="startInspection(${e.assetid}, 'VISUAL', 'inspections')">
          Inspection
        </button>

        ${[`100`,`400`,`500`].includes(String(e.equipgroupid))?`
            <button
              class="load-test-btn"
              onclick="startInspection(${e.assetid}, 'LOADTEST', 'inspections')">
              Load Test
            </button>
          `:``}

      </div>
    </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>

    <br>

    <div id="inspectionFormContainer"></div>
  `}function ce(e,r){let o=[...e].sort((e,t)=>(e.description||``).localeCompare(t.description||``)),s=window.criteriaEquipmentFilter||``,u=i(t(s?r.filter(e=>String(e.equiptypeid)===String(s)):r,`criteria`,{equipmenttype:e=>e.equipmenttype,inspectioncategory:e=>e.inspectioncategory,inspection_category:e=>e.inspection_category,severity:e=>e.severity,criterianame:e=>e.criterianame,resulttype:e=>e.resulttype,active:e=>e.active?`Active`:`Inactive`},`equipmenttype`),`criteriaCurrentPage`,`criteriaRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h1>Equipment Type Criteria Setup</h1>

    <div class="filter-card">
      <div class="form-row">
        <div class="form-group">
          <label>Show Criteria For</label>
          <select id="criteriaEquipmentFilter" onchange="filterEquipmentCriteria()">
            <option value="">All Equipment Types</option>
            ${o.map(e=>`
              <option
                value="${l(e.equiptypeid)}"
                ${String(e.equiptypeid)===String(s)?`selected`:``}
              >
                ${c(e.description)}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="form-group criteria-action-group">
          <button type="button" onclick="openCriteriaPopup()">
            Add Criteria
          </button>
        </div>
      </div>
    </div>

    ${a({...u,label:`criteria`,onPage:`goToCriteriaPage`,onPageSize:`setCriteriaRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${n(`Equipment Type`,`criteria`,`equipmenttype`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Type`,`criteria`,`inspectioncategory`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Category`,`criteria`,`inspection_category`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Severity`,`criteria`,`severity`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Criteria`,`criteria`,`criterianame`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Result Type`,`criteria`,`resulttype`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Status`,`criteria`,`active`,`showEquipmentTypeCriteria`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody>
        ${u.rows.map(e=>`
          <tr>
            <td>${c(e.equipmenttype||``)}</td>
            <td>${c(e.inspectioncategory||``)}</td>
            <td>${c(le(e.inspection_category))}</td>
            <td>${c(le(e.severity))}</td>
            <td>${c(e.criteriadescription||e.criterianame||``)}</td>
            <td>${c(le(e.resulttype||e.fieldtype))}</td>
            <td>${e.active===!1?`Inactive`:`Active`}</td>
            <td class="criteria-row-actions">
              <button type="button" onclick="editCriteria(${e.criteriaid})">
                Edit
              </button>
              <button type="button" onclick="deleteCriteria(${e.criteriaid})">
                Delete
              </button>
            </td>
          </tr>
        `).join(``)||`
          <tr>
            <td colspan="8">No criteria found for the selected equipment type.</td>
          </tr>
        `}
      </tbody>
    </table>
  `}function le(e){return String(e||``).replaceAll(`_`,` `).toLowerCase().replace(/\b\w/g,e=>e.toUpperCase())}function ue(){document.querySelector(`#page`).innerHTML=`
    <h2>Quick Inspection/Test</h2>

    <div class="filter-card">
      <h3>Scan / Search Asset</h3>

      <label>QR Code, Asset ID, Serial No, Hoist Serial No or Asset Tag</label>

      <input
        id="quickAssetSearch"
        class="quick-scan-box"
        type="text"
        placeholder="Scan or type here..."
        autofocus
        onkeydown="handleQuickInspectionEnter(event)"
      >

      <div class="quick-scan-actions">
        <button onclick="quickFindAsset()">
          Find Asset
        </button>

        <button type="button" class="qr-scan-btn" onclick="startQuickCameraScan()">
          Scan With Camera
        </button>
      </div>

      <div id="quickCameraScanner" class="quick-camera-scanner" hidden>
        <video id="quickCameraVideo" playsinline></video>
        <div class="quick-scan-actions">
          <button type="button" onclick="stopQuickCameraScan()">Stop Scan</button>
        </div>
        <p id="quickScanStatus">Point the camera at the ATEC QR label.</p>
      </div>
    </div>

    <div id="quickInspectionResult"></div>
  `}function de(){return`${window.location.origin}/api`}var g=de().replace(/\/$/,``);function fe(e=``){return e?/^https?:\/\//i.test(e)?e.replace(/^http:\/\/localhost:5000/i,g):`${g}${e.startsWith(`/`)?e:`/${e}`}`:g}function pe(e=``){return`/${String(e||``).replace(/^\/+/,``)}`}function me(e=``){if(!e)return``;let t=String(e).trim();if(/^https?:\/\//i.test(t))return fe(t);t.startsWith(`/`)||(t=t.startsWith(`uploads/`)?`/${t}`:t.startsWith(`assets/`)?`/uploads/${t}`:`/uploads/assets/${t}`);let n=encodeURI(t);return t.startsWith(`/uploads/`)?`${window.location.origin}${n}`:fe(n)}async function he(e){let t=await e.text();if(!t)return{};try{return JSON.parse(t)}catch{return{error:e.ok?`The server returned an unexpected certificate response.`:`The server returned an unexpected error while loading the certificate.`}}}async function ge(e){let t=await e.text();return e.ok?{html:t,error:``}:{html:``,error:t||`The server returned an unexpected error while loading the certificate.`}}function _e(e){return`${g}/inspections/${encodeURIComponent(e)}/certificate.html?t=${Date.now()}`}function ve(e=[],t=[],n=[]){document.querySelector(`#page`).innerHTML=`
    <h1>Certificates</h1>
    <p>Search, view and manage inspection and load test certificates.</p>

    <div class="filter-card">
      <h2>Search Certificates</h2>

      <div class="asset-form-grid">
        <div class="form-group">
          <label>Broad Search</label>
          <input
            id="certSearch"
            type="text"
            placeholder="Test ID, tag, serial, client, site, asset description..."
          >
        </div>

        <div class="form-group">
          <label>Inspection Type</label>
          <select id="certInspectionType">
            <option value="">All Types</option>
            <option value="VISUAL">Visual Inspection</option>
            <option value="LOADTEST">Load Test</option>
          </select>
        </div>

        <div class="form-group">
          <label>Status</label>
          <select id="certStatus">
            <option value="">All Statuses</option>
            <option value="SAFE">SAFE</option>
            <option value="NOT SAFE">NOT SAFE</option>
          </select>
        </div>

        <div class="form-group">
          <label>Client</label>
          <select id="certClient">
            <option value="">All Clients</option>
            ${e.map(e=>`
              <option value="${l(e.clientid)}">${c(e.clientname)}</option>
            `).join(``)}
          </select>
        </div>

        <div class="form-group">
          <label>Site</label>
          <select id="certSite">
            <option value="">All Sites</option>
          </select>
        </div>

        <div class="form-group">
          <label>Section</label>
          <select id="certSection">
            <option value="">All Sections</option>
          </select>
        </div>

        <div class="form-group">
          <label>Date From</label>
          <input id="certDateFrom" type="date">
        </div>

        <div class="form-group">
          <label>Date To</label>
          <input id="certDateTo" type="date">
        </div>
      </div>

      <div class="form-actions">
        <button id="certSearchBtn">Search</button>
        <button id="certClearBtn">Clear Filters</button>
      </div>
    </div>

    <div class="filter-card bulk-certificate-card">
      <h2>Bulk Print Certificates</h2>
      <p>Select a customer and date range, then choose the certificates to print together.</p>

      <div class="asset-form-grid">
        <div class="form-group">
          <label>Customer</label>
          <select id="bulkCertClient">
            <option value="">Select Customer</option>
            ${e.map(e=>`
              <option value="${l(e.clientid)}">${c(e.clientname)}</option>
            `).join(``)}
          </select>
        </div>

        <div class="form-group">
          <label>Date From</label>
          <input id="bulkCertDateFrom" type="date">
        </div>

        <div class="form-group">
          <label>Date To</label>
          <input id="bulkCertDateTo" type="date">
        </div>

        <div class="form-group">
          <label>Site</label>
          <select id="bulkCertSite">
            <option value="">All Sites</option>
          </select>
        </div>

        <div class="form-group">
          <label>Inspection Type</label>
          <select id="bulkCertInspectionType">
            <option value="ALL">All Types</option>
            <option value="VISUAL">Visual Inspection</option>
            <option value="LOADTEST">Load Test</option>
          </select>
        </div>

        <div class="form-group">
          <label>Status</label>
          <select id="bulkCertStatus">
            <option value="ALL">All Statuses</option>
            <option value="SAFE">SAFE</option>
            <option value="NOT SAFE">NOT SAFE</option>
          </select>
        </div>
      </div>

      <div class="form-actions">
        <button id="bulkCertSearchBtn" type="button">Load Certificates</button>
        <button id="bulkCertPrintBtn" type="button" disabled>Print Selected Certificates</button>
        <button id="bulkCertDownloadSelectedBtn" type="button" disabled>Download Selected as PDF</button>
        <button id="bulkCertDownloadAllBtn" type="button" disabled>Download All Results as PDF</button>
      </div>

      <div id="bulkCertificateResults" class="bulk-certificate-results">
        <p>No bulk search loaded yet.</p>
      </div>
    </div>

    <div class="certificate-dashboard-grid">
      <div class="filter-card">
        <h2>Search Results</h2>
        <div id="certificateResults">
          <p>Loading certificates...</p>
        </div>
      </div>

      <div>
        <div class="filter-card">
          <h2>Quick Stats</h2>
          <div id="certificateStats">
            <p>No search loaded yet.</p>
          </div>
        </div>

        <div class="filter-card" id="certificatePreviewPanel">
          <h2>Certificate Preview</h2>
          <p>Select Preview on a certificate to view quick details here.</p>
        </div>
      </div>
    </div>
  `,window.certificateCustomers=e,window.certificateSites=t,window.certificateSections=n,_(),document.querySelector(`#certSearch`).addEventListener(`keydown`,e=>{e.key===`Enter`&&window.searchCertificates()}),document.querySelector(`#certClient`).addEventListener(`change`,window.filterCertificateSites),document.querySelector(`#certSite`).addEventListener(`change`,window.filterCertificateSections),document.querySelector(`#certSearchBtn`).addEventListener(`click`,window.searchCertificates),document.querySelector(`#certClearBtn`).addEventListener(`click`,window.clearCertificateSearch),document.querySelector(`#bulkCertClient`).addEventListener(`change`,window.filterBulkCertificateSites),document.querySelector(`#bulkCertSearchBtn`).addEventListener(`click`,window.searchBulkCertificates),document.querySelector(`#bulkCertPrintBtn`).addEventListener(`click`,window.printSelectedBulkCertificates),document.querySelector(`#bulkCertDownloadSelectedBtn`).addEventListener(`click`,window.downloadSelectedBulkCertificatesPdf),document.querySelector(`#bulkCertDownloadAllBtn`).addEventListener(`click`,window.downloadAllBulkCertificatesPdf),window.searchCertificates()}function _(){Object.assign(window,De)}window.filterCertificateSites=function(){let e=document.querySelector(`#certClient`).value,t=document.querySelector(`#certSite`),n=document.querySelector(`#certSection`);n.innerHTML=`<option value="">All Sections</option>`,t.innerHTML=`
    <option value="">All Sites</option>
    ${(e?window.certificateSites.filter(t=>String(t.clientid)===String(e)):window.certificateSites).map(e=>`
      <option value="${l(e.siteid)}">${c(e.sitename)}</option>
    `).join(``)}
  `},window.filterCertificateSections=function(){let e=document.querySelector(`#certSite`).value,t=document.querySelector(`#certSection`);t.innerHTML=`
    <option value="">All Sections</option>
    ${(e?window.certificateSections.filter(t=>String(t.siteid)===String(e)):window.certificateSections).map(e=>`
      <option value="${l(e.sectionid)}">${c(e.sectionname)}</option>
    `).join(``)}
  `},window.filterBulkCertificateSites=function(){let e=document.querySelector(`#bulkCertClient`).value,t=document.querySelector(`#bulkCertSite`);t.innerHTML=`
    <option value="">All Sites</option>
    ${(e?window.certificateSites.filter(t=>String(t.clientid)===String(e)):[]).map(e=>`
      <option value="${l(e.siteid)}">${c(e.sitename)}</option>
    `).join(``)}
  `},window.clearCertificateSearch=function(){document.querySelector(`#certSearch`).value=``,document.querySelector(`#certInspectionType`).value=``,document.querySelector(`#certStatus`).value=``,document.querySelector(`#certClient`).value=``,document.querySelector(`#certSite`).innerHTML=`<option value="">All Sites</option>`,document.querySelector(`#certSection`).innerHTML=`<option value="">All Sections</option>`,document.querySelector(`#certDateFrom`).value=``,document.querySelector(`#certDateTo`).value=``,window.certCurrentPage=1,window.searchCertificates()},window.searchCertificates=async function(t=!0){t&&(window.certCurrentPage=1);let n=new URLSearchParams;n.append(`search`,document.querySelector(`#certSearch`)?.value||``),n.append(`inspectiontype`,document.querySelector(`#certInspectionType`)?.value||``),n.append(`status`,document.querySelector(`#certStatus`)?.value||``),n.append(`clientid`,document.querySelector(`#certClient`)?.value||``),n.append(`siteid`,document.querySelector(`#certSite`)?.value||``),n.append(`sectionid`,document.querySelector(`#certSection`)?.value||``),n.append(`datefrom`,document.querySelector(`#certDateFrom`)?.value||``),n.append(`dateto`,document.querySelector(`#certDateTo`)?.value||``),n.append(`page`,String(window.certCurrentPage||1)),n.append(`limit`,String(window.certRowsPerPage||25));let r=e(`certificates`,`testid`,`desc`);n.append(`sortKey`,r.key||`testid`),n.append(`sortDir`,r.direction||`desc`);let i=await fetch(`${g}/certificates/search?${n.toString()}`),a=await i.json();if(!i.ok){alert(`Error searching certificates: `+a.error);return}let o=Array.isArray(a)?a:a.rows||[];window.currentCertificateResults=o,window.currentCertificatePageInfo=Array.isArray(a)?null:{currentPage:Number(a.page||1),pageSize:Number(a.limit||window.certRowsPerPage||25),totalRows:Number(a.total||o.length),totalPages:Number(a.totalPages||1),startIndex:(Number(a.page||1)-1)*Number(a.limit||window.certRowsPerPage||25),endIndex:(Number(a.page||1)-1)*Number(a.limit||window.certRowsPerPage||25)+o.length},ye(o,a.summary),be(o)};function ye(e,t=null){let n=t?t.safe:e.filter(e=>e.status===`SAFE`).length,r=t?t.notSafe:e.filter(e=>e.status===`NOT SAFE`).length,i=t?t.loadTest:e.filter(e=>e.inspectiontype===`LOADTEST`).length,a=t?t.visual:e.filter(e=>e.inspectiontype===`VISUAL`).length,o=t?Number(t.total||window.currentCertificatePageInfo?.totalRows||e.length):e.length;document.querySelector(`#certificateStats`).innerHTML=`
    <p><strong>Total:</strong> ${o||window.currentCertificatePageInfo?.totalRows||e.length}</p>
    <p><strong>Safe:</strong> ${n}</p>
    <p><strong>Not Safe:</strong> ${r}</p>
    <p><strong>Visual:</strong> ${a}</p>
    <p><strong>Load Tests:</strong> ${i}</p>
  `}function v(t,n){let r=e(`certificates`,`testid`,`desc`),i=r.key===n,a=i?r.direction===`desc`?`v`:`^`:`^v`;return`
    <span class="certificate-sort-heading">
      <span>${t}</span>
      <button
        type="button"
        class="certificate-sort-btn ${i?`active`:``}"
        onclick="sortTable('certificates', '${n}', 'rerenderCertificateResults')"
        aria-label="Sort ${t}"
        title="Sort ${t}"
      >${a}</button>
    </span>
  `}function be(e){if(e.length===0){document.querySelector(`#certificateResults`).innerHTML=`<p>No certificates found.</p>`;return}let n=window.currentUser?.role===`ADMIN`,r=window.currentCertificatePageInfo?e:t(e,`certificates`,{testid:e=>e.testid,tagnumber:e=>e.tagnumber,clientname:e=>e.clientname,sitename:e=>e.sitename,description:e=>e.description,serialno:e=>e.serialno,inspectiontype:e=>e.inspectiontype,testdate:e=>e.testdate,status:e=>e.status,inspector:e=>e.inspector},`testid`,`desc`),o=window.currentCertificatePageInfo?{...window.currentCertificatePageInfo,rows:r}:i(r,`certCurrentPage`,`certRowsPerPage`);document.querySelector(`#certificateResults`).innerHTML=`
    ${a({...o,label:`certificates`,onPage:`goToCertificatePage`,onPageSize:`setCertificateRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${v(`Test ID`,`testid`)}</th>
          <th>${v(`Tag No`,`tagnumber`)}</th>
          <th>${v(`Client`,`clientname`)}</th>
          <th>${v(`Site`,`sitename`)}</th>
          <th>${v(`Asset`,`description`)}</th>
          <th>${v(`Serial No`,`serialno`)}</th>
          <th>${v(`Type`,`inspectiontype`)}</th>
          <th>${v(`Date`,`testdate`)}</th>
          <th>${v(`Status`,`status`)}</th>
          <th>${v(`Inspector`,`inspector`)}</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody>
        ${o.rows.map(e=>{let t=l(e.testid),r=c(e.status||``);return`
          <tr data-testid="${t}">
            <td>${c(e.testid)}</td>
            <td>${c(e.tagnumber||`-`)}</td>
            <td>${c(e.clientname||``)}</td>
            <td>${c(e.sitename||``)}</td>
            <td>${c(e.description||``)}</td>
            <td>${c(e.serialno||``)}</td>
            <td>${c(e.inspectiontype||``)}</td>
            <td>${c(Te(e.testdate))}</td>
            <td>
              <strong class="${e.status===`SAFE`?`status-safe`:`status-unsafe`}">
                ${r}
              </strong>
            </td>
            <td>${c(e.inspector||`-`)}</td>
            <td>
              <button type="button" class="cert-preview-btn" data-testid="${t}">
                Preview
              </button>

              <button type="button" class="cert-view-btn" data-testid="${t}">
                View
              </button>

              <a
                class="cert-action-link cert-download-btn"
                href="${g}/inspections/${encodeURIComponent(e.testid)}/certificate.pdf?t=${Date.now()}"
                download="certificate-${t}.pdf"
                onclick="event.stopPropagation()"
              >
                Download PDF
              </a>

              <button type="button" class="cert-mail-btn" data-testid="${t}">
                Mail
              </button>

              ${n?`
                <button type="button" class="cert-delete-btn" data-testid="${t}">
                  Delete
                </button>
              `:``}
            </td>
          </tr>
        `}).join(``)}
      </tbody>
    </table>
  `,we()}window.searchBulkCertificates=async function(){let e=document.querySelector(`#bulkCertClient`).value,t=document.querySelector(`#bulkCertDateFrom`).value,n=document.querySelector(`#bulkCertDateTo`).value,r=document.querySelector(`#bulkCertSite`).value,i=document.querySelector(`#bulkCertInspectionType`).value,a=document.querySelector(`#bulkCertStatus`).value;if(!e||!t||!n){alert(`Please select a customer, Date From and Date To for bulk printing.`);return}let o=new URLSearchParams({clientid:e,datefrom:t,dateto:n});r&&o.set(`siteid`,r),i&&i!==`ALL`&&o.set(`inspectiontype`,i),a&&a!==`ALL`&&o.set(`status`,a);let s=document.querySelector(`#bulkCertificateResults`),c=document.querySelector(`#bulkCertPrintBtn`),l=document.querySelector(`#bulkCertDownloadSelectedBtn`),u=document.querySelector(`#bulkCertDownloadAllBtn`);s.innerHTML=`<p>Loading matching certificates...</p>`,c.disabled=!0,l.disabled=!0,u.disabled=!0;let d=await fetch(`${g}/certificates/bulk-print?${o.toString()}`),f=await d.json();if(!d.ok){s.innerHTML=`<p>No bulk search loaded yet.</p>`,alert(`Error loading bulk certificates: `+(f.error||`Unable to load certificates`));return}window.bulkCertificateResults=f.certificates||[],y(window.bulkCertificateResults)};function y(e){let t=document.querySelector(`#bulkCertificateResults`),n=document.querySelector(`#bulkCertPrintBtn`),r=document.querySelector(`#bulkCertDownloadSelectedBtn`),i=document.querySelector(`#bulkCertDownloadAllBtn`);if(!e.length){t.innerHTML=`<p>No certificates found for the selected customer and date range.</p>`,n.disabled=!0,r.disabled=!0,i.disabled=!0;return}t.innerHTML=`
    <div class="bulk-certificate-summary">
      <strong>${e.length}</strong> matching certificate${e.length===1?``:`s`} found.
    </div>

    <div class="table-scroll bulk-certificate-table-wrap">
      <table class="bulk-certificate-table">
        <thead>
          <tr>
            <th>
              <input
                type="checkbox"
                id="bulkCertSelectAll"
                checked
                aria-label="Select all certificates"
              >
            </th>
            <th>Certificate No</th>
            <th>Date</th>
            <th>Valid Date</th>
            <th>Type</th>
            <th>Status</th>
            <th>Asset</th>
            <th>Asset Tag</th>
            <th>Serial No</th>
            <th>Site</th>
            <th>Inspector</th>
          </tr>
        </thead>

        <tbody>
          ${e.map(e=>{let t=e.inspection||{};return`
              <tr>
                <td>
                  <input
                    type="checkbox"
                    class="bulk-cert-check"
                    value="${l(t.testid)}"
                    checked
                    aria-label="Select certificate ${l(t.testid)}"
                  >
                </td>
                <td>${c(t.testid||``)}</td>
                <td>${c(Te(t.testdate))}</td>
                <td>${c(Te(t.validdate))}</td>
                <td>${c(t.inspectiontype||``)}</td>
                <td>
                  <strong class="${t.status===`SAFE`?`status-safe`:`status-unsafe`}">
                    ${c(t.status||``)}
                  </strong>
                </td>
                <td>${c(t.description||``)}</td>
                <td>${c(t.assettagno||t.tagnumber||`-`)}</td>
                <td>${c(t.serialno||``)}</td>
                <td>${c(t.sitename||``)}</td>
                <td>${c(t.inspector||`-`)}</td>
              </tr>
            `}).join(``)}
        </tbody>
      </table>
    </div>
  `,document.querySelector(`#bulkCertSelectAll`).addEventListener(`change`,e=>{document.querySelectorAll(`.bulk-cert-check`).forEach(t=>{t.checked=e.target.checked}),xe()}),document.querySelectorAll(`.bulk-cert-check`).forEach(e=>{e.addEventListener(`change`,xe)}),xe(),i.disabled=!1}function xe(){let e=document.querySelectorAll(`.bulk-cert-check:checked`).length,t=document.querySelector(`#bulkCertPrintBtn`),n=document.querySelector(`#bulkCertDownloadSelectedBtn`),r=document.querySelector(`#bulkCertSelectAll`);if(t&&(t.disabled=e===0,t.textContent=e?`Print Selected Certificates (${e})`:`Print Selected Certificates`),n&&(n.disabled=e===0,n.textContent=e?`Download Selected PDFs (${e})`:`Download Selected PDFs`),r){let t=document.querySelectorAll(`.bulk-cert-check`).length;r.checked=e>0&&e===t,r.indeterminate=e>0&&e<t}}window.printSelectedBulkCertificates=function(){let e=Array.from(document.querySelectorAll(`.bulk-cert-check:checked`)).map(e=>String(e.value));if(!e.length){alert(`Select at least one certificate to print.`);return}let t=b();t&&(t.set(`testids`,e.join(`,`)),t.set(`inline`,`1`),window.open(`${g}/certificates/bulk-pdf?${t.toString()}`,`_blank`))};function b(){let e=document.querySelector(`#bulkCertClient`).value,t=document.querySelector(`#bulkCertDateFrom`).value,n=document.querySelector(`#bulkCertDateTo`).value,r=document.querySelector(`#bulkCertSite`).value,i=document.querySelector(`#bulkCertInspectionType`).value,a=document.querySelector(`#bulkCertStatus`).value;if(!e||!t||!n)return alert(`Please select a customer, Date From and Date To before downloading PDFs.`),null;let o=new URLSearchParams({clientid:e,datefrom:t,dateto:n});return r&&o.set(`siteid`,r),i&&i!==`ALL`&&o.set(`inspectiontype`,i),a&&a!==`ALL`&&o.set(`status`,a),o}function Se(){return Array.from(document.querySelectorAll(`.bulk-cert-check:checked`)).map(e=>String(e.value))}window.downloadSelectedBulkCertificatesPdf=async function(){let e=Se();if(!e.length){alert(`Select at least one certificate to download.`);return}await Ee(e)},window.downloadAllBulkCertificatesPdf=async function(){if(!(window.bulkCertificateResults||[]).length){alert(`No certificates found to download. Load certificates first.`);return}let e=b();e&&await Ce(e)};async function Ce(e){let t=await fetch(`${g}/certificates/bulk-pdf?${e.toString()}`);if(!t.ok){let e=await t.json().catch(()=>({error:`Unable to download bulk certificates`}));alert(e.error||`Unable to download bulk certificates`);return}let n=await t.blob(),r=x(t.headers.get(`content-disposition`),`FB-Certificates.pdf`),i=window.URL.createObjectURL(n),a=document.createElement(`a`);a.href=i,a.download=r,document.body.appendChild(a),a.click(),a.remove(),window.URL.revokeObjectURL(i)}function x(e,t){let n=String(e||``).match(/filename="?([^"]+)"?/i);return n?n[1]:t}window.setCertificateRowsPerPage=function(e){window.certRowsPerPage=Number(e)||25,window.certCurrentPage=1,window.searchCertificates(!1)},window.rerenderCertificateResults=function(){window.certCurrentPage=1,window.searchCertificates(!1)},window.goToCertificatePage=function(e){window.certCurrentPage=Math.max(1,Number(e)||1),window.searchCertificates(!1)};function we(){document.querySelectorAll(`#certificateResults tbody tr`).forEach(e=>{e.addEventListener(`click`,()=>{window.selectCertificateRow(e,e.dataset.testid)})}),document.querySelectorAll(`.cert-preview-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation(),window.previewCertificate(e.dataset.testid)})}),document.querySelectorAll(`.cert-view-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation(),window.openCertificateModal(e.dataset.testid)})}),document.querySelectorAll(`.cert-mail-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation(),window.mailCertificate(e.dataset.testid)})}),document.querySelectorAll(`.cert-delete-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation(),window.deleteCertificate(e.dataset.testid)})})}window.selectCertificateRow=function(e,t){document.querySelectorAll(`#certificateResults tbody tr`).forEach(e=>e.classList.remove(`selected-certificate-row`)),e.classList.add(`selected-certificate-row`),window.previewCertificate(t)},window.previewCertificate=async function(e){let t=document.querySelector(`#certificatePreviewPanel`);if(!t)return;t.innerHTML=`
    <h2>Certificate Preview</h2>
    <p>Loading certificate...</p>
  `;let n=await fetch(_e(e),{credentials:`include`}),{html:r,error:i}=await ge(n);if(!n.ok){alert(`Error loading certificate preview: `+i),t.innerHTML=`
      <h2>Certificate Preview</h2>
      <p>Unable to load certificate preview.</p>
    `;return}t.innerHTML=`
    <h2>Certificate Preview</h2>

    <div class="certificate-preview-html-frame-wrap">
      <iframe
        class="certificate-preview-html-frame"
        title="Certificate ${c(e)} preview"
      ></iframe>
    </div>

    <div class="form-actions">
      <button type="button" id="previewOpenCertificateBtn">Open</button>
      <button type="button" id="previewPrintCertificateBtn">Print</button>
    </div>
  `;let a=t.querySelector(`iframe`);a.srcdoc=r,document.querySelector(`#previewOpenCertificateBtn`).addEventListener(`click`,()=>window.openCertificateModal(e)),document.querySelector(`#previewPrintCertificateBtn`).addEventListener(`click`,()=>{window.printCertificatePdf(e)})},window.openCertificateModal=async function(e){let t=await fetch(_e(e),{credentials:`include`}),{html:n,error:r}=await ge(t);if(!t.ok){alert(`Error loading certificate: `+r);return}let i=document.querySelector(`#certificateModal`);i&&i.remove();let a=document.createElement(`div`);a.id=`certificateModal`,a.className=`certificate-modal-overlay`,a.innerHTML=`
    <div class="certificate-modal certificate-original-layout">

      <div class="certificate-modal-header screen-only">
        <h2>Certificate ${c(e)}</h2>
        <div class="form-actions">
          <a
            id="certificatePrintBtn"
            class="cert-action-link"
            href="${g}/inspections/${encodeURIComponent(e)}/certificate.pdf?inline=1&t=${Date.now()}"
            target="_blank"
          >
            Print
          </a>
          <a
            id="certificateDownloadPdfBtn"
            class="cert-action-link"
            href="${g}/inspections/${encodeURIComponent(e)}/certificate.pdf?t=${Date.now()}"
            download="certificate-${c(e)}.pdf"
          >
            Download PDF
          </a>
          <button type="button" id="certificateMailBtn">Mail</button>
          <button type="button" id="certificateCloseBtn">Close</button>
        </div>
      </div>

      <div class="certificate-modal-body" id="certificatePrintArea">
        <iframe
          class="certificate-modal-html-frame"
          title="Certificate ${c(e)}"
        ></iframe>
      </div>
    </div>
  `,document.body.appendChild(a),a.querySelector(`iframe`).srcdoc=n,document.querySelector(`#certificateCloseBtn`).addEventListener(`click`,window.closeCertificateModal),document.querySelector(`#certificateMailBtn`).addEventListener(`click`,()=>{window.mailCertificate(e)})},window.printCertificatePdf=function(e){window.open(`${g}/inspections/${e}/certificate.pdf?inline=1&t=${Date.now()}`,`_blank`)},window.downloadCertificatePdf=async function(e){let t=await fetch(`${g}/inspections/${e}/certificate.pdf?t=${Date.now()}`);if(!t.ok){let e=await t.json().catch(()=>({error:`Unable to download certificate PDF`}));alert(`Error downloading certificate PDF: `+e.error);return}let n=await t.blob(),r=URL.createObjectURL(n),i=document.createElement(`a`);i.href=r,i.download=`certificate-${e}.pdf`,document.body.appendChild(i),i.click(),i.remove(),URL.revokeObjectURL(r)},window.mailCertificate=async function(e){let t=window.prompt(`Enter recipient email address`);if(t)try{let n=await fetch(`${g}/certificates/${e}/email`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({to:t.trim()})}),r=await n.json().catch(()=>({error:`Unable to read the email error from the server.`}));if(!n.ok){alert(r.error||`Unable to email certificate`);return}alert(`Certificate emailed successfully`)}catch(e){alert(`Unable to email certificate: ${e.message}`)}},window.deleteCertificate=async function(e){if(window.currentUser?.role!==`ADMIN`){alert(`Only admins may delete certificates.`);return}if(!window.confirm(`Delete certificate ${e}? This removes it from ATEC and cannot be undone.`))return;let t=await fetch(`${g}/certificates/${e}`,{method:`DELETE`}),n=await he(t);if(!t.ok){alert(n.error||`Unable to delete certificate ${e}.`);return}window.currentCertificateResults=(window.currentCertificateResults||[]).filter(t=>String(t.testid)!==String(e)),be(window.currentCertificateResults),ye(window.currentCertificateResults);let r=document.querySelector(`#certificatePreviewPanel`);r&&(r.innerHTML=`
      <h2>Certificate Preview</h2>
      <p>Certificate ${e} deleted.</p>
    `),alert(`Certificate ${e} deleted successfully.`)},window.closeCertificateModal=function(){let e=document.querySelector(`#certificateModal`);e&&e.remove()};function Te(e){return e?String(e).split(`T`)[0]:`-`}async function Ee(e){let t=(window.bulkCertificateResults||[]).filter(t=>e.includes(String(t.inspection?.testid)));if(!t.length){alert(`No selected certificates could be prepared for download.`);return}for(let e of t){let t=e.inspection?.testid,n=await fetch(`${g}/inspections/${t}/certificate.pdf?t=${Date.now()}`,{credentials:`include`});if(!n.ok){alert(`Unable to download certificate ${t}.`);continue}let r=await n.blob(),i=x(n.headers.get(`content-disposition`),`certificate-${t}.pdf`),a=window.URL.createObjectURL(r),o=document.createElement(`a`);o.href=a,o.download=i,o.style.display=`none`,document.body.appendChild(o),o.click(),o.remove(),window.setTimeout(()=>window.URL.revokeObjectURL(a),1e3)}}var De={filterCertificateSites:window.filterCertificateSites,filterCertificateSections:window.filterCertificateSections,filterBulkCertificateSites:window.filterBulkCertificateSites,clearCertificateSearch:window.clearCertificateSearch,searchCertificates:window.searchCertificates,rerenderCertificateResults:window.rerenderCertificateResults,goToCertificatePage:window.goToCertificatePage,setCertificateRowsPerPage:window.setCertificateRowsPerPage,previewCertificate:window.previewCertificate,openCertificateModal:window.openCertificateModal,closeCertificateModal:window.closeCertificateModal,downloadCertificatePdf:window.downloadCertificatePdf,mailCertificate:window.mailCertificate,searchBulkCertificates:window.searchBulkCertificates,printSelectedBulkCertificates:window.printSelectedBulkCertificates,downloadSelectedBulkCertificatesPdf:window.downloadSelectedBulkCertificatesPdf,downloadAllBulkCertificatesPdf:window.downloadAllBulkCertificatesPdf,toggleBulkCertificateSelection:window.toggleBulkCertificateSelection,updateBulkCertificateButtons:window.updateBulkCertificateButtons},S=null,C=1,Oe=25;function ke(e=[],t=[],n=[],r=[],i=[],a={}){let o=[...e].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``)),s=[...n].sort((e,t)=>(e.sitename||``).localeCompare(t.sitename||``)),u=[...r].sort((e,t)=>(e.sectionname||``).localeCompare(t.sectionname||``)),d=[...i].sort((e,t)=>(e.name||``).localeCompare(t.name||``)),f=[...t].sort((e,t)=>(e.description||``).localeCompare(t.description||``));if(document.querySelector(`#page`).innerHTML=`
    <div class="report-page">
      <div class="report-hero">
        <div>
          <h1>Customer Detailed Report</h1>
          <p>Review customer assets, latest inspection status and due items in one place.</p>
        </div>
      </div>

      <div class="report-toolbar">
        <div class="report-filter-control">
          <label for="customerReportClient">Customer</label>
          <select id="customerReportClient">
              <option value="">All Customers</option>
              ${o.map(e=>`
                <option value="${l(e.clientid)}">
                  ${c(e.clientname||`Customer ${e.clientid}`)}
                </option>
              `).join(``)}
            </select>
          </div>

        <div class="report-filter-control">
          <label for="customerReportSite">Site</label>
          <select id="customerReportSite">
            <option value="">All Sites</option>
            ${s.map(e=>`
              <option value="${l(e.siteid)}">
                ${c(e.sitename||`Site ${e.siteid}`)}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="report-filter-control">
          <label for="customerReportSection">Section</label>
          <select id="customerReportSection">
            <option value="">All Sections</option>
            ${u.map(e=>`
              <option value="${l(e.sectionid)}">
                ${c(e.sectionname||`Section ${e.sectionid}`)}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="report-filter-control">
          <label for="customerReportResponsible">Responsible Person</label>
          <select id="customerReportResponsible">
            <option value="">All Responsible Persons</option>
            ${d.map(e=>`
              <option value="${l(e.personid)}">
                ${c(e.name||`Person ${e.personid}`)}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="report-filter-control">
          <label for="customerReportEquipment">Equipment Type</label>
          <select id="customerReportEquipment">
            <option value="">All Equipment Types</option>
            ${f.map(e=>`
              <option value="${l(e.equiptypeid)}">
                ${c(e.description||`Equipment ${e.equiptypeid}`)}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="report-filter-control">
          <label for="customerReportDateFrom">Inspection Date From</label>
          <input id="customerReportDateFrom" type="date">
        </div>

        <div class="report-filter-control">
          <label for="customerReportDateTo">Inspection Date To</label>
          <input id="customerReportDateTo" type="date">
        </div>

        <div class="report-toolbar-actions">
            <button id="customerReportPreviewBtn" type="button">
              Preview Report
            </button>

            <a
              id="customerReportPdfLink"
              class="cert-action-link"
              href="${g}/reports/customer-detailed.pdf"
              download
            >
              Download PDF
            </a>

            <a
              id="customerReportExcelLink"
              class="cert-action-link"
              href="${g}/reports/customer-detailed.xlsx"
              download
            >
              Export Excel
            </a>
          </div>
        </div>

      <div id="customerReportPreview" class="report-preview-empty">
        <h2>No report preview yet</h2>
        <p>Select a customer or leave it on All Customers, then preview the report.</p>
      </div>
    </div>
  `,Ae(),a?.clientid){let e=document.querySelector(`#customerReportClient`);e&&(e.value=String(a.clientid))}w(),a?.autoLoad&&T()}function Ae(){document.querySelectorAll(`#customerReportClient, #customerReportSite, #customerReportSection, #customerReportResponsible, #customerReportEquipment, #customerReportDateFrom, #customerReportDateTo`).forEach(e=>{e.addEventListener(`change`,()=>{C=1,w()})}),document.querySelector(`#customerReportPreviewBtn`)?.addEventListener(`click`,()=>{C=1,T()})}function w(){let e=E(),t=document.querySelector(`#customerReportPdfLink`),n=document.querySelector(`#customerReportExcelLink`);t&&(t.href=`${g}/reports/customer-detailed.pdf${e}`),n&&(n.href=`${g}/reports/customer-detailed.xlsx${e}`)}async function T(){w();let e=E({includePagination:!0}),t=document.querySelector(`#customerReportPreview`);t.className=`report-preview-empty`,t.innerHTML=`<div class="report-preview-empty">Loading report...</div>`;let n=await fetch(`${g}/reports/customer-detailed${e}`),r=await n.json();if(!n.ok){t.innerHTML=`
      <div class="report-preview-empty">
        Error loading report: ${c(r.error||`Unknown error`)}
      </div>
    `;return}S=null,t.className=`report-preview-loaded`,S=r,Me()}window.updateCustomerReportLinks=w,window.loadCustomerDetailedReport=T;function E(t={}){let n=new URLSearchParams,r=document.querySelector(`#customerReportClient`)?.value||``,i=document.querySelector(`#customerReportSite`)?.value||``,a=document.querySelector(`#customerReportSection`)?.value||``,o=document.querySelector(`#customerReportResponsible`)?.value||``,s=document.querySelector(`#customerReportEquipment`)?.value||``,c=document.querySelector(`#customerReportDateFrom`)?.value||``,l=document.querySelector(`#customerReportDateTo`)?.value||``;if(r&&n.append(`clientid`,r),i&&n.append(`siteid`,i),a&&n.append(`sectionid`,a),o&&n.append(`responsibleid`,o),s&&n.append(`equiptypeid`,s),c&&n.append(`datefrom`,c),l&&n.append(`dateto`,l),t.includePagination){let t=e(`customerReport`,`latestinspectiondate`,`desc`);n.append(`page`,String(C||1)),n.append(`limit`,String(Oe||25)),n.append(`sortKey`,t.key||`latestinspectiondate`),n.append(`sortDir`,t.direction||`desc`)}let u=n.toString();return u?`?${u}`:``}function je(e){let t=e.customers.length===1?c(e.customers[0].clientname):`All Customers`,r=Ie(),i=e.pagination||{page:C,limit:r,total:e.assets.length,totalPages:Math.max(1,Math.ceil(e.assets.length/r))},a=Math.max(1,Number(i.totalPages||1)),o=Math.min(Number(i.page||C||1),a),s=Number(i.total||e.assets.length),l=(o-1)*Number(i.limit||r),u=e.assets||[],d=s===0?0:l+u.length;return`
    <div class="report-summary-card">
      <div class="report-summary-heading">
        <div>
          <h2>${t}</h2>
          <p>Generated ${Be(e.generatedAt)}</p>
        </div>

        <div class="report-count-note">
          ${s} assets in report
        </div>
      </div>

      <div class="report-summary-grid">
        ${D(`Customers`,e.summary.customers)}
        ${D(`Assets`,e.summary.assets)}
        ${D(`Active Assets`,e.summary.activeAssets)}
        ${D(`OK`,e.summary.safeAssets)}
        ${D(`Not Safe`,e.summary.notSafeAssets)}
        ${D(`Visual Overdue`,e.summary.visualOverdueAssets)}
        ${D(`Load Overdue`,e.summary.loadOverdueAssets)}
        ${D(`No Visual`,e.summary.noVisualAssets)}
        ${D(`No Load Test`,e.summary.noLoadAssets)}
      </div>
    </div>

    <div class="report-detail-card">
      <div class="report-detail-heading">
        <div>
          <h2>Asset Detail Preview</h2>
          <p>Showing ${s===0?0:l+1} to ${d} of ${s} assets. Use PDF or Excel for the full detailed report.</p>
        </div>
      </div>

      <div class="report-pagination-bar">
        <div class="report-page-size">
          <label for="reportRowsPerPage">Rows per page</label>
          <select id="reportRowsPerPage">
            ${[25,50,100,250].map(e=>`
              <option value="${e}" ${e===r?`selected`:``}>
                ${e}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="report-page-controls">
          <button id="reportPrevPageBtn" type="button" ${o<=1?`disabled`:``}>
            Previous
          </button>
          ${Fe(o,a)}
          <button id="reportNextPageBtn" type="button" ${o>=a?`disabled`:``}>
            Next
          </button>
          <span>Page ${o} of ${a}</span>
        </div>
      </div>

      <div class="report-scroll-control">
        <span>Left</span>
        <input id="reportTableSlider" type="range" min="0" max="0" value="0" step="1">
        <span>Right</span>
      </div>

      <div class="report-table-wrap">
        <table class="report-table">
          <thead>
            <tr>
              <th>${n(`Customer`,`customerReport`,`clientname`,`rerenderCustomerReport`)}</th>
              <th>${n(`Asset ID`,`customerReport`,`assetid`,`rerenderCustomerReport`)}</th>
              <th>${n(`Asset Tag`,`customerReport`,`assettagno`,`rerenderCustomerReport`)}</th>
              <th>${n(`Serial No`,`customerReport`,`serialno`,`rerenderCustomerReport`)}</th>
              <th>${n(`Site`,`customerReport`,`sitename`,`rerenderCustomerReport`)}</th>
              <th>${n(`Section`,`customerReport`,`sectionname`,`rerenderCustomerReport`)}</th>
              <th>${n(`Responsible Person`,`customerReport`,`responsiblename`,`rerenderCustomerReport`)}</th>
              <th>${n(`Equipment Type`,`customerReport`,`equipmenttype`,`rerenderCustomerReport`)}</th>
              <th>${n(`Description`,`customerReport`,`description`,`rerenderCustomerReport`)}</th>
              <th>${n(`Latest Inspection`,`customerReport`,`latestinspectiondate`,`rerenderCustomerReport`)}</th>
              <th>${n(`Last Visual`,`customerReport`,`visualtestdate`,`rerenderCustomerReport`)}</th>
              <th>${n(`Visual Status`,`customerReport`,`visualstatus`,`rerenderCustomerReport`)}</th>
              <th>${n(`Last Load`,`customerReport`,`loadtestdate`,`rerenderCustomerReport`)}</th>
              <th>${n(`Load Status`,`customerReport`,`loadstatus`,`rerenderCustomerReport`)}</th>
              <th>${n(`Report Status`,`customerReport`,`reportstatus`,`rerenderCustomerReport`)}</th>
            </tr>
          </thead>
          <tbody>
            ${u.map(e=>`
              <tr>
                <td>${c(e.clientname||`-`)}</td>
                <td>${c(e.assetid||`-`)}</td>
                <td>${c(e.assettagno||`-`)}</td>
                <td>${c(e.serialno||`-`)}</td>
                <td>${c(e.sitename||`-`)}</td>
                <td>${c(e.sectionname||`-`)}</td>
                <td>${c(e.responsiblename||`-`)}</td>
                <td>${c(e.equipmenttype||`-`)}</td>
                <td>${c(e.description||`-`)}</td>
                <td>${Be(e.latestinspectiondate)}</td>
                <td>${Be(e.visualtestdate)}</td>
                <td class="${Re(e.visualstatus)}">${c(e.visualstatus||`-`)}</td>
                <td>${Be(e.loadtestdate)}</td>
                <td class="${Re(e.loadstatus)}">${c(e.loadstatus||`-`)}</td>
                <td>
                  <span class="report-status-pill ${ze(e.reportstatus)}">
                    ${c(e.reportstatus||`-`)}
                  </span>
                </td>
              </tr>
            `).join(``)||`
              <tr>
                <td colspan="15">No assets found for this report.</td>
              </tr>
            `}
          </tbody>
        </table>
      </div>
    </div>
  `}function Me(){let e=document.querySelector(`#customerReportPreview`);!e||!S||(e.innerHTML=je(S),Ne(),Le())}function Ne(){document.querySelector(`#reportRowsPerPage`)?.addEventListener(`change`,e=>{Oe=Number(e.target.value)||25,C=1,T()}),document.querySelector(`#reportPrevPageBtn`)?.addEventListener(`click`,()=>{C=Math.max(1,C-1),T()}),document.querySelector(`#reportNextPageBtn`)?.addEventListener(`click`,()=>{let e=S?.pagination?.totalPages||1;C=Math.min(e,C+1),T()})}function Pe(e,t){let n=[];if(t<=10){for(let e=1;e<=t;e+=1)n.push(e);return n}let r=Math.max(1,e-4),i=Math.min(t,r+9-1);i-r+1<9&&(r=Math.max(1,i-9+1)),r>1&&(n.push(1),r>2&&n.push(`...`));for(let e=r;e<=i;e+=1)n.push(e);return i<t&&(i<t-1&&n.push(`...`),n.push(t)),n}function Fe(e,t){return Pe(e,t).map(t=>t===`...`?`<span class="pagination-ellipsis">...</span>`:`
      <button
        type="button"
        class="pagination-page-btn ${t===e?`active`:``}"
        onclick="goToCustomerReportPage(${t})"
        ${t===e?`disabled`:``}
      >
        ${t}
      </button>
    `).join(``)}window.goToCustomerReportPage=function(e){C=Math.max(1,Number(e)||1),T()},window.rerenderCustomerReport=function(){C=1,T()};function Ie(){return Oe||25}function Le(){let e=document.querySelector(`#reportTableSlider`),t=document.querySelector(`.report-table-wrap`);if(!e||!t)return;let n=()=>{let n=Math.max(0,t.scrollWidth-t.clientWidth);e.max=String(n),e.value=String(Math.min(t.scrollLeft,n)),e.disabled=n===0};n(),e.addEventListener(`input`,()=>{t.scrollLeft=Number(e.value)}),t.addEventListener(`scroll`,()=>{e.value=String(t.scrollLeft)}),window.addEventListener(`resize`,n,{once:!0})}function D(e,t){return`
    <div class="report-summary-tile">
      <span>${e}</span>
      <strong>${t??0}</strong>
    </div>
  `}function Re(e){return e===`SAFE`||e===`OK`?`status-safe`:e===`NOT SAFE`?`status-unsafe`:``}function ze(e){return e===`OK`?`is-ok`:e===`NOT SAFE`?`is-danger`:(e||``).includes(`OVERDUE`)?`is-warning`:(e||``).includes(`NO `)?`is-muted`:``}function Be(e){return e?String(e).split(`T`)[0]:`-`}function Ve(){return new Date().toISOString().split(`T`)[0]}function O(e=``){return[1,2,3,4,5].map(t=>`
    <option value="${t}" ${String(e)===String(t)?`selected`:``}>
      ${t}
    </option>
  `).join(``)}function He(e=`OPEN`){return[`OPEN`,`IN_PROGRESS`,`CLOSED`].map(t=>`
    <option value="${t}" ${t===e?`selected`:``}>
      ${t.replaceAll(`_`,` `)}
    </option>
  `).join(``)}var Ue=[`Machine Mobile`,`Electrical`,`Object / Pressure`,`Machine Fixed`,`Thermal Stress`,`Slip / Trip / Strain`,`Chemical`,`Noise`],We=[[`routine_task`,`Is this a routine task, done daily or weekly?`],[`team_fit`,`Is the team physically and mentally fit to safely execute the task?`],[`authorized`,`Does the team have the necessary authorization, area access or permit to do the task?`],[`tools_ppe_safe`,`Are all tools, equipment and PPE correctly selected, inspected and safe for use?`],[`energy_locked_out`,`Have all energy sources been de-energized and locked out where required?`],[`team_competent`,`Are all team members trained, competent and properly appointed for their roles?`],[`task_planned`,`Was the task carefully planned to avoid improvisation or unsafe last-minute solutions?`],[`stop_if_risk_changes`,`Are all team members aware they must stop, regroup, replan and escalate if risk increases?`],[`standard_understood`,`Is there a standard for this task, and does the team understand it?`]],Ge=[[`task_completed_safely`,`Has the task been completed safely?`],[`team_accounted_for`,`Are all team members accounted for, safe and healthy?`],[`near_misses`,`Were near misses or incidents experienced during the task?`],[`ppe_worn`,`Did you wear the required PPE?`],[`housekeeping_done`,`Was good housekeeping practiced at the work site?`],[`reported_complete`,`Have you reported task completion to the appointed person?`],[`went_to_plan`,`Did the task go according to plan?`],[`extra_information`,`Would you like to communicate any additional information about the task?`]];function Ke(e,t=``){return`
    <option value="">General / no asset</option>
    ${e.map(e=>`
      <option value="${l(e.assetid)}" ${String(t)===String(e.assetid)?`selected`:``}>
        ${c(e.assetid)} - ${c(e.assettagno||e.serialno||e.description||`Asset`)}
      </option>
    `).join(``)}
  `}function qe(e=``){return`
    <option value="">Select</option>
    <option value="YES" ${e===`YES`?`selected`:``}>YES</option>
    <option value="NO" ${e===`NO`?`selected`:``}>NO</option>
    <option value="N/A" ${e===`N/A`?`selected`:``}>N/A</option>
  `}function Je(e,t){return e.map(([e,n])=>`
    <div class="slamm-question-row">
      <span>${n}</span>
      <select class="${t}" data-key="${e}">
        ${qe(``)}
      </select>
    </div>
  `).join(``)}function k(){return Array.from({length:6},(e,t)=>`
    <div class="slamm-team-row" data-index="${t}">
      <span>${t+1}</span>
      <input class="slamm-team-name" type="text" placeholder="Name">
      <input class="slamm-team-surname" type="text" placeholder="Surname">
      <input class="slamm-team-signature" type="text" placeholder="Signature / initials">
    </div>
  `).join(``)}function Ye(e){return e?String(e).split(`T`)[0]:`-`}function Xe(e){let t=Number(e||0);return t>=15?`danger`:t>=8?`warning`:`success`}async function Ze(e=[],t=!0){let n=document.querySelector(`#page`);n.innerHTML=`
    <h1>Risk Assessment / SHE</h1>
    <p>SLAMM - Stop, Look, Assess, Manage and Monitor before and after the task.</p>

    ${t?`<div class="filter-card">
      <h2>New SLAMM Risk Assessment</h2>
      <input type="hidden" id="riskId" value="">

      <div class="risk-form-grid risk-form-grid--top">
        <div class="form-group">
          <label>Asset</label>
          <select id="riskAssetId">${Ke(e)}</select>
        </div>

        <div class="form-group">
          <label>Assessment Date</label>
          <input id="riskAssessmentDate" type="date" value="${Ve()}">
        </div>

        <div class="form-group">
          <label>Assessment Time</label>
          <input id="riskAssessmentTime" type="time">
        </div>

        <div class="form-group">
          <label>Status</label>
          <select id="riskStatus">${He()}</select>
        </div>

        <div class="form-group risk-span-2">
          <label>Task Description</label>
          <input id="riskActivity" type="text">
        </div>

        <div class="form-group">
          <label>Responsible Person</label>
          <input id="riskResponsiblePerson" type="text">
        </div>
      </div>

      <div class="slamm-section">
        <h3>STOP and LOOK - Hazard Types</h3>
        <div class="slamm-check-grid">
          ${Ue.map(e=>`
            <label class="slamm-check">
              <input type="checkbox" class="risk-hazard-category" value="${e}">
              <span>${e}</span>
            </label>
          `).join(``)}
        </div>
      </div>

      <div class="slamm-section">
        <h3>STOP Questions</h3>
        <p>If any answer is NO, stop and apply the required controls or escalate before continuing.</p>
        <div class="slamm-question-grid">
          ${Je(We,`slamm-stop-question`)}
        </div>
      </div>

      <div class="risk-assessment-flow">
        <div class="form-group risk-full">
          <label>LOOK / ASSESS - Hazards and Risks</label>
          <textarea id="riskHazard" rows="2"></textarea>
        </div>

        <div class="form-group risk-full">
          <label>Consequence</label>
          <textarea id="riskConsequence" rows="2"></textarea>
        </div>

        <div class="risk-score-grid">
          <div class="form-group">
            <label>Initial Severity</label>
            <select id="riskInitialSeverity">${O(3)}</select>
          </div>

          <div class="form-group">
            <label>Initial Likelihood</label>
            <select id="riskInitialLikelihood">${O(3)}</select>
          </div>

          <div class="form-group">
            <label>Residual Severity</label>
            <select id="riskResidualSeverity">${O(2)}</select>
          </div>

          <div class="form-group">
            <label>Residual Likelihood</label>
            <select id="riskResidualLikelihood">${O(2)}</select>
          </div>
        </div>

        <div class="form-group risk-full">
          <label>Controls to Manage the Hazards and Risks</label>
          <textarea id="riskControls" rows="2"></textarea>
        </div>

        <div class="form-group risk-full">
          <label>MANAGE - Actions Required</label>
          <textarea id="riskActionRequired" rows="2"></textarea>
        </div>

        <div class="form-group risk-full">
          <label>Manage Plan</label>
          <textarea id="riskManagePlan" rows="2"></textarea>
        </div>

        <div class="form-group risk-full">
          <label>MONITOR - New Hazards / Changes During Task</label>
          <textarea id="riskMonitorNotes" rows="2"></textarea>
        </div>

        <div class="risk-due-row">
          <div class="form-group risk-due-field">
            <label>Due Date</label>
            <input id="riskDueDate" type="date">
          </div>
        </div>
      </div>

      <div class="slamm-section">
        <h3>After Task Review</h3>
        <div class="slamm-question-grid">
          ${Je(Ge,`slamm-review-question`)}
        </div>
        <div class="form-group">
          <label>Additional Comments / Recommendations</label>
          <textarea id="riskAdditionalNotes" rows="3"></textarea>
        </div>
      </div>

      <div class="slamm-section">
        <h3>Team Members Involved in the SLAMM Process</h3>
        <div class="slamm-team-grid">
          ${k()}
        </div>
      </div>

      <div class="asset-form-grid">
        <div class="form-group">
          <label>After Task Sign-off by Responsible Person</label>
          <input id="riskResponsibleSignoffName" type="text" placeholder="Name and surname">
        </div>

        <div class="form-group">
          <label>After Task Sign-off by Supervisor</label>
          <input id="riskSupervisorSignoffName" type="text" placeholder="Name and surname">
        </div>
      </div>

      <div class="form-actions">
        <button onclick="saveRiskAssessment()">Save Risk Assessment</button>
        <button type="button" class="secondary-button" onclick="showRiskAssessments()">Clear Form</button>
      </div>
    </div>`:``}

    <div class="filter-card">
      <div class="form-row">
        <div class="form-group">
          <label>Search</label>
          <input id="riskSearch" type="text" placeholder="Asset, activity, hazard, status..." onkeyup="filterRiskAssessments()">
        </div>

        <div class="form-group">
          <label>Status</label>
          <select id="riskStatusFilter" onchange="filterRiskAssessments()">
            <option value="">All</option>
            ${He(``)}
          </select>
        </div>
      </div>

      <div class="form-actions">
        <button type="button" onclick="downloadRiskAssessments('pdf')">
          Download PDF
        </button>
        <button type="button" onclick="downloadRiskAssessments('xlsx')">
          Export Excel
        </button>
      </div>
    </div>

    <div id="riskAssessmentTable"></div>
  `,await window.loadRiskAssessments()}function Qe(e=[],r=!0){let i=document.querySelector(`#riskAssessmentTable`),a=document.querySelector(`#riskSearch`)?.value.toLowerCase().trim()||``,o=document.querySelector(`#riskStatusFilter`)?.value||``,s=t(e.filter(e=>{let t=!o||e.status===o,n=[e.riskid,e.assettagno,e.serialno,e.asset_description,e.clientname,e.sitename,e.activity,e.hazard,e.hazard_categories,e.status].join(` `).toLowerCase();return t&&n.includes(a)}),`riskAssessments`,{riskid:e=>e.riskid,assessment_date:e=>e.assessment_date,assettagno:e=>e.assettagno,activity:e=>e.activity,initial_rating:e=>e.initial_rating,residual_rating:e=>e.residual_rating,responsible_person:e=>e.responsible_person,status:e=>e.status,due_date:e=>e.due_date},`assessment_date`);i.innerHTML=`
    <table>
      <thead>
        <tr>
          <th>${n(`ID`,`riskAssessments`,`riskid`,`filterRiskAssessments`)}</th>
          <th>${n(`Date`,`riskAssessments`,`assessment_date`,`filterRiskAssessments`)}</th>
          <th>${n(`Asset`,`riskAssessments`,`assettagno`,`filterRiskAssessments`)}</th>
          <th>${n(`Activity`,`riskAssessments`,`activity`,`filterRiskAssessments`)}</th>
          <th>Hazard</th>
          <th>Hazard Types</th>
          <th>${n(`Initial Risk`,`riskAssessments`,`initial_rating`,`filterRiskAssessments`)}</th>
          <th>${n(`Residual Risk`,`riskAssessments`,`residual_rating`,`filterRiskAssessments`)}</th>
          <th>${n(`Responsible`,`riskAssessments`,`responsible_person`,`filterRiskAssessments`)}</th>
          <th>${n(`Status`,`riskAssessments`,`status`,`filterRiskAssessments`)}</th>
          <th>${n(`Due`,`riskAssessments`,`due_date`,`filterRiskAssessments`)}</th>
          ${r?`<th>Action</th>`:``}
        </tr>
      </thead>
      <tbody>
        ${s.length?s.map(e=>`
          <tr>
            <td>${c(e.riskid)}</td>
            <td>${Ye(e.assessment_date)}</td>
            <td>
              <strong>${c(e.assettagno||e.assetid||`-`)}</strong><br>
              <small>${c(e.asset_description||e.serialno||``)}</small>
            </td>
            <td>${c(e.activity||``)}</td>
            <td>${c(e.hazard||``)}</td>
            <td>${c(Array.isArray(e.hazard_categories)?e.hazard_categories.join(`, `):``)}</td>
            <td><span class="status-badge ${Xe(e.initial_rating)}">${c(e.initial_rating||`-`)}</span></td>
            <td><span class="status-badge ${Xe(e.residual_rating)}">${c(e.residual_rating||`-`)}</span></td>
            <td>${c(e.responsible_person||``)}</td>
            <td>${c(e.status||``)}</td>
            <td>${Ye(e.due_date)}</td>
            ${r?`<td>
              <div class="action-buttons">
                <button onclick="editRiskAssessment(${e.riskid})">Edit</button>
                <button onclick="archiveRiskAssessment(${e.riskid})">Archive</button>
              </div>
            </td>`:``}
          </tr>
        `).join(``):`
          <tr>
            <td colspan="${r?`12`:`11`}" class="empty-row">No risk assessments found</td>
          </tr>
        `}
      </tbody>
    </table>
  `}var A=`unavailable`,$e=`unavailable`,et=6e4;function j(){return localStorage.getItem(`currentPage`)===`system-health`}function M(){window.systemHealthRefreshTimer&&(clearInterval(window.systemHealthRefreshTimer),window.systemHealthRefreshTimer=null)}function N(e){let t=Number(e);if(!Number.isFinite(t))return`Unknown`;let n=[`B`,`KB`,`MB`,`GB`,`TB`],r=Math.max(0,t),i=0;for(;r>=1024&&i<n.length-1;)r/=1024,i+=1;return`${r.toFixed(i===0?0:1)} ${n[i]}`}function tt(e){let t=Number(e);if(!Number.isFinite(t))return`Unknown`;let n=Math.floor(t/86400),r=Math.floor(t%86400/3600),i=Math.floor(t%3600/60);return n?`${n}d ${r}h`:r?`${r}h ${i}m`:`${i}m`}function P(e){if(!e||e===`unavailable`)return`Unavailable`;let t=new Date(e);return Number.isNaN(t.getTime())?`Unavailable`:t.toLocaleString()}function nt(e=``){let t=String(e).toLowerCase();return/healthy|connected|current/.test(t)?`health-good`:/critical|failed|offline|overdue|mismatch/.test(t)?`health-bad`:`health-warning`}function F(e,t){return`<span class="health-badge ${nt(t)}">${c(e||t||`Unknown`)}</span>`}function I(e,t){return`
    <div class="health-info-row">
      <span>${c(e)}</span>
      <strong>${c(t??`Unknown`)}</strong>
    </div>
  `}function rt(e){return e?`
    ${I(`Latest file`,e.filename)}
    ${I(`Modified`,P(e.modifiedAt))}
    ${I(`Size`,N(e.sizeBytes))}
    ${e.ageHours===void 0?``:I(`Age`,`${e.ageHours} hours`)}
  `:I(`Latest file`,`No file found`)}function it(e={}){return`
    ${I(`Latest backup set`,e.latestBackupSetId||`Unavailable`)}
    ${I(`Database backup timestamp`,P(e.latestSuccessfulDatabaseBackupAt))}
    ${I(`Media backup timestamp`,P(e.latestSuccessfulMediaBackupAt))}
    ${I(`Backup age`,e.backupAgeHours===null||e.backupAgeHours===void 0?`Unknown`:`${e.backupAgeHours} hours`)}
    ${I(`Validation`,`${e.validation?.status||`not-run`}${e.validation?.timestamp?` at ${P(e.validation.timestamp)}`:``}`)}
    ${I(`Restore verification`,`${e.restoreVerification?.status||`not-run`}${e.restoreVerification?.timestamp?` at ${P(e.restoreVerification.timestamp)}`:``}`)}
    ${I(`Checksum`,e.checksumStatus||`not-run`)}
    ${I(`Last job duration`,e.lastBackupDurationMs?tt(Number(e.lastBackupDurationMs)/1e3):`Unknown`)}
    ${I(`Retention`,`${e.retention?.status||`not-run`}${e.retention?.timestamp?` at ${P(e.retention.timestamp)}`:``}`)}
    ${I(`Next scheduled backup`,P(e.nextScheduledBackup))}
    ${e.lastFailure?I(`Last failure`,e.lastFailure):``}
  `}function at(e){return`
    <div class="system-health-page">
      <div class="section-header system-health-header">
        <div>
          <h1>System Health</h1>
          <p>Last refreshed ${c(P(e.checkedAt))}</p>
        </div>
        <button type="button" onclick="refreshSystemHealth()">Refresh</button>
      </div>

      <div class="health-status-grid">
        <div class="health-status-card">
          <span>Backend</span>
          ${F(e.overallStatus,e.overallStatus)}
        </div>
        <div class="health-status-card">
          <span>Database</span>
          ${F(e.database.status,e.database.status)}
        </div>
        <div class="health-status-card">
          <span>Backup</span>
          ${F(e.backup.status,e.backup.status)}
        </div>
        <div class="health-status-card">
          <span>Disk</span>
          ${F(e.disk.status,e.disk.status)}
        </div>
        <div class="health-status-card">
          <span>Memory</span>
          ${F(e.server.systemMemory.status,e.server.systemMemory.status)}
        </div>
        <div class="health-status-card">
          <span>Deployment</span>
          ${F(e.deployment.status,e.deployment.status)}
        </div>
      </div>

      <div class="health-section-grid">
        <section class="dashboard-section">
          <div class="section-header"><h2>Deployment Information</h2></div>
          ${I(`Running commit`,e.deployment.runningGitCommit)}
          ${I(`Latest local commit`,e.deployment.latestLocalGitCommit)}
          ${I(`Git branch`,e.deployment.gitBranch)}
          ${I(`Working tree`,e.deployment.workingTreeClean===null?`Unverified`:e.deployment.workingTreeClean?`Clean`:`Local changes present`)}
          ${I(`Frontend build ID`,A)}
          ${I(`Frontend build timestamp`,$e)}
          ${I(`Backend build ID`,e.deployment.backendBuildIdentifier)}
          ${I(`Frontend/backend match`,`Unverified`)}
        </section>

        <section class="dashboard-section">
          <div class="section-header"><h2>Application</h2></div>
          ${I(`Application`,e.application.name)}
          ${I(`Version`,e.application.version)}
          ${I(`Environment`,e.application.environment)}
          ${I(`Node.js`,e.application.nodeVersion)}
          ${I(`Backend started`,P(e.application.backendStartTime))}
          ${I(`Backend uptime`,tt(e.application.backendUptimeSeconds))}
          ${I(`Build/deployment date`,P(e.application.buildOrDeploymentDate))}
        </section>

        <section class="dashboard-section">
          <div class="section-header"><h2>Database</h2></div>
          ${I(`Status`,e.database.status)}
          ${I(`Database`,e.database.databaseName)}
          ${I(`Schema`,e.database.schemaName)}
          ${I(`Response time`,e.database.responseTimeMs===null?`Unavailable`:`${e.database.responseTimeMs} ms`)}
          ${I(`Pool max`,e.database.pool.max??`Unknown`)}
          ${I(`Pool total`,e.database.pool.total)}
          ${I(`Pool idle`,e.database.pool.idle)}
          ${I(`Pool waiting`,e.database.pool.waiting)}
          ${I(`PostgreSQL`,e.database.postgresVersion)}
        </section>

        <section class="dashboard-section">
          <div class="section-header"><h2>Server Resources</h2></div>
          ${I(`Platform`,e.server.platform)}
          ${I(`Hostname`,e.server.hostname)}
          ${I(`Process ID`,e.server.processId)}
          ${I(`Configured port`,e.server.configuredPort)}
          ${I(`Process memory`,N(e.server.processMemory.rss))}
          ${I(`System free memory`,N(e.server.systemMemory.freeBytes))}
          ${I(`System memory used`,`${e.server.systemMemory.usedPercent}%`)}
          ${I(`System uptime`,tt(e.server.systemUptimeSeconds))}
          ${I(`CPU load`,e.server.cpuLoadAverage.map(e=>Number(e).toFixed(2)).join(` / `))}
        </section>

        <section class="dashboard-section">
          <div class="section-header"><h2>Performance</h2></div>
          ${I(`Slow threshold`,e.performance?.slowRequestThresholdMs?`${e.performance.slowRequestThresholdMs} ms`:`Unknown`)}
          ${I(`Recent requests`,e.performance?.recentRequestCount??0)}
          ${I(`Recent slow requests`,e.performance?.recentSlowRequestCount??0)}
          ${I(`Recent average`,`${e.performance?.recentAverageMs??0} ms`)}
          ${I(`Recent max`,`${e.performance?.recentMaxMs??0} ms`)}
          ${e.performance?.lastSlowRequest?I(`Last slow request`,`${e.performance.lastSlowRequest.method} ${e.performance.lastSlowRequest.route} - ${e.performance.lastSlowRequest.elapsedMs} ms`):I(`Last slow request`,`None`)}
        </section>

        <section class="dashboard-section">
          <div class="section-header"><h2>PDF Queue</h2></div>
          ${I(`Concurrency`,e.pdf?.concurrency??`Unknown`)}
          ${I(`Max bulk certificates`,e.pdf?.maxBulkCertificates??`Unknown`)}
          ${I(`Active`,e.pdf?.active??0)}
          ${I(`Queued`,e.pdf?.queued??0)}
          ${I(`Completed`,e.pdf?.completed??0)}
          ${I(`Failed`,e.pdf?.failed??0)}
        </section>

        <section class="dashboard-section">
          <div class="section-header"><h2>Disk Usage</h2></div>
          ${I(`Status`,e.disk.status)}
          ${I(`Filesystem`,e.disk.checkedPathLabel)}
          ${I(`Used`,N(e.disk.usedBytes))}
          ${I(`Available`,N(e.disk.availableBytes))}
          ${I(`Used percent`,e.disk.usedPercent===null?`Unknown`:`${e.disk.usedPercent}%`)}
          ${I(`Warning threshold`,`${e.thresholds.diskWarningPercent}%`)}
          ${I(`Critical threshold`,`${e.thresholds.diskCriticalPercent}%`)}
        </section>

        <section class="dashboard-section">
          <div class="section-header"><h2>Backup Status</h2></div>
          ${I(`Status`,e.backup.status)}
          ${I(`Directory`,e.backup.accessible?`Accessible`:`Not accessible`)}
          ${I(`Maximum expected age`,`${e.thresholds.backupMaxAgeHours} hours`)}
          ${I(`Message`,e.backup.message)}
          ${it(e.backup)}
          <h3>Database Backup</h3>
          ${rt(e.backup.latestDatabaseBackup)}
          <h3>Uploads Backup</h3>
          ${rt(e.backup.latestUploadsBackup)}
        </section>
      </div>
    </div>
  `}async function ot(){if(!j()){M();return}let e=document.querySelector(`#page`);if(e){e.innerHTML=`
    <h1>System Health</h1>
    <div class="filter-card">Loading system health...</div>
  `;try{let t=await fetch(`${g}/admin/system-info`),n=await t.json().catch(()=>({}));if(!t.ok){if(!j()){M();return}e.innerHTML=`
        <h1>System Health</h1>
        <div class="filter-card">
          ${c(n.error||`Unable to load system health.`)}
        </div>
      `;return}if(!j()){M();return}e.innerHTML=at(n)}catch{if(!j()){M();return}e.innerHTML=`
      <h1>System Health</h1>
      <div class="filter-card">Unable to reach the system health endpoint.</div>
    `}}}function st(){M(),ot(),window.systemHealthRefreshTimer=setInterval(ot,et)}window.refreshSystemHealth=ot,window.location.pathname.toLowerCase().startsWith(`/atec/atec`)&&window.history.replaceState({},``,`/atec/`);var ct=window.fetch.bind(window);window.fetch=function(e,t={}){let n=(typeof e==`string`?e:e?.url||``).startsWith(g);return ct(e,{...t,credentials:n?`include`:t.credentials})};async function L(e){let t=await e.text();if(!t)return{};try{return JSON.parse(t)}catch{return{error:e.ok?`The server returned an unexpected response`:`The server returned an unexpected error. Please try again.`}}}var R=null,z=[],B=[],V=[],H=[],U=[],W=[],lt={},G=[],ut=null,dt={dashboard:[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`],customers:[`ADMIN`,`MANAGER`,`INSPECTOR`],sites:[`ADMIN`,`MANAGER`,`INSPECTOR`],responsible:[`ADMIN`,`MANAGER`,`INSPECTOR`],sections:[`ADMIN`,`MANAGER`,`INSPECTOR`],assets:[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`],inspections:[`ADMIN`,`MANAGER`,`INSPECTOR`],"quick-inspection":[`ADMIN`,`MANAGER`,`INSPECTOR`],certificates:[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`,`CUSTOMER`],"customer-report":[`ADMIN`,`MANAGER`,`VIEWER`,`CUSTOMER`],she:[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`],criteria:[`ADMIN`],users:[`ADMIN`],"system-health":[`ADMIN`],profile:[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`,`CUSTOMER`]};function ft(e){return R?.role===`ADMIN`||(dt[e]||[]).includes(R?.role)}function pt(){document.querySelector(`#page`).innerHTML=`
    <div class="filter-card">
      <h2>Access denied</h2>
      <p>You do not have permission to view this page.</p>
    </div>
  `}function K(e){return ft(e)?!0:(pt(),!1)}function q(e,t,n){return ft(e)?`<button onclick="closeMobileMenu(); ${n}">${t}</button>`:``}function mt(){return[`ADMIN`,`MANAGER`,`INSPECTOR`].includes(R?.role)}function J(){return R?.role===`ADMIN`}function Y(){return R?.role===`ADMIN`}function ht(){return[`ADMIN`,`MANAGER`,`INSPECTOR`].includes(R?.role)}function gt(e=``){document.querySelector(`#app`).innerHTML=`
    <div class="login-page">
      <div class="login-card">
        <img src="${pe(`logo.jpg`)}" alt="ATEC Logo" class="login-logo">
        <h1>ATEC Login</h1>
        ${e?`<p class="login-error">${e}</p>`:``}
        <label>Username or Email</label>
        <input id="loginUsername" type="text" autocomplete="username">
        <label>Password</label>
        <input id="loginPassword" type="password" autocomplete="current-password">
        <button onclick="loginUser()">Login</button>
      </div>
    </div>
  `}window.loginUser=async function(){let e=document.querySelector(`#loginUsername`)?.value||``,t=document.querySelector(`#loginPassword`)?.value||``,n=await fetch(`${g}/auth/login`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({username:e,password:t})}),r=await n.json();if(!n.ok){gt(r.error||`Login failed`);return}R=r.user,window.currentUser=R,localStorage.setItem(`currentPage`,R.role===`CUSTOMER`?`certificates`:`dashboard`),await $()},window.logoutUser=async function(){await fetch(`${g}/auth/logout`,{method:`POST`}),R=null,window.currentUser=null,localStorage.removeItem(`currentPage`),gt()};var _t={username:e=>e.username,email:e=>e.email,full_name:e=>e.full_name,role:e=>e.role,lmi_number:e=>e.lmi_number,clientid:e=>yt(e.clientid),siteid:e=>bt(e.siteid),sectionid:e=>xt(e.sectionid),is_active:e=>+!!e.is_active,signature_image:e=>+!!e.signature_image};function vt(){return window.userManagementLookups||{customers:[],sites:[],sections:[]}}function yt(e){return vt().customers.find(t=>String(t.clientid)===String(e||``))?.clientname||``}function bt(e){return vt().sites.find(t=>String(t.siteid)===String(e||``))?.sitename||``}function xt(e){return vt().sections.find(t=>String(t.sectionid)===String(e||``))?.sectionname||``}function X(e,t,n,r,i){return`
    <option value="">${c(i)}</option>
    ${e.map(e=>`
      <option value="${l(e[t])}" ${String(e[t])===String(r||``)?`selected`:``}>
        ${c(e[n]||`${i} ${e[t]}`)}
      </option>
    `).join(``)}
  `}function St(){return window.userManagementSort=window.userManagementSort||{key:`username`,direction:`asc`},window.userManagementSort}function Ct(e){let t=St(),n=_t[t.key]||_t.username,r=t.direction===`desc`?-1:1;return[...e].sort((e,t)=>{let i=n(e),a=n(t),o=Number(i),s=Number(a);return i!==``&&a!==``&&!Number.isNaN(o)&&!Number.isNaN(s)?(o-s)*r:String(i||``).localeCompare(String(a||``),void 0,{numeric:!0,sensitivity:`base`})*r})}function Z(e,t){let n=St(),r=n.key===t,i=r?n.direction:``;return`
    <span class="user-table-heading">
      <span>${e}</span>
      <button
        type="button"
        class="user-sort-btn ${r?`active ${i}`:``}"
        onclick="sortUserManagement('${t}')"
        aria-label="Sort ${e}"
        title="Sort ${e}"
      ></button>
    </span>
  `}window.sortUserManagement=function(e){let t=St();window.userManagementSort={key:e,direction:t.key===e&&t.direction===`asc`?`desc`:`asc`},showUserManagement()},window.showUserManagement=async function(){if(!K(`users`))return;localStorage.setItem(`currentPage`,`users`);let[e,t,n,r]=await Promise.all([fetch(`${g}/users`),Q(`${g}/customers`,[]),Q(`${g}/sites`,[]),Q(`${g}/sections`,[])]),i=await e.json();if(!e.ok){alert(i.error||`Unable to load users`);return}window.userManagementLookups={customers:t,sites:n,sections:r};let a=Ct(i);document.querySelector(`#page`).innerHTML=`
    <div class="user-management-page">
    <h1>User Management</h1>

    <div class="filter-card user-create-card">
      <h2>Create User</h2>
      <div class="asset-form-grid">
        <div class="form-group">
          <label>Username</label>
          <input id="newUserUsername" type="text">
        </div>
        <div class="form-group">
          <label>Email</label>
          <input id="newUserEmail" type="email">
        </div>
        <div class="form-group">
          <label>Password</label>
          <input id="newUserPassword" type="password">
        </div>
        <div class="form-group">
          <label>Full Name</label>
          <input id="newUserFullName" type="text">
        </div>
        <div class="form-group">
          <label>Role</label>
          <select id="newUserRole">
            <option value="ADMIN">ADMIN</option>
            <option value="MANAGER">MANAGER</option>
            <option value="INSPECTOR">INSPECTOR</option>
            <option value="VIEWER">VIEWER</option>
            <option value="CUSTOMER">CUSTOMER</option>
          </select>
        </div>
        <div class="form-group">
          <label>LMI Number</label>
          <input id="newUserLmi" type="text">
        </div>
        <div class="form-group">
          <label>Customer Name</label>
          <select id="newUserClientId">
            ${X(t,`clientid`,`clientname`,``,`No customer selected`)}
          </select>
        </div>
        <div class="form-group">
          <label>Site Name</label>
          <select id="newUserSiteId">
            ${X(n,`siteid`,`sitename`,``,`No site selected`)}
          </select>
        </div>
        <div class="form-group">
          <label>Section Name</label>
          <select id="newUserSectionId">
            ${X(r,`sectionid`,`sectionname`,``,`No section selected`)}
          </select>
        </div>
      </div>
      <button onclick="createUser()">Create User</button>
    </div>

    <div class="filter-card user-signature-card">
      <h2>My Signature</h2>
      <p>Upload your own inspector signature. It will be used on new inspections saved under your login.</p>
      <input id="mySignatureUpload" type="file" accept="image/*">
      <button onclick="uploadMySignature()">Upload Signature</button>
    </div>

    <div class="user-management-table-wrap">
    <table class="user-management-table">
      <thead>
        <tr>
          <th>${Z(`User`,`username`)}</th>
          <th>${Z(`Email`,`email`)}</th>
          <th>${Z(`Full Name`,`full_name`)}</th>
          <th>${Z(`Role`,`role`)}</th>
          <th>${Z(`LMI Number`,`lmi_number`)}</th>
          <th>${Z(`Customer Name`,`clientid`)}</th>
          <th>${Z(`Site Name`,`siteid`)}</th>
          <th>${Z(`Section Name`,`sectionid`)}</th>
          <th>${Z(`Active`,`is_active`)}</th>
          <th>${Z(`Signature`,`signature_image`)}</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ${a.map(e=>`
          <tr class="${e.is_active?``:`inactive-user-row`}">
            <td class="user-name-cell">${c(e.username)}</td>
            <td><input id="user-email-${l(e.user_id)}" value="${l(e.email||``)}"></td>
            <td><input id="user-name-${l(e.user_id)}" value="${l(e.full_name||``)}"></td>
            <td>
              <select id="user-role-${e.user_id}">
                ${[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`,`CUSTOMER`].map(t=>`
                  <option value="${t}" ${t===e.role?`selected`:``}>${t}</option>
                `).join(``)}
              </select>
            </td>
            <td><input id="user-lmi-${l(e.user_id)}" value="${l(e.lmi_number||``)}"></td>
            <td>
              <select id="user-client-${e.user_id}">
                ${X(t,`clientid`,`clientname`,e.clientid,`No customer selected`)}
              </select>
            </td>
            <td>
              <select id="user-site-${e.user_id}">
                ${X(n,`siteid`,`sitename`,e.siteid,`No site selected`)}
              </select>
            </td>
            <td>
              <select id="user-section-${e.user_id}">
                ${X(r,`sectionid`,`sectionname`,e.sectionid,`No section selected`)}
              </select>
            </td>
            <td class="user-active-cell">
              <input class="user-status-check" id="user-active-${e.user_id}" type="checkbox" ${e.is_active?`checked`:``}>
            </td>
            <td>
              <div class="user-signature-cell">
                <span class="${e.signature_image?`signature-status saved`:`signature-status`}">${e.signature_image?`Saved`:`-`}</span>
                <input id="user-signature-${e.user_id}" type="file" accept="image/*">
                <button type="button" class="secondary-small-btn" onclick="uploadUserSignature(${e.user_id})">Upload</button>
              </div>
            </td>
            <td class="user-row-actions">
              <button onclick="saveUser(${e.user_id})">Save</button>
              <button class="secondary-small-btn" onclick="resetUserPassword(${e.user_id})">Reset Password</button>
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
    </div>
    </div>
  `},window.createUser=async function(){let e=await fetch(`${g}/users`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({username:document.querySelector(`#newUserUsername`).value,email:document.querySelector(`#newUserEmail`).value,password:document.querySelector(`#newUserPassword`).value,full_name:document.querySelector(`#newUserFullName`).value,role:document.querySelector(`#newUserRole`).value,lmi_number:document.querySelector(`#newUserLmi`).value,clientid:document.querySelector(`#newUserClientId`).value,siteid:document.querySelector(`#newUserSiteId`).value,sectionid:document.querySelector(`#newUserSectionId`).value})}),t=await e.json();if(!e.ok){alert(t.error||`Unable to create user`);return}alert(`User created successfully`),showUserManagement()},window.saveUser=async function(e){if(!e||e===`null`){alert(`This user record is missing an account ID. The list will refresh now.`),showUserManagement();return}let t=await fetch(`${g}/users/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({email:document.querySelector(`#user-email-${e}`).value,full_name:document.querySelector(`#user-name-${e}`).value,role:document.querySelector(`#user-role-${e}`).value,lmi_number:document.querySelector(`#user-lmi-${e}`).value,clientid:document.querySelector(`#user-client-${e}`).value,siteid:document.querySelector(`#user-site-${e}`).value,sectionid:document.querySelector(`#user-section-${e}`).value,is_active:document.querySelector(`#user-active-${e}`).checked})}),n=await t.json();if(!t.ok){alert(n.error||`Unable to save user`);return}alert(`User saved successfully`),showUserManagement()},window.uploadUserSignature=async function(e){if(!e||e===`null`){alert(`This user record is missing an account ID. The list will refresh now.`),showUserManagement();return}let t=document.querySelector(`#user-signature-${e}`)?.files[0];if(!t){alert(`Choose a signature image for this user`);return}let n=new FormData;n.append(`signature`,t);let r=await fetch(`${g}/users/${e}/signature`,{method:`POST`,body:n}),i=await L(r);if(!r.ok){alert(i.error||`Unable to upload signature`);return}alert(`Signature saved successfully`),showUserManagement()},window.resetUserPassword=async function(e){if(!e||e===`null`){alert(`This user record is missing an account ID. The list will refresh now.`),showUserManagement();return}let t=prompt(`Enter the new password for this user. It must be at least 8 characters.`);if(t===null)return;if(t.length<8){alert(`Password must be at least 8 characters`);return}let n=prompt(`Confirm the new password`);if(n===null)return;if(t!==n){alert(`Passwords do not match`);return}let r=await fetch(`${g}/users/${e}/reset-password`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({password:t})}),i=await L(r);if(!r.ok){alert(i.error||`Unable to reset password`);return}alert(`Password reset successfully`)},window.deleteUser=async function(e){if(!confirm(`Delete this user? This will deactivate the login and keep old records safe.`))return;let t=await fetch(`${g}/users/${e}`,{method:`DELETE`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to delete user`);return}showUserManagement()},window.uploadMySignature=async function(){let e=document.querySelector(`#mySignatureUpload`)?.files[0];if(!e){alert(`Choose a signature image`);return}let t=new FormData;t.append(`signature`,e);let n=await fetch(`${g}/users/me/signature`,{method:`POST`,body:t}),r=await n.json();if(!n.ok){alert(r.error||`Unable to upload signature`);return}R=r.user,window.currentUser=R,alert(`Signature saved successfully`),ft(`users`)&&localStorage.getItem(`currentPage`)===`users`?showUserManagement():showMyProfile()},window.showMyProfile=async function(){if(!K(`profile`))return;localStorage.setItem(`currentPage`,`profile`);let e=await fetch(`${g}/users/me`),t=await L(e);if(!e.ok){alert(t.error||`Unable to load your profile`);return}R=t.user,window.currentUser=R,document.querySelector(`#page`).innerHTML=`
    <h1>My Profile</h1>
    <div class="filter-card my-profile-card">
      <h2>Profile Details</h2>
      <div class="asset-form-grid">
        <div class="form-group">
          <label>Username</label>
          <input value="${l(R.username||``)}" disabled>
        </div>
        <div class="form-group">
          <label>Role</label>
          <input value="${l(R.role||``)}" disabled>
        </div>
        <div class="form-group">
          <label>Full Name</label>
          <input id="myProfileFullName" type="text" value="${l(R.full_name||``)}">
        </div>
        <div class="form-group">
          <label>Email</label>
          <input id="myProfileEmail" type="email" value="${l(R.email||``)}">
        </div>
        <div class="form-group">
          <label>LMI Number</label>
          <input id="myProfileLmi" type="text" value="${l(R.lmi_number||``)}">
        </div>
      </div>
      <button onclick="saveMyProfile()">Save Profile</button>
    </div>

    <div class="filter-card user-signature-card">
      <h2>My Signature</h2>
      <p>Your signature will be used on new inspection and load test certificates saved under your login.</p>
      <div class="profile-signature-status">
        Current signature: <strong>${R.signature_image?`Saved`:`Not uploaded yet`}</strong>
      </div>
      <input id="mySignatureUpload" type="file" accept="image/*">
      <button onclick="uploadMySignature()">Upload Signature</button>
    </div>
  `},window.saveMyProfile=async function(){let e=await fetch(`${g}/users/me`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({full_name:document.querySelector(`#myProfileFullName`)?.value||``,email:document.querySelector(`#myProfileEmail`)?.value||``,lmi_number:document.querySelector(`#myProfileLmi`)?.value||``})}),t=await L(e);if(!e.ok){alert(t.error||`Unable to save your profile`);return}R=t.user,window.currentUser=R,alert(`Profile saved successfully`),showMyProfile()};async function Q(e,t){let n=await fetch(e);if(!n.ok){if([401,403].includes(n.status))return t;let r=await n.json().catch(()=>({}));throw Error(r.error||`Unable to load ${e}`,{cause:{url:e,status:n.status}})}return n.json()}async function wt(e,t){try{return await Q(e,t)}catch(n){return console.error(`Unable to load optional data from ${e}:`,n),t}}async function Tt(e){let t=B.find(t=>String(t.assetid)===String(e));if(t)return t;let n=await fetch(`${g}/assets/${e}`),r=await n.json().catch(()=>({}));if(!n.ok)throw Error(r.error||`Asset not found`);return r}function Et(e,t={}){let n=t.url||``,r=[t.status?`Status ${t.status}`:``,n].filter(Boolean).join(` - `);document.querySelector(`#app`).innerHTML=`
    <div class="login-page">
      <div class="login-card">
        <img src="${pe(`logo.jpg`)}" alt="ATEC Logo" class="login-logo">
        <h1>ATEC could not finish loading</h1>
        <p>${e}</p>
        ${r?`<p><strong>${c(r)}</strong></p>`:``}
        <button type="button" onclick="location.reload()">Reload</button>
      </div>
    </div>
  `}async function $(){let n;try{n=await fetch(`${g}/auth/me`)}catch{gt(`Cannot connect to the ATEC backend. Please check that the backend is running.`);return}if(!n.ok){gt();return}R=(await n.json()).user,window.currentUser=R,B=[];try{let[e,t,n,r,i,a,o]=await Promise.all([Q(`${g}/customers`,[]),Q(`${g}/sites`,[]),Q(`${g}/responsible-persons`,[]),Q(`${g}/sections`,[]),Q(`${g}/equipment-types`,[]),wt(`${g}/dashboard/stats`,{}),Q(`${g}/equipment-type-criteria`,[])]);z=e,V=t,H=n,U=r,W=i,lt=a,G=o,window.atecCriteria=G}catch(e){Et(e.message||`The app could not load its startup data.`,e.cause||{});return}document.querySelector(`#app`).innerHTML=`
    <div class="app">

     <div class="layout">

  <div class="sidebar">

          <div class="logo-container">
            <img src="${pe(`logo.jpg`)}" alt="ATEC Logo" class="logo">
          </div>

          <div class="system-title">
            Inspection Platform
          </div>

    <div class="user-panel">
      <strong>${c(R.full_name)}</strong>
      <span>${c(R.role)}${R.lmi_number?` | LMI ${c(R.lmi_number)}`:``}</span>
    </div>

    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()" aria-expanded="false">
      Menu
    </button>

    <div class="mobile-menu-actions">
    ${q(`dashboard`,`Dashboard`,`showDashboard()`)}
    ${q(`customers`,`Customer Setup`,`showCustomerSetup()`)}
    ${q(`sites`,`Sites`,`showSites()`)}
    ${q(`responsible`,`Responsible Persons`,`showResponsiblePersons()`)}
    ${q(`sections`,`Sections`,`showSections()`)}
    ${q(`assets`,`Assets`,`showAssetSetup()`)}
    ${q(`inspections`,`Inspection/Testing`,`showInspections()`)}
    ${q(`quick-inspection`,`Quick Inspection/Testing`,`showQuickInspection()`)}
    ${q(`certificates`,`Certificates`,`showCertificateSearch()`)}
    ${q(`customer-report`,`Reports`,`showCustomerDetailedReport()`)}
    ${q(`she`,`Risk Assessment / SHE`,`showRiskAssessments()`)}
    ${q(`criteria`,`Equipment Type Criteria`,`showEquipmentTypeCriteria()`)}
    ${q(`users`,`User Management`,`showUserManagement()`)}
    ${q(`system-health`,`System Health`,`showSystemHealth()`)}
    ${q(`profile`,`My Profile`,`showMyProfile()`)}

    <button onclick="logoutUser()">Logout</button>
    </div>

  </div>

  <div class="content">
    <div id="page"></div>
  </div>

</div>

</div>

  `,window.toggleMobileMenu=function(){let e=document.querySelector(`.sidebar`),t=document.querySelector(`.mobile-menu-toggle`),n=e?.classList.toggle(`mobile-menu-open`);t?.setAttribute(`aria-expanded`,n?`true`:`false`)},window.closeMobileMenu=function(){let e=document.querySelector(`.sidebar`),t=document.querySelector(`.mobile-menu-toggle`);e?.classList.remove(`mobile-menu-open`),t?.setAttribute(`aria-expanded`,`false`)},window.showDashboard=function(){K(`dashboard`)&&(localStorage.setItem(`currentPage`,`dashboard`),r(z,B,V,W,lt),ot())};let o=localStorage.getItem(`customerArchiveMode`)||`active`;window.showCustomerSetup=function(e=o){K(`customers`)&&(o=e,localStorage.setItem(`currentPage`,`customers`),localStorage.setItem(`customerArchiveMode`,e),u(z,o))},window.addClient=async function(){let e=prompt(`Enter Client Name`);if(!e)return;let t=prompt(`Enter Client Address`),n=await fetch(`${g}/customers`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientname:e,clientaddr:t})}),r=await n.json();if(!n.ok){alert(`Error saving client: `+r.error);return}alert(`Client saved: `+r.clientname),$()},window.editClient=function(e){let t=z.find(t=>String(t.clientid)===String(e));if(!t){alert(`Client not found`);return}document.querySelector(`#page`).innerHTML=`

    <h2>Edit Client</h2>

    <label>Client Name</label>
    <input
      id="editClientName"
      type="text"
      value="${l(t.clientname||``)}"
    >

    <label>Address</label>
    <input
      id="editClientAddress"
      type="text"
      value="${l(t.clientaddr||``)}"
    >

    <button onclick="saveClientChanges(${t.clientid})">
      Save Changes
    </button>

    <button onclick="showCustomerSetup()">
      Cancel
    </button>

  `},window.saveClientChanges=async function(e){let t=document.querySelector(`#editClientName`).value,n=document.querySelector(`#editClientAddress`).value,r=await fetch(`${g}/customers/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientname:t,clientaddr:n})}),i=await r.json();if(!r.ok){alert(`Error updating client: `+i.error);return}alert(`Client updated`),await $(),showCustomerSetup()},window.filterCustomers=function(e=!1){e&&(window.customerCurrentPage=1);let t=document.querySelector(`#customerSearch`).value.toLowerCase(),n=i(z.filter(e=>{let n=e.archived===!0||e.archived===`true`,r=o===`all`||o===`active`&&!n||o===`archived`&&n,i=String(e.clientid||``).includes(t)||(e.clientname||``).toLowerCase().includes(t)||(e.clientaddr||``).toLowerCase().includes(t);return r&&i}),`customerCurrentPage`,`customerRowsPerPage`),r=document.querySelector(`.report-pagination-bar`);r&&(r.outerHTML=a({...n,label:`customers`,onPage:`goToCustomerPage`,onPageSize:`setCustomerRowsPerPage`}));let s=document.querySelector(`#customerTableBody`);s.innerHTML=n.rows.map(e=>{let t=e.archived===!0||e.archived===`true`;return`
      <tr>
        <td>${c(e.clientid)}</td>
        <td>${c(e.clientname||``)}</td>
        <td>${c(e.clientaddr||``)}</td>
        <td>${t?`Archived`:`Active`}</td>
        <td>
          <button onclick="editClient(${e.clientid})">Edit</button>

          ${Y()?`
          ${t?`<button onclick="unarchiveClient(${e.clientid})">Restore</button>`:`<button onclick="archiveClient(${e.clientid})">Archive</button>`}
          `:``}
        </td>
      </tr>
    `}).join(``)},window.setCustomerRowsPerPage=function(e){window.customerRowsPerPage=Number(e)||25,window.customerCurrentPage=1,filterCustomers()},window.goToCustomerPage=function(e){window.customerCurrentPage=Math.max(1,Number(e)||1),filterCustomers()},window.archiveClient=async function(e){if(!Y()){alert(`You do not have permission to archive customers.`);return}confirm(`Archive this client and all linked data?`)&&(await fetch(`${g}/customers/${e}/archive`,{method:`PUT`}),await $(),showCustomerSetup())},window.unarchiveClient=async function(e){if(!Y()){alert(`You do not have permission to restore customers.`);return}await fetch(`${g}/customers/${e}/unarchive`,{method:`PUT`}),await $(),showCustomerSetup()};let s=localStorage.getItem(`responsibleArchiveMode`)||`active`;window.showResponsiblePersons=function(e=s){K(`responsible`)&&(s=e,localStorage.setItem(`currentPage`,`responsible`),localStorage.setItem(`responsibleArchiveMode`,e),f(H,s))},window.showAddResponsiblePersonForm=function(){let e=[...z].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``));document.querySelector(`#page`).innerHTML=`
    <h2>Add Responsible Person</h2>

    <label>Client</label>
    <select id="responsibleClient">
      <option value="">Select Client</option>

      ${e.map(e=>`
        <option value="${l(e.clientid)}">
          ${c(e.clientname)}
        </option>
      `).join(``)}
    </select>

    <label>Responsible Person Name</label>
    <input id="responsibleName" type="text">

    <button onclick="saveResponsiblePerson()">
      Save
    </button>

    <button onclick="showResponsiblePersons()">
      Cancel
    </button>
  `},window.saveResponsiblePerson=async function(){let e=document.querySelector(`#responsibleClient`).value,t=document.querySelector(`#responsibleName`).value;if(!e||!t){alert(`Please complete all fields`);return}let n=await fetch(`${g}/responsible-persons`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:e,name:t})}),r=await n.json();if(!n.ok){alert(r.error);return}alert(`Responsible Person Saved`),await $(),showResponsiblePersons()},window.editResponsiblePerson=function(e){let t=H.find(t=>String(t.personid)===String(e));if(!t){alert(`Person not found`);return}document.querySelector(`#page`).innerHTML=`
    <h2>Edit Responsible Person</h2>

    <label>Name</label>
    <input
      id="editResponsibleName"
      type="text"
      value="${l(t.name||``)}"
    >

    <button onclick="saveResponsiblePersonChanges(${t.personid})">
      Save Changes
    </button>

    <button onclick="showResponsiblePersons()">
      Cancel
    </button>
  `},window.saveResponsiblePersonChanges=async function(e){let t=H.find(t=>String(t.personid)===String(e)),n=document.querySelector(`#editResponsibleName`).value,r=await fetch(`${g}/responsible-persons/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:t.clientid,name:n})}),i=await r.json();if(!r.ok){alert(i.error);return}alert(`Responsible Person Updated`),await $(),showResponsiblePersons()},window.filterResponsiblePersons=function(e=!1){e&&(window.responsibleCurrentPage=1);let t=document.querySelector(`#responsibleSearch`).value.toLowerCase().trim(),n=i(H.filter(e=>{let n=e.archived===!0||e.archived===`true`;return s===`active`&&n||s===`archived`&&!n?!1:String(e.personid||``).includes(t)||(e.clientname||``).toLowerCase().includes(t)||(e.name||``).toLowerCase().includes(t)}),`responsibleCurrentPage`,`responsibleRowsPerPage`),r=document.querySelector(`.report-pagination-bar`);r&&(r.outerHTML=a({...n,label:`people`,onPage:`goToResponsiblePage`,onPageSize:`setResponsibleRowsPerPage`})),document.querySelector(`#responsibleTableBody`).innerHTML=n.rows.map(e=>`
      <tr>
        <td>${c(e.personid)}</td>
        <td>${c(e.clientname||``)}</td>
        <td>${c(e.name||``)}</td>
        <td>${e.archived?`Archived`:`Active`}</td>
        <td>
          <button onclick="editResponsiblePerson(${e.personid})">
            Edit
          </button>
          ${Y()?`
          ${e.archived?`<button onclick="unarchiveResponsiblePerson(${e.personid})">Restore</button>`:`<button onclick="archiveResponsiblePerson(${e.personid})">Archive</button>`}
          `:``}
        </td>
      </tr>
    `).join(``)},window.archiveResponsiblePerson=async function(e){if(!Y()){alert(`You do not have permission to archive responsible persons.`);return}if(!confirm(`Archive this responsible person? Active sections and assets must be moved first.`))return;let t=await fetch(`${g}/responsible-persons/${e}/archive`,{method:`PUT`}),n=await L(t);if(!t.ok){alert(n.error||`Unable to archive responsible person.`);return}alert(`Responsible person archived`),await $(),showResponsiblePersons()},window.unarchiveResponsiblePerson=async function(e){if(!Y()){alert(`You do not have permission to restore responsible persons.`);return}let t=await fetch(`${g}/responsible-persons/${e}/unarchive`,{method:`PUT`}),n=await L(t);if(!t.ok){alert(n.error||`Unable to restore responsible person.`);return}alert(`Responsible person restored`),await $(),showResponsiblePersons()},window.setResponsibleRowsPerPage=function(e){window.responsibleRowsPerPage=Number(e)||25,window.responsibleCurrentPage=1,filterResponsiblePersons()},window.goToResponsiblePage=function(e){window.responsibleCurrentPage=Math.max(1,Number(e)||1),filterResponsiblePersons()};let p=localStorage.getItem(`sectionArchiveMode`)||`active`;window.showSections=function(e=p){K(`sections`)&&(p=e,localStorage.setItem(`currentPage`,`sections`),localStorage.setItem(`sectionArchiveMode`,e),m(U,p))},window.showAddSectionForm=function(){let e=[...z].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``));document.querySelector(`#page`).innerHTML=`
    <h2>Add Section</h2>

    <div class="form-row">

      <div class="form-group">
        <label>Client</label>
        <select id="sectionClient" onchange="filterSectionDropdowns()">
          <option value="">Select Client</option>
          ${e.map(e=>`
            <option value="${l(e.clientid)}">
              ${c(e.clientname)}
            </option>
          `).join(``)}
        </select>
      </div>

      <div class="form-group">
        <label>Site</label>
        <select id="sectionSite">
          <option value="">Select Client First</option>
        </select>
      </div>

      <div class="form-group">
        <label>Responsible Person</label>
        <select id="sectionResponsible">
          <option value="">Select Client First</option>
        </select>
      </div>

      <div class="form-group">
        <label>Section Name</label>
        <input id="sectionName" type="text" placeholder="Enter section name">
      </div>

    </div>

    <button onclick="saveSectionFromForm()">Save Section</button>
    <button onclick="showSections()">Cancel</button>
  `},window.filterSectionDropdowns=function(){let e=document.querySelector(`#sectionClient`).value,t=document.querySelector(`#sectionSite`),n=document.querySelector(`#sectionResponsible`);if(!e){t.innerHTML=`<option value="">Select Client First</option>`,n.innerHTML=`<option value="">Select Client First</option>`;return}let r=V.filter(t=>String(t.clientid)===String(e)&&!(t.archived===!0||t.archived===`true`)).sort((e,t)=>(e.sitename||``).localeCompare(t.sitename||``)),i=H.filter(t=>String(t.clientid)===String(e)&&!(t.archived===!0||t.archived===`true`)).sort((e,t)=>(e.name||``).localeCompare(t.name||``));t.innerHTML=`
    <option value="">Select Site</option>
    ${r.map(e=>`
      <option value="${l(e.siteid)}">
        ${c(e.sitename)}
      </option>
    `).join(``)}
  `,n.innerHTML=`
    <option value="">Select Responsible Person</option>
    ${i.map(e=>`
      <option value="${l(e.personid)}">
        ${c(e.name)}
      </option>
    `).join(``)}
  `},window.filterSections=function(e=!1){e&&(window.sectionCurrentPage=1);let n=document.querySelector(`#sectionSearchType`).value,r=document.querySelector(`#sectionSearch`).value.toLowerCase().trim(),o=i(t(U.filter(e=>{let t=e.archived===!0||e.archived===`true`;return p===`active`&&t||p===`archived`&&!t?!1:String(e[n]||``).toLowerCase().includes(r)}),`sections`,{client_section:e=>`${e.clientname||``}\u0000${e.sectionname||``}`,sectionid:e=>e.sectionid,clientname:e=>e.clientname,sitename:e=>e.sitename,responsiblename:e=>e.responsiblename,sectionname:e=>e.sectionname,archived:e=>e.archived?`Archived`:`Active`},`client_section`),`sectionCurrentPage`,`sectionRowsPerPage`),s=document.querySelector(`.report-pagination-bar`);s&&(s.outerHTML=a({...o,label:`sections`,onPage:`goToSectionPage`,onPageSize:`setSectionRowsPerPage`})),document.querySelector(`#sectionTableBody`).innerHTML=o.rows.map(e=>`
      <tr>
        <td>${c(e.sectionid)}</td>
        <td>${c(e.clientname||``)}</td>
        <td>${c(e.sitename||``)}</td>
        <td>${c(e.responsiblename||``)}</td>
        <td>${c(e.sectionname||``)}</td>
        <td>${e.archived?`Archived`:`Active`}</td>
        <td>
          <button onclick="editSection(${e.sectionid})">
            Edit
          </button>
          ${Y()?`
          ${e.archived?`<button onclick="unarchiveSection(${e.sectionid})">Restore</button>`:`<button onclick="archiveSection(${e.sectionid})">Archive</button>`}
          `:``}
        </td>
      </tr>
    `).join(``)},window.setSectionRowsPerPage=function(e){window.sectionRowsPerPage=Number(e)||25,window.sectionCurrentPage=1,filterSections()},window.goToSectionPage=function(e){window.sectionCurrentPage=Math.max(1,Number(e)||1),filterSections()},window.editSection=function(e){let t=U.find(t=>String(t.sectionid)===String(e));if(!t){alert(`Section not found`);return}let n=H.filter(e=>String(e.clientid)===String(t.clientid)&&(!(e.archived===!0||e.archived===`true`)||String(e.personid)===String(t.responsibleid))).sort((e,t)=>(e.name||``).localeCompare(t.name||``));document.querySelector(`#page`).innerHTML=`
    <h2>Edit Section</h2>

    <label>Client</label>
    <input type="text" value="${l(t.clientname||``)}" disabled>

    <label>Site</label>
    <input type="text" value="${l(t.sitename||``)}" disabled>

    <label>Responsible Person</label>
    <select id="editSectionResponsible">
      <option value="" ${t.responsibleid?``:`selected`}>
        Select Responsible Person
      </option>
      ${n.map(e=>`
        <option
          value="${l(e.personid)}"
          ${String(e.personid)===String(t.responsibleid)?`selected`:``}
        >
          ${c(e.name)}
        </option>
      `).join(``)}
    </select>

    <label>Section Name</label>
    <input
      id="editSectionName"
      type="text"
      value="${l(t.sectionname||``)}"
    >

    <button onclick="saveSectionChanges(${t.sectionid})">
      Save Changes
    </button>

    <button onclick="showSections()">
      Cancel
    </button>
  `},window.saveSectionChanges=async function(e){let t=document.querySelector(`#editSectionResponsible`).value,n=document.querySelector(`#editSectionName`).value;if(!t||!n){alert(`Please complete all fields`);return}let r=await fetch(`${g}/sections/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({responsibleid:t,sectionname:n})}),i=await r.json();if(!r.ok){alert(`Error updating section: `+i.error);return}alert(`Section updated`),await $(),showSections()},window.saveSectionFromForm=async function(){let e=document.querySelector(`#sectionClient`).value,t=document.querySelector(`#sectionSite`).value,n=document.querySelector(`#sectionResponsible`).value,r=document.querySelector(`#sectionName`).value;if(!e||!t||!n||!r){alert(`Please complete all fields`);return}let i=await fetch(`${g}/sections`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:e,siteid:t,responsibleid:n,sectionname:r})}),a=await i.json();if(!i.ok){alert(`Error saving section: `+a.error);return}alert(`Section saved: `+a.sectionname),await $(),showSections()},window.archiveSection=async function(e){if(!Y()){alert(`You do not have permission to archive sections.`);return}if(!confirm(`Archive this section? Active assets must be moved or archived first.`))return;let t=await fetch(`${g}/sections/${e}/archive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to archive section`);return}alert(`Section archived`),await $(),showSections()},window.unarchiveSection=async function(e){if(!Y()){alert(`You do not have permission to restore sections.`);return}let t=await fetch(`${g}/sections/${e}/unarchive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to restore section`);return}alert(`Section restored`),await $(),showSections()};let h=localStorage.getItem(`siteArchiveMode`)||`active`;window.showSites=function(e=h){K(`sites`)&&(h=e,localStorage.setItem(`currentPage`,`sites`),localStorage.setItem(`siteArchiveMode`,e),d(V,h))},window.filterSites=function(e=!1){e&&(window.siteCurrentPage=1);let t=document.querySelector(`#siteSearch`).value.toLowerCase().trim(),n=i(V.filter(e=>{let n=e.archived===!0||e.archived===`true`,r=h===`all`||h===`active`&&!n||h===`archived`&&n,i=String(e.siteid||``).includes(t)||(e.clientname||``).toLowerCase().includes(t)||(e.sitename||``).toLowerCase().includes(t);return r&&i}),`siteCurrentPage`,`siteRowsPerPage`),r=document.querySelector(`.report-pagination-bar`);r&&(r.outerHTML=a({...n,label:`sites`,onPage:`goToSitePage`,onPageSize:`setSiteRowsPerPage`})),document.querySelector(`#siteTableBody`).innerHTML=n.rows.map(e=>`
      <tr>
        <td>${c(e.siteid)}</td>
        <td>${c(e.clientname||``)}</td>
        <td>${c(e.sitename||``)}</td>
        <td>${e.archived?`Archived`:`Active`}</td>
        <td>
          <button onclick="editSite(${e.siteid})">
            Edit
          </button>
          ${Y()?`
          ${e.archived?`<button onclick="unarchiveSite(${e.siteid})">Restore</button>`:`<button onclick="archiveSite(${e.siteid})">Archive</button>`}
          `:``}
        </td>
      </tr>
    `).join(``)},window.setSiteRowsPerPage=function(e){window.siteRowsPerPage=Number(e)||25,window.siteCurrentPage=1,filterSites()},window.goToSitePage=function(e){window.siteCurrentPage=Math.max(1,Number(e)||1),filterSites()},window.editSite=function(e){let t=V.find(t=>String(t.siteid)===String(e));if(!t){alert(`Site not found`);return}document.querySelector(`#page`).innerHTML=`
    <h2>Edit Site</h2>

    <label>Client</label>
    <input
      type="text"
      value="${l(t.clientname||``)}"
      disabled
    >

    <label>Site Name</label>
    <input
      id="editSiteName"
      type="text"
      value="${l(t.sitename||``)}"
    >

    <button onclick="saveSiteChanges(${t.siteid})">
      Save Changes
    </button>

    <button onclick="showSites()">
      Cancel
    </button>
  `},window.saveSiteChanges=async function(e){let t=document.querySelector(`#editSiteName`).value;if(!t){alert(`Please enter a site name`);return}let n=await fetch(`${g}/sites/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({sitename:t})}),r=await n.json();if(!n.ok){alert(`Error updating site: `+r.error);return}alert(`Site updated`),await $(),showSites()},window.archiveSite=async function(e){if(!Y()){alert(`You do not have permission to archive sites.`);return}if(!confirm(`Archive this site? Active assets must be moved or archived first.`))return;let t=await fetch(`${g}/sites/${e}/archive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to archive site`);return}alert(`Site archived`),await $(),showSites()},window.unarchiveSite=async function(e){if(!Y()){alert(`You do not have permission to restore sites.`);return}let t=await fetch(`${g}/sites/${e}/unarchive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to restore site`);return}alert(`Site restored`),await $(),showSites()},window.showAddSiteForm=function(){let e=[...z].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``));document.querySelector(`#page`).innerHTML=`
    <h2>Add Site</h2>

    <label>Client</label>
    <select id="siteClient">
      <option value="">Select Client</option>
      ${e.map(e=>`
        <option value="${l(e.clientid)}">
          ${c(e.clientname)}
        </option>
      `).join(``)}
    </select>

    <label>Site Name</label>
    <input id="siteName" type="text" placeholder="Enter site name">

    <button onclick="saveSiteFromForm()">
      Save Site
    </button>

    <button onclick="showSites()">
      Cancel
    </button>
  `},window.saveSiteFromForm=async function(){let e=document.querySelector(`#siteClient`).value,t=document.querySelector(`#siteName`).value;if(!e||!t){alert(`Please complete all fields`);return}let n=await fetch(`${g}/sites`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:e,sitename:t})}),r=await n.json();if(!n.ok){alert(`Error saving site: `+r.error);return}alert(`Site saved: `+r.sitename),await $(),showSites()},window.showAssetSetup=async function(){if(!K(`assets`))return;localStorage.setItem(`currentPage`,`assets`);let e=window.assetListState||{};window.assetCurrentPage=e.currentPage||window.assetCurrentPage||1,window.assetRowsPerPage=e.rowsPerPage||window.assetRowsPerPage||25,await _e()},window.showRiskAssessments=async function(){K(`she`)&&(localStorage.setItem(`currentPage`,`she`),window.canWriteRiskAssessments=[`ADMIN`,`MANAGER`,`INSPECTOR`].includes(R?.role),await Ze(B,window.canWriteRiskAssessments))},window.loadRiskAssessments=async function(){let e=await fetch(`${g}/she/risk-assessments`),t=await e.json();if(!e.ok){alert(t.error||`Unable to load risk assessments`);return}window.riskAssessments=t,Qe(window.riskAssessments,window.canWriteRiskAssessments)},window.filterRiskAssessments=function(){Qe(window.riskAssessments||[],window.canWriteRiskAssessments)},window.downloadRiskAssessments=async function(e=`pdf`){let t=new URLSearchParams,n=document.querySelector(`#riskSearch`)?.value||``,r=document.querySelector(`#riskStatusFilter`)?.value||``;n&&t.append(`search`,n),r&&t.append(`status`,r);let i=e===`xlsx`?`xlsx`:`pdf`,a=await fetch(`${g}/she/risk-assessments.${i}?${t.toString()}`);if(!a.ok){let e=await L(a);alert(e.error||`Unable to download risk assessment register`);return}let o=await a.blob(),s=URL.createObjectURL(o),c=document.createElement(`a`);c.href=s,c.download=`ATEC-SHE-Risk-Register.${i}`,document.body.appendChild(c),c.click(),c.remove(),URL.revokeObjectURL(s)};function ee(e){return Array.from(document.querySelectorAll(e)).filter(e=>e.checked).map(e=>e.value)}function re(e,t=[]){let n=Array.isArray(t)?t:[];document.querySelectorAll(e).forEach(e=>{e.checked=n.includes(e.value)})}function ie(e){return Array.from(document.querySelectorAll(e)).reduce((e,t)=>(e[t.dataset.key]=t.value||``,e),{})}function ae(e,t={}){document.querySelectorAll(e).forEach(e=>{e.value=t?.[e.dataset.key]||``})}function oe(){return Array.from(document.querySelectorAll(`.slamm-team-row`)).map(e=>({name:e.querySelector(`.slamm-team-name`)?.value?.trim()||``,surname:e.querySelector(`.slamm-team-surname`)?.value?.trim()||``,signature:e.querySelector(`.slamm-team-signature`)?.value?.trim()||``})).filter(e=>e.name||e.surname||e.signature)}function le(e=[]){Array.from(document.querySelectorAll(`.slamm-team-row`)).forEach((t,n)=>{let r=Array.isArray(e)&&e[n]||{};t.querySelector(`.slamm-team-name`).value=r.name||``,t.querySelector(`.slamm-team-surname`).value=r.surname||``,t.querySelector(`.slamm-team-signature`).value=r.signature||``})}window.saveRiskAssessment=async function(){let e=document.querySelector(`#riskId`)?.value||``,t={assetid:document.querySelector(`#riskAssetId`)?.value||null,assessment_date:document.querySelector(`#riskAssessmentDate`)?.value,assessment_time:document.querySelector(`#riskAssessmentTime`)?.value||null,activity:document.querySelector(`#riskActivity`)?.value,hazard:document.querySelector(`#riskHazard`)?.value,hazard_categories:ee(`.risk-hazard-category`),stop_questions:ie(`.slamm-stop-question`),consequence:document.querySelector(`#riskConsequence`)?.value,initial_severity:document.querySelector(`#riskInitialSeverity`)?.value,initial_likelihood:document.querySelector(`#riskInitialLikelihood`)?.value,controls:document.querySelector(`#riskControls`)?.value,residual_severity:document.querySelector(`#riskResidualSeverity`)?.value,residual_likelihood:document.querySelector(`#riskResidualLikelihood`)?.value,action_required:document.querySelector(`#riskActionRequired`)?.value,manage_plan:document.querySelector(`#riskManagePlan`)?.value,monitor_notes:document.querySelector(`#riskMonitorNotes`)?.value,review_questions:ie(`.slamm-review-question`),additional_notes:document.querySelector(`#riskAdditionalNotes`)?.value,team_members:oe(),responsible_signoff_name:document.querySelector(`#riskResponsibleSignoffName`)?.value,supervisor_signoff_name:document.querySelector(`#riskSupervisorSignoffName`)?.value,responsible_person:document.querySelector(`#riskResponsiblePerson`)?.value,due_date:document.querySelector(`#riskDueDate`)?.value||null,status:document.querySelector(`#riskStatus`)?.value||`OPEN`};if(!t.activity||!t.hazard){alert(`Activity and hazard are required`);return}let n=await fetch(e?`${g}/she/risk-assessments/${e}`:`${g}/she/risk-assessments`,{method:e?`PUT`:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(t)}),r=await n.json();if(!n.ok){alert(r.error||`Unable to save risk assessment`);return}alert(`Risk assessment saved successfully`),await showRiskAssessments()},window.editRiskAssessment=function(e){let t=(window.riskAssessments||[]).find(t=>String(t.riskid)===String(e));if(t){if(!document.querySelector(`#riskId`)){let e=document.createElement(`input`);e.type=`hidden`,e.id=`riskId`,document.querySelector(`.filter-card`).appendChild(e)}document.querySelector(`#riskId`).value=t.riskid,document.querySelector(`#riskAssetId`).value=t.assetid||``,document.querySelector(`#riskAssessmentDate`).value=t.assessment_date?t.assessment_date.split(`T`)[0]:``,document.querySelector(`#riskAssessmentTime`).value=t.assessment_time?String(t.assessment_time).slice(0,5):``,document.querySelector(`#riskStatus`).value=t.status||`OPEN`,document.querySelector(`#riskActivity`).value=t.activity||``,document.querySelector(`#riskHazard`).value=t.hazard||``,re(`.risk-hazard-category`,t.hazard_categories||[]),ae(`.slamm-stop-question`,t.stop_questions||{}),document.querySelector(`#riskConsequence`).value=t.consequence||``,document.querySelector(`#riskInitialSeverity`).value=t.initial_severity||3,document.querySelector(`#riskInitialLikelihood`).value=t.initial_likelihood||3,document.querySelector(`#riskControls`).value=t.controls||``,document.querySelector(`#riskResidualSeverity`).value=t.residual_severity||2,document.querySelector(`#riskResidualLikelihood`).value=t.residual_likelihood||2,document.querySelector(`#riskActionRequired`).value=t.action_required||``,document.querySelector(`#riskManagePlan`).value=t.manage_plan||``,document.querySelector(`#riskMonitorNotes`).value=t.monitor_notes||``,ae(`.slamm-review-question`,t.review_questions||{}),document.querySelector(`#riskAdditionalNotes`).value=t.additional_notes||``,le(t.team_members||[]),document.querySelector(`#riskResponsibleSignoffName`).value=t.responsible_signoff_name||``,document.querySelector(`#riskSupervisorSignoffName`).value=t.supervisor_signoff_name||``,document.querySelector(`#riskResponsiblePerson`).value=t.responsible_person||``,document.querySelector(`#riskDueDate`).value=t.due_date?t.due_date.split(`T`)[0]:``,window.scrollTo({top:0,behavior:`smooth`})}},window.archiveRiskAssessment=async function(e){if(!confirm(`Archive this risk assessment?`))return;let t=await fetch(`${g}/she/risk-assessments/${e}/archive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to archive risk assessment`);return}await window.loadRiskAssessments()},window.openAssetQrLabel=function(e){window.open(`${g}/assets/${e}/qr-label.pdf`,`_blank`)},window.showAddAssetForm=function(){if(!mt()){pt();return}let e=[...z].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``)),t=[...W].sort((e,t)=>(e.description||``).localeCompare(t.description||``));document.querySelector(`#page`).innerHTML=`
    <h2>Add Asset</h2>

    <div class="filter-card">

     <div class="asset-form-grid">

  <div class="form-group">
    <label>Client</label>
    <select id="assetClient" onchange="filterAssetDropdowns()">
      <option value="">Select Client</option>
      ${e.map(e=>`
        <option value="${l(e.clientid)}">
          ${c(e.clientname)}
        </option>
      `).join(``)}
    </select>
  </div>

  <div class="form-group">
    <label>Site</label>
    <select id="assetSite" onchange="filterAssetSections()">
      <option value="">Select Client First</option>
    </select>
  </div>

  <div class="form-group">
    <label>Section</label>
    <select id="assetSection" onchange="autoFillResponsibleFromSection()">
      <option value="">Select Site First</option>
    </select>
  </div>

  <div class="form-group">
    <label>Responsible Person</label>
    <input id="assetResponsibleName" type="text" placeholder="Auto-filled from Section" disabled>
    <select id="assetResponsibleSelect" style="display:none;" onchange="syncAssetResponsibleFromSelect()">
      <option value="">Select Responsible Person</option>
    </select>
    <input id="assetResponsible" type="hidden">
  </div>

  <div class="form-group">
    <label>Equipment Type</label>
    <select id="assetEquipType" onchange="handleAssetEquipmentTypeChange()">
      <option value="">Select Equipment Type</option>
      ${t.map(e=>`
        <option value="${l(e.equiptypeid)}">
          ${c(e.description)}
        </option>
      `).join(``)}
    </select>
  </div>

  <div id="dynamicAssetFields" class="dynamic-asset-fields"></div>

    <div class="form-group">
    <label>Serial No</label>
    <input id="assetSerialNo" type="text">
  </div>

  <div class="form-group">
    <label>Asset Tag Number <span class="optional-label">(Optional)</span></label>
    <input id="assetTagNo" type="text" placeholder="Customer tag / plant number if available">
  </div>

  <div class="form-group">
    <label>Manufacturer</label>
    <input id="assetManufacturer" type="text">
  </div>

  <div class="form-group asset-description">
    <label>Description</label>
    <textarea id="assetDescription" rows="4" placeholder="Enter full asset description..."></textarea>
  </div>

  <div class="form-group" id="manufactureDateRow" style="display:none;">
    <label>Manufacture Date</label>
    <input id="assetManufactDate" type="date">
  </div>

  <div class="asset-photo-row">
    <div class="form-group">
      <label>Asset Photo 1</label>
      <input id="newAssetPhoto1" type="file" accept="image/*">
    </div>

    <div class="form-group">
      <label>Asset Photo 2</label>
      <input id="newAssetPhoto2" type="file" accept="image/*">
    </div>
  </div>

  <div class="form-actions">
    <button onclick="saveAssetFromForm()">Save Asset</button>
    <button onclick="showAssetSetup()">Cancel</button>
  </div>

</div>

  `},window.toggleManufactureDate=function(){let e=document.querySelector(`#assetEquipType`).value,t=W.find(t=>String(t.equiptypeid)===String(e)),n=document.querySelector(`#manufactureDateRow`),r=document.querySelector(`#assetManufactDate`);t&&String(t.equipgroupid)===`400`?n.style.display=`flex`:(n.style.display=`none`,r.value=``)},window.handleAssetEquipmentTypeChange=function(){toggleManufactureDate(),loadDynamicAssetFields()},window.loadDynamicAssetFields=function(){let e=document.querySelector(`#assetEquipType`).value,t=document.querySelector(`#dynamicAssetFields`);t.innerHTML=``;let n=W.find(t=>String(t.equiptypeid)===String(e));if(!n)return;let r=String(n.equipgroupid),i=``;r===`100`&&(i=`
      <div class="form-group"><label>WLL(kg)</label><input id="assetWLL" type="number"></div>
      <div class="form-group"><label>Height of Lift(mm)</label><input id="assetHeightOfLift" type="number"></div>
      <div class="form-group"><label>Number of Chain Falls</label><input id="assetNumberOfChainFalls" type="number"></div>
      <div class="form-group"><label>OEM Top Hook Size(mm)</label><input id="assetOEMTopHookSize" type="number"></div>
      <div class="form-group"><label>OEM Bottom Hook Size(mm)</label><input id="assetOEMBottomHookSize" type="number"></div>
      <div class="form-group"><label>Load Chain Diameter(mm)</label><input id="assetLoadChainDiameter" type="number"></div>
    `),r===`200`&&(i=`
      <div class="form-group"><label>WLL(kg)</label><input id="assetWLL" type="number"></div>
      <div class="form-group"><label>Effective Length(mm)</label><input id="assetEffectiveLength" type="number"></div>
    `),(r===`300`||r===`600`)&&(i=`
      <div class="form-group"><label>WLL(kg)</label><input id="assetWLL" type="number"></div>
    `),r===`400`&&(i=`
      <div class="form-group"><label>Main Hoist WLL(kg)</label><input id="assetWLL" type="number"></div>
      <div class="form-group"><label>Auxiliary Hoist WLL(kg)</label><input id="assetAuxHoistWLL" type="number"></div>
      <div class="form-group"><label>Span(mm)</label><input id="assetSpan" type="number"></div>
      <div class="form-group"><label>Permissible Deflection(mm)</label><input id="assetPermissibleDeflection" type="number"></div>
      <div class="form-group"><label>Main Hoist Description</label><input id="assetHoistDescription" type="text"></div>
      <div class="form-group"><label>Main Hoist Serial No</label><input id="assetHoistSerialNo" type="text"></div>
      <div class="form-group"><label>Auxiliary Hoist Description</label><input id="assetAuxHoistDescription" type="text"></div>
      <div class="form-group"><label>Auxiliary Hoist Serial No</label><input id="assetAuxHoistSerialNo" type="text"></div>
      <div class="form-group"><label>Main Hoist Hook Size(mm)</label><input id="assetHookSize" type="number"></div>
      <div class="form-group"><label>Auxiliary Hoist Hook Size(mm)</label><input id="assetAuxHoistHookSize" type="number"></div>
      <div class="form-group"><label>Height of Lift(mm)</label><input id="assetHeightOfLift" type="number"></div>
      <div class="form-group"><label>Main Hoist Steel Wire Rope(mm)</label><input id="assetSteelWireRopeMM" type="number"></div>
      <div class="form-group"><label>Auxiliary Hoist Steel Wire Rope(mm)</label><input id="assetAuxHoistRopeMM" type="number"></div>
    `),r===`500`&&(i=`
      <div class="form-group"><label>WLL(kg)</label><input id="assetWLL" type="number"></div>
      <div class="form-group"><label>Span(mm)</label><input id="assetSpan" type="number"></div>
      <div class="form-group"><label>Permissible Deflection(mm)</label><input id="assetPermissibleDeflection" type="number"></div>
      <div class="form-group"><label>Hook Size(mm)</label><input id="assetHookSize" type="number"></div>
      <div class="form-group"><label>Hoist Description</label><input id="assetHoistDescription" type="text"></div>
      <div class="form-group"><label>Hoist Serial No</label><input id="assetHoistSerialNo" type="text"></div>
    `),t.innerHTML=i},window.filterAssetDropdowns=function(){let e=document.querySelector(`#assetClient`).value,t=document.querySelector(`#assetSite`);if(document.querySelector(`#assetSection`).innerHTML=`<option value="">Select Site First</option>`,document.querySelector(`#assetResponsibleName`).value=``,document.querySelector(`#assetResponsible`).value=``,de(),!e){t.innerHTML=`<option value="">Select Client First</option>`;return}t.innerHTML=`
    <option value="">Select Site</option>

    ${V.filter(t=>String(t.clientid)===String(e)&&!(t.archived===!0||t.archived===`true`)).sort((e,t)=>(e.sitename||``).localeCompare(t.sitename||``)).map(e=>`
      <option value="${l(e.siteid)}">
        ${c(e.sitename)}
      </option>
    `).join(``)}
  `},window.filterAssetSections=function(){let e=document.querySelector(`#assetSite`).value,t=document.querySelector(`#assetSection`);if(document.querySelector(`#assetResponsibleName`).value=``,document.querySelector(`#assetResponsible`).value=``,de(),!e){t.innerHTML=`<option value="">Select Site First</option>`;return}t.innerHTML=`
    <option value="">Select Section</option>

    ${U.filter(t=>String(t.siteid)===String(e)&&!(t.archived===!0||t.archived===`true`)).sort((e,t)=>(e.sectionname||``).localeCompare(t.sectionname||``)).map(e=>`
      <option value="${l(e.sectionid)}">
        ${c(e.sectionname)}
      </option>
    `).join(``)}
  `};function de(){let e=document.querySelector(`#assetResponsibleName`),t=document.querySelector(`#assetResponsibleSelect`);e&&(e.style.display=``),t&&(t.style.display=`none`,t.innerHTML=`<option value="">Select Responsible Person</option>`)}function fe(e=``){let t=document.querySelector(`#assetClient`)?.value||``,n=document.querySelector(`#assetResponsibleName`),r=document.querySelector(`#assetResponsibleSelect`);if(!r||!n)return;let i=H.filter(e=>String(e.clientid)===String(t)&&!(e.archived===!0||e.archived===`true`)).sort((e,t)=>(e.name||``).localeCompare(t.name||``));n.style.display=`none`,r.style.display=``,r.innerHTML=`
    <option value="">Select Responsible Person</option>
    ${i.map(t=>`
      <option value="${l(t.personid)}" ${String(t.personid)===String(e)?`selected`:``}>
        ${c(t.name||`Responsible Person ${t.personid}`)}
      </option>
    `).join(``)}
  `}window.syncAssetResponsibleFromSelect=function(){let e=document.querySelector(`#assetResponsibleSelect`),t=document.querySelector(`#assetResponsible`);t&&(t.value=e?.value||``)},window.autoFillResponsibleFromSection=function(){let e=document.querySelector(`#assetSection`).value,t=document.querySelector(`#assetResponsibleName`),n=document.querySelector(`#assetResponsible`);if(t.value=``,n.value=``,de(),!e)return;let r=U.find(t=>String(t.sectionid)===String(e));r&&(t.value=r.responsiblename||``,n.value=r.responsibleid||``,r.responsibleid||fe())};let he=new Set([`image/jpeg`,`image/png`,`image/webp`]);function ge(e){for(let t of e.filter(Boolean)){if(!he.has(t.type))return alert(`Asset photos must be JPG, PNG or WebP images.`),!1;if(t.size>15728640)return alert(`Asset photos must be 15 MB or smaller.`),!1}return!0}window.saveAssetFromForm=async function(){if(!mt()){alert(`You do not have permission to add assets.`);return}let e=document.querySelector(`#assetClient`).value,t=document.querySelector(`#assetSite`).value,n=document.querySelector(`#assetSection`).value,r=document.querySelector(`#assetResponsible`).value,i=document.querySelector(`#assetEquipType`).value,a=document.querySelector(`#assetTagNo`)?.value||``,o=document.querySelector(`#assetSerialNo`).value,s=document.querySelector(`#assetManufacturer`).value,c=document.querySelector(`#assetDescription`).value,l=document.querySelector(`#assetManufactDate`)?.value||``;if(!e||!t||!n||!r||!i||!c){alert(`Please complete Client, Site, Section, Responsible Person, Equipment Type, and Description`);return}let u=document.querySelector(`#newAssetPhoto1`)?.files[0],d=document.querySelector(`#newAssetPhoto2`)?.files[0];if(!ge([u,d]))return;let f=await fetch(`${g}/assets`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:e,siteid:t,sectionid:n,responsibleid:r,equiptypeid:i,assettagno:a,serialno:o,manufacturer:s,description:c,manufactdate:l,wll:document.querySelector(`#assetWLL`)?.value||null,heightoflift:document.querySelector(`#assetHeightOfLift`)?.value||null,numberofchainfalls:document.querySelector(`#assetNumberOfChainFalls`)?.value||null,oemtophooksize:document.querySelector(`#assetOEMTopHookSize`)?.value||null,oembottomhooksize:document.querySelector(`#assetOEMBottomHookSize`)?.value||null,loadchaindiameter:document.querySelector(`#assetLoadChainDiameter`)?.value||null,effectivelength:document.querySelector(`#assetEffectiveLength`)?.value||null,span:document.querySelector(`#assetSpan`)?.value||null,permissibledeflection:document.querySelector(`#assetPermissibleDeflection`)?.value||null,hooksize:document.querySelector(`#assetHookSize`)?.value||null,steelwireropemm:document.querySelector(`#assetSteelWireRopeMM`)?.value||null,hoistdescription:document.querySelector(`#assetHoistDescription`)?.value||null,hoistserialno:document.querySelector(`#assetHoistSerialNo`)?.value||null,auxhoistdescription:document.querySelector(`#assetAuxHoistDescription`)?.value||null,auxhoistserialno:document.querySelector(`#assetAuxHoistSerialNo`)?.value||null,auxhoistwll:document.querySelector(`#assetAuxHoistWLL`)?.value||null,auxhoisthooksize:document.querySelector(`#assetAuxHoistHookSize`)?.value||null,auxhoistropemm:document.querySelector(`#assetAuxHoistRopeMM`)?.value||null})}),p=await f.json();if(!f.ok){alert(`Error saving asset: `+p.error);return}if(u||d){let e=new FormData;u&&e.append(`photo1`,u),d&&e.append(`photo2`,d);let t=await fetch(`${g}/assets/${p.assetid}/photos`,{method:`POST`,body:e}),n=await t.json();if(!t.ok){alert(`Asset saved, but photo upload failed: `+n.error),await $(),showAssetSetup();return}}alert(`Asset saved successfully`),await $(),showAssetSetup()};async function _e(){_();let t=window.assetListState||{},n=e(`assets`,`assetid`,`desc`),r=await Q(`${g}/assets?${new URLSearchParams({page:String(window.assetCurrentPage||t.currentPage||1),limit:String(window.assetRowsPerPage||t.rowsPerPage||25),searchBy:t.searchType||`all`,search:t.search||``,sortKey:n.key||`assetid`,sortDir:n.direction||`desc`,archiveMode:t.archiveMode||`active`}).toString()}`,{rows:[],total:0,page:1,limit:Number(window.assetRowsPerPage||25)});B=r.rows||[],window.assetCurrentPage=Number(r.page||window.assetCurrentPage||1),window.assetRowsPerPage=Number(r.limit||window.assetRowsPerPage||25);let i={serverPaged:!0,total:r.total||0,page:window.assetCurrentPage,limit:window.assetRowsPerPage};document.querySelector(`#assetTableBody`)?ne(B,i):te(B,i),ye()}window.filterAssets=async function(e=!1){e&&(window.assetCurrentPage=1),await _e()},window.filterAssetsDebounced=function(e=!1){_(),ut&&clearTimeout(ut),ut=setTimeout(()=>{filterAssets(e)},350)};function _(){let e=document.querySelector(`#assetSearchType`),t=document.querySelector(`#assetSearch`),n=document.querySelector(`#assetRowsPerPage`);window.assetListState={searchType:e?e.value:window.assetListState?.searchType||`all`,search:t?t.value:window.assetListState?.search||``,currentPage:window.assetCurrentPage||window.assetListState?.currentPage||1,rowsPerPage:Number(n?.value||window.assetRowsPerPage||window.assetListState?.rowsPerPage||25)}}function ye(){let e=window.assetListState||{},t=document.querySelector(`#assetSearchType`),n=document.querySelector(`#assetSearch`),r=document.querySelector(`#assetRowsPerPage`);window.assetRowsPerPage=Number(e.rowsPerPage||window.assetRowsPerPage||25),window.assetCurrentPage=Number(e.currentPage||window.assetCurrentPage||1),t&&(t.value=e.searchType||`all`),n&&(n.value=e.search||``),r&&(r.value=String(window.assetRowsPerPage))}window.setAssetRowsPerPage=function(e){window.assetRowsPerPage=Number(e)||25,window.assetCurrentPage=1,filterAssets()},window.changeAssetPage=function(e){window.assetCurrentPage=Math.max(1,(window.assetCurrentPage||1)+e),filterAssets()},window.goToAssetPage=function(e){window.assetCurrentPage=Math.max(1,Number(e)||1),filterAssets()},window.setAssetFilterKey=function(e){let t=document.querySelector(`#assetSearchType`);t&&(t.value=e,window.assetCurrentPage=1,filterAssets())},window.showMoveAssetForm=async function(e){if(!J()){pt();return}_();let t;try{t=await Tt(e)}catch(e){alert(e.message||`Asset not found`);return}let n=V.filter(e=>String(e.clientid)===String(t.clientid)&&!(e.archived===!0||e.archived===`true`)).sort((e,t)=>(e.sitename||``).localeCompare(t.sitename||``));document.querySelector(`#page`).innerHTML=`
    <h2>Move Asset ${c(t.assetid)}</h2>

    <div class="filter-card">
      <div class="asset-form-grid">
        <div class="form-group">
          <label>Customer</label>
          <input type="text" value="${l(t.clientname||``)}" disabled>
        </div>

        <div class="form-group">
          <label>Current Site</label>
          <input type="text" value="${l(t.sitename||`-`)}" disabled>
        </div>

        <div class="form-group">
          <label>Current Section</label>
          <input type="text" value="${l(t.sectionname||`-`)}" disabled>
        </div>

        <div class="form-group">
          <label>New Site</label>
          <select id="moveAssetSite" onchange="filterMoveAssetSections()">
            <option value="">Select Site</option>
            ${n.map(e=>`
              <option value="${l(e.siteid)}" ${String(e.siteid)===String(t.siteid)?`selected`:``}>
                ${c(e.sitename)}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="form-group">
          <label>New Section</label>
          <select id="moveAssetSection">
            <option value="">Select Site First</option>
          </select>
        </div>
      </div>

      <div class="form-actions">
        <button onclick="saveAssetMove(${t.assetid})">Move Asset</button>
        <button onclick="showAssetSetup()">Cancel</button>
      </div>
    </div>
  `,filterMoveAssetSections(t.sectionid)},window.filterMoveAssetSections=function(e=``){let t=document.querySelector(`#moveAssetSite`)?.value||``,n=document.querySelector(`#moveAssetSection`);if(n){if(!t){n.innerHTML=`<option value="">Select Site First</option>`;return}n.innerHTML=`
    <option value="">Select Section</option>
    ${U.filter(e=>String(e.siteid)===String(t)&&!(e.archived===!0||e.archived===`true`)).sort((e,t)=>(e.sectionname||``).localeCompare(t.sectionname||``)).map(t=>`
      <option value="${l(t.sectionid)}" ${String(t.sectionid)===String(e)?`selected`:``}>
        ${c(t.sectionname)}
      </option>
    `).join(``)}
  `}},window.saveAssetMove=async function(e){if(!J()){alert(`You do not have permission to move assets.`);return}let t=document.querySelector(`#moveAssetSite`)?.value||``,n=document.querySelector(`#moveAssetSection`)?.value||``;if(!t||!n){alert(`Please select the new site and section`);return}let r=await fetch(`${g}/assets/${e}/move`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({siteid:t,sectionid:n})}),i=await r.json();if(!r.ok){alert(i.error||`Unable to move asset`);return}alert(`Asset moved successfully`),await $(),showAssetSetup()};function v(e,t={}){let n=``;return e===`100`&&(n=`
      <div class="form-group"><label>WLL(kg)</label><input id="editAssetWLL" type="number" value="${l(t.wll||``)}"></div>
      <div class="form-group"><label>Height of Lift(mm)</label><input id="editAssetHeightOfLift" type="number" value="${l(t.heightoflift||``)}"></div>
      <div class="form-group"><label>Number of Chain Falls</label><input id="editAssetNumberOfChainFalls" type="number" value="${l(t.numberofchainfalls||``)}"></div>
      <div class="form-group"><label>OEM Top Hook Size(mm)</label><input id="editAssetOEMTopHookSize" type="number" value="${l(t.oemtophooksize||``)}"></div>
      <div class="form-group"><label>OEM Bottom Hook Size(mm)</label><input id="editAssetOEMBottomHookSize" type="number" value="${l(t.oembottomhooksize||``)}"></div>
      <div class="form-group"><label>Load Chain Diameter(mm)</label><input id="editAssetLoadChainDiameter" type="number" value="${l(t.loadchaindiameter||``)}"></div>
    `),e===`200`&&(n=`
      <div class="form-group"><label>WLL(kg)</label><input id="editAssetWLL" type="number" value="${l(t.wll||``)}"></div>
      <div class="form-group"><label>Effective Length(mm)</label><input id="editAssetEffectiveLength" type="number" value="${l(t.effectivelength||``)}"></div>
    `),(e===`300`||e===`600`)&&(n=`
      <div class="form-group"><label>WLL(kg)</label><input id="editAssetWLL" type="number" value="${l(t.wll||``)}"></div>
    `),e===`400`&&(n=`
      <div class="form-group"><label>Main Hoist WLL(kg)</label><input id="editAssetWLL" type="number" value="${l(t.wll||``)}"></div>
      <div class="form-group"><label>Auxiliary Hoist WLL(kg)</label><input id="editAssetAuxHoistWLL" type="number" value="${l(t.auxhoistwll||``)}"></div>
      <div class="form-group"><label>Span(mm)</label><input id="editAssetSpan" type="number" value="${l(t.span||``)}"></div>
      <div class="form-group"><label>Permissible Deflection(mm)</label><input id="editAssetPermissibleDeflection" type="number" value="${l(t.permissibledeflection||``)}"></div>
      <div class="form-group"><label>Main Hoist Description</label><input id="editAssetHoistDescription" type="text" value="${l(t.hoistdescription||``)}"></div>
      <div class="form-group"><label>Main Hoist Serial No</label><input id="editAssetHoistSerialNo" type="text" value="${l(t.hoistserialno||``)}"></div>
      <div class="form-group"><label>Auxiliary Hoist Description</label><input id="editAssetAuxHoistDescription" type="text" value="${l(t.auxhoistdescription||``)}"></div>
      <div class="form-group"><label>Auxiliary Hoist Serial No</label><input id="editAssetAuxHoistSerialNo" type="text" value="${l(t.auxhoistserialno||``)}"></div>
      <div class="form-group"><label>Main Hoist Hook Size(mm)</label><input id="editAssetHookSize" type="number" value="${l(t.hooksize||``)}"></div>
      <div class="form-group"><label>Auxiliary Hoist Hook Size(mm)</label><input id="editAssetAuxHoistHookSize" type="number" value="${l(t.auxhoisthooksize||``)}"></div>
      <div class="form-group"><label>Height of Lift(mm)</label><input id="editAssetHeightOfLift" type="number" value="${l(t.heightoflift||``)}"></div>
      <div class="form-group"><label>Main Hoist Steel Wire Rope(mm)</label><input id="editAssetSteelWireRopeMM" type="number" value="${l(t.steelwireropemm||``)}"></div>
      <div class="form-group"><label>Auxiliary Hoist Steel Wire Rope(mm)</label><input id="editAssetAuxHoistRopeMM" type="number" value="${l(t.auxhoistropemm||``)}"></div>
    `),e===`500`&&(n=`
      <div class="form-group"><label>WLL(kg)</label><input id="editAssetWLL" type="number" value="${l(t.wll||``)}"></div>
      <div class="form-group"><label>Span(mm)</label><input id="editAssetSpan" type="number" value="${l(t.span||``)}"></div>
      <div class="form-group"><label>Permissible Deflection(mm)</label><input id="editAssetPermissibleDeflection" type="number" value="${l(t.permissibledeflection||``)}"></div>
      <div class="form-group"><label>Hook Size(mm)</label><input id="editAssetHookSize" type="number" value="${l(t.hooksize||``)}"></div>
      <div class="form-group"><label>Hoist Description</label><input id="editAssetHoistDescription" type="text" value="${l(t.hoistdescription||``)}"></div>
      <div class="form-group"><label>Hoist Serial No</label><input id="editAssetHoistSerialNo" type="text" value="${l(t.hoistserialno||``)}"></div>
    `),n}function be(e={}){let t=(t,n)=>document.querySelector(t)?.value??e[n]??``;return{manufactdate:((t,n)=>{let r=document.querySelector(t)?.value??e[n]??``;return String(r||``).slice(0,10)})(`#editAssetManufactDate`,`manufactdate`),wll:t(`#editAssetWLL`,`wll`),heightoflift:t(`#editAssetHeightOfLift`,`heightoflift`),numberofchainfalls:t(`#editAssetNumberOfChainFalls`,`numberofchainfalls`),oemtophooksize:t(`#editAssetOEMTopHookSize`,`oemtophooksize`),oembottomhooksize:t(`#editAssetOEMBottomHookSize`,`oembottomhooksize`),loadchaindiameter:t(`#editAssetLoadChainDiameter`,`loadchaindiameter`),effectivelength:t(`#editAssetEffectiveLength`,`effectivelength`),span:t(`#editAssetSpan`,`span`),permissibledeflection:t(`#editAssetPermissibleDeflection`,`permissibledeflection`),hooksize:t(`#editAssetHookSize`,`hooksize`),steelwireropemm:t(`#editAssetSteelWireRopeMM`,`steelwireropemm`),hoistdescription:t(`#editAssetHoistDescription`,`hoistdescription`),hoistserialno:t(`#editAssetHoistSerialNo`,`hoistserialno`),auxhoistdescription:t(`#editAssetAuxHoistDescription`,`auxhoistdescription`),auxhoistserialno:t(`#editAssetAuxHoistSerialNo`,`auxhoistserialno`),auxhoistwll:t(`#editAssetAuxHoistWLL`,`auxhoistwll`),auxhoisthooksize:t(`#editAssetAuxHoistHookSize`,`auxhoisthooksize`),auxhoistropemm:t(`#editAssetAuxHoistRopeMM`,`auxhoistropemm`)}}window.refreshEditAssetDynamicFields=function(){let e=document.querySelector(`#editAssetEquipType`)?.value,t=W.find(t=>String(t.equiptypeid)===String(e)),n=String(t?.equipgroupid||``),r=document.querySelector(`#editDynamicAssetFields`),i=document.querySelector(`#editManufactureDateRow`),a=document.querySelector(`#editAssetManufactDate`);r&&(r.innerHTML=v(n,be()),i&&(i.style.display=n===`400`?`flex`:`none`),a&&n!==`400`&&(a.value=``))},window.editAsset=async function(e){if(!mt()){pt();return}_();let t;try{t=await Tt(e)}catch(e){alert(e.message||`Asset not found`);return}let n=W.find(e=>String(e.equiptypeid)===String(t.equiptypeid)),r=String(n?.equipgroupid||``),i=v(r,t),a=r===`400`,o=[...W].sort((e,t)=>(e.description||``).localeCompare(t.description||``)).map(e=>`
      <option value="${l(e.equiptypeid)}" ${String(e.equiptypeid)===String(t.equiptypeid)?`selected`:``}>
        ${c(e.description)}
      </option>
    `).join(``);document.querySelector(`#page`).innerHTML=`
    <h2>Edit Asset ${c(t.assetid)}</h2>

    <div class="filter-card">
      <div class="asset-form-grid">

        <div class="form-group">
          <label>Equipment Type</label>
          <select id="editAssetEquipType" onchange="refreshEditAssetDynamicFields()">
            <option value="">Select Equipment Type</option>
            ${o}
          </select>
        </div>

        <div class="form-group">
          <label>Serial No</label>
          <input id="editAssetSerialNo" type="text" value="${l(t.serialno||``)}">
        </div>

        <div class="form-group">
          <label>Asset Tag Number <span class="optional-label">(Optional)</span></label>
          <input id="editAssetTagNo" type="text" value="${l(t.assettagno||``)}" placeholder="Customer tag / plant number if available">
        </div>

        <div class="form-group">
          <label>Manufacturer</label>
          <input id="editAssetManufacturer" type="text" value="${l(t.manufacturer||``)}">
        </div>

        <div class="form-group" id="editManufactureDateRow" style="${a?``:`display:none;`}">
          <label>Manufacture Date</label>
          <input id="editAssetManufactDate" type="date" value="${l(String(t.manufactdate||``).slice(0,10))}">
        </div>

        <div id="editDynamicAssetFields" class="dynamic-asset-fields">
          ${i}
        </div>

        <div class="form-group asset-description">
          <label>Description</label>
          <textarea id="editAssetDescription" rows="4">${c(t.description||``)}</textarea>
        </div>

        <div class="asset-photo-row">
          <div class="form-group">
            <label>Replace Photo 1</label>
            <input id="assetPhoto1" type="file" accept="image/*">
          </div>

          <div class="form-group">
            <label>Replace Photo 2</label>
            <input id="assetPhoto2" type="file" accept="image/*">
          </div>
        </div>

        <div class="form-actions">
          <button onclick="saveAssetChanges(${t.assetid})">
            Save Changes
          </button>

          <button onclick="uploadAssetPhotos(${t.assetid})">
            Upload Photos
          </button>

          <button onclick="showAssetSetup()">
            Cancel
          </button>

          ${J()?`
            <button class="danger-btn" onclick="archiveAsset(${t.assetid})">
              Archive
            </button>
          `:``}
        </div>

      </div>
    </div>

    <div class="photo-preview-grid">
      ${t.media1?`
        <div class="photo-card">
          <h3>Photo 1</h3>
          <img src="${l(me(t.media1))}">
          ${J()?`
            <button
              type="button"
              class="danger-btn photo-delete-btn"
              onclick="deleteAssetPhoto(${t.assetid}, 1)"
            >
              Delete Photo 1
            </button>
          `:``}
        </div>
      `:``}

      ${t.media2?`
        <div class="photo-card">
          <h3>Photo 2</h3>
          <img src="${l(me(t.media2))}">
          ${J()?`
            <button
              type="button"
              class="danger-btn photo-delete-btn"
              onclick="deleteAssetPhoto(${t.assetid}, 2)"
            >
              Delete Photo 2
            </button>
          `:``}
        </div>
      `:``}
    </div>
  `},window.saveAssetChanges=async function(e){if(!mt()){alert(`You do not have permission to edit assets.`);return}let t=document.querySelector(`#editAssetEquipType`)?.value||null,n=document.querySelector(`#editAssetSerialNo`).value,r=document.querySelector(`#editAssetTagNo`)?.value||``,i=document.querySelector(`#editAssetManufacturer`).value,a=document.querySelector(`#editAssetManufactDate`)?.value||``,o=document.querySelector(`#editAssetDescription`).value,s=await fetch(`${g}/assets/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({equiptypeid:t,serialno:n,assettagno:r,manufacturer:i,manufactdate:a,description:o,wll:document.querySelector(`#editAssetWLL`)?.value||null,heightoflift:document.querySelector(`#editAssetHeightOfLift`)?.value||null,numberofchainfalls:document.querySelector(`#editAssetNumberOfChainFalls`)?.value||null,oemtophooksize:document.querySelector(`#editAssetOEMTopHookSize`)?.value||null,oembottomhooksize:document.querySelector(`#editAssetOEMBottomHookSize`)?.value||null,loadchaindiameter:document.querySelector(`#editAssetLoadChainDiameter`)?.value||null,effectivelength:document.querySelector(`#editAssetEffectiveLength`)?.value||null,span:document.querySelector(`#editAssetSpan`)?.value||null,permissibledeflection:document.querySelector(`#editAssetPermissibleDeflection`)?.value||null,hooksize:document.querySelector(`#editAssetHookSize`)?.value||null,steelwireropemm:document.querySelector(`#editAssetSteelWireRopeMM`)?.value||null,hoistdescription:document.querySelector(`#editAssetHoistDescription`)?.value||null,hoistserialno:document.querySelector(`#editAssetHoistSerialNo`)?.value||null,auxhoistdescription:document.querySelector(`#editAssetAuxHoistDescription`)?.value||null,auxhoistserialno:document.querySelector(`#editAssetAuxHoistSerialNo`)?.value||null,auxhoistwll:document.querySelector(`#editAssetAuxHoistWLL`)?.value||null,auxhoisthooksize:document.querySelector(`#editAssetAuxHoistHookSize`)?.value||null,auxhoistropemm:document.querySelector(`#editAssetAuxHoistRopeMM`)?.value||null})}),c=await s.json();if(!s.ok){alert(`Error updating asset: `+c.error);return}alert(`Asset updated: `+c.assetid),await $(),showAssetSetup()},window.archiveAsset=async function(e){if(!J()){alert(`You do not have permission to archive assets.`);return}if(!confirm(`Archive asset `+e+`? It will be hidden but its inspection history will remain.`))return;let t=await fetch(`${g}/assets/${e}/archive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(`Error archiving asset: `+n.error);return}alert(`Asset archived: `+n.assetid),await $(),showAssetSetup()},window.unarchiveAsset=async function(e){if(!J()){alert(`You do not have permission to restore assets.`);return}if(!confirm(`Restore asset `+e+`?`))return;let t=await fetch(`${g}/assets/${e}/unarchive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(`Error restoring asset: `+n.error);return}alert(`Asset restored: `+n.assetid),await $(),showAssetSetup()},window.uploadAssetPhotos=async function(e){if(!mt()){alert(`You do not have permission to update asset photos.`);return}let t=document.querySelector(`#assetPhoto1`).files[0],n=document.querySelector(`#assetPhoto2`).files[0];if(!t&&!n){alert(`Please choose at least one photo`);return}if(!ge([t,n]))return;let r=new FormData;t&&r.append(`photo1`,t),n&&r.append(`photo2`,n);let i=await fetch(`${g}/assets/${e}/photos`,{method:`POST`,body:r}),a=await L(i);if(!i.ok){alert(`Error uploading photos: `+a.error);return}alert(`Photos uploaded for asset `+a.assetid),await $(),editAsset(e)},window.deleteAssetPhoto=async function(e,t){if(!J()){alert(`You do not have permission to delete asset photos.`);return}if(!confirm(`Delete asset photo ${t}?`))return;let n=await fetch(`${g}/assets/${e}/photos/${t}`,{method:`DELETE`}),r=await L(n);if(!n.ok){alert(`Error deleting photo: `+r.error);return}alert(`Asset photo ${t} deleted successfully`),await $(),editAsset(e)},window.showEquipmentTypeCriteria=function(){K(`criteria`)&&(localStorage.setItem(`currentPage`,`criteria`),window.criteriaEquipmentFilter=window.criteriaEquipmentFilter||``,ce(W,G))},window.filterEquipmentCriteria=function(){window.criteriaEquipmentFilter=document.querySelector(`#criteriaEquipmentFilter`)?.value||``,window.criteriaCurrentPage=1,showEquipmentTypeCriteria()},window.setCriteriaRowsPerPage=function(e){window.criteriaRowsPerPage=Number(e)||25,window.criteriaCurrentPage=1,showEquipmentTypeCriteria()},window.goToCriteriaPage=function(e){window.criteriaCurrentPage=Math.max(1,Number(e)||1),showEquipmentTypeCriteria()};function y(e){return l(e)}function xe(e={}){let t=[...W].sort((e,t)=>(e.description||``).localeCompare(t.description||``)),n=e.equiptypeid||window.criteriaEquipmentFilter||t[0]?.equiptypeid||``,r=e.inspectioncategory||`VISUAL`,i=e.fieldtype||`PASS_FAIL`,a=e.resulttype||(i===`NUMBER`?`MEASURED`:`PASS_FAIL`),o=e.inspection_category||`PERIODIC_THOROUGH_INSPECTION`,s=e.severity||`MINOR`;document.querySelector(`#criteriaPopup`)?.remove(),document.body.insertAdjacentHTML(`beforeend`,`
    <div
      id="criteriaPopup"
      class="criteria-modal-overlay"
      onclick="closeCriteriaPopupOnBackdrop(event)"
    >
      <div class="criteria-modal" role="dialog" aria-modal="true" aria-labelledby="criteriaPopupTitle">
        <div class="criteria-modal-header">
          <h2 id="criteriaPopupTitle">
            ${e.criteriaid?`Edit Criteria`:`Add Criteria`}
          </h2>

          <button type="button" onclick="cancelCriteriaEdit()">
            Close
          </button>
        </div>

        <div class="criteria-modal-body">
          <input id="editingCriteriaId" type="hidden" value="${l(e.criteriaid||``)}">

          <div class="form-row">
            <div class="form-group">
              <label>Equipment Type</label>
              <select id="criteriaEquipType">
                ${t.map(e=>`
                  <option
                    value="${l(e.equiptypeid)}"
                    ${String(e.equiptypeid)===String(n)?`selected`:``}
                  >
                    ${c(e.description)}
                  </option>
                `).join(``)}
              </select>
            </div>

            <div class="form-group">
              <label>Inspection Type</label>
              <select id="criteriaCategory">
                <option value="VISUAL" ${r===`VISUAL`?`selected`:``}>
                  Visual Inspection
                </option>
                <option value="LOADTEST" ${r===`LOADTEST`?`selected`:``}>
                  Load Test
                </option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group form-group-wide">
              <label>Criteria Name</label>
              <input id="criteriaName" type="text" value="${y(e.criteriadescription||e.criterianame)}">
            </div>

            <div class="form-group">
              <label>Field Type</label>
              <select id="criteriaFieldType">
                <option value="PASS_FAIL" ${i===`PASS_FAIL`||i===`PASSFAIL`?`selected`:``}>Pass / Fail / N/A</option>
                <option value="TEXT" ${i===`TEXT`?`selected`:``}>Text Input</option>
                <option value="NUMBER" ${i===`NUMBER`?`selected`:``}>Number Input</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Result Type</label>
              <select id="criteriaResultType">
                <option value="PASS_FAIL" ${a===`PASS_FAIL`?`selected`:``}>PASS / FAIL</option>
                <option value="MEASURED" ${a===`MEASURED`?`selected`:``}>Measured</option>
                <option value="YES_NO" ${a===`YES_NO`?`selected`:``}>YES / NO</option>
              </select>
            </div>

            <div class="form-group">
              <label>Inspection Category</label>
              <select id="criteriaInspectionGroup">
                <option value="FREQUENT_INSPECTION" ${o===`FREQUENT_INSPECTION`?`selected`:``}>
                  Frequent Inspection
                </option>
                <option value="PERIODIC_THOROUGH_INSPECTION" ${o===`PERIODIC_THOROUGH_INSPECTION`?`selected`:``}>
                  Periodic Thorough Inspection
                </option>
              </select>
            </div>

            <div class="form-group">
              <label>Severity</label>
              <select id="criteriaSeverity">
                <option value="CRITICAL" ${s===`CRITICAL`?`selected`:``}>Critical</option>
                <option value="MAJOR" ${s===`MAJOR`?`selected`:``}>Major</option>
                <option value="MINOR" ${s===`MINOR`?`selected`:``}>Minor</option>
                <option value="OBSERVATION" ${s===`OBSERVATION`?`selected`:``}>Observation</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Display Order</label>
              <input id="criteriaDisplayOrder" type="number" min="1" value="${y(e.displayorder||e.sortorder||1)}">
            </div>

            <div class="form-group">
              <label>Active</label>
              <select id="criteriaActive">
                <option value="true" ${e.active===!1?``:`selected`}>Active</option>
                <option value="false" ${e.active===!1?`selected`:``}>Inactive</option>
              </select>
            </div>
          </div>
        </div>

        <div class="criteria-modal-footer">
          <button type="button" onclick="cancelCriteriaEdit()">
            Cancel
          </button>

          <button type="button" onclick="saveCriteria()">
            Save Criteria
          </button>
        </div>
      </div>
    </div>
  `),document.querySelector(`#criteriaName`)?.focus()}window.openCriteriaPopup=function(){xe()},window.closeCriteriaPopupOnBackdrop=function(e){e.target.id===`criteriaPopup`&&cancelCriteriaEdit()},window.saveCriteria=async function(){let e=document.querySelector(`#editingCriteriaId`)?.value||``,t=document.querySelector(`#criteriaEquipType`).value,n=document.querySelector(`#criteriaCategory`).value,r=document.querySelector(`#criteriaName`).value;if(!r){alert(`Please enter a criteria name`);return}let i={equiptypeid:t,criterianame:r,criteriadescription:r,fieldtype:document.querySelector(`#criteriaFieldType`).value,resulttype:document.querySelector(`#criteriaResultType`).value,required:!0,sortorder:Number(document.querySelector(`#criteriaDisplayOrder`)?.value||1),displayorder:Number(document.querySelector(`#criteriaDisplayOrder`)?.value||1),inspectioncategory:n,inspection_category:document.querySelector(`#criteriaInspectionGroup`).value,severity:document.querySelector(`#criteriaSeverity`).value,active:document.querySelector(`#criteriaActive`).value===`true`},a=await fetch(e?`${g}/equipment-type-criteria/${e}`:`${g}/equipment-type-criteria`,{method:e?`PUT`:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(i)}),o=await a.json();if(!a.ok){alert(`Error saving criteria: `+o.error);return}alert(e?`Criteria updated`:`Criteria saved`),await $(),cancelCriteriaEdit(),showEquipmentTypeCriteria()},window.editCriteria=function(e){let t=G.find(t=>String(t.criteriaid)===String(e));if(!t){alert(`Criteria not found`);return}xe(t)},window.cancelCriteriaEdit=function(){document.querySelector(`#criteriaPopup`)?.remove()},window.deleteCriteria=async function(e){let t=G.find(t=>String(t.criteriaid)===String(e));if(!t){alert(`Criteria not found`);return}if(!confirm(`Delete this criteria?\n\n${t.criterianame}\n\nThis removes it from future inspection/load test forms.`))return;let n=await fetch(`${g}/equipment-type-criteria/${e}`,{method:`DELETE`}),r=await n.json();if(!n.ok){alert(`Error deleting criteria: `+r.error);return}alert(`Criteria deleted`),await $(),showEquipmentTypeCriteria()},window.showInspections=async function(){K(`inspections`)&&(localStorage.setItem(`currentPage`,`inspections`),await Oe())},window.showCertificateSearch=function(){K(`certificates`)&&(localStorage.setItem(`currentPage`,`certificates`),ve(z,V,U))},window.showCustomerDetailedReport=function(e={}){K(`customer-report`)&&(localStorage.setItem(`currentPage`,`customer-report`),ke(z,W,V,U,H,e))},window.showSystemHealth=function(){K(`system-health`)&&(localStorage.setItem(`currentPage`,`system-health`),st())},window.handleCertificateEnter=function(e){e.key===`Enter`&&searchCertificates()},window.filterCertificateSites=function(){let e=document.querySelector(`#certClient`).value,t=document.querySelector(`#certSite`),n=document.querySelector(`#certSection`);n.innerHTML=`<option value="">All Sections</option>`,t.innerHTML=`
    <option value="">All Sites</option>
    ${(e?V.filter(t=>String(t.clientid)===String(e)):V).map(e=>`
      <option value="${l(e.siteid)}">
        ${c(e.sitename)}
      </option>
    `).join(``)}
  `},window.filterCertificateSections=function(){let e=document.querySelector(`#certSite`).value,t=document.querySelector(`#certSection`);t.innerHTML=`
    <option value="">All Sections</option>
    ${(e?U.filter(t=>String(t.siteid)===String(e)):U).map(e=>`
      <option value="${l(e.sectionid)}">
        ${c(e.sectionname)}
      </option>
    `).join(``)}
  `},window.clearCertificateSearch=function(){document.querySelector(`#certSearch`).value=``,document.querySelector(`#certInspectionType`).value=``,document.querySelector(`#certStatus`).value=``,document.querySelector(`#certClient`).value=``,document.querySelector(`#certSite`).innerHTML=`<option value="">All Sites</option>`,document.querySelector(`#certSection`).innerHTML=`<option value="">All Sections</option>`,document.querySelector(`#certDateFrom`).value=``,document.querySelector(`#certDateTo`).value=``,window.certCurrentPage=1,searchCertificates()},window.searchCertificates=async function(t=!0){t&&(window.certCurrentPage=1);let n=new URLSearchParams;n.append(`search`,document.querySelector(`#certSearch`)?.value||``),n.append(`inspectiontype`,document.querySelector(`#certInspectionType`)?.value||``),n.append(`status`,document.querySelector(`#certStatus`)?.value||``),n.append(`clientid`,document.querySelector(`#certClient`)?.value||``),n.append(`siteid`,document.querySelector(`#certSite`)?.value||``),n.append(`sectionid`,document.querySelector(`#certSection`)?.value||``),n.append(`datefrom`,document.querySelector(`#certDateFrom`)?.value||``),n.append(`dateto`,document.querySelector(`#certDateTo`)?.value||``),n.append(`page`,String(window.certCurrentPage||1)),n.append(`limit`,String(window.certRowsPerPage||25));let r=e(`certificates`,`testid`,`desc`);n.append(`sortKey`,r.key||`testid`),n.append(`sortDir`,r.direction||`desc`);let i=await fetch(`${g}/certificates/search?${n.toString()}`),a=await i.json();if(!i.ok){alert(`Error searching certificates: `+a.error);return}let o=Array.isArray(a)?a:a.rows||[];window.currentCertificatePageInfo=Array.isArray(a)?null:{currentPage:Number(a.page||1),pageSize:Number(a.limit||window.certRowsPerPage||25),totalRows:Number(a.total||o.length),totalPages:Number(a.totalPages||1),startIndex:(Number(a.page||1)-1)*Number(a.limit||window.certRowsPerPage||25),endIndex:(Number(a.page||1)-1)*Number(a.limit||window.certRowsPerPage||25)+o.length};let s=a.summary||null,c=s?s.safe:o.filter(e=>e.status===`SAFE`).length,l=s?s.notSafe:o.filter(e=>e.status===`NOT SAFE`).length,u=s?s.loadTest:o.filter(e=>e.inspectiontype===`LOADTEST`).length,d=s?s.visual:o.filter(e=>e.inspectiontype===`VISUAL`).length,f=s?Number(s.total||window.currentCertificatePageInfo?.totalRows||o.length):o.length;if(document.querySelector(`#certificateStats`).innerHTML=`
    <p><strong>Total:</strong> ${f||window.currentCertificatePageInfo?.totalRows||o.length}</p>
    <p><strong>Safe:</strong> ${c}</p>
    <p><strong>Not Safe:</strong> ${l}</p>
    <p><strong>Visual:</strong> ${d}</p>
    <p><strong>Load Tests:</strong> ${u}</p>
  `,o.length===0){document.querySelector(`#certificateResults`).innerHTML=`
      <p>No certificates found.</p>
    `;return}window.currentCertificateResults=o,Se(o)};function b(t,n){let r=e(`certificates`,`testid`,`desc`),i=r.key===n,a=i?r.direction===`desc`?`v`:`^`:`^v`;return`
    <span class="certificate-sort-heading">
      <span>${t}</span>
      <button
        type="button"
        class="certificate-sort-btn ${i?`active`:``}"
        onclick="sortTable('certificates', '${n}', 'rerenderCertificateResults')"
        aria-label="Sort ${t}"
        title="Sort ${t}"
      >${a}</button>
    </span>
  `}window.rerenderCertificateResults=function(){window.certCurrentPage=1,searchCertificates(!1)};function Se(e){let n=window.currentCertificatePageInfo?e:t(e,`certificates`,{testid:e=>e.testid,tagnumber:e=>e.tagnumber,clientname:e=>e.clientname,sitename:e=>e.sitename,description:e=>e.description,serialno:e=>e.serialno,inspectiontype:e=>e.inspectiontype,testdate:e=>e.testdate,status:e=>e.status,inspector:e=>e.inspector},`testid`,`desc`),r=window.currentCertificatePageInfo?{...window.currentCertificatePageInfo,rows:n}:i(n,`certCurrentPage`,`certRowsPerPage`);document.querySelector(`#certificateResults`).innerHTML=`
    ${a({...r,label:`certificates`,onPage:`goToCertificatePage`,onPageSize:`setCertificateRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${b(`Test ID`,`testid`)}</th>
          <th>${b(`Tag No`,`tagnumber`)}</th>
          <th>${b(`Client`,`clientname`)}</th>
          <th>${b(`Site`,`sitename`)}</th>
          <th>${b(`Asset`,`description`)}</th>
          <th>${b(`Serial No`,`serialno`)}</th>
          <th>${b(`Type`,`inspectiontype`)}</th>
          <th>${b(`Date`,`testdate`)}</th>
          <th>${b(`Status`,`status`)}</th>
          <th>${b(`Inspector`,`inspector`)}</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody>
        ${r.rows.map(e=>`
          <tr>
            <td>${c(e.testid)}</td>
            <td>${c(e.tagnumber||`-`)}</td>
            <td>${c(e.clientname||``)}</td>
            <td>${c(e.sitename||``)}</td>
            <td>${c(e.description||``)}</td>
            <td>${c(e.serialno||``)}</td>
            <td>${c(e.inspectiontype||``)}</td>
            <td>${c(e.testdate?e.testdate.split(`T`)[0]:``)}</td>
            <td>
              <strong class="${e.status===`SAFE`?`status-safe`:`status-unsafe`}">
                ${c(e.status||``)}
              </strong>
            </td>
            <td>${c(e.inspector||`-`)}</td>
            <td>
              <button onclick="previewCertificate(${e.testid})">Preview</button>
              <button onclick="openCertificateModal(${e.testid})">View</button>
              <a
                class="cert-action-link"
                href="${l(`${g}/inspections/${encodeURIComponent(e.testid)}/certificate.pdf?t=${Date.now()}`)}"
                download="certificate-${l(e.testid)}.pdf"
              >
                Download PDF
              </a>
              <button onclick="mailCertificate(${e.testid})">Mail</button>
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `}window.setCertificateRowsPerPage=function(e){window.certRowsPerPage=Number(e)||25,window.certCurrentPage=1,searchCertificates(!1)},window.goToCertificatePage=function(e){window.certCurrentPage=Math.max(1,Number(e)||1),searchCertificates(!1)},window.openCertificateFromSearch=function(){let e=document.querySelector(`#certificateSearch`).value.trim();if(!e){alert(`Enter a certificate number`);return}openCertificateModal(e)},window.showQuickInspection=function(){K(`quick-inspection`)&&(localStorage.setItem(`currentPage`,`quick-inspection`),ue())},window.handleQuickInspectionEnter=function(e){e.key===`Enter`&&quickFindAsset()};function Ce(e=``){let t=String(e||``).trim(),n=t.toLowerCase(),r=t.match(/[?&]qr=([^&\s]+)/i);if(r)return decodeURIComponent(r[1]).trim();let i=t.match(/ATEC-ASSET-\d+/i);if(i)return i[0].trim();let a=t.match(/(?:Asset ID|Serial No|Hoist Serial No|Asset Tag)\s*:\s*([^\n\r]+)/i);if(a){let e=a[1].replace(/^-$/,``).trim();if(e)return e}if(n.includes(`atec asset label`)){let e=t.split(/\r?\n/).map(e=>e.trim()).find(e=>e&&!/^(atec asset label|website|landline|equipment|status|inspection pdf|load test pdf|last |next )/i.test(e));if(e)return e.replace(/^[^:]+:\s*/,``).trim()}return t}window.quickFindAsset=async function(){let e=document.querySelector(`#quickAssetSearch`),t=Ce(e?.value||``),n=t.toLowerCase().trim();e&&t!==e.value.trim()&&(e.value=t);let r=document.querySelector(`#quickInspectionResult`);if(!n){r.innerHTML=`
      <p>Please scan or enter an asset number.</p>
    `;return}let i=B.filter(e=>String(e.assetid||``).toLowerCase().includes(n)||(e.assettagno||``).toLowerCase().includes(n)||(e.serialno||``).toLowerCase().includes(n)||(e.hoistserialno||``).toLowerCase().includes(n)||(e.auxhoistserialno||``).toLowerCase().includes(n)||(e.qrcode||``).toLowerCase().includes(n));if(i.length===0){try{let e=await fetch(`${g}/assets/qr/${encodeURIComponent(n)}`);if(e.ok){let t=await e.json();quickOpenAsset(t.assetid);return}let t=await fetch(`${g}/inspections/assets/search?q=${encodeURIComponent(n)}`);if(t.ok){let e=await t.json();if(e.length===1){quickOpenAsset(e[0].assetid);return}if(e.length>1){r.innerHTML=`
            <div class="filter-card">
              <h3>Multiple Assets Found</h3>
              <p>Please select the correct asset.</p>

              <table>
                <thead>
                  <tr>
                    <th>Asset ID</th>
                    <th>Asset Tag</th>
                    <th>Serial No</th>
                    <th>Description</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  ${e.map(e=>`
                    <tr>
                      <td>${c(e.assetid)}</td>
                      <td>${c(e.assettagno||``)}</td>
                      <td>${c(e.serialno||e.hoistserialno||e.auxhoistserialno||``)}</td>
                      <td>${c(e.description||``)}</td>
                      <td>
                        <button onclick="quickOpenAsset(${e.assetid})">
                          Select
                        </button>
                      </td>
                    </tr>
                  `).join(``)}
                </tbody>
              </table>
            </div>
          `;return}}}catch(e){console.error(`Asset lookup failed:`,e)}r.innerHTML=`
      <div class="filter-card">
        <h3>No Asset Found</h3>
        <p>No asset matched: <strong>${c(n)}</strong></p>
      </div>
    `;return}if(i.length>1){r.innerHTML=`
      <div class="filter-card">
        <h3>Multiple Assets Found</h3>
        <p>Please select the correct asset.</p>

        <table>
          <thead>
            <tr>
              <th>Asset ID</th>
              <th>Asset Tag</th>
              <th>Serial No</th>
              <th>Description</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            ${i.map(e=>`
              <tr>
                <td>${c(e.assetid)}</td>
                <td>${c(e.assettagno||``)}</td>
                <td>${c(e.serialno||``)}</td>
                <td>${c(e.description||``)}</td>
                <td>
                  <button onclick="quickOpenAsset(${e.assetid})">
                    Select
                  </button>
                </td>
              </tr>
            `).join(``)}
          </tbody>
        </table>
      </div>
    `;return}quickOpenAsset(i[0].assetid)};let x=null,we=!1;window.startQuickCameraScan=async function(){let e=document.querySelector(`#quickCameraScanner`),t=document.querySelector(`#quickCameraVideo`),n=document.querySelector(`#quickScanStatus`);if(!(`BarcodeDetector`in window)){n&&(n.textContent=`Camera scanning is not supported by this browser. Use the scan/type box above.`),e?.removeAttribute(`hidden`);return}try{let r=await window.BarcodeDetector.getSupportedFormats(),i=[`qr_code`,`code_128`,`code_39`,`ean_13`].filter(e=>r.includes(e)),a=new window.BarcodeDetector({formats:i});x=await navigator.mediaDevices.getUserMedia({video:{facingMode:`environment`},audio:!1}),t.srcObject=x,e?.removeAttribute(`hidden`),await t.play(),we=!0,n&&(n.textContent=`Scanning... point the camera at the QR label or barcode.`);let o=async()=>{if(we){try{let e=await a.detect(t);if(e.length){let t=Ce(e[0].rawValue);document.querySelector(`#quickAssetSearch`).value=t,stopQuickCameraScan(),quickFindAsset();return}}catch(e){console.error(`Quick camera scan failed:`,e)}requestAnimationFrame(o)}};o()}catch(t){console.error(`Unable to start camera scanner:`,t),e?.removeAttribute(`hidden`),n&&(n.textContent=`Camera could not start. Please allow camera access or use the scan/type box.`)}},window.stopQuickCameraScan=function(){we=!1,x&&=(x.getTracks().forEach(e=>e.stop()),null);let e=document.querySelector(`#quickCameraVideo`);e&&(e.srcObject=null),document.querySelector(`#quickCameraScanner`)?.setAttribute(`hidden`,``)},window.quickOpenAsset=async function(e){let t=document.querySelector(`#quickInspectionResult`)||document.querySelector(`#dashboardAssetSearchResult`);if(!t){alert(`No asset result panel found`);return}let n=(t.id,`quick`),r=await fetch(`${g}/assets/${e}/quick-details`),i=await r.json();if(!r.ok){alert(`Asset details not found: `+i.error);return}t.innerHTML=`
    <div class="filter-card quick-result-card">
      <div class="quick-result-header">
        <h3>Asset Found</h3>
        <strong>${c(i.assetid)}</strong>
      </div>

      <div class="quick-asset-grid">

        <div class="quick-detail-grid">
          <p><span>Asset Tag</span><strong>${c(i.assettagno||`-`)}</strong></p>
          <p><span>Serial No</span><strong>${c(i.serialno||`-`)}</strong></p>
          <p><span>Equipment</span><strong>${c(i.equipmenttype||`-`)}</strong></p>
          <p class="quick-wide"><span>Description</span><strong>${c(i.description||`-`)}</strong></p>
          <p><span>Client</span><strong>${c(i.clientname||`-`)}</strong></p>
          <p><span>Site</span><strong>${c(i.sitename||`-`)}</strong></p>
          <p><span>Section</span><strong>${c(i.sectionname||`-`)}</strong></p>
        </div>

        <div class="quick-history-card">
          <h4>Inspection History</h4>
          <p><span>Last Visual</span><strong>${c(i.lastvisualdate?i.lastvisualdate.split(`T`)[0]:`No record`)}</strong><em>${c(i.lastvisualstatus||`-`)}</em></p>
          <p><span>Last Load Test</span><strong>${c(i.lastloadtestdate?i.lastloadtestdate.split(`T`)[0]:`No record`)}</strong><em>${c(i.lastloadteststatus||`-`)}</em></p>
        </div>

      </div>

      <div class="quick-result-bottom">
        <div class="quick-photo-grid">
        ${i.media1?`
          <div class="quick-photo-card">
            <img src="${l(me(i.media1))}">
            <span>Photo 1</span>
          </div>
        `:``}

        ${i.media2?`
          <div class="quick-photo-card">
            <img src="${l(me(i.media2))}">
            <span>Photo 2</span>
          </div>
        `:``}
        </div>

        <div class="form-actions quick-result-actions">
          <button onclick="startInspection(${i.assetid}, 'VISUAL', '${n}')">Visual Inspection</button>

          <button class="load-test-btn" onclick="startInspection(${i.assetid}, 'LOADTEST', '${n}')">Load Test</button>

          <button onclick="openAssetQrLabel(${i.assetid})">QR Label</button>
        </div>

      </div>
    </div>
  `},window.startQuickInspection=function(e,t){startInspection(e,t,`quick`)};function Te(){let e=document.querySelector(`#inspectionSearchType`),t=document.querySelector(`#inspectionAssetSearch`);window.inspectionAssetListState={searchType:e?e.value:window.inspectionAssetListState?.searchType||`all`,search:t?t.value:window.inspectionAssetListState?.search||``,currentPage:window.inspectionCurrentPage||window.inspectionAssetListState?.currentPage||1,rowsPerPage:Number(window.inspectionRowsPerPage||window.inspectionAssetListState?.rowsPerPage||25)}}function Ee(){let e=window.inspectionAssetListState||{},t=document.querySelector(`#inspectionSearchType`),n=document.querySelector(`#inspectionAssetSearch`);t&&(t.value=e.searchType||`all`),n&&(n.value=e.search||``)}function De(){let e=document.activeElement;return!e||![`inspectionAssetSearch`,`inspectionSearchType`].includes(e.id)?null:{id:e.id,selectionStart:typeof e.selectionStart==`number`?e.selectionStart:null,selectionEnd:typeof e.selectionEnd==`number`?e.selectionEnd:null}}function S(e){if(!e?.id)return;let t=document.getElementById(e.id);t&&(t.focus(),typeof t.setSelectionRange==`function`&&typeof e.selectionStart==`number`&&typeof e.selectionEnd==`number`&&t.setSelectionRange(e.selectionStart,e.selectionEnd))}let C=0;async function Oe(){let t=De();Te();let n=window.inspectionAssetListState||{},r=e(`inspectionAssets`,`client_section_serial`,`asc`),i=++C,a=await Q(`${g}/inspections/assets?${new URLSearchParams({page:String(window.inspectionCurrentPage||n.currentPage||1),limit:String(window.inspectionRowsPerPage||n.rowsPerPage||25),searchBy:n.searchType||`all`,search:n.search||``,sortKey:r.key||`client_section_serial`,sortDir:r.direction||`asc`,archiveMode:`active`}).toString()}`,{rows:[],total:0,page:1,limit:Number(window.inspectionRowsPerPage||25)});i===C&&(B=a.rows||[],window.inspectionCurrentPage=Number(a.page||window.inspectionCurrentPage||1),window.inspectionRowsPerPage=Number(a.limit||window.inspectionRowsPerPage||25),se(B,{serverPaged:!0,total:a.total||0,page:window.inspectionCurrentPage,limit:window.inspectionRowsPerPage}),Ee(),S(t))}window.filterInspectionAssets=async function(e=!1){e&&(window.inspectionCurrentPage=1),await Oe()},window.setInspectionFilterKey=function(e){let t=document.querySelector(`#inspectionSearchType`);t&&(t.value=e,filterInspectionAssets(!0))},window.setInspectionRowsPerPage=function(e){window.inspectionRowsPerPage=Number(e)||25,window.inspectionCurrentPage=1,filterInspectionAssets()},window.goToInspectionPage=function(e){window.inspectionCurrentPage=Math.max(1,Number(e)||1),filterInspectionAssets()};function Ae(e){return e!=null&&String(e).trim()!==``&&String(e).trim()!==`-`}function w(e,t,n=``){if(!Ae(t))return``;let r=n?` ${n}`:``;return`<div><span>${c(e)}</span><strong>${c(t)}${c(r)}</strong></div>`}let T={"Top Hook Dimensions":`oemtophooksize`,"Bottom Hook Dimensions":`oembottomhooksize`,"Load Chain Diameter":`loadchaindiameter`,"Hook Size mm":`hooksize`,"Hoist Serial Number":`hoistserialno`,"WLL Main Hoist - Load Mass kg":`wll`,"WLL Auxiliary Hoist - Load Mass kg":`auxhoistwll`,"SWL of Beam - Load Mass kg":`wll`,"SWL Installed Hoist - Load Mass kg":`wll`,"SWL of Beam - Length Span mm":`span`,"WLL Main Hoist - Length Span/Jib mm":`span`,"WLL Auxiliary Hoist - Length Span/Jib mm":`span`,"Permissible Deflection mm":`permissibledeflection`,"WLL Main Hoist - Deflection mm":`permissibledeflection`,"WLL Auxiliary Hoist - Deflection mm":`permissibledeflection`,"Steel Wire Rope mm":`steelwireropemm`};function E(e=``){return String(e).toLowerCase().replace(/\s+/g,` `).trim()}function je(e){let t=Number(e);return Number.isFinite(t)?String(Number.isInteger(t)?t:Number(t.toFixed(2))):``}function Me(e=new Date){let t=new Date(e);return t.setMinutes(t.getMinutes()-t.getTimezoneOffset()),t.toISOString().split(`T`)[0]}function Ne(e,t=`VISUAL`){let n=e?new Date(`${e}T00:00:00`):new Date,r=new Date(n);return t===`LOADTEST`?r.setFullYear(r.getFullYear()+1):r.setMonth(r.getMonth()+3),Me(r)}window.updateInspectionValidDateFromTestDate=function(e=`VISUAL`){let t=document.querySelector(`#inspectionTestDate`)?.value||``,n=document.querySelector(`#inspectionValidDate`);!n||!t||(n.value=Ne(t,e))};function Pe(e){return E([e?.criterianame,e?.criteriadescription].filter(Boolean).join(` `)).includes(`proof load`)}function Fe(e){let t=E([e?.criterianame,e?.criteriadescription].filter(Boolean).join(` `));return t.includes(`hook measured size`)||t.includes(`measured hook throat opening`)}let Ie=new Set([`401`,`402`,`404`,`406`]);function Le(e){let t=Number(e?.wll);return!Number.isFinite(t)||t<=0?``:je(t*(Ie.has(String(e?.equiptypeid))?1:1.1))}function D(e,t){let n=t?.criterianame||t?.criteriadescription||``,r=E(n),i=T[n],a=r.includes(`auxiliary hoist`);return i?e?.[i]||``:Pe(t)||Fe(t)?``:r.includes(`top hook`)?e?.oemtophooksize||e?.hooksize||``:r.includes(`bottom hook`)?e?.oembottomhooksize||e?.hooksize||``:r.includes(`load chain`)||r.includes(`chain diameter`)?e?.loadchaindiameter||``:r.includes(`load mass`)||r.includes(`swl installed hoist`)||r.includes(`swl of beam`)?a?e?.auxhoistwll||``:e?.wll||``:r.includes(`span`)||r.includes(`length span`)||r.includes(`span/jib`)?e?.span||``:r.includes(`deflection`)?e?.permissibledeflection||``:r.includes(`wire rope`)?a?e?.auxhoistropemm||``:e?.steelwireropemm||``:r.includes(`hook opening`)||r.includes(`hook size`)?a?e?.auxhoisthooksize||``:e?.hooksize||``:r.includes(`hoist serial`)?a?e?.auxhoistserialno||``:e?.hoistserialno||``:``}function Re(e,t,n){return Pe(t)?Le(e):Fe(t)?e?.hooksize||``:n||``}let ze=new Set([`WLL Main Hoist - Deflection mm`,`WLL Main Hoist - Length Span/Jib mm`,`WLL Auxiliary Hoist - Deflection mm`,`WLL Auxiliary Hoist - Length Span/Jib mm`]);function Be(e){return[`WLL Main Hoist - Load Mass kg`,`WLL Auxiliary Hoist - Load Mass kg`,`SWL of Beam - Load Mass kg`,`SWL Installed Hoist - Load Mass kg`,`Hoist Proof Load Test kg`].includes(e)}function Ve(e){return[`100`,`400`,`500`].includes(String(e?.equipgroupid||``))?!0:(window.atecCriteria||[]).some(t=>String(t.equiptypeid)===String(e?.equiptypeid)&&String(t.inspectioncategory||t.inspection_category||``).toUpperCase()===`LOADTEST`&&t.active!==!1&&t.active!==`false`)}function O(e,t,n){if(n!==`LOADTEST`||!E(e?.equipmenttype||``).includes(`crawl beam`))return!1;let r=E([t?.criterianame,t?.criteriadescription].filter(Boolean).join(` `));return r.includes(`serial number`)&&r.includes(`hoist`)&&(r.includes(`trolley`)||r.includes(`beam`))}function He(e){let t=(e.criterianame||``).toLowerCase();return e.fieldtype===`TEXT`||t.includes(`defects and recommendations`)}function Ue(e){if(String(e.fieldtype||``).toUpperCase()!==`TEXT`)return!1;let t=[e.criterianame,e.criteriadescription].filter(Boolean).join(` `).toLowerCase().trim();return t.includes(`any defects noted`)||t.includes(`comments`)||t.includes(`remarks`)}function We(e,t=``){let n=String(t??``);return n.trim()?n:Ue(e)?`None`:``}function Ge(e){return k(e)}function Ke(e){return E([e?.criterianame,e?.criteriadescription].filter(Boolean).join(` `)).includes(`hook wear does not exceed allowable limits`)}function qe(e,t){return e.filter(e=>t!==`LOADTEST`||!ze.has(e.criterianame)).filter(e=>!Ke(e)).sort((e,t)=>Ge(e)?1:Ge(t)?-1:0)}function Je(e=`quick`){if(e===`quick`){showQuickInspection();return}if(e===`assets`){showAssetSetup();return}showInspections()}window.returnToInspectionOrigin=Je,window.toggleFailRemark=function(e){let t=document.querySelector(`#result-${e}`)?.value,n=document.querySelector(`#fail-remarks-${e}`);n&&(n.style.display=t===`FAIL`||t===`NO`?`block`:`none`)};function k(e){let t=String(e?.criteriadescription||e?.criterianame||``).trim().toUpperCase();return t===`SAFE FOR CONTINUED OPERATION`||t===`SAFE FOR SERVICE`}function Ye(e){return String(e?.result??e?.savedresult??e?.measuredvalue??e?.value??``).trim().toUpperCase()}function Xe(e){return Ye(e)||(e.resulttype===`YES_NO`||k(e)?`YES`:`PASS`)}function A(e,t,n){return`<option value="${e}" ${n===e?`selected`:``}>${t}</option>`}function $e(e){return String(e?.severity||``).toUpperCase()===`CRITICAL`}window.updateInspectionSafetyWarning=function(){let e=window.currentInspectionCriteria||[],t=e.filter(e=>{let t=document.querySelector(`#result-${e.criteriaid}`)?.value;return $e(e)&&!k(e)&&[`FAIL`,`NO`].includes(t)}),n=document.querySelector(`#inspectionCriticalWarning`),r=e.find(k);if(r&&t.length){let e=document.querySelector(`#result-${r.criteriaid}`);e&&(e.value=e.querySelector(`option[value="NO"]`)?`NO`:`FAIL`,e.disabled=!0,e.dataset.autoForcedSafety=`true`,toggleFailRemark(r.criteriaid))}if(r&&t.length===0){let e=document.querySelector(`#result-${r.criteriaid}`);e&&(e.disabled=!1,e.dataset.autoForcedSafety===`true`&&(e.value=e.querySelector(`option[value="YES"]`)?`YES`:`PASS`,delete e.dataset.autoForcedSafety,toggleFailRemark(r.criteriaid)))}n&&(n.style.display=t.length?`block`:`none`,n.innerHTML=t.length?`<strong>NOT SAFE rule applied:</strong> ${t.length} critical item failed. SAFE FOR CONTINUED OPERATION is forced to NO and the certificate will be NOT SAFE.`:``)};function et(e,t=`VISUAL`){if(t!==`VISUAL`&&t!==`LOADTEST`)return`GENERIC`;let n=E([e?.equipmenttype,e?.equipmenttypedescription,e?.description].filter(Boolean).join(` `));return n.includes(`manual chain hoist`)||n.includes(`manual lever hoist`)||n.includes(`chain block`)||n.includes(`lever hoist`)?`CHAIN_BLOCK_LEVER_HOIST`:`GENERIC`}function j(e){return String(e?.criteriadescription||e?.criterianame||``)}function M(e,t,n){let r=D(t,e),i=Re(t,e,r);return`
    <div class="inspection-row compact-row ${n===`LOADTEST`?`loadtest-measurement-row`:``}">
      <div class="inspection-criteria">
        ${c(j(e))}
        ${e.severity?`<span class="inspection-criteria-badge ${l(String(e.severity).toLowerCase())}">${c(e.severity)}</span>`:``}
      </div>

      <div class="comparison-grid">
        ${r?`
          <input
            type="text"
            value="${y(r)}"
            readonly
            class="readonly-value"
          >
        `:`
          <div class="readonly-value readonly-value-empty"></div>
        `}

        <input
          id="measured-${e.criteriaid}"
          type="text"
          value="${y(i)}"
        >
      </div>

      ${n===`LOADTEST`&&Be(e.criterianame)?`
        <div class="inspection-remarks">
          <input
            id="remarks-${e.criteriaid}"
            type="text"
            placeholder="Comments / Remarks"
          >
        </div>
      `:n===`LOADTEST`?`<div></div>`:``}
    </div>
  `}function N(e){let t=Xe(e);return He(e)?`
      <div class="inspection-row compact-row">
        <div class="inspection-criteria">
          ${c(j(e))}
          ${e.severity?`<span class="inspection-criteria-badge ${l(String(e.severity).toLowerCase())}">${c(e.severity)}</span>`:``}
        </div>

        <div class="inspection-result inspection-text-result">
          <textarea
            id="remarks-${e.criteriaid}"
            rows="3"
            placeholder="${y(e.criterianame)}"
          >${y(We(e))}</textarea>
        </div>
      </div>
    `:`
    <div class="inspection-row compact-row">
      <div class="inspection-criteria">
        ${c(j(e))}
        ${e.severity?`<span class="inspection-criteria-badge ${l(String(e.severity).toLowerCase())}">${c(e.severity)}</span>`:``}
      </div>

      <div class="inspection-result">
        <select
          id="result-${e.criteriaid}"
          onchange="toggleFailRemark(${e.criteriaid}); updateInspectionSafetyWarning()"
        >
          ${e.resulttype===`YES_NO`||k(e)?`
                ${A(`YES`,`YES`,t)}
                ${A(`NO`,`NO`,t)}
                ${A(`N/A`,`N/A`,t)}
              `:`
                ${A(`PASS`,`PASS`,t)}
                ${A(`FAIL`,`FAIL`,t)}
                ${A(`N/A`,`N/A`,t)}
              `}
        </select>
      </div>

      <div
        class="inspection-remarks"
        id="fail-remarks-${e.criteriaid}"
        style="display:none;"
      >
        <input
          id="remarks-${e.criteriaid}"
          type="text"
          placeholder="Reason for FAIL"
        >
      </div>
    </div>
  `}function tt(e,t,n,r){return`
    ${t.length?`
      <div class="inspection-section-title">
        Measurements
      </div>

      <div class="inspection-header measurements ${r===`LOADTEST`?`loadtest-measurements`:``}">
        <div>Criteria</div>
        <div>Standard Dimension</div>
        <div>Measured Dimension</div>
        ${r===`LOADTEST`?`<div>Comments / Remarks</div>`:``}
      </div>

      ${t.map(t=>M(t,e,r)).join(``)}
    `:``}

    <div class="inspection-section-title">
      Visual Inspection
    </div>

    <div class="inspection-header visual">
      <div>Criteria</div>
      <div>Result</div>
      <div>Reason for FAIL (required)</div>
    </div>

    ${n.map(e=>N(e)).join(``)}
  `}function P(e){let t=E(j(e));return k(e)||t.includes(`defect`)||t.includes(`recommendation`)||t.includes(`comment`)?`Final Result`:t.includes(`hook`)||t.includes(`latch`)||t.includes(`throat`)?`Hooks`:t.includes(`chain`)||t.includes(`link`)?`Load Chain`:t.includes(`brake`)||t.includes(`load holding`)||t.includes(`proof load`)||t.includes(`load limiter`)||t.includes(`loadcell`)?`Brake / Load Holding`:t.includes(`marking`)||t.includes(`swl`)||t.includes(`wll`)||t.includes(`identification`)||t.includes(`serial`)?`Markings`:t.includes(`body`)||t.includes(`casing`)||t.includes(`cover`)||t.includes(`frame`)||t.includes(`structure`)?`Body / Casing`:t.includes(`function`)||t.includes(`operate`)||t.includes(`movement`)||t.includes(`raising`)||t.includes(`lowering`)||t.includes(`test`)?`Functional Test`:`Identification`}function nt(e,t,n){let r=[`Identification`,`Hooks`,`Load Chain`,`Body / Casing`,`Brake / Load Holding`,`Markings`,`Functional Test`,`Final Result`],i=r.reduce((e,t)=>(e[t]=[],e),{});return t.forEach(e=>{i[P(e)].push(e)}),`
    <div class="inspection-wizard-banner">
      <div>
        <span>Inspection Wizard</span>
        <strong>Chain Block / Lever Hoist</strong>
      </div>
      <p>Guided sections use the same saved criteria and certificate output as the normal inspection form.</p>
    </div>

    ${r.map(t=>{let r=i[t]||[];if(!r.length)return``;let a=r.filter(e=>e.fieldtype===`NUMBER`),o=r.filter(e=>e.fieldtype!==`NUMBER`);return`
        <div class="inspection-wizard-section">
          <div class="inspection-section-title">${t}</div>

          ${a.length?`
            <div class="inspection-header measurements ${n===`LOADTEST`?`loadtest-measurements`:``}">
              <div>Criteria</div>
              <div>Standard Dimension</div>
              <div>Measured Dimension</div>
              ${n===`LOADTEST`?`<div>Comments / Remarks</div>`:``}
            </div>
            ${a.map(t=>M(t,e,n)).join(``)}
          `:``}

          ${o.length?`
            <div class="inspection-header visual">
              <div>Criteria</div>
              <div>Result</div>
              <div>Reason for FAIL (required)</div>
            </div>
            ${o.map(e=>N(e)).join(``)}
          `:``}
        </div>
      `}).join(``)}
  `}function F(e,t,n,r,i){return et(e,i)===`CHAIN_BLOCK_LEVER_HOIST`?nt(e,t,i):tt(e,n,r,i)}window.pendingInspectionPhotos=[];function I(e=`GENERAL`){return[`GENERAL`,`DEFECT`,`REPAIR`,`LOAD_TEST`,`NAMEPLATE`,`HOOK`,`WIRE_ROPE`,`STRUCTURE`,`ELECTRICAL`].map(t=>`
    <option value="${t}" ${e===t?`selected`:``}>
      ${t.replaceAll(`_`,` `)}
    </option>
  `).join(``)}window.handleInspectionPhotoSelection=function(e){Array.from(e.target.files||[]).forEach(e=>{window.pendingInspectionPhotos.push({id:`${Date.now()}-${Math.random()}`,file:e,caption:``,photoType:`GENERAL`,previewUrl:URL.createObjectURL(e)})}),e.target.value=``,rt()},window.updateInspectionPhotoMeta=function(e,t,n){let r=window.pendingInspectionPhotos.find(t=>t.id===e);r&&(r[t]=n)},window.removeInspectionPhoto=function(e){let t=window.pendingInspectionPhotos.find(t=>t.id===e);t?.previewUrl&&URL.revokeObjectURL(t.previewUrl),window.pendingInspectionPhotos=window.pendingInspectionPhotos.filter(t=>t.id!==e),rt()};function rt(){let e=document.querySelector(`#inspectionPhotoPreview`);if(e){if(!window.pendingInspectionPhotos.length){e.innerHTML=`<p class="muted-text">No inspection photos selected.</p>`;return}e.innerHTML=window.pendingInspectionPhotos.map(e=>`
    <div class="inspection-photo-preview-card">
      <img src="${e.previewUrl}" alt="Inspection photo preview">
      <div class="inspection-photo-preview-fields">
        <label>
          Photo Type
          <select onchange="updateInspectionPhotoMeta('${e.id}', 'photoType', this.value)">
            ${I(e.photoType)}
          </select>
        </label>
        <label>
          Caption
          <input
            type="text"
            value="${y(e.caption)}"
            placeholder="Optional caption"
            oninput="updateInspectionPhotoMeta('${e.id}', 'caption', this.value)"
          >
        </label>
        <button type="button" class="secondary-btn" onclick="removeInspectionPhoto('${e.id}')">
          Remove
        </button>
      </div>
    </div>
  `).join(``)}}window.startInspection=async function(e,t=`VISUAL`,n=`quick`){if(!ht()){alert(`You do not have permission to create inspections or load tests.`);return}n===`assets`&&_();let r;try{r=await Tt(e)}catch(e){alert(e.message||`Asset not found`);return}let i=await fetch(`${g}/assets/${e}/quick-details`),a=Me(),o=Ne(a,t),s=await i.json();window.scrollTo(0,0),window.pendingInspectionPhotos=[];let u=qe(G.filter(e=>String(e.equiptypeid)===String(r.equiptypeid)&&String(e.inspectioncategory)===String(t)&&e.active!==!1),t);u=u.filter(e=>!O(r,e,t));let d=u.filter(e=>e.fieldtype===`NUMBER`),f=u.filter(e=>e.fieldtype!==`NUMBER`);window.currentInspectionCriteria=u;let p=String(r.equipgroupid||``)===`400`;document.querySelector(`#page`).innerHTML=`
    <h2>${c(t)} - Asset ${c(r.assetid)}</h2>

    <div class="filter-card">
      <div class="inspection-asset-summary">
        <div class="inspection-asset-title">
          <strong>${c(r.description||``)}</strong>
          <span>Asset ${c(r.assetid)}</span>
        </div>

        <div class="inspection-asset-details">
          <div><span>Serial No</span><strong>${c(r.serialno||`-`)}</strong></div>
          <div><span>Equipment Type</span><strong>${c(r.equipmenttype||`-`)}</strong></div>
          <div><span>WLL</span><strong>${c(r.wll||`-`)} kg</strong></div>
          ${w(`Span/Jib`,r.span,`mm`)}
          ${w(`Permissible Deflection`,r.permissibledeflection,`mm`)}
        </div>

        <div class="inspection-asset-actions">
          <button onclick="passAllCriteria(${r.assetid}, '${t}', '${n}')">
            Pass All & Save
          </button>

          <button onclick="returnToInspectionOrigin('${n}')">
            Cancel
          </button>
        </div>
      </div>
    </div>

    <div class="quick-photo-grid">

  ${r.media1?`
    <div class="quick-photo-card">
      <img src="${l(me(r.media1))}">
    </div>
  `:``}

  ${r.media2?`
    <div class="quick-photo-card">
      <img src="${l(me(r.media2))}">
    </div>
  `:``}

</div>

<div class="filter-card">

  <h3>Replace Asset Photos</h3>

  <p class="muted-text">
    Choose a replacement only when the asset master photo should be updated on save.
  </p>

  <div class="asset-photo-row inspection-asset-photo-row">
    <div class="form-group">
      <label>Replace Asset Photo 1</label>
      <input id="inspectionAssetPhoto1" type="file" accept="image/*">
    </div>

    <div class="form-group">
      <label>Replace Asset Photo 2</label>
      <input id="inspectionAssetPhoto2" type="file" accept="image/*">
    </div>
  </div>

  ${p?`
    <hr>

    <h3>Inspection Photos</h3>

    <input
      id="inspectionPhotoFiles"
      type="file"
      accept="image/*"
      multiple
      onchange="handleInspectionPhotoSelection(event)"
    >

    <div id="inspectionPhotoPreview" class="inspection-photo-preview-grid">
      <p class="muted-text">No inspection photos selected.</p>
    </div>
  `:``}

</div>

<div id="inspectionCriticalWarning" class="inspection-critical-warning" style="display:none;"></div>

<div class="inspection-tag-card">

  <div class="inspection-tag-title">
    INSPECTION DETAILS
  </div>

  <div class="inspector-identity-card">
    <div>
      <span>Logged-in Inspector</span>
      <strong>${c(R?.full_name||`-`)}</strong>
    </div>
    <div>
      <span>LMI Number</span>
      <strong>${c(R?.lmi_number||`-`)}</strong>
    </div>
  </div>

  <div class="form-row">

    <div class="form-group">
      <label>${t===`LOADTEST`?`Load Test Date`:`Inspection Date`}</label>
      <input
        id="inspectionTestDate"
        type="date"
        value="${a}"
        onchange="updateInspectionValidDateFromTestDate('${t}')"
      >
    </div>

    <div class="form-group">
      <label>Inspection Tag No</label>
      <input
        id="inspectionTagNo"
        class="inspection-tag-input"
        type="text"
        placeholder="ENTER TAG NUMBER"
      >
    </div>

    <div class="form-group">
      <label>Certificate Expiry Date</label>
      <input
        id="inspectionValidDate"
        type="date"
        value="${o}"
      >
    </div>

  </div>

</div>
      <div class="inspection-history-card">

        <div class="inspection-history-title">
          LAST INSPECTION
        </div>

        <div class="inspection-history-grid">

          <div>
            <strong>Date:</strong><br>
            ${c(s.lastinspectiondate||`Never Inspected`)}
          </div>

          <div>
            <strong>Tag Number:</strong><br>
            ${c(s.lastinspectiontag||`-`)}
          </div>

          <div>
            <strong>Type:</strong><br>
            ${c(s.lastinspectiontype||`-`)}
          </div>

          <div>
            <strong>Status:</strong><br>
           <span class="${s.lastinspectionstatus===`SAFE`?`status-safe`:`status-unsafe`}">
              ${c(s.lastinspectionstatus||`-`)}
            </span>
          </div>

          <div>
            <strong>Inspector:</strong><br>
            ${c(s.lastinspector||`-`)}
          </div>

        </div>

      </div>

<div class="inspection-list">
  ${F(r,u,d,f,t)}
</div>

    <div class="filter-card">
      <button type="button" onclick="window.saveInspection(${r.assetid}, '${t}', '${n}')">
        Save ${t}
      </button>

      <button onclick="returnToInspectionOrigin('${n}')">
        Cancel
      </button>
    </div>

        <div class="filter-card">

        <button onclick="showInspectionHistory(${r.assetid})">
          Show Inspection History
        </button>

        <div id="inspectionHistoryPanel"></div>

      </div>

  `},window.showInspectionHistory=async function(e){let t=await fetch(`${g}/assets/${e}/inspection-history`),n=await t.json();if(!t.ok){alert(`Error loading inspection history: `+n.error);return}let r=n.map(e=>`
    <tr>
      <td>${c(e.testdate||``)}</td>
      <td>${c(e.inspectiontype||``)}</td>
      <td><strong>${c(e.tagnumber||`-`)}</strong></td>
      <td>${c(e.status||``)}</td>
      <td>${c(e.inspector||`-`)}</td>
      <td>
          <button onclick="openCertificateModal(${e.testid})">
            View Certificate
          </button>
      </td>
    </tr>
  `).join(``);document.querySelector(`#inspectionHistoryPanel`).innerHTML=`
    <h3>Inspection History</h3>

    <table>
      <thead>
        <tr>
          <th>Date</th>
          <th>Type</th>
          <th>Tag No</th>
          <th>Status</th>
          <th>Inspector</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ${r||`
          <tr>
            <td colspan="5">No inspection history found</td>
          </tr>
        `}
      </tbody>
    </table>
  `},window.showAssetHistoryFromSetup=async function(e){_();let t=await fetch(`${g}/assets/${e}/inspection-history`),n=await t.json();if(!t.ok){alert(`Error loading inspection history: `+n.error);return}document.querySelector(`#page`).innerHTML=`
    <h2>Inspection History - Asset ${e}</h2>

    <div class="filter-card">
      <button onclick="showAssetSetup()">Back to Asset Setup</button>
    </div>

    <div class="filter-card">
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Type</th>
            <th>Tag No</th>
            <th>Status</th>
            <th>Inspector</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          ${n.length?n.map(e=>`
            <tr>
              <td>${c(e.testdate||``)}</td>
              <td>${c(e.inspectiontype||``)}</td>
              <td><strong>${c(e.tagnumber||`-`)}</strong></td>
              <td>${c(e.status||``)}</td>
              <td>${c(e.inspector||`-`)}</td>
              <td>
              <button onclick="openCertificateModal(${e.testid})">
                View Certificate
              </button>
              </td>
            </tr>
          `).join(``):`
            <tr>
              <td colspan="6">No inspection history found</td>
            </tr>
          `}
        </tbody>
      </table>
    </div>
  `},window.passAllCriteria=function(e,t,n=`quick`){confirm(`Are you sure you want to mark all visual criteria as PASS and save this inspection?`)&&(document.querySelectorAll(`select[id^="result-"]`).forEach(e=>{e.value=Array.from(e.options).some(e=>e.value===`YES`)?`YES`:`PASS`}),updateInspectionSafetyWarning(),document.querySelectorAll(`input[id^="measured-"]`).forEach(e=>{e.value||=e.defaultValue||``}),saveInspection(e,t,n))},window.handleDashboardSearchEnter=function(e){e.key===`Enter`&&dashboardFindAsset()},window.dashboardFindAsset=async function(){let e=document.querySelector(`#dashboardAssetSearch`),t=Ce(e?.value||``),n=t.trim(),r=document.querySelector(`#dashboardAssetSearchResult`);if(e&&t!==e.value.trim()&&(e.value=t),!n){r.innerHTML=`<p>Please enter or scan an asset number, tag, serial number or QR code.</p>`;return}r.innerHTML=`<p>Searching...</p>`;try{let e=await fetch(`${g}/inspections/assets/search?q=${encodeURIComponent(n)}`);if(!e.ok)throw Error(`Asset search failed`);let t=await e.json();if(!t.length){r.innerHTML=`
        <p>No asset found for <strong>${c(n)}</strong>.</p>
      `;return}if(t.length===1){quickOpenAsset(t[0].assetid);return}r.innerHTML=`
      <div class="dashboard-result-table">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th>Asset ID</th>
              <th>Tag No</th>
              <th>Serial No</th>
              <th>Hoist Serial No</th>
              <th>Description</th>
              <th>Equipment Type</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            ${t.slice(0,10).map(e=>`
              <tr>
                <td>${c(e.assetid)}</td>
                <td>${c(e.assettagno||`-`)}</td>
                <td>${c(e.serialno||`-`)}</td>
                <td>${c(e.hoistserialno||`-`)}</td>
                <td>${c(e.description||``)}</td>
                <td>${c(e.equipmenttype||``)}</td>
                <td class="dashboard-search-actions">
                  <button onclick="startInspection(${e.assetid}, 'VISUAL', 'quick')">Inspect</button>
                  ${Ve(e)?`<button class="load-test-btn" onclick="startInspection(${e.assetid}, 'LOADTEST', 'quick')">Load Test</button>`:``}
                </td>
              </tr>
            `).join(``)}
          </tbody>
        </table>
      </div>
    `}catch(e){console.error(`Dashboard asset search error:`,e),r.innerHTML=`<p>Unable to search assets. Please try again.</p>`}};let it=null,at=!1;window.startDashboardCameraScan=async function(){let e=document.querySelector(`#dashboardCameraScanner`),t=document.querySelector(`#dashboardCameraVideo`),n=document.querySelector(`#dashboardScanStatus`);if(!(`BarcodeDetector`in window)){n&&(n.textContent=`Camera scanning is not supported by this browser. Use the scan/type box above.`),e?.removeAttribute(`hidden`);return}try{let r=await window.BarcodeDetector.getSupportedFormats(),i=[`qr_code`,`code_128`,`code_39`,`ean_13`].filter(e=>r.includes(e)),a=new window.BarcodeDetector({formats:i});it=await navigator.mediaDevices.getUserMedia({video:{facingMode:`environment`},audio:!1}),t.srcObject=it,e?.removeAttribute(`hidden`),await t.play(),at=!0,n&&(n.textContent=`Scanning... point the camera at the QR label or barcode.`);let o=async()=>{if(at){try{let e=await a.detect(t);if(e.length){let t=Ce(e[0].rawValue);document.querySelector(`#dashboardAssetSearch`).value=t,stopDashboardCameraScan(),dashboardFindAsset();return}}catch(e){console.error(`Dashboard camera scan failed:`,e)}requestAnimationFrame(o)}};o()}catch(t){console.error(`Unable to start dashboard camera scanner:`,t),e?.removeAttribute(`hidden`),n&&(n.textContent=`Camera could not start. Please allow camera access or use the scan/type box.`)}},window.stopDashboardCameraScan=function(){at=!1,it&&=(it.getTracks().forEach(e=>e.stop()),null);let e=document.querySelector(`#dashboardCameraVideo`);e&&(e.srcObject=null),document.querySelector(`#dashboardCameraScanner`)?.setAttribute(`hidden`,``)};async function ot(){try{let e=await fetch(`${g}/dashboard/summary`);if(!e.ok)throw Error(`Failed to load dashboard summary`);let t=await e.json();ct(t.alerts||{}),dt(t.failedEquipmentByCustomer||[]),_t(t.upcomingExpiriesByCustomer||[]),vt(t.topCustomers||[]),yt(t.equipmentByType||[])}catch(e){console.error(`Failed to load dashboard summary:`,e),ct(),dt(),_t(),vt(),yt()}}async function ct(e=null){try{let t=e;if(!t){let e=await fetch(`${g}/dashboard/alerts`);if(!e.ok)throw Error(`Failed to load dashboard alerts`);t=await e.json()}let n=document.querySelector(`#dashboardAlerts`);if(!n)return;let r=``;Number(t.overdue)>0&&(r+=`
        <div class="alert-card danger">
          ALERT: ${t.overdue} Assets Overdue
        </div>
      `),Number(t.expiring)>0&&(r+=`
        <div class="alert-card warning">
          WARNING: ${t.expiring} Certificates Expiring Within 30 Days
        </div>
      `),Number(t.failed)>0&&(r+=`
        <div class="alert-card danger">
          ALERT: ${t.failed} Failed Assets
        </div>
      `),r===``&&(r=`
        <div class="alert-card success">
          OK: No operational alerts
        </div>
      `),n.innerHTML=r}catch(e){console.error(`Failed to load dashboard alerts:`,e);let t=document.querySelector(`#dashboardAlerts`);t&&(t.innerHTML=`
        <div class="alert-card warning">
          Unable to load dashboard alerts
        </div>
      `)}}async function dt(e=null){let n=document.querySelector(`#failedEquipmentTableBody`);if(n)try{let r=e;if(!r){let e=await fetch(`${g}/dashboard/failed-equipment-by-customer`);if(!e.ok)throw Error(`Failed to load failed equipment`);r=await e.json()}if(!Array.isArray(r)||!r.length){n.innerHTML=`
        <tr>
          <td colspan="4" class="empty-row">
            No failed equipment found
          </td>
        </tr>
      `;return}n.innerHTML=t(r,`dashboardFailed`,{clientname:e=>e.clientname,failed_assets:e=>e.failed_assets,latest_failed_date:e=>e.latest_failed_date},`failed_assets`).map(e=>{let t=l(JSON.stringify({clientid:e.clientid,autoLoad:!0}));return`
      <tr>
        <td>${c(e.clientname||``)}</td>
        <td><strong>${c(e.failed_assets||0)}</strong></td>
        <td>${c(e.latest_failed_date?e.latest_failed_date.split(`T`)[0]:``)}</td>
        <td>
          <button
            class="small-btn"
            onclick="showCustomerDetailedReport(${t})"
          >
            View Assets
          </button>
        </td>
      </tr>
    `}).join(``)}catch(e){console.error(`Failed to load failed equipment:`,e),n.innerHTML=`
      <tr>
        <td colspan="4" class="empty-row">Unable to load failed equipment data</td>
      </tr>
    `}}async function _t(e=null){let n=document.querySelector(`#upcomingExpiriesTableBody`);if(n)try{let r=e;if(!r){let e=await fetch(`${g}/dashboard/upcoming-expiries-by-customer`);if(!e.ok)throw Error(`Failed to load upcoming certificate expiries`);r=await e.json()}if(!Array.isArray(r)||!r.length){n.innerHTML=`
        <tr>
          <td colspan="5" class="empty-row">
            No upcoming certificate expiries
          </td>
        </tr>
      `;return}n.innerHTML=t(r,`dashboardExpiries`,{clientname:e=>e.clientname,upcoming_assets:e=>e.upcoming_assets,next_expiry_date:e=>e.next_expiry_date,days_remaining:e=>e.days_remaining},`days_remaining`).map(e=>{let t=l(JSON.stringify({clientid:e.clientid,autoLoad:!0}));return`
      <tr>
        <td>${c(e.clientname||``)}</td>
        <td><strong>${c(e.upcoming_assets||0)}</strong></td>
        <td>${c(e.next_expiry_date?e.next_expiry_date.split(`T`)[0]:``)}</td>
        <td><strong>${c(e.days_remaining??``)}</strong></td>
        <td>
          <button
            class="small-btn"
            onclick="showCustomerDetailedReport(${t})"
          >
            View Assets
          </button>
        </td>
      </tr>
    `}).join(``)}catch(e){console.error(`Failed to load upcoming expiries:`,e),n.innerHTML=`
      <tr>
        <td colspan="5" class="empty-row">Unable to load upcoming certificate expiry data</td>
      </tr>
    `}}async function vt(e=null){let n=document.querySelector(`#dashboardTopCustomersBody`);if(n)try{let r=e;if(!r){let e=await fetch(`${g}/dashboard/top-customers`);if(!e.ok)throw Error(`Failed to load top customers`);r=await e.json()}if(!Array.isArray(r)||!r.length){n.innerHTML=`
        <tr>
          <td colspan="3" class="empty-row">No customer asset data found</td>
        </tr>
      `;return}n.innerHTML=t(r,`dashboardCustomers`,{clientname:e=>e.clientname,sites:e=>e.sites,assets:e=>e.assets},`assets`).slice(0,10).map(e=>`
      <tr>
        <td>${c(e.clientname||``)}</td>
        <td>${c(e.sites||0)}</td>
        <td><strong>${c(e.assets||0)}</strong></td>
      </tr>
    `).join(``)}catch(e){console.error(`Failed to load top customers:`,e),n.innerHTML=`
      <tr>
        <td colspan="3" class="empty-row">Unable to load customer asset data</td>
      </tr>
    `}}async function yt(e=null){let n=document.querySelector(`#dashboardEquipmentTypeBody`);if(n)try{let r=e;if(!r){let e=await fetch(`${g}/dashboard/equipment-by-type`);if(!e.ok)throw Error(`Failed to load equipment by type`);r=await e.json()}if(!Array.isArray(r)||!r.length){n.innerHTML=`
        <tr>
          <td colspan="2" class="empty-row">No equipment type data found</td>
        </tr>
      `;return}n.innerHTML=t(r,`dashboardEquipment`,{equipmenttype:e=>e.equipmenttype,total:e=>e.total},`total`).slice(0,10).map(e=>`
      <tr>
        <td>${c(e.equipmenttype||`Unknown`)}</td>
        <td><strong>${c(e.total||0)}</strong></td>
      </tr>
    `).join(``)}catch(e){console.error(`Failed to load equipment by type:`,e),n.innerHTML=`
      <tr>
        <td colspan="2" class="empty-row">Unable to load equipment type data</td>
      </tr>
    `}}window.saveInspection=async function(e,t=`VISUAL`,n=`quick`){let r=document.querySelector(`#inspectionTagNo`)?.value.trim()||``,i=document.querySelector(`#inspectionTestDate`)?.value||Me(),a;try{a=await Tt(e)}catch(e){alert(e.message||`Asset not found`);return}let o=qe(G.filter(e=>String(e.equiptypeid)===String(a.equiptypeid)&&String(e.inspectioncategory)===String(t)&&e.active!==!1),t);o=o.filter(e=>!O(a,e,t));let s=[],c=`SAFE`,l=null;for(let e of o){let n=document.querySelector(`#result-${e.criteriaid}`),r=document.querySelector(`#measured-${e.criteriaid}`),i=n?n.value:`RECORDED`,o=document.querySelector(`#remarks-${e.criteriaid}`),u=He(e)||t===`LOADTEST`?o?.value||``:[`FAIL`,`NO`].includes(i)&&o?.value||``,d=k(e)&&n?.dataset.autoForcedSafety===`true`;if(!He(e)&&[`FAIL`,`NO`].includes(i)&&!d&&!String(u||``).trim()){l=e;break}k(e)&&![`PASS`,`YES`].includes(i)&&(c=`NOT SAFE`),$e(e)&&!k(e)&&[`FAIL`,`NO`].includes(i)&&(c=`NOT SAFE`);let f=D(a,e)||null,p=r?r.value:null;s.push({criteriaid:e.criteriaid,criterianame:e.criterianame,assetvalue:f,measuredvalue:p,result:i,remarks:u})}if(l){alert(`Please enter a reason/comment for the failed item: ${j(l)}`);let e=document.querySelector(`#remarks-${l.criteriaid}`),t=document.querySelector(`#fail-remarks-${l.criteriaid}`);t&&(t.style.display=`block`),e&&e.focus();return}let u=new FormData;u.append(`assetid`,e),u.append(`testdate`,i),u.append(`validdate`,document.querySelector(`#inspectionValidDate`)?.value||``),u.append(`comments`,``),u.append(`status`,c),u.append(`inspectiontype`,t),u.append(`tagnumber`,r),u.append(`results`,JSON.stringify(s));let d=document.querySelector(`#inspectionAssetPhoto1`)?.files?.[0]||null,f=document.querySelector(`#inspectionAssetPhoto2`)?.files?.[0]||null;if(!ge([d,f]))return;let p=!!(d||f);u.append(`updateassetphotos`,p),d&&u.append(`photo1`,d),f&&u.append(`photo2`,f),(String(a.equipgroupid||``)===`400`&&window.pendingInspectionPhotos||[]).forEach(e=>{u.append(`inspectionPhotos`,e.file),u.append(`photoCaptions`,e.caption||``),u.append(`photoTypes`,e.photoType||`GENERAL`)});let m,h;try{m=await fetch(`${g}/inspections`,{method:`POST`,body:u}),h=await m.json()}catch(e){alert(`Error saving inspection: `+e.message);return}if(!m.ok){alert(`Error saving inspection: `+h.error);return}alert(`Inspection saved. Status: `+(h.status||c)),await $(),Je(n)};let bt=localStorage.getItem(`currentPage`)||`dashboard`;switch(ft(bt)||(bt=R.role===`CUSTOMER`?`certificates`:`dashboard`,localStorage.setItem(`currentPage`,bt)),bt){case`dashboard`:showDashboard();break;case`customers`:showCustomerSetup();break;case`sites`:showSites();break;case`responsible`:showResponsiblePersons();break;case`sections`:showSections();break;case`assets`:showAssetSetup();break;case`inspections`:showInspections();break;case`quick-inspection`:showQuickInspection();break;case`criteria`:showEquipmentTypeCriteria();break;case`certificates`:showCertificateSearch();break;case`customer-report`:showCustomerDetailedReport();break;case`she`:showRiskAssessments();break;case`users`:showUserManagement();break;case`system-health`:showSystemHealth();break;case`profile`:showMyProfile();break;default:showDashboard();break}}$();