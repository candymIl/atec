(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();function e(e,t=``){let n=`${e}Sort`;return window[n]=window[n]||{key:t,direction:`asc`},window[n]}function t(t,n,r,i=``){let a=e(n,i),o=r[a.key||i];if(!o)return[...t];let s=a.direction===`desc`?-1:1;return[...t].sort((e,t)=>{let n=o(e),r=o(t),i=Number(n),a=Number(r);return n!==``&&r!==``&&!Number.isNaN(i)&&!Number.isNaN(a)?(i-a)*s:String(n||``).localeCompare(String(r||``),void 0,{numeric:!0,sensitivity:`base`})*s})}function n(t,n,r,i){let a=e(n,r),o=a.key===r,s=o?a.direction:``;return`
    <span class="user-table-heading">
      <span>${t}</span>
      <button
        type="button"
        class="user-sort-btn ${o?`active ${s}`:``}"
        onclick="sortTable('${n}', '${r}', '${i}')"
        aria-label="Sort ${t}"
        title="Sort ${t}"
      ></button>
    </span>
  `}window.sortTable=function(t,n,r){let i=e(t,n);window[`${t}Sort`]={key:n,direction:i.key===n&&i.direction===`asc`?`desc`:`asc`};let a=window[r];typeof a==`function`&&a()};function r(e,r,i,a,o){let s={};r.forEach(e=>{let t=e.equipmenttype||`Unknown`;s[t]=(s[t]||0)+1});let c=Object.entries(s).sort((e,t)=>t[1]-e[1]).slice(0,10),l=t(e.map(e=>{let t=i.filter(t=>String(t.clientid)===String(e.clientid)),n=t.map(e=>String(e.siteid)),a=r.filter(e=>n.includes(String(e.siteid)));return{clientname:e.clientname||``,sites:t.length,assets:a.length}}),`dashboardCustomers`,{clientname:e=>e.clientname,sites:e=>e.sites,assets:e=>e.assets},`assets`).slice(0,10),u=t(c.map(e=>({equipmenttype:e[0],total:e[1]})),`dashboardEquipment`,{equipmenttype:e=>e.equipmenttype,total:e=>e.total},`total`);document.querySelector(`#page`).innerHTML=`

    <h2>Dashboard</h2>

    <div class="filter-card">
  <h3>Quick Asset Search</h3>

  <div class="form-row">
    <input
      id="dashboardAssetSearch"
      class="search-box"
      type="text"
      placeholder="Scan QR / Asset ID / Tag No / Serial No..."
      onkeydown="handleDashboardSearchEnter(event)"
    >

    <button onclick="dashboardFindAsset()">
      Search
    </button>
  </div>

  <div id="dashboardAssetSearchResult"></div>
</div>

<div class="dashboard-cards">

  <div class="stat-card stat-blue">
    <div class="stat-icon">👥</div>
    <div>
      <h3>Customers</h3>
      <p>${o.customers}</p>
    </div>
  </div>

  <div class="stat-card stat-blue">
    <div class="stat-icon">🏭</div>
    <div>
      <h3>Sites</h3>
      <p>${o.sites}</p>
    </div>
  </div>

  <div class="stat-card stat-blue">
    <div class="stat-icon">📦</div>
    <div>
      <h3>Assets</h3>
      <p>${o.assets}</p>
    </div>
  </div>

  <div class="stat-card stat-blue">
    <div class="stat-icon">🛠️</div>
    <div>
      <h3>Equipment Types</h3>
      <p>${o.equipmenttypes}</p>
    </div>
  </div>

  <div class="stat-card stat-orange">
    <div class="stat-icon">👁️</div>
    <div>
      <h3>Visual Due</h3>
      <p>${o.visualdue}</p>
    </div>
  </div>

  <div class="stat-card stat-orange">
    <div class="stat-icon">⚖️</div>
    <div>
      <h3>Load Tests Due</h3>
      <p>${o.loadtestdue}</p>
    </div>
  </div>

  <div class="stat-card stat-green">
    <div class="stat-icon">📄</div>
    <div>
      <h3>Certificates</h3>
      <p>${o.certificates}</p>
    </div>
  </div>

  <div class="stat-card stat-red">
    <div class="stat-icon">⚠️</div>
    <div>
      <h3>Overdue</h3>
      <p>${o.overdue}</p>
    </div>
  </div>

</div>

<div class="dashboard-section dashboard-alerts">

  <div class="section-header">
    <h2>Operational Alerts</h2>
  </div>

  <div id="dashboardAlerts">
    Loading...
  </div>

</div>

<div class="dashboard-section full-width">

  <div class="section-header">
    <h2>Assets Requiring Attention</h2>
  </div>

  <table class="dashboard-table">

    <thead>
      <tr>
        <th>${n(`Asset`,`dashboardAttention`,`assettagno`,`showDashboard`)}</th>
        <th>${n(`Customer`,`dashboardAttention`,`clientname`,`showDashboard`)}</th>
        <th>${n(`Site`,`dashboardAttention`,`sitename`,`showDashboard`)}</th>
        <th>${n(`Equipment`,`dashboardAttention`,`equipmenttype`,`showDashboard`)}</th>
        <th>${n(`Reason`,`dashboardAttention`,`reason`,`showDashboard`)}</th>
        <th>${n(`Days Overdue`,`dashboardAttention`,`daysoverdue`,`showDashboard`)}</th>
        <th>Action</th>
      </tr>
    </thead>

    <tbody id="attentionTableBody">
      <tr>
        <td colspan="7">Loading...</td>
      </tr>
    </tbody>

  </table>

</div>

<div class="dashboard-section full-width">

  <div class="section-header">
    <h2>Failed Equipment</h2>
  </div>

  <table class="dashboard-table">

    <thead>
      <tr>
        <th>${n(`Asset`,`dashboardFailed`,`assettagno`,`showDashboard`)}</th>
        <th>${n(`Customer`,`dashboardFailed`,`clientname`,`showDashboard`)}</th>
        <th>${n(`Site`,`dashboardFailed`,`sitename`,`showDashboard`)}</th>
        <th>${n(`Equipment`,`dashboardFailed`,`equipmenttype`,`showDashboard`)}</th>
        <th>${n(`Failed Date`,`dashboardFailed`,`testdate`,`showDashboard`)}</th>
        <th>${n(`Inspector`,`dashboardFailed`,`inspector`,`showDashboard`)}</th>
        <th>Action</th>
      </tr>
    </thead>

    <tbody id="failedEquipmentTableBody">
      <tr>
        <td colspan="7">Loading...</td>
      </tr>
    </tbody>

  </table>

</div>

<div class="dashboard-section full-width">
  <div class="section-header">
    <h2>Upcoming Certificate Expiries</h2>
  </div>

  <table class="dashboard-table">
    <thead>
      <tr>
        <th>${n(`Asset`,`dashboardExpiries`,`assettagno`,`showDashboard`)}</th>
        <th>${n(`Customer`,`dashboardExpiries`,`clientname`,`showDashboard`)}</th>
        <th>${n(`Site`,`dashboardExpiries`,`sitename`,`showDashboard`)}</th>
        <th>${n(`Equipment`,`dashboardExpiries`,`equipmenttype`,`showDashboard`)}</th>
        <th>${n(`Type`,`dashboardExpiries`,`inspectiontype`,`showDashboard`)}</th>
        <th>${n(`Expiry Date`,`dashboardExpiries`,`validdate`,`showDashboard`)}</th>
        <th>${n(`Days Left`,`dashboardExpiries`,`daysremaining`,`showDashboard`)}</th>
        <th>Action</th>
      </tr>
    </thead>

    <tbody id="upcomingExpiriesTableBody">
      <tr>
        <td colspan="8">Loading...</td>
      </tr>
    </tbody>
  </table>
</div>

<hr>

<h2>Top Customers by Asset Count</h2>

<table>
  <thead>
    <tr>
      <th>${n(`Client`,`dashboardCustomers`,`clientname`,`showDashboard`)}</th>
      <th>${n(`Sites`,`dashboardCustomers`,`sites`,`showDashboard`)}</th>
      <th>${n(`Assets`,`dashboardCustomers`,`assets`,`showDashboard`)}</th>
    </tr>
  </thead>

<tbody>
  ${l.map(e=>`
      <tr>
        <td>${e.clientname}</td>
        <td>${e.sites}</td>
        <td>${e.assets}</td>
      </tr>
    `).join(``)}
</tbody>

  </table>

    <br>

<div class="dashboard-row">

<div class="dashboard-panel">

    <h2>Equipment by Type</h2>

    <table>

        <thead>
            <tr>
                <th>${n(`Equipment Type`,`dashboardEquipment`,`equipmenttype`,`showDashboard`)}</th>
                <th>${n(`Total`,`dashboardEquipment`,`total`,`showDashboard`)}</th>
            </tr>
        </thead>

        <tbody>

            ${u.map(e=>`
                <tr>
                    <td>${e.equipmenttype}</td>
                    <td><strong>${e.total}</strong></td>
                </tr>
            `).join(``)}

        </tbody>

    </table>

</div>

    <div class="dashboard-panel">

        <h2>Quick Actions</h2>

        <div class="dashboard-buttons">

            <button onclick="showQuickInspection()">
                New Inspection
            </button>

            <button onclick="showInspections()">
                Load Test
            </button>

            <button onclick="showAssetSetup()">
                Assets
            </button>

            <button onclick="showCertificateSearch()">
                Certificates
            </button>

        </div>

    </div>
</div>

  
  `}function i(e,t,n,r=25){let i=window[n]||r,a=Math.max(1,Math.ceil(e.length/i)),o=Math.min(window[t]||1,a),s=(o-1)*i,c=e.slice(s,s+i),l=e.length===0?0:s+c.length;return window[t]=o,window[n]=i,{currentPage:o,endIndex:l,pageSize:i,rows:c,startIndex:s,totalPages:a,totalRows:e.length}}function a({currentPage:e,endIndex:t,label:n,onPage:r,onPageSize:i,pageSize:a,startIndex:o,totalPages:c,totalRows:l}){return`
    <div class="report-pagination-bar">
      <div class="report-page-size">
        <label>Rows per page</label>
        <select onchange="${i}(this.value)">
          ${[25,50,100,250].map(e=>`
            <option value="${e}" ${e===a?`selected`:``}>
              ${e}
            </option>
          `).join(``)}
        </select>
      </div>

      <div class="report-page-controls">
        <button type="button" onclick="${r}(${e-1})" ${e<=1?`disabled`:``}>
          Previous
        </button>
        ${s(e,c,r)}
        <button type="button" onclick="${r}(${e+1})" ${e>=c?`disabled`:``}>
          Next
        </button>
        <span>Showing ${l===0?0:o+1} to ${t} of ${l} ${n} - Page ${e} of ${c}</span>
      </div>
    </div>
  `}function o(e,t){let n=[];if(t<=7){for(let e=1;e<=t;e+=1)n.push(e);return n}n.push(1),e>4&&n.push(`...`);let r=Math.max(2,e-1),i=Math.min(t-1,e+1);for(let e=r;e<=i;e+=1)n.push(e);return e<t-3&&n.push(`...`),n.push(t),n}function s(e,t,n){return o(e,t).map(t=>t===`...`?`<span class="pagination-ellipsis">...</span>`:`
      <button
        type="button"
        class="pagination-page-btn ${t===e?`active`:``}"
        onclick="${n}(${t})"
        ${t===e?`disabled`:``}
      >
        ${t}
      </button>
    `).join(``)}function c(e,r=`active`){let o=i(t(e.filter(e=>{let t=e.archived===!0||e.archived===`true`;return r===`active`?!t:r===`archived`?t:!0}),`customers`,{clientid:e=>e.clientid,clientname:e=>e.clientname,clientaddr:e=>e.clientaddr,archived:e=>e.archived?`Archived`:`Active`},`clientname`),`customerCurrentPage`,`customerRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h2>Customer Setup</h2>

    <button onclick="addClient()">Add Client</button>
    <button onclick="showCustomerSetup()">Refresh</button>

    <br><br>

    <div class="filter-card">
      <label>Show Customers</label>

      <div class="radio-row">
        <label>
          <input
            type="radio"
            name="customerArchiveFilter"
            value="active"
            ${r===`active`?`checked`:``}
            onchange="showCustomerSetup('active')"
          >
          Active
        </label>

        <label>
          <input
            type="radio"
            name="customerArchiveFilter"
            value="archived"
            ${r===`archived`?`checked`:``}
            onchange="showCustomerSetup('archived')"
          >
          Archived
        </label>

        <label>
          <input
            type="radio"
            name="customerArchiveFilter"
            value="all"
            ${r===`all`?`checked`:``}
            onchange="showCustomerSetup('all')"
          >
          All
        </label>
      </div>
    </div>
</div>

      <br>

      <input
        id="customerSearch"
        type="text"
        placeholder="Search Client ID, Client Name or Address..."
        onkeyup="filterCustomers(true)"
      />

      <br><br>

      ${a({...o,label:`customers`,onPage:`goToCustomerPage`,onPageSize:`setCustomerRowsPerPage`})}

      <table>
      <thead>
        <tr>
          <th>${n(`Client ID`,`customers`,`clientid`,`showCustomerSetup`)}</th>
          <th>${n(`Client Name`,`customers`,`clientname`,`showCustomerSetup`)}</th>
          <th>${n(`Address`,`customers`,`clientaddr`,`showCustomerSetup`)}</th>
          <th>${n(`Status`,`customers`,`archived`,`showCustomerSetup`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody id="customerTableBody">
        ${o.rows.map(e=>`
          <tr>
            <td>${e.clientid}</td>
            <td>${e.clientname||``}</td>
            <td>${e.clientaddr||``}</td>
            <td>${e.archived?`Archived`:`Active`}</td>
            <td>
              <button onclick="editClient(${e.clientid})">Edit</button>

              ${e.archived?`<button onclick="unarchiveClient(${e.clientid})">Unarchive</button>`:`<button onclick="archiveClient(${e.clientid})">Archive</button>`}
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `}function l(e,r=`active`){let o=e.filter(e=>{let t=e.archived===!0||e.archived===`true`;return r===`active`?!t:r===`archived`?t:!0}),s=i(t(o,`sites`,{siteid:e=>e.siteid,clientname:e=>e.clientname,sitename:e=>e.sitename,archived:e=>e.archived?`Archived`:`Active`},`sitename`),`siteCurrentPage`,`siteRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h2>Sites</h2>

    <button onclick="showAddSiteForm()">
      Add Site
    </button>

    <br><br>

    <p>Total Sites: <strong>${o.length}</strong></p>

    <div class="filter-card">
      <label>Show Sites</label>
      <div class="radio-row">
        ${[`active`,`archived`,`all`].map(e=>`
          <label>
            <input
              type="radio"
              name="siteArchiveFilter"
              value="${e}"
              ${r===e?`checked`:``}
              onchange="showSites('${e}')"
            >
            ${e[0].toUpperCase()+e.slice(1)}
          </label>
        `).join(``)}
      </div>
    </div>

    <label><strong>Search Sites</strong></label>
    <br>

    <input
      id="siteSearch"
      class="search-box"
      type="text"
      placeholder="Search Site ID, Client or Site Name..."
      onkeyup="filterSites(true)"
    />

    <br><br>

    ${a({...s,label:`sites`,onPage:`goToSitePage`,onPageSize:`setSiteRowsPerPage`})}

    <table>
    <thead>
      <tr>
        <th>${n(`Site ID`,`sites`,`siteid`,`showSites`)}</th>
        <th>${n(`Client`,`sites`,`clientname`,`showSites`)}</th>
        <th>${n(`Site Name`,`sites`,`sitename`,`showSites`)}</th>
        <th>${n(`Status`,`sites`,`archived`,`showSites`)}</th>
        <th>Actions</th>
      </tr>
    </thead>

      <tbody id="siteTableBody">
        ${s.rows.map(e=>`
         <tr>
          <td>${e.siteid}</td>
          <td>${e.clientname||``}</td>
          <td>${e.sitename||``}</td>
          <td>${e.archived?`Archived`:`Active`}</td>
          <td>
            <button onclick="editSite(${e.siteid})">
              Edit
            </button>
            ${e.archived?`<button onclick="unarchiveSite(${e.siteid})">Restore</button>`:`<button onclick="archiveSite(${e.siteid})">Archive</button>`}
          </td>
        </tr>
        `).join(``)}
      </tbody>
    </table>
  `}function u(e){let r=i(t(e,`responsible`,{personid:e=>e.personid,clientname:e=>e.clientname,name:e=>e.name},`name`),`responsibleCurrentPage`,`responsibleRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h2>Responsible Persons</h2>

    <button onclick="showAddResponsiblePersonForm()">
      Add Responsible Person
    </button>

    <br><br>

    <p>
      Total Responsible Persons:
      <strong>${e.length}</strong>
    </p>

    <label><strong>Search Responsible Persons</strong></label>
    <br>

    <input
      id="responsibleSearch"
      class="search-box"
      type="text"
      placeholder="Search Customer Name or Responsible Person..."
      onkeyup="filterResponsiblePersons(true)"
    />

    <br><br>

    ${a({...r,label:`people`,onPage:`goToResponsiblePage`,onPageSize:`setResponsibleRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${n(`Person ID`,`responsible`,`personid`,`showResponsiblePersons`)}</th>
          <th>${n(`Client`,`responsible`,`clientname`,`showResponsiblePersons`)}</th>
          <th>${n(`Name`,`responsible`,`name`,`showResponsiblePersons`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody id="responsibleTableBody">
        ${r.rows.map(e=>`
          <tr>
            <td>${e.personid}</td>
            <td>${e.clientname||``}</td>
            <td>${e.name||``}</td>
            <td>
              <button onclick="editResponsiblePerson(${e.personid})">
                Edit
              </button>
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `}function d(e,r=`active`){let o=e.filter(e=>{let t=e.archived===!0||e.archived===`true`;return r===`active`?!t:r===`archived`?t:!0}),s=i(t(o,`sections`,{sectionid:e=>e.sectionid,clientname:e=>e.clientname,sitename:e=>e.sitename,responsiblename:e=>e.responsiblename,sectionname:e=>e.sectionname,archived:e=>e.archived?`Archived`:`Active`},`sectionname`),`sectionCurrentPage`,`sectionRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h2>Sections</h2>

    <div class="page-actions">
      <button onclick="showAddSectionForm()">
        Add Section
      </button>
    </div>

    <div class="filter-card">
      <p>
        Total Sections:
        <strong>${o.length}</strong>
      </p>

      <label>Show Sections</label>
      <div class="radio-row">
        ${[`active`,`archived`,`all`].map(e=>`
          <label>
            <input
              type="radio"
              name="sectionArchiveFilter"
              value="${e}"
              ${r===e?`checked`:``}
              onchange="showSections('${e}')"
            >
            ${e[0].toUpperCase()+e.slice(1)}
          </label>
        `).join(``)}
      </div>

      <label><strong><h2>Search Sections</h2></strong></label>

      <div class="form-row">
        <div class="form-group">
          <label>Search By</label>

          <select id="sectionSearchType" onchange="filterSections(true)">
            <option value="clientname">Customer</option>
            <option value="sitename">Site</option>
            <option value="responsiblename">Responsible Person</option>
            <option value="sectionname">Section</option>
          </select>
        </div>

        <div class="form-group">
          <label>Search Text</label>

          <input
            id="sectionSearch"
            class="search-box"
            type="text"
            placeholder="Type search text..."
            onkeyup="filterSections(true)"
          />
        </div>
      </div>
    </div>

    ${a({...s,label:`sections`,onPage:`goToSectionPage`,onPageSize:`setSectionRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${n(`ID`,`sections`,`sectionid`,`showSections`)}</th>
          <th>${n(`Client`,`sections`,`clientname`,`showSections`)}</th>
          <th>${n(`Site`,`sections`,`sitename`,`showSections`)}</th>
          <th>${n(`Responsible Person`,`sections`,`responsiblename`,`showSections`)}</th>
          <th>${n(`Section Name`,`sections`,`sectionname`,`showSections`)}</th>
          <th>${n(`Status`,`sections`,`archived`,`showSections`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody id="sectionTableBody">
        ${s.rows.map(e=>`
          <tr>
            <td>${e.sectionid}</td>
            <td>${e.clientname||``}</td>
            <td>${e.sitename||``}</td>
            <td>${e.responsiblename||``}</td>
            <td>${e.sectionname||``}</td>
            <td>${e.archived?`Archived`:`Active`}</td>
            <td>
              <button onclick="editSection(${e.sectionid})">
                Edit
              </button>
              ${e.archived?`<button onclick="unarchiveSection(${e.sectionid})">Restore</button>`:`<button onclick="archiveSection(${e.sectionid})">Archive</button>`}
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `}function f(e){return[`100`,`400`,`500`].includes(String(e.equipgroupid||``))?!0:(window.atecCriteria||[]).some(t=>String(t.equiptypeid)===String(e.equiptypeid)&&String(t.inspectioncategory||t.inspection_category||``).toUpperCase()===`LOADTEST`&&t.active!==!1&&t.active!==`false`)}function p(e){let t=e.serialno||e.hoistserialno||``,n=[`ADMIN`,`MANAGER`,`INSPECTOR`].includes(window.currentUser?.role);return`
    <tr>
      <td>${e.assetid}</td>
      <td>${e.assettagno||``}</td>
      <td>
        ${t}
        ${e.serialno&&e.hoistserialno&&e.serialno!==e.hoistserialno?`
          <br><small>Hoist: ${e.hoistserialno}</small>
        `:``}
      </td>
      <td>${e.clientname||``}</td>
      <td>${e.sitename||``}</td>
      <td>${e.sectionname||``}</td>
      <td>${e.equipmenttype||``}</td>
      <td>${e.description||``}</td>
      <td>
        <div class="action-buttons">
          ${n?`
            <button onclick="editAsset(${e.assetid})">
              Edit
            </button>

            <button onclick="startInspection(${e.assetid}, 'VISUAL', 'assets')">
              Inspect
            </button>

            ${f(e)?`
              <button
                class="load-test-btn"
                onclick="startInspection(${e.assetid}, 'LOADTEST', 'assets')"
              >
                Load Test
              </button>
            `:``}
          `:``}

          <button onclick="showAssetHistoryFromSetup(${e.assetid})">
            History
          </button>

          <button onclick="openAssetQrLabel(${e.assetid})">
            QR Label
          </button>

          ${n?`
            <button onclick="showMoveAssetForm(${e.assetid})">
              Move
            </button>

            <button onclick="archiveAsset(${e.assetid})">
              Archive
            </button>
          `:``}
        </div>
      </td>
    </tr>
  `}function ee(e){let r=t(e,`assets`,{assetid:e=>e.assetid,assettagno:e=>e.assettagno,serialno:e=>e.serialno||e.hoistserialno,clientname:e=>e.clientname,sitename:e=>e.sitename,sectionname:e=>e.sectionname,equipmenttype:e=>e.equipmenttype,description:e=>e.description,qrcode:e=>e.qrcode},`assetid`),i=window.assetRowsPerPage||25,a=Math.max(1,Math.ceil(r.length/i)),o=Math.min(window.assetCurrentPage||1,a),s=(o-1)*i,c=r.slice(s,s+i),l=r.length===0?0:s+c.length,u=m(r.length,s,l,o,a,i,!0),d=m(r.length,s,l,o,a,i,!1);document.querySelector(`#page`).innerHTML=`
    <h1>Asset Setup</h1>

    ${[`ADMIN`,`MANAGER`,`INSPECTOR`].includes(window.currentUser?.role)?`
      <div class="page-actions">
        <button onclick="showAddAssetForm()">
          Add Asset
        </button>
      </div>
    `:``}

    <div class="filter-card">
      <p>
        Total Assets:
        <strong>${r.length}</strong>
      </p>

      <h2>Search Assets</h2>

      <div class="form-row">
        <div class="form-group">
          <label>Search By</label>

          <select id="assetSearchType" onchange="filterAssets(true)">
            <option value="all">All Fields</option>
            <option value="assetid">Asset ID</option>
            <option value="assettagno">Asset Tag</option>
            <option value="serialno">Serial No</option>
            <option value="hoistserialno">Hoist Serial No</option>
            <option value="clientname">Client</option>
            <option value="sitename">Site</option>
            <option value="sectionname">Section</option>
            <option value="equipmenttype">Equipment Type</option>
            <option value="description">Description</option>
            <option value="qrcode">QR Code</option>
          </select>
        </div>

        <div class="form-group">
          <label>Search Text</label>

          <input
            id="assetSearch"
            class="search-box"
            type="text"
            placeholder="Type search text..."
            onkeyup="filterAssets(true)"
          />
        </div>
      </div>

      <div class="filter-key-row">
        ${[[`all`,`All`],[`assetid`,`Asset ID`],[`assettagno`,`Asset Tag`],[`serialno`,`Serial No`],[`hoistserialno`,`Hoist Serial No`],[`clientname`,`Client`],[`sitename`,`Site`],[`sectionname`,`Section`],[`equipmenttype`,`Equipment Type`],[`description`,`Description`],[`qrcode`,`QR Code`]].map(([e,t])=>`
          <button type="button" class="filter-key-btn" onclick="setAssetFilterKey('${e}')">
            ${t}
          </button>
        `).join(``)}
      </div>
    </div>

    ${u}

    <table>
      <thead>
        <tr>
          <th>${n(`Asset ID`,`assets`,`assetid`,`showAssetSetup`)}</th>
          <th>${n(`Asset Tag`,`assets`,`assettagno`,`showAssetSetup`)}</th>
          <th>${n(`Serial No`,`assets`,`serialno`,`showAssetSetup`)}</th>
          <th>${n(`Client`,`assets`,`clientname`,`showAssetSetup`)}</th>
          <th>${n(`Site`,`assets`,`sitename`,`showAssetSetup`)}</th>
          <th>${n(`Section`,`assets`,`sectionname`,`showAssetSetup`)}</th>
          <th>${n(`Equipment Type`,`assets`,`equipmenttype`,`showAssetSetup`)}</th>
          <th>${n(`Description`,`assets`,`description`,`showAssetSetup`)}</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody id="assetTableBody">
        ${c.map(p).join(``)}
      </tbody>
    </table>

    ${d}
  `}function m(e,t,n,r,i,a,o){let s=g(r,i);return`
    <div ${o?`id="assetPaginationControls"`:``} class="report-pagination-bar asset-pagination-bar ${o?``:`asset-pagination-bottom`}">
      ${o?`
        <div class="report-page-size">
          <label for="assetRowsPerPage">Rows per page</label>
          <select id="assetRowsPerPage" onchange="setAssetRowsPerPage(this.value)">
            ${[25,50,100,250].map(e=>`
              <option value="${e}" ${e===a?`selected`:``}>
                ${e}
              </option>
            `).join(``)}
          </select>
        </div>
      `:`<div></div>`}

      <div class="report-page-controls">
        <button type="button" onclick="changeAssetPage(-1)" ${r<=1?`disabled`:``}>
          Previous
        </button>
        ${s}
        <button type="button" onclick="changeAssetPage(1)" ${r>=i?`disabled`:``}>
          Next
        </button>
        <span>Showing ${e===0?0:t+1} to ${n} of ${e} assets - Page ${r} of ${i}</span>
      </div>
    </div>
  `}function h(e,t){let n=[];if(t<=7){for(let e=1;e<=t;e+=1)n.push(e);return n}n.push(1),e>4&&n.push(`...`);let r=Math.max(2,e-1),i=Math.min(t-1,e+1);for(let e=r;e<=i;e+=1)n.push(e);return e<t-3&&n.push(`...`),n.push(t),n}function g(e,t){return h(e,t).map(t=>t===`...`?`<span class="pagination-ellipsis">...</span>`:`
      <button
        type="button"
        class="pagination-page-btn ${t===e?`active`:``}"
        onclick="goToAssetPage(${t})"
        ${t===e?`disabled`:``}
      >
        ${t}
      </button>
    `).join(``)}function te(e){let r=i(t([...e].reverse(),`inspectionAssets`,{assetid:e=>e.assetid,assettagno:e=>e.assettagno,serialno:e=>e.serialno,clientname:e=>e.clientname,sitename:e=>e.sitename,sectionname:e=>e.sectionname,description:e=>e.description,equipmenttype:e=>e.equipmenttype},`assetid`),`inspectionCurrentPage`,`inspectionRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h1>Inspections/Load Tests</h1>

    <div class="filter-card">
      <label><strong><h2>Search Assets</h2></strong></label>

      <div class="form-row">
        <div class="form-group">
          <label>Search By</label>

          <select id="inspectionSearchType" onchange="filterInspectionAssets(true)">
            <option value="all">All Fields</option>
            <option value="assetid">Asset ID</option>
            <option value="assettagno">Asset Tag</option>
            <option value="serialno">Serial No</option>
            <option value="clientname">Client</option>
            <option value="sitename">Site</option>
            <option value="sectionname">Section</option>
            <option value="description">Description</option>
            <option value="equipmenttype">Equipment Type</option>
          </select>
        </div>

        <div class="form-group">
          <label>Search Text</label>

          <input
            id="inspectionAssetSearch"
            class="search-box"
            type="text"
            placeholder="Type search text..."
            onkeyup="filterInspectionAssets(true)"
          />
        </div>
      </div>

      <div class="filter-key-row">
        ${[[`all`,`All`],[`assetid`,`Asset ID`],[`assettagno`,`Asset Tag`],[`serialno`,`Serial No`],[`clientname`,`Client`],[`sitename`,`Site`],[`sectionname`,`Section`],[`equipmenttype`,`Equipment Type`],[`description`,`Description`]].map(([e,t])=>`
          <button type="button" class="filter-key-btn" onclick="setInspectionFilterKey('${e}')">
            ${t}
          </button>
        `).join(``)}
      </div>
    </div>

    ${a({...r,label:`assets`,onPage:`goToInspectionPage`,onPageSize:`setInspectionRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${n(`Asset ID`,`inspectionAssets`,`assetid`,`showInspections`)}</th>
          <th>${n(`Asset Tag`,`inspectionAssets`,`assettagno`,`showInspections`)}</th>
          <th>${n(`Serial No`,`inspectionAssets`,`serialno`,`showInspections`)}</th>
          <th>${n(`Client`,`inspectionAssets`,`clientname`,`showInspections`)}</th>
          <th>${n(`Site`,`inspectionAssets`,`sitename`,`showInspections`)}</th>
          <th>${n(`Section`,`inspectionAssets`,`sectionname`,`showInspections`)}</th>
          <th>${n(`Description`,`inspectionAssets`,`description`,`showInspections`)}</th>
          <th>${n(`Equipment Type`,`inspectionAssets`,`equipmenttype`,`showInspections`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody id="inspectionAssetTableBody">
        ${r.rows.map(e=>`
          <tr>
            <td>${e.assetid}</td>
            <td>${e.assettagno||``}</td>
            <td>${e.serialno||``}</td>
            <td>${e.clientname||``}</td>
            <td>${e.sitename||``}</td>
            <td>${e.sectionname||``}</td>
            <td>${e.description||``}</td>
            <td>${e.equipmenttype||``}</td>
            <td>
  <div class="action-buttons">

    <button
          onclick="startInspection(${e.assetid}, 'VISUAL', 'inspections')">
          Inspection
        </button>

        ${[`100`,`400`,`500`].includes(String(e.equipgroupid))?`
            <button
              class="load-test-btn"
              onclick="startInspection(${e.assetid}, 'LOADTEST', 'inspections')">
              Load Test
            </button>
          `:``}

      </div>
    </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>

    <br>

    <div id="inspectionFormContainer"></div>
  `}function ne(e,r){let o=[...e].sort((e,t)=>(e.description||``).localeCompare(t.description||``)),s=window.criteriaEquipmentFilter||``,c=i(t(s?r.filter(e=>String(e.equiptypeid)===String(s)):r,`criteria`,{equipmenttype:e=>e.equipmenttype,inspectioncategory:e=>e.inspectioncategory,inspection_category:e=>e.inspection_category,severity:e=>e.severity,criterianame:e=>e.criterianame,resulttype:e=>e.resulttype,active:e=>e.active?`Active`:`Inactive`},`equipmenttype`),`criteriaCurrentPage`,`criteriaRowsPerPage`);document.querySelector(`#page`).innerHTML=`
    <h1>Equipment Type Criteria Setup</h1>

    <div class="filter-card">
      <div class="form-row">
        <div class="form-group">
          <label>Show Criteria For</label>
          <select id="criteriaEquipmentFilter" onchange="filterEquipmentCriteria()">
            <option value="">All Equipment Types</option>
            ${o.map(e=>`
              <option
                value="${e.equiptypeid}"
                ${String(e.equiptypeid)===String(s)?`selected`:``}
              >
                ${e.description}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="form-group criteria-action-group">
          <button type="button" onclick="openCriteriaPopup()">
            Add Criteria
          </button>
        </div>
      </div>
    </div>

    ${a({...c,label:`criteria`,onPage:`goToCriteriaPage`,onPageSize:`setCriteriaRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${n(`Equipment Type`,`criteria`,`equipmenttype`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Type`,`criteria`,`inspectioncategory`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Category`,`criteria`,`inspection_category`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Severity`,`criteria`,`severity`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Criteria`,`criteria`,`criterianame`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Result Type`,`criteria`,`resulttype`,`showEquipmentTypeCriteria`)}</th>
          <th>${n(`Status`,`criteria`,`active`,`showEquipmentTypeCriteria`)}</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody>
        ${c.rows.map(e=>`
          <tr>
            <td>${e.equipmenttype||``}</td>
            <td>${e.inspectioncategory||``}</td>
            <td>${_(e.inspection_category)}</td>
            <td>${_(e.severity)}</td>
            <td>${e.criteriadescription||e.criterianame||``}</td>
            <td>${_(e.resulttype||e.fieldtype)}</td>
            <td>${e.active===!1?`Inactive`:`Active`}</td>
            <td class="criteria-row-actions">
              <button type="button" onclick="editCriteria(${e.criteriaid})">
                Edit
              </button>
              <button type="button" onclick="deleteCriteria(${e.criteriaid})">
                Delete
              </button>
            </td>
          </tr>
        `).join(``)||`
          <tr>
            <td colspan="8">No criteria found for the selected equipment type.</td>
          </tr>
        `}
      </tbody>
    </table>
  `}function _(e){return String(e||``).replaceAll(`_`,` `).toLowerCase().replace(/\b\w/g,e=>e.toUpperCase())}function re(){document.querySelector(`#page`).innerHTML=`
    <h2>Quick Inspection/Test</h2>

    <div class="filter-card">
      <h3>Scan / Search Asset</h3>

      <label>QR Code, Serial No or Asset Tag</label>

      <input
        id="quickAssetSearch"
        class="quick-scan-box"
        type="text"
        placeholder="Scan or type here..."
        autofocus
        onkeydown="handleQuickInspectionEnter(event)"
      >

      <button onclick="quickFindAsset()">
        Find Asset
      </button>
    </div>

    <div id="quickInspectionResult"></div>
  `}var v=`/atec/`;function y(){{let e=v.replace(/\/$/,``);return`${window.location.origin}${e}/api`}return`http://localhost:5000`}var b=y().replace(/\/$/,``);function x(e=``){return`${v}${String(e||``).replace(/^\/+/,``)}`}async function S(e){let t=await e.text();if(!t)return{};try{return JSON.parse(t)}catch{return{error:e.ok?`The server returned an unexpected certificate response.`:`The server returned an unexpected error while loading the certificate.`}}}function ie(e=[],t=[],n=[]){document.querySelector(`#page`).innerHTML=`
    <h1>Certificates</h1>
    <p>Search, view and manage inspection and load test certificates.</p>

    <div class="filter-card">
      <h2>Search Certificates</h2>

      <div class="asset-form-grid">
        <div class="form-group">
          <label>Broad Search</label>
          <input
            id="certSearch"
            type="text"
            placeholder="Test ID, tag, serial, client, site, asset description..."
          >
        </div>

        <div class="form-group">
          <label>Inspection Type</label>
          <select id="certInspectionType">
            <option value="">All Types</option>
            <option value="VISUAL">Visual Inspection</option>
            <option value="LOADTEST">Load Test</option>
          </select>
        </div>

        <div class="form-group">
          <label>Status</label>
          <select id="certStatus">
            <option value="">All Statuses</option>
            <option value="SAFE">SAFE</option>
            <option value="NOT SAFE">NOT SAFE</option>
          </select>
        </div>

        <div class="form-group">
          <label>Client</label>
          <select id="certClient">
            <option value="">All Clients</option>
            ${e.map(e=>`
              <option value="${e.clientid}">${e.clientname}</option>
            `).join(``)}
          </select>
        </div>

        <div class="form-group">
          <label>Site</label>
          <select id="certSite">
            <option value="">All Sites</option>
          </select>
        </div>

        <div class="form-group">
          <label>Section</label>
          <select id="certSection">
            <option value="">All Sections</option>
          </select>
        </div>

        <div class="form-group">
          <label>Date From</label>
          <input id="certDateFrom" type="date">
        </div>

        <div class="form-group">
          <label>Date To</label>
          <input id="certDateTo" type="date">
        </div>
      </div>

      <div class="form-actions">
        <button id="certSearchBtn">Search</button>
        <button id="certClearBtn">Clear Filters</button>
      </div>
    </div>

    <div class="filter-card bulk-certificate-card">
      <h2>Bulk Print Certificates</h2>
      <p>Select a customer and date range, then choose the certificates to print together.</p>

      <div class="asset-form-grid">
        <div class="form-group">
          <label>Customer</label>
          <select id="bulkCertClient">
            <option value="">Select Customer</option>
            ${e.map(e=>`
              <option value="${e.clientid}">${e.clientname}</option>
            `).join(``)}
          </select>
        </div>

        <div class="form-group">
          <label>Date From</label>
          <input id="bulkCertDateFrom" type="date">
        </div>

        <div class="form-group">
          <label>Date To</label>
          <input id="bulkCertDateTo" type="date">
        </div>

        <div class="form-group">
          <label>Site</label>
          <select id="bulkCertSite">
            <option value="">All Sites</option>
          </select>
        </div>

        <div class="form-group">
          <label>Inspection Type</label>
          <select id="bulkCertInspectionType">
            <option value="ALL">All Types</option>
            <option value="VISUAL">Visual Inspection</option>
            <option value="LOADTEST">Load Test</option>
          </select>
        </div>

        <div class="form-group">
          <label>Status</label>
          <select id="bulkCertStatus">
            <option value="ALL">All Statuses</option>
            <option value="SAFE">SAFE</option>
            <option value="NOT SAFE">NOT SAFE</option>
          </select>
        </div>
      </div>

      <div class="form-actions">
        <button id="bulkCertSearchBtn" type="button">Load Certificates</button>
        <button id="bulkCertPrintBtn" type="button" disabled>Print Selected Certificates</button>
        <button id="bulkCertDownloadSelectedBtn" type="button" disabled>Download Selected as PDF</button>
        <button id="bulkCertDownloadAllBtn" type="button" disabled>Download All Results as PDF</button>
      </div>

      <div id="bulkCertificateResults" class="bulk-certificate-results">
        <p>No bulk search loaded yet.</p>
      </div>
    </div>

    <div class="certificate-dashboard-grid">
      <div class="filter-card">
        <h2>Search Results</h2>
        <div id="certificateResults">
          <p>Loading certificates...</p>
        </div>
      </div>

      <div>
        <div class="filter-card">
          <h2>Quick Stats</h2>
          <div id="certificateStats">
            <p>No search loaded yet.</p>
          </div>
        </div>

        <div class="filter-card" id="certificatePreviewPanel">
          <h2>Certificate Preview</h2>
          <p>Select Preview on a certificate to view quick details here.</p>
        </div>
      </div>
    </div>
  `,window.certificateCustomers=e,window.certificateSites=t,window.certificateSections=n,C(),document.querySelector(`#certSearch`).addEventListener(`keydown`,e=>{e.key===`Enter`&&window.searchCertificates()}),document.querySelector(`#certClient`).addEventListener(`change`,window.filterCertificateSites),document.querySelector(`#certSite`).addEventListener(`change`,window.filterCertificateSections),document.querySelector(`#certSearchBtn`).addEventListener(`click`,window.searchCertificates),document.querySelector(`#certClearBtn`).addEventListener(`click`,window.clearCertificateSearch),document.querySelector(`#bulkCertClient`).addEventListener(`change`,window.filterBulkCertificateSites),document.querySelector(`#bulkCertSearchBtn`).addEventListener(`click`,window.searchBulkCertificates),document.querySelector(`#bulkCertPrintBtn`).addEventListener(`click`,window.printSelectedBulkCertificates),document.querySelector(`#bulkCertDownloadSelectedBtn`).addEventListener(`click`,window.downloadSelectedBulkCertificatesPdf),document.querySelector(`#bulkCertDownloadAllBtn`).addEventListener(`click`,window.downloadAllBulkCertificatesPdf),window.searchCertificates()}function C(){Object.assign(window,we)}window.filterCertificateSites=function(){let e=document.querySelector(`#certClient`).value,t=document.querySelector(`#certSite`),n=document.querySelector(`#certSection`);n.innerHTML=`<option value="">All Sections</option>`,t.innerHTML=`
    <option value="">All Sites</option>
    ${(e?window.certificateSites.filter(t=>String(t.clientid)===String(e)):window.certificateSites).map(e=>`
      <option value="${e.siteid}">${e.sitename}</option>
    `).join(``)}
  `},window.filterCertificateSections=function(){let e=document.querySelector(`#certSite`).value,t=document.querySelector(`#certSection`);t.innerHTML=`
    <option value="">All Sections</option>
    ${(e?window.certificateSections.filter(t=>String(t.siteid)===String(e)):window.certificateSections).map(e=>`
      <option value="${e.sectionid}">${e.sectionname}</option>
    `).join(``)}
  `},window.filterBulkCertificateSites=function(){let e=document.querySelector(`#bulkCertClient`).value,t=document.querySelector(`#bulkCertSite`);t.innerHTML=`
    <option value="">All Sites</option>
    ${(e?window.certificateSites.filter(t=>String(t.clientid)===String(e)):[]).map(e=>`
      <option value="${e.siteid}">${e.sitename}</option>
    `).join(``)}
  `},window.clearCertificateSearch=function(){document.querySelector(`#certSearch`).value=``,document.querySelector(`#certInspectionType`).value=``,document.querySelector(`#certStatus`).value=``,document.querySelector(`#certClient`).value=``,document.querySelector(`#certSite`).innerHTML=`<option value="">All Sites</option>`,document.querySelector(`#certSection`).innerHTML=`<option value="">All Sections</option>`,document.querySelector(`#certDateFrom`).value=``,document.querySelector(`#certDateTo`).value=``,window.certCurrentPage=1,window.searchCertificates()},window.searchCertificates=async function(e=!0){e&&(window.certCurrentPage=1);let t=new URLSearchParams;t.append(`search`,document.querySelector(`#certSearch`)?.value||``),t.append(`inspectiontype`,document.querySelector(`#certInspectionType`)?.value||``),t.append(`status`,document.querySelector(`#certStatus`)?.value||``),t.append(`clientid`,document.querySelector(`#certClient`)?.value||``),t.append(`siteid`,document.querySelector(`#certSite`)?.value||``),t.append(`sectionid`,document.querySelector(`#certSection`)?.value||``),t.append(`datefrom`,document.querySelector(`#certDateFrom`)?.value||``),t.append(`dateto`,document.querySelector(`#certDateTo`)?.value||``);let n=await fetch(`${b}/certificates/search?${t.toString()}`),r=await n.json();if(!n.ok){alert(`Error searching certificates: `+r.error);return}ae(r),window.currentCertificateResults=r,T(r)};function ae(e){let t=e.filter(e=>e.status===`SAFE`).length,n=e.filter(e=>e.status===`NOT SAFE`).length,r=e.filter(e=>e.inspectiontype===`LOADTEST`).length,i=e.filter(e=>e.inspectiontype===`VISUAL`).length;document.querySelector(`#certificateStats`).innerHTML=`
    <p><strong>Total:</strong> ${e.length}</p>
    <p><strong>Safe:</strong> ${t}</p>
    <p><strong>Not Safe:</strong> ${n}</p>
    <p><strong>Visual:</strong> ${i}</p>
    <p><strong>Load Tests:</strong> ${r}</p>
  `}function w(t,n){let r=e(`certificates`,`testid`),i=r.key===n,a=i?r.direction===`desc`?`v`:`^`:`^v`;return`
    <span class="certificate-sort-heading">
      <span>${t}</span>
      <button
        type="button"
        class="certificate-sort-btn ${i?`active`:``}"
        onclick="sortTable('certificates', '${n}', 'rerenderCertificateResults')"
        aria-label="Sort ${t}"
        title="Sort ${t}"
      >${a}</button>
    </span>
  `}function T(e){if(e.length===0){document.querySelector(`#certificateResults`).innerHTML=`<p>No certificates found.</p>`;return}let n=i(t(e,`certificates`,{testid:e=>e.testid,tagnumber:e=>e.tagnumber,clientname:e=>e.clientname,sitename:e=>e.sitename,description:e=>e.description,serialno:e=>e.serialno,inspectiontype:e=>e.inspectiontype,testdate:e=>e.testdate,status:e=>e.status,inspector:e=>e.inspector},`testid`),`certCurrentPage`,`certRowsPerPage`);document.querySelector(`#certificateResults`).innerHTML=`
    ${a({...n,label:`certificates`,onPage:`goToCertificatePage`,onPageSize:`setCertificateRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${w(`Test ID`,`testid`)}</th>
          <th>${w(`Tag No`,`tagnumber`)}</th>
          <th>${w(`Client`,`clientname`)}</th>
          <th>${w(`Site`,`sitename`)}</th>
          <th>${w(`Asset`,`description`)}</th>
          <th>${w(`Serial No`,`serialno`)}</th>
          <th>${w(`Type`,`inspectiontype`)}</th>
          <th>${w(`Date`,`testdate`)}</th>
          <th>${w(`Status`,`status`)}</th>
          <th>${w(`Inspector`,`inspector`)}</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody>
        ${n.rows.map(e=>`
          <tr data-testid="${e.testid}">
            <td>${e.testid}</td>
            <td>${e.tagnumber||`-`}</td>
            <td>${e.clientname||``}</td>
            <td>${e.sitename||``}</td>
            <td>${e.description||``}</td>
            <td>${e.serialno||``}</td>
            <td>${e.inspectiontype||``}</td>
            <td>${P(e.testdate)}</td>
            <td>
              <strong class="${e.status===`SAFE`?`status-safe`:`status-unsafe`}">
                ${e.status||``}
              </strong>
            </td>
            <td>${e.inspector||`-`}</td>
            <td>
              <button type="button" class="cert-preview-btn" data-testid="${e.testid}">
                Preview
              </button>

              <button type="button" class="cert-view-btn" data-testid="${e.testid}">
                View
              </button>

              <a
                class="cert-action-link"
                href="${b}/inspections/${e.testid}/certificate.pdf"
                download="certificate-${e.testid}.pdf"
                onclick="event.stopPropagation()"
              >
                Download PDF
              </a>

              <button type="button" class="cert-mail-btn" data-testid="${e.testid}">
                Mail
              </button>
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `,D()}window.searchBulkCertificates=async function(){let e=document.querySelector(`#bulkCertClient`).value,t=document.querySelector(`#bulkCertDateFrom`).value,n=document.querySelector(`#bulkCertDateTo`).value,r=document.querySelector(`#bulkCertSite`).value,i=document.querySelector(`#bulkCertInspectionType`).value,a=document.querySelector(`#bulkCertStatus`).value;if(!e||!t||!n){alert(`Please select a customer, Date From and Date To for bulk printing.`);return}let o=new URLSearchParams({clientid:e,datefrom:t,dateto:n});r&&o.set(`siteid`,r),i&&i!==`ALL`&&o.set(`inspectiontype`,i),a&&a!==`ALL`&&o.set(`status`,a);let s=document.querySelector(`#bulkCertificateResults`),c=document.querySelector(`#bulkCertPrintBtn`),l=document.querySelector(`#bulkCertDownloadSelectedBtn`),u=document.querySelector(`#bulkCertDownloadAllBtn`);s.innerHTML=`<p>Loading matching certificates...</p>`,c.disabled=!0,l.disabled=!0,u.disabled=!0;let d=await fetch(`${b}/certificates/bulk-print?${o.toString()}`),f=await d.json();if(!d.ok){s.innerHTML=`<p>No bulk search loaded yet.</p>`,alert(`Error loading bulk certificates: `+(f.error||`Unable to load certificates`));return}window.bulkCertificateResults=f.certificates||[],oe(window.bulkCertificateResults)};function oe(e){let t=document.querySelector(`#bulkCertificateResults`),n=document.querySelector(`#bulkCertPrintBtn`),r=document.querySelector(`#bulkCertDownloadSelectedBtn`),i=document.querySelector(`#bulkCertDownloadAllBtn`);if(!e.length){t.innerHTML=`<p>No certificates found for the selected customer and date range.</p>`,n.disabled=!0,r.disabled=!0,i.disabled=!0;return}t.innerHTML=`
    <div class="bulk-certificate-summary">
      <strong>${e.length}</strong> matching certificate${e.length===1?``:`s`} found.
    </div>

    <div class="table-scroll bulk-certificate-table-wrap">
      <table class="bulk-certificate-table">
        <thead>
          <tr>
            <th>
              <input
                type="checkbox"
                id="bulkCertSelectAll"
                checked
                aria-label="Select all certificates"
              >
            </th>
            <th>Certificate No</th>
            <th>Date</th>
            <th>Valid Date</th>
            <th>Type</th>
            <th>Status</th>
            <th>Asset</th>
            <th>Asset Tag</th>
            <th>Serial No</th>
            <th>Site</th>
            <th>Inspector</th>
          </tr>
        </thead>

        <tbody>
          ${e.map(e=>{let t=e.inspection||{};return`
              <tr>
                <td>
                  <input
                    type="checkbox"
                    class="bulk-cert-check"
                    value="${t.testid}"
                    checked
                    aria-label="Select certificate ${t.testid}"
                  >
                </td>
                <td>${t.testid||``}</td>
                <td>${P(t.testdate)}</td>
                <td>${P(t.validdate)}</td>
                <td>${t.inspectiontype||``}</td>
                <td>
                  <strong class="${t.status===`SAFE`?`status-safe`:`status-unsafe`}">
                    ${t.status||``}
                  </strong>
                </td>
                <td>${t.description||``}</td>
                <td>${t.assettagno||t.tagnumber||`-`}</td>
                <td>${t.serialno||``}</td>
                <td>${t.sitename||``}</td>
                <td>${t.inspector||`-`}</td>
              </tr>
            `}).join(``)}
        </tbody>
      </table>
    </div>
  `,document.querySelector(`#bulkCertSelectAll`).addEventListener(`change`,e=>{document.querySelectorAll(`.bulk-cert-check`).forEach(t=>{t.checked=e.target.checked}),E()}),document.querySelectorAll(`.bulk-cert-check`).forEach(e=>{e.addEventListener(`change`,E)}),E(),i.disabled=!1}function E(){let e=document.querySelectorAll(`.bulk-cert-check:checked`).length,t=document.querySelector(`#bulkCertPrintBtn`),n=document.querySelector(`#bulkCertDownloadSelectedBtn`),r=document.querySelector(`#bulkCertSelectAll`);if(t&&(t.disabled=e===0,t.textContent=e?`Print Selected Certificates (${e})`:`Print Selected Certificates`),n&&(n.disabled=e===0,n.textContent=e?`Download Selected PDFs (${e})`:`Download Selected PDFs`),r){let t=document.querySelectorAll(`.bulk-cert-check`).length;r.checked=e>0&&e===t,r.indeterminate=e>0&&e<t}}window.printSelectedBulkCertificates=function(){let e=Array.from(document.querySelectorAll(`.bulk-cert-check:checked`)).map(e=>String(e.value));if(!e.length){alert(`Select at least one certificate to print.`);return}let t=(window.bulkCertificateResults||[]).filter(t=>e.includes(String(t.inspection?.testid)));if(!t.length){alert(`No selected certificates could be prepared for printing.`);return}let n=document.querySelector(`#bulkCertificatePrintView`);n&&n.remove();let r=document.createElement(`div`);r.id=`bulkCertificatePrintView`,r.className=`bulk-certificate-print-view`,r.innerHTML=`
    <div class="bulk-print-toolbar screen-only">
      <h2>Bulk Certificate Print</h2>
      <div class="form-actions">
        <button type="button" id="bulkPrintNowBtn">Print</button>
        <button type="button" id="bulkPrintCloseBtn">Close</button>
      </div>
    </div>

    <div class="bulk-certificate-print-pages">
      ${t.map(e=>`
        <section class="bulk-certificate-page">
          ${de(e)}
        </section>
      `).join(``)}
    </div>
  `,document.body.appendChild(r),document.body.classList.add(`bulk-print-mode`),document.querySelector(`#bulkPrintCloseBtn`).addEventListener(`click`,window.closeBulkCertificatePrintView),document.querySelector(`#bulkPrintNowBtn`).addEventListener(`click`,()=>{window.print()}),setTimeout(()=>window.print(),250)},window.closeBulkCertificatePrintView=function(){let e=document.querySelector(`#bulkCertificatePrintView`);e&&e.remove(),document.body.classList.remove(`bulk-print-mode`)};function se(){let e=document.querySelector(`#bulkCertClient`).value,t=document.querySelector(`#bulkCertDateFrom`).value,n=document.querySelector(`#bulkCertDateTo`).value,r=document.querySelector(`#bulkCertSite`).value,i=document.querySelector(`#bulkCertInspectionType`).value,a=document.querySelector(`#bulkCertStatus`).value;if(!e||!t||!n)return alert(`Please select a customer, Date From and Date To before downloading PDFs.`),null;let o=new URLSearchParams({clientid:e,datefrom:t,dateto:n});return r&&o.set(`siteid`,r),i&&i!==`ALL`&&o.set(`inspectiontype`,i),a&&a!==`ALL`&&o.set(`status`,a),o}function ce(){return Array.from(document.querySelectorAll(`.bulk-cert-check:checked`)).map(e=>String(e.value))}window.downloadSelectedBulkCertificatesPdf=async function(){let e=ce();if(!e.length){alert(`Select at least one certificate to download.`);return}await Ce(e)},window.downloadAllBulkCertificatesPdf=async function(){if(!(window.bulkCertificateResults||[]).length){alert(`No certificates found to download. Load certificates first.`);return}let e=se();e&&await le(e)};async function le(e){let t=await fetch(`${b}/certificates/bulk-pdf?${e.toString()}`);if(!t.ok){let e=await t.json().catch(()=>({error:`Unable to download bulk certificates`}));alert(e.error||`Unable to download bulk certificates`);return}let n=await t.blob(),r=ue(t.headers.get(`content-disposition`),`FB-Certificates.pdf`),i=window.URL.createObjectURL(n),a=document.createElement(`a`);a.href=i,a.download=r,document.body.appendChild(a),a.click(),a.remove(),window.URL.revokeObjectURL(i)}function ue(e,t){let n=String(e||``).match(/filename="?([^"]+)"?/i);return n?n[1]:t}window.setCertificateRowsPerPage=function(e){window.certRowsPerPage=Number(e)||25,window.certCurrentPage=1,T(window.currentCertificateResults||[])},window.rerenderCertificateResults=function(){window.certCurrentPage=1,T(window.currentCertificateResults||[])},window.goToCertificatePage=function(e){window.certCurrentPage=Math.max(1,Number(e)||1),T(window.currentCertificateResults||[])};function D(){document.querySelectorAll(`#certificateResults tbody tr`).forEach(e=>{e.addEventListener(`click`,()=>{window.selectCertificateRow(e,e.dataset.testid)})}),document.querySelectorAll(`.cert-preview-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation(),window.previewCertificate(e.dataset.testid)})}),document.querySelectorAll(`.cert-view-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation(),window.openCertificateModal(e.dataset.testid)})}),document.querySelectorAll(`.cert-mail-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault(),t.stopPropagation(),window.mailCertificate(e.dataset.testid)})})}window.selectCertificateRow=function(e,t){document.querySelectorAll(`#certificateResults tbody tr`).forEach(e=>e.classList.remove(`selected-certificate-row`)),e.classList.add(`selected-certificate-row`),window.previewCertificate(t)},window.previewCertificate=async function(e){let t=await fetch(`${b}/inspections/${e}/certificate`),n=await S(t);if(!t.ok){alert(`Error loading certificate preview: `+n.error);return}let r=n.inspection,i=n.results||[],a=i.filter(e=>e.result===`FAIL`).length,o=i.filter(e=>e.result===`PASS`).length,s=xe(r),c=r.status===`SAFE`?`status-safe`:`status-unsafe`;document.querySelector(`#certificatePreviewPanel`).innerHTML=`
    <h2>Certificate Preview</h2>

    <div class="certificate-preview-status ${c}">
      ${r.status||`-`}
    </div>

    <div class="certificate-preview-row">
      <span>Certificate No</span>
      <strong>${r.testid}</strong>
    </div>

    <div class="certificate-preview-row">
      <span>Tag No</span>
      <strong>${r.tagnumber||`-`}</strong>
    </div>

    <hr>

    <div class="certificate-preview-row">
      <span>Client</span>
      <strong>${r.clientname||`-`}</strong>
    </div>

    <div class="certificate-preview-row">
      <span>Site</span>
      <strong>${r.sitename||`-`}</strong>
    </div>

    <div class="certificate-preview-row">
      <span>Section</span>
      <strong>${r.sectionname||`-`}</strong>
    </div>

    <hr>

    <p><strong>Asset</strong><br>${r.description||`-`}</p>
    <p><strong>Equipment Type</strong><br>${r.equipmenttype||`-`}</p>
    <p><strong>Serial No</strong><br>${r.serialno||`-`}</p>

    <hr>

    <div class="certificate-preview-row">
      <span>Type</span>
      <strong>${r.inspectiontype||`-`}</strong>
    </div>

    <div class="certificate-preview-row">
      <span>Date</span>
      <strong>${P(r.testdate)}</strong>
    </div>

    <div class="certificate-preview-row">
      <span>Certificate Expiry Date</span>
      <strong>${P(r.validdate)}</strong>
    </div>

    <div class="certificate-preview-row">
      <span>Inspector</span>
      <strong>${r.inspector||`-`}</strong>
    </div>

    <hr>

    <div class="certificate-preview-summary">
      <div>
        <span>Passed</span>
        <strong>${o}</strong>
      </div>

      <div>
        <span>Failed</span>
        <strong>${a}</strong>
      </div>
    </div>

    ${s.map(e=>`
      <p class="fb-cert-driven-note">
        ${e}
      </p>
    `).join(``)}

    <div class="form-actions">
      <button type="button" id="previewOpenCertificateBtn">Open</button>
      <button type="button" id="previewPrintCertificateBtn">Print</button>
    </div>
  `,document.querySelector(`#previewOpenCertificateBtn`).addEventListener(`click`,()=>window.openCertificateModal(r.testid)),document.querySelector(`#previewPrintCertificateBtn`).addEventListener(`click`,async()=>{await window.openCertificateModal(r.testid),setTimeout(()=>{Se(),window.print()},250)})},window.openCertificateModal=async function(e){let t=await fetch(`${b}/inspections/${e}/certificate`),n=await S(t);if(!t.ok){alert(`Error loading certificate: `+n.error);return}let r=n.inspection,i=document.querySelector(`#certificateModal`);i&&i.remove();let a=document.createElement(`div`);a.id=`certificateModal`,a.className=`certificate-modal-overlay`,a.innerHTML=`
    <div class="certificate-modal certificate-original-layout">

      <div class="certificate-modal-header screen-only">
        <h2>Certificate ${r.testid}</h2>
        <div class="form-actions">
          <a
            id="certificatePrintBtn"
            class="cert-action-link"
            href="${b}/inspections/${r.testid}/certificate.pdf?inline=1"
            target="_blank"
          >
            Print
          </a>
          <a
            id="certificateDownloadPdfBtn"
            class="cert-action-link"
            href="${b}/inspections/${r.testid}/certificate.pdf"
            download="certificate-${r.testid}.pdf"
          >
            Download PDF
          </a>
          <button type="button" id="certificateMailBtn">Mail</button>
          <button type="button" id="certificateCloseBtn">Close</button>
        </div>
      </div>

      <div class="certificate-modal-body" id="certificatePrintArea">
        ${de(n)}
      </div>
    </div>
  `,document.body.appendChild(a),document.querySelector(`#certificateCloseBtn`).addEventListener(`click`,window.closeCertificateModal),document.querySelector(`#certificateMailBtn`).addEventListener(`click`,()=>{window.mailCertificate(r.testid)})};function de(e){let t=e.inspection||{},n=he(e.results||[],t),r=O(t,e.photos||[]),i=k(t),a=fe(t),o=xe(t);return`
    <div class="fb-cert-page">
      <img src="${x(`header.jpg`)}" class="fb-cert-header" alt="FB Cranes Header">

      <div class="fb-cert-title">
        <h1>${a}</h1>
      </div>

      <div class="fb-cert-meta">
        <div>
          <strong>Certificate No:</strong>
          <span>${t.testid}</span>
        </div>

        <div>
          <strong>Tag Number:</strong>
          <span>${t.tagnumber||`-`}</span>
        </div>

        <div>
          <strong>Status:</strong>
          <span class="${t.status===`SAFE`?`status-safe`:`status-unsafe`}">
            ${t.status||`-`}
          </span>
        </div>
      </div>

      <div class="fb-cert-section">
        <h3>Customer Details</h3>
        <div class="fb-cert-grid">
          <p><strong>Client:</strong> ${t.clientname||`-`}</p>
          <p><strong>Site:</strong> ${t.sitename||`-`}</p>
          <p><strong>Section:</strong> ${t.sectionname||`-`}</p>
        </div>
      </div>

      <div class="fb-cert-section">
        <h3>Asset Details</h3>
        <div class="fb-cert-grid">
          <p><strong>Asset ID:</strong> ${t.assetid||`-`}</p>
          <p><strong>Asset Tag No:</strong> ${t.assettagno||`-`}</p>
          <p><strong>Equipment Type:</strong> ${t.equipmenttype||`-`}</p>
          <p><strong>Description:</strong> ${t.description||`-`}</p>
          <p><strong>Serial No:</strong> ${t.serialno||`-`}</p>
          <p><strong>Manufacturer:</strong> ${t.manufacturer||`-`}</p>
        </div>
      </div>

      ${i.length?`
        <div class="fb-cert-section">
          <h3>Asset Specifications</h3>
          <div class="fb-cert-grid">
            ${i.map(([e,t])=>`
              <p><strong>${e}:</strong> ${t}</p>
            `).join(``)}
          </div>
        </div>
      `:``}

      <div class="fb-cert-section">
        <h3>Inspection Details</h3>
        <div class="fb-cert-grid">
          <p><strong>Inspection Type:</strong> ${t.inspectiontype||`-`}</p>
          <p><strong>Inspection Date:</strong> ${P(t.testdate)}</p>
          <p><strong>Certificate Expiry Date:</strong> ${P(t.validdate)}</p>
          <p><strong>Inspector:</strong> ${t.inspector||`-`}</p>
          <p><strong>LMI Number:</strong> ${t.inspector_lmi_number||`-`}</p>
        </div>
      </div>

      <div class="fb-cert-section">
        <h3>Inspection Photos</h3>
        <div class="fb-cert-photo-grid">
          ${r.length?r.slice(0,4).map((e,t)=>`
            <div>
              <img src="${b}${e.photo_path}">
              <p>${e.photo_type?e.photo_type.replaceAll(`_`,` `):`Photo ${t+1}`}</p>
              ${e.caption?`<p>${e.caption}</p>`:``}
            </div>
          `).join(``):`
            <div class="fb-cert-no-photo">No inspection photos</div>
          `}
        </div>
      </div>

      <div class="fb-cert-section">
        <h3>Inspection Results</h3>

        <table class="fb-cert-results-table">
          <colgroup>
            <col class="fb-cert-results-criteria-col">
            <col class="fb-cert-results-result-col">
            <col class="fb-cert-results-standard-col">
            <col class="fb-cert-results-measured-col">
            <col class="fb-cert-results-remarks-col">
          </colgroup>
          <thead>
            <tr>
              <th>Criteria</th>
              <th>Result</th>
              <th>Standard Dimension</th>
              <th>Measured Dimension</th>
              <th>Remarks</th>
            </tr>
          </thead>

          <tbody>
            ${n.map(e=>`
              <tr>
                <td>${e.criterianame||``}</td>
                <td>
                  <strong class="${N(e)===`YES`||N(e)===`PASS`?`status-safe`:N(e)===`NO`||N(e)===`FAIL`?`status-unsafe`:``}">
                    ${N(e)}
                  </strong>
                </td>
                <td>${e.assetvalue||``}</td>
                <td>${e.measuredvalue||``}</td>
                <td>${e.remarks||``}</td>
              </tr>
            `).join(``)}
          </tbody>
        </table>
      </div>

      <div class="fb-cert-signature-section">
        <div>
          <strong>Inspector Signature</strong>
          ${t.inspector_signature_image?`
            <img
              class="fb-cert-signature-image"
              src="${b}${t.inspector_signature_image}"
              alt="Inspector Signature"
            >
          `:``}
          <div class="fb-cert-signature-line"></div>
        </div>
      </div>

      ${o.map(e=>`
        <p class="fb-cert-driven-note">
          ${e}
        </p>
      `).join(``)}

      <img src="${x(`footer.jpg`)}" class="fb-cert-footer" alt="FB Cranes Footer">
    </div>
  `}window.printCertificatePdf=function(e){window.open(`${b}/inspections/${e}/certificate.pdf?inline=1`,`_blank`)},window.downloadCertificatePdf=async function(e){let t=await fetch(`${b}/inspections/${e}/certificate.pdf`);if(!t.ok){let e=await t.json().catch(()=>({error:`Unable to download certificate PDF`}));alert(`Error downloading certificate PDF: `+e.error);return}let n=await t.blob(),r=URL.createObjectURL(n),i=document.createElement(`a`);i.href=r,i.download=`certificate-${e}.pdf`,document.body.appendChild(i),i.click(),i.remove(),URL.revokeObjectURL(r)},window.mailCertificate=async function(e){let t=window.prompt(`Enter recipient email address`);if(!t)return;let n=await fetch(`${b}/certificates/${e}/email`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({to:t.trim()})}),r=await n.json();if(!n.ok){alert(r.error||`Unable to email certificate`);return}alert(`Certificate emailed successfully`)},window.closeCertificateModal=function(){let e=document.querySelector(`#certificateModal`);e&&e.remove()};function O(e,t=[]){return t.length?t:[e.photo1||e.media1,e.photo2||e.media2].filter(Boolean).map((e,t)=>({photo_path:e,photo_type:`Photo ${t+1}`,caption:``}))}function k(e){return[[`WLL`,e.wll?`${e.wll} kg`:``],[`Height of Lift`,e.heightoflift?`${e.heightoflift} mm`:``],[`Number of Chain Falls`,e.numberofchainfalls],[`OEM Top Hook Size`,e.oemtophooksize?`${e.oemtophooksize} mm`:``],[`OEM Bottom Hook Size`,e.oembottomhooksize?`${e.oembottomhooksize} mm`:``],[`Load Chain Diameter`,e.loadchaindiameter?`${e.loadchaindiameter} mm`:``],[`Effective Length`,e.effectivelength?`${e.effectivelength} mm`:``],[`Span/Jib`,e.span?`${e.span} mm`:``],[`Permissible Deflection`,e.permissibledeflection?`${e.permissibledeflection} mm`:``],[`Hook Size`,e.hooksize?`${e.hooksize} mm`:``],[`Steel Wire Rope`,e.steelwireropemm?`${e.steelwireropemm} mm`:``],[`Hoist Description`,e.hoistdescription],[`Hoist Serial No`,e.hoistserialno],[`Auxiliary Hoist Description`,e.auxhoistdescription],[`Auxiliary Hoist Serial No`,e.auxhoistserialno],[`Auxiliary Hoist WLL`,e.auxhoistwll?`${e.auxhoistwll} kg`:``],[`Auxiliary Hoist Hook Size`,e.auxhoisthooksize?`${e.auxhoisthooksize} mm`:``],[`Auxiliary Hoist Steel Wire Rope`,e.auxhoistropemm?`${e.auxhoistropemm} mm`:``],[`Manufacture Date`,P(e.manufactdate)]].filter(([,e])=>e&&e!==`-`)}function fe(e){return e.inspectiontype===`LOADTEST`?`CERTIFICATE OF EXAMINATION AND TEST`:`CERTIFICATE OF INSPECTION`}function A(e){let t=String(e?.criterianame||``).toLowerCase().replace(/\s+/g,` `).trim();return t.includes(`safe for service`)||t.includes(`safe for continued operation`)||t.includes(`safe for review`)}function pe(e,t){if(t?.inspectiontype!==`LOADTEST`)return!1;let n=String(e?.result||``).trim().toUpperCase(),r=String(e?.measuredvalue||``).trim(),i=String(e?.remarks||``).trim();return n===`RECORDED`&&!r&&!i}function j(e){return[e?.criterianame,e?.criteriadescription].filter(Boolean).join(` `).toLowerCase().includes(`hook wear does not exceed allowable limits`)}function me(e){let t=[e?.criterianame,e?.criteriadescription].filter(Boolean).join(` `).toLowerCase();return t.includes(`hook measured size`)||t.includes(`measured hook throat opening`)}function M(e,t={}){return me(e)?{...e,measuredvalue:e.measuredvalue||t.hooksize||``}:e}function he(e,t={}){return e.map(e=>M(e,t)).filter(e=>!j(e)).filter(e=>!pe(e,t)).sort((e,t)=>{let n=A(e),r=A(t);return n&&!r?1:!n&&r?-1:0})}function N(e){let t=String(e?.result||``).trim().toUpperCase();return t===`RECORDED`?`PASS`:A(e)?[`NO`,`FAIL`,`NOT SAFE`,`UNSAFE`].includes(t)?`NO`:[`YES`,`PASS`,`SAFE`].includes(t)?`YES`:t||`-`:t}var ge=`Certification that the item has been inspected in accordance with the requirements of Driven Machinery and SANS Regulations and the responsible person has been informed of all defects.`,_e=`Certification that the items have been inspected in accordance with the requirements of Driven Machinery and SANS Regulations and the responsible person has been informed of all defects.`,ve=`EXAMINED AND TESTED IN ACCORDANCE WITH SANS 500`,ye=`EXAMINED AND TESTED IN ACCORDANCE WITH REGULATION 18 OF OHS ACT 85 OF 1993`,be=new Set([`201`,`202`,`203`,`301`,`302`,`303`,`304`,`305`,`309`,`312`,`314`,`315`,`317`,`319`,`320`,`323`,`324`,`338`,`339`]);function xe(e){let t=[],n=String(e.equiptypeid||``);return[`400`,`500`].includes(String(e.equipgroupid||``))&&t.push(ge),n===`102`&&t.push(ve),[`103`,`105`].includes(n)&&t.push(ye),be.has(n)&&t.push(_e),t}function Se(){let e=document.querySelector(`#certificateModal .fb-cert-page`);e&&e.style.removeProperty(`--cert-print-scale`)}function P(e){return e?String(e).split(`T`)[0]:`-`}async function Ce(e){let t=(window.bulkCertificateResults||[]).filter(t=>e.includes(String(t.inspection?.testid)));if(!t.length){alert(`No selected certificates could be prepared for download.`);return}for(let e of t){let t=e.inspection?.testid,n=await fetch(`${b}/inspections/${t}/certificate.pdf`,{credentials:`include`});if(!n.ok){alert(`Unable to download certificate ${t}.`);continue}let r=await n.blob(),i=ue(n.headers.get(`content-disposition`),`certificate-${t}.pdf`),a=window.URL.createObjectURL(r),o=document.createElement(`a`);o.href=a,o.download=i,o.style.display=`none`,document.body.appendChild(o),o.click(),o.remove(),window.setTimeout(()=>window.URL.revokeObjectURL(a),1e3)}}var we={filterCertificateSites:window.filterCertificateSites,filterCertificateSections:window.filterCertificateSections,filterBulkCertificateSites:window.filterBulkCertificateSites,clearCertificateSearch:window.clearCertificateSearch,searchCertificates:window.searchCertificates,rerenderCertificateResults:window.rerenderCertificateResults,goToCertificatePage:window.goToCertificatePage,setCertificateRowsPerPage:window.setCertificateRowsPerPage,previewCertificate:window.previewCertificate,openCertificateModal:window.openCertificateModal,closeCertificateModal:window.closeCertificateModal,downloadCertificatePdf:window.downloadCertificatePdf,mailCertificate:window.mailCertificate,searchBulkCertificates:window.searchBulkCertificates,printSelectedBulkCertificates:window.printSelectedBulkCertificates,closeBulkCertificatePrintView:window.closeBulkCertificatePrintView,downloadSelectedBulkCertificatesPdf:window.downloadSelectedBulkCertificatesPdf,downloadAllBulkCertificatesPdf:window.downloadAllBulkCertificatesPdf,toggleBulkCertificateSelection:window.toggleBulkCertificateSelection,updateBulkCertificateButtons:window.updateBulkCertificateButtons},F=null,I=1,L=25;function Te(e=[],t=[]){let n=[...e].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``)),r=[...t].sort((e,t)=>(e.description||``).localeCompare(t.description||``));document.querySelector(`#page`).innerHTML=`
    <div class="report-page">
      <div class="report-hero">
        <div>
          <h1>Customer Detailed Report</h1>
          <p>Review customer assets, latest inspection status and due items in one place.</p>
        </div>
      </div>

      <div class="report-toolbar">
        <div class="report-filter-control">
          <label for="customerReportClient">Customer</label>
          <select id="customerReportClient">
              <option value="">All Customers</option>
              ${n.map(e=>`
                <option value="${e.clientid}">
                  ${e.clientname||`Customer ${e.clientid}`}
                </option>
              `).join(``)}
            </select>
          </div>

        <div class="report-filter-control">
          <label for="customerReportEquipment">Equipment Type</label>
          <select id="customerReportEquipment">
            <option value="">All Equipment Types</option>
            ${r.map(e=>`
              <option value="${e.equiptypeid}">
                ${e.description||`Equipment ${e.equiptypeid}`}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="report-filter-control">
          <label for="customerReportDateFrom">Inspection Date From</label>
          <input id="customerReportDateFrom" type="date">
        </div>

        <div class="report-filter-control">
          <label for="customerReportDateTo">Inspection Date To</label>
          <input id="customerReportDateTo" type="date">
        </div>

        <div class="report-toolbar-actions">
            <button id="customerReportPreviewBtn" type="button">
              Preview Report
            </button>

            <a
              id="customerReportPdfLink"
              class="cert-action-link"
              href="${b}/reports/customer-detailed.pdf"
              download
            >
              Download PDF
            </a>

            <a
              id="customerReportExcelLink"
              class="cert-action-link"
              href="${b}/reports/customer-detailed.xlsx"
              download
            >
              Export Excel
            </a>
          </div>
        </div>

      <div id="customerReportPreview" class="report-preview-empty">
        <h2>No report preview yet</h2>
        <p>Select a customer or leave it on All Customers, then preview the report.</p>
      </div>
    </div>
  `,R(),Ee()}function Ee(){document.querySelectorAll(`#customerReportClient, #customerReportEquipment, #customerReportDateFrom, #customerReportDateTo`).forEach(e=>{e.addEventListener(`change`,R)}),document.querySelector(`#customerReportPreviewBtn`)?.addEventListener(`click`,De)}function R(){let e=z(),t=document.querySelector(`#customerReportPdfLink`),n=document.querySelector(`#customerReportExcelLink`);t&&(t.href=`${b}/reports/customer-detailed.pdf${e}`),n&&(n.href=`${b}/reports/customer-detailed.xlsx${e}`)}async function De(){R();let e=z(),t=document.querySelector(`#customerReportPreview`);t.className=`report-preview-empty`,t.innerHTML=`<div class="report-preview-empty">Loading report...</div>`;let n=await fetch(`${b}/reports/customer-detailed${e}`),r=await n.json();if(!n.ok){t.innerHTML=`
      <div class="report-preview-empty">
        Error loading report: ${r.error||`Unknown error`}
      </div>
    `;return}F=null,I=1,L=25,t.className=`report-preview-loaded`,F=r,B()}window.updateCustomerReportLinks=R,window.loadCustomerDetailedReport=De;function z(){let e=new URLSearchParams,t=document.querySelector(`#customerReportClient`)?.value||``,n=document.querySelector(`#customerReportEquipment`)?.value||``,r=document.querySelector(`#customerReportDateFrom`)?.value||``,i=document.querySelector(`#customerReportDateTo`)?.value||``;t&&e.append(`clientid`,t),n&&e.append(`equiptypeid`,n),r&&e.append(`datefrom`,r),i&&e.append(`dateto`,i);let a=e.toString();return a?`?${a}`:``}function Oe(e){let r=e.customers.length===1?e.customers[0].clientname:`All Customers`,i=Me(),a=t(e.assets,`customerReport`,{clientname:e=>e.clientname,assetid:e=>e.assetid,assettagno:e=>e.assettagno,serialno:e=>e.serialno,sitename:e=>e.sitename,sectionname:e=>e.sectionname,equipmenttype:e=>e.equipmenttype,description:e=>e.description,latestinspectiondate:e=>e.latestinspectiondate,visualtestdate:e=>e.visualtestdate,visualstatus:e=>e.visualstatus,loadtestdate:e=>e.loadtestdate,loadstatus:e=>e.loadstatus,reportstatus:e=>e.reportstatus},`latestinspectiondate`),o=Math.max(1,Math.ceil(a.length/i)),s=Math.min(I,o),c=(s-1)*i,l=a.slice(c,c+i),u=a.length===0?0:c+l.length;return`
    <div class="report-summary-card">
      <div class="report-summary-heading">
        <div>
          <h2>${r}</h2>
          <p>Generated ${H(e.generatedAt)}</p>
        </div>

        <div class="report-count-note">
          ${e.assets.length} assets in report
        </div>
      </div>

      <div class="report-summary-grid">
        ${V(`Customers`,e.summary.customers)}
        ${V(`Assets`,e.summary.assets)}
        ${V(`Active Assets`,e.summary.activeAssets)}
        ${V(`OK`,e.summary.safeAssets)}
        ${V(`Not Safe`,e.summary.notSafeAssets)}
        ${V(`Visual Overdue`,e.summary.visualOverdueAssets)}
        ${V(`Load Overdue`,e.summary.loadOverdueAssets)}
        ${V(`No Visual`,e.summary.noVisualAssets)}
        ${V(`No Load Test`,e.summary.noLoadAssets)}
      </div>
    </div>

    <div class="report-detail-card">
      <div class="report-detail-heading">
        <div>
          <h2>Asset Detail Preview</h2>
          <p>Showing ${e.assets.length===0?0:c+1} to ${u} of ${e.assets.length} assets. Use PDF or Excel for the full detailed report.</p>
        </div>
      </div>

      <div class="report-pagination-bar">
        <div class="report-page-size">
          <label for="reportRowsPerPage">Rows per page</label>
          <select id="reportRowsPerPage">
            ${[25,50,100,250].map(e=>`
              <option value="${e}" ${e===i?`selected`:``}>
                ${e}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="report-page-controls">
          <button id="reportPrevPageBtn" type="button" ${s<=1?`disabled`:``}>
            Previous
          </button>
          ${je(s,o)}
          <button id="reportNextPageBtn" type="button" ${s>=o?`disabled`:``}>
            Next
          </button>
          <span>Page ${s} of ${o}</span>
        </div>
      </div>

      <div class="report-scroll-control">
        <span>Left</span>
        <input id="reportTableSlider" type="range" min="0" max="0" value="0" step="1">
        <span>Right</span>
      </div>

      <div class="report-table-wrap">
        <table class="report-table">
          <thead>
            <tr>
              <th>${n(`Customer`,`customerReport`,`clientname`,`rerenderCustomerReport`)}</th>
              <th>${n(`Asset ID`,`customerReport`,`assetid`,`rerenderCustomerReport`)}</th>
              <th>${n(`Asset Tag`,`customerReport`,`assettagno`,`rerenderCustomerReport`)}</th>
              <th>${n(`Serial No`,`customerReport`,`serialno`,`rerenderCustomerReport`)}</th>
              <th>${n(`Site`,`customerReport`,`sitename`,`rerenderCustomerReport`)}</th>
              <th>${n(`Section`,`customerReport`,`sectionname`,`rerenderCustomerReport`)}</th>
              <th>${n(`Equipment Type`,`customerReport`,`equipmenttype`,`rerenderCustomerReport`)}</th>
              <th>${n(`Description`,`customerReport`,`description`,`rerenderCustomerReport`)}</th>
              <th>${n(`Latest Inspection`,`customerReport`,`latestinspectiondate`,`rerenderCustomerReport`)}</th>
              <th>${n(`Last Visual`,`customerReport`,`visualtestdate`,`rerenderCustomerReport`)}</th>
              <th>${n(`Visual Status`,`customerReport`,`visualstatus`,`rerenderCustomerReport`)}</th>
              <th>${n(`Last Load`,`customerReport`,`loadtestdate`,`rerenderCustomerReport`)}</th>
              <th>${n(`Load Status`,`customerReport`,`loadstatus`,`rerenderCustomerReport`)}</th>
              <th>${n(`Report Status`,`customerReport`,`reportstatus`,`rerenderCustomerReport`)}</th>
            </tr>
          </thead>
          <tbody>
            ${l.map(e=>`
              <tr>
                <td>${e.clientname||`-`}</td>
                <td>${e.assetid||`-`}</td>
                <td>${e.assettagno||`-`}</td>
                <td>${e.serialno||`-`}</td>
                <td>${e.sitename||`-`}</td>
                <td>${e.sectionname||`-`}</td>
                <td>${e.equipmenttype||`-`}</td>
                <td>${e.description||`-`}</td>
                <td>${H(e.latestinspectiondate)}</td>
                <td>${H(e.visualtestdate)}</td>
                <td class="${Pe(e.visualstatus)}">${e.visualstatus||`-`}</td>
                <td>${H(e.loadtestdate)}</td>
                <td class="${Pe(e.loadstatus)}">${e.loadstatus||`-`}</td>
                <td>
                  <span class="report-status-pill ${Fe(e.reportstatus)}">
                    ${e.reportstatus||`-`}
                  </span>
                </td>
              </tr>
            `).join(``)||`
              <tr>
                <td colspan="14">No assets found for this report.</td>
              </tr>
            `}
          </tbody>
        </table>
      </div>
    </div>
  `}function B(){let e=document.querySelector(`#customerReportPreview`);!e||!F||(e.innerHTML=Oe(F),ke(),Ne())}function ke(){document.querySelector(`#reportRowsPerPage`)?.addEventListener(`change`,e=>{L=Number(e.target.value)||25,I=1,B()}),document.querySelector(`#reportPrevPageBtn`)?.addEventListener(`click`,()=>{I=Math.max(1,I-1),B()}),document.querySelector(`#reportNextPageBtn`)?.addEventListener(`click`,()=>{let e=F?Math.max(1,Math.ceil(F.assets.length/Me())):1;I=Math.min(e,I+1),B()})}function Ae(e,t){let n=[];if(t<=7){for(let e=1;e<=t;e+=1)n.push(e);return n}n.push(1),e>4&&n.push(`...`);let r=Math.max(2,e-1),i=Math.min(t-1,e+1);for(let e=r;e<=i;e+=1)n.push(e);return e<t-3&&n.push(`...`),n.push(t),n}function je(e,t){return Ae(e,t).map(t=>t===`...`?`<span class="pagination-ellipsis">...</span>`:`
      <button
        type="button"
        class="pagination-page-btn ${t===e?`active`:``}"
        onclick="goToCustomerReportPage(${t})"
        ${t===e?`disabled`:``}
      >
        ${t}
      </button>
    `).join(``)}window.goToCustomerReportPage=function(e){I=Math.max(1,Number(e)||1),B()},window.rerenderCustomerReport=function(){I=1,B()};function Me(){return L||25}function Ne(){let e=document.querySelector(`#reportTableSlider`),t=document.querySelector(`.report-table-wrap`);if(!e||!t)return;let n=()=>{let n=Math.max(0,t.scrollWidth-t.clientWidth);e.max=String(n),e.value=String(Math.min(t.scrollLeft,n)),e.disabled=n===0};n(),e.addEventListener(`input`,()=>{t.scrollLeft=Number(e.value)}),t.addEventListener(`scroll`,()=>{e.value=String(t.scrollLeft)}),window.addEventListener(`resize`,n,{once:!0})}function V(e,t){return`
    <div class="report-summary-tile">
      <span>${e}</span>
      <strong>${t??0}</strong>
    </div>
  `}function Pe(e){return e===`SAFE`||e===`OK`?`status-safe`:e===`NOT SAFE`?`status-unsafe`:``}function Fe(e){return e===`OK`?`is-ok`:e===`NOT SAFE`?`is-danger`:(e||``).includes(`OVERDUE`)?`is-warning`:(e||``).includes(`NO `)?`is-muted`:``}function H(e){return e?String(e).split(`T`)[0]:`-`}function Ie(){return new Date().toISOString().split(`T`)[0]}function U(e=``){return[1,2,3,4,5].map(t=>`
    <option value="${t}" ${String(e)===String(t)?`selected`:``}>
      ${t}
    </option>
  `).join(``)}function Le(e=`OPEN`){return[`OPEN`,`IN_PROGRESS`,`CLOSED`].map(t=>`
    <option value="${t}" ${t===e?`selected`:``}>
      ${t.replaceAll(`_`,` `)}
    </option>
  `).join(``)}function Re(e,t=``){return`
    <option value="">General / no asset</option>
    ${e.map(e=>`
      <option value="${e.assetid}" ${String(t)===String(e.assetid)?`selected`:``}>
        ${e.assetid} - ${e.assettagno||e.serialno||e.description||`Asset`}
      </option>
    `).join(``)}
  `}function ze(e){return e?String(e).split(`T`)[0]:`-`}function Be(e){let t=Number(e||0);return t>=15?`danger`:t>=8?`warning`:`success`}async function Ve(e=[],t=!0){let n=document.querySelector(`#page`);n.innerHTML=`
    <h1>Risk Assessment / SHE</h1>
    <p>Create and track SHE risk assessments linked to assets where needed.</p>

    ${t?`<div class="filter-card">
      <h2>New Risk Assessment</h2>

      <div class="asset-form-grid">
        <div class="form-group">
          <label>Asset</label>
          <select id="riskAssetId">${Re(e)}</select>
        </div>

        <div class="form-group">
          <label>Assessment Date</label>
          <input id="riskAssessmentDate" type="date" value="${Ie()}">
        </div>

        <div class="form-group">
          <label>Status</label>
          <select id="riskStatus">${Le()}</select>
        </div>

        <div class="form-group asset-description">
          <label>Activity / Task</label>
          <input id="riskActivity" type="text">
        </div>

        <div class="form-group asset-description">
          <label>Hazard</label>
          <textarea id="riskHazard" rows="2"></textarea>
        </div>

        <div class="form-group asset-description">
          <label>Consequence</label>
          <textarea id="riskConsequence" rows="2"></textarea>
        </div>

        <div class="form-group">
          <label>Initial Severity</label>
          <select id="riskInitialSeverity">${U(3)}</select>
        </div>

        <div class="form-group">
          <label>Initial Likelihood</label>
          <select id="riskInitialLikelihood">${U(3)}</select>
        </div>

        <div class="form-group asset-description">
          <label>Controls</label>
          <textarea id="riskControls" rows="2"></textarea>
        </div>

        <div class="form-group">
          <label>Residual Severity</label>
          <select id="riskResidualSeverity">${U(2)}</select>
        </div>

        <div class="form-group">
          <label>Residual Likelihood</label>
          <select id="riskResidualLikelihood">${U(2)}</select>
        </div>

        <div class="form-group asset-description">
          <label>Action Required</label>
          <textarea id="riskActionRequired" rows="2"></textarea>
        </div>

        <div class="form-group">
          <label>Responsible Person</label>
          <input id="riskResponsiblePerson" type="text">
        </div>

        <div class="form-group">
          <label>Due Date</label>
          <input id="riskDueDate" type="date">
        </div>
      </div>

      <div class="form-actions">
        <button onclick="saveRiskAssessment()">Save Risk Assessment</button>
      </div>
    </div>`:``}

    <div class="filter-card">
      <div class="form-row">
        <div class="form-group">
          <label>Search</label>
          <input id="riskSearch" type="text" placeholder="Asset, activity, hazard, status..." onkeyup="filterRiskAssessments()">
        </div>

        <div class="form-group">
          <label>Status</label>
          <select id="riskStatusFilter" onchange="filterRiskAssessments()">
            <option value="">All</option>
            ${Le(``)}
          </select>
        </div>
      </div>

      <div class="form-actions">
        <button type="button" onclick="downloadRiskAssessments('pdf')">
          Download PDF
        </button>
        <button type="button" onclick="downloadRiskAssessments('xlsx')">
          Export Excel
        </button>
      </div>
    </div>

    <div id="riskAssessmentTable"></div>
  `,await window.loadRiskAssessments()}function He(e=[],r=!0){let i=document.querySelector(`#riskAssessmentTable`),a=document.querySelector(`#riskSearch`)?.value.toLowerCase().trim()||``,o=document.querySelector(`#riskStatusFilter`)?.value||``,s=t(e.filter(e=>{let t=!o||e.status===o,n=[e.riskid,e.assettagno,e.serialno,e.asset_description,e.clientname,e.sitename,e.activity,e.hazard,e.status].join(` `).toLowerCase();return t&&n.includes(a)}),`riskAssessments`,{riskid:e=>e.riskid,assessment_date:e=>e.assessment_date,assettagno:e=>e.assettagno,activity:e=>e.activity,initial_rating:e=>e.initial_rating,residual_rating:e=>e.residual_rating,status:e=>e.status,due_date:e=>e.due_date},`assessment_date`);i.innerHTML=`
    <table>
      <thead>
        <tr>
          <th>${n(`ID`,`riskAssessments`,`riskid`,`filterRiskAssessments`)}</th>
          <th>${n(`Date`,`riskAssessments`,`assessment_date`,`filterRiskAssessments`)}</th>
          <th>${n(`Asset`,`riskAssessments`,`assettagno`,`filterRiskAssessments`)}</th>
          <th>${n(`Activity`,`riskAssessments`,`activity`,`filterRiskAssessments`)}</th>
          <th>Hazard</th>
          <th>${n(`Initial Risk`,`riskAssessments`,`initial_rating`,`filterRiskAssessments`)}</th>
          <th>${n(`Residual Risk`,`riskAssessments`,`residual_rating`,`filterRiskAssessments`)}</th>
          <th>${n(`Status`,`riskAssessments`,`status`,`filterRiskAssessments`)}</th>
          <th>${n(`Due`,`riskAssessments`,`due_date`,`filterRiskAssessments`)}</th>
          ${r?`<th>Action</th>`:``}
        </tr>
      </thead>
      <tbody>
        ${s.length?s.map(e=>`
          <tr>
            <td>${e.riskid}</td>
            <td>${ze(e.assessment_date)}</td>
            <td>
              <strong>${e.assettagno||e.assetid||`-`}</strong><br>
              <small>${e.asset_description||e.serialno||``}</small>
            </td>
            <td>${e.activity||``}</td>
            <td>${e.hazard||``}</td>
            <td><span class="status-badge ${Be(e.initial_rating)}">${e.initial_rating||`-`}</span></td>
            <td><span class="status-badge ${Be(e.residual_rating)}">${e.residual_rating||`-`}</span></td>
            <td>${e.status||``}</td>
            <td>${ze(e.due_date)}</td>
            ${r?`<td>
              <div class="action-buttons">
                <button onclick="editRiskAssessment(${e.riskid})">Edit</button>
                <button onclick="archiveRiskAssessment(${e.riskid})">Archive</button>
              </div>
            </td>`:``}
          </tr>
        `).join(``):`
          <tr>
            <td colspan="${r?`10`:`9`}" class="empty-row">No risk assessments found</td>
          </tr>
        `}
      </tbody>
    </table>
  `}window.location.pathname.toLowerCase().startsWith(`/atec/atec`)&&window.history.replaceState({},``,`/atec/`);var Ue=window.fetch.bind(window);window.fetch=function(e,t={}){let n=(typeof e==`string`?e:e?.url||``).startsWith(b);return Ue(e,{...t,credentials:n?`include`:t.credentials})};async function W(e){let t=await e.text();if(!t)return{};try{return JSON.parse(t)}catch{return{error:e.ok?`The server returned an unexpected response`:`The server returned an unexpected error. Please try again.`}}}var G=null,We={dashboard:[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`],customers:[`ADMIN`,`MANAGER`],sites:[`ADMIN`,`MANAGER`],responsible:[`ADMIN`],sections:[`ADMIN`,`MANAGER`],assets:[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`],inspections:[`ADMIN`,`INSPECTOR`],"quick-inspection":[`ADMIN`,`INSPECTOR`],certificates:[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`,`CUSTOMER`],"customer-report":[`ADMIN`,`MANAGER`,`VIEWER`,`CUSTOMER`],she:[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`],criteria:[`ADMIN`],users:[`ADMIN`]};function Ge(e){return G?.role===`ADMIN`||(We[e]||[]).includes(G?.role)}function K(){document.querySelector(`#page`).innerHTML=`
    <div class="filter-card">
      <h2>Access denied</h2>
      <p>You do not have permission to view this page.</p>
    </div>
  `}function q(e){return Ge(e)?!0:(K(),!1)}function J(e,t,n){return Ge(e)?`<button onclick="${n}">${t}</button>`:``}function Y(){return[`ADMIN`,`MANAGER`,`INSPECTOR`].includes(G?.role)}function Ke(){return[`ADMIN`,`INSPECTOR`].includes(G?.role)}function qe(e=``){document.querySelector(`#app`).innerHTML=`
    <div class="login-page">
      <div class="login-card">
        <img src="${x(`logo.png`)}" alt="ATEC Logo" class="login-logo">
        <h1>ATEC Login</h1>
        ${e?`<p class="login-error">${e}</p>`:``}
        <label>Username or Email</label>
        <input id="loginUsername" type="text" autocomplete="username">
        <label>Password</label>
        <input id="loginPassword" type="password" autocomplete="current-password">
        <button onclick="loginUser()">Login</button>
      </div>
    </div>
  `}window.loginUser=async function(){let e=document.querySelector(`#loginUsername`)?.value||``,t=document.querySelector(`#loginPassword`)?.value||``,n=await fetch(`${b}/auth/login`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({username:e,password:t})}),r=await n.json();if(!n.ok){qe(r.error||`Login failed`);return}G=r.user,window.currentUser=G,localStorage.setItem(`currentPage`,G.role===`CUSTOMER`?`certificates`:`dashboard`),await $()},window.logoutUser=async function(){await fetch(`${b}/auth/logout`,{method:`POST`}),G=null,window.currentUser=null,localStorage.removeItem(`currentPage`),qe()};var Je={username:e=>e.username,email:e=>e.email,full_name:e=>e.full_name,role:e=>e.role,lmi_number:e=>e.lmi_number,clientid:e=>Xe(e.clientid),siteid:e=>Ze(e.siteid),sectionid:e=>Qe(e.sectionid),is_active:e=>+!!e.is_active,signature_image:e=>+!!e.signature_image};function Ye(){return window.userManagementLookups||{customers:[],sites:[],sections:[]}}function Xe(e){return Ye().customers.find(t=>String(t.clientid)===String(e||``))?.clientname||``}function Ze(e){return Ye().sites.find(t=>String(t.siteid)===String(e||``))?.sitename||``}function Qe(e){return Ye().sections.find(t=>String(t.sectionid)===String(e||``))?.sectionname||``}function X(e,t,n,r,i){return`
    <option value="">${i}</option>
    ${e.map(e=>`
      <option value="${e[t]}" ${String(e[t])===String(r||``)?`selected`:``}>
        ${e[n]||`${i} ${e[t]}`}
      </option>
    `).join(``)}
  `}function $e(){return window.userManagementSort=window.userManagementSort||{key:`username`,direction:`asc`},window.userManagementSort}function et(e){let t=$e(),n=Je[t.key]||Je.username,r=t.direction===`desc`?-1:1;return[...e].sort((e,t)=>{let i=n(e),a=n(t),o=Number(i),s=Number(a);return i!==``&&a!==``&&!Number.isNaN(o)&&!Number.isNaN(s)?(o-s)*r:String(i||``).localeCompare(String(a||``),void 0,{numeric:!0,sensitivity:`base`})*r})}function Z(e,t){let n=$e(),r=n.key===t,i=r?n.direction:``;return`
    <span class="user-table-heading">
      <span>${e}</span>
      <button
        type="button"
        class="user-sort-btn ${r?`active ${i}`:``}"
        onclick="sortUserManagement('${t}')"
        aria-label="Sort ${e}"
        title="Sort ${e}"
      ></button>
    </span>
  `}window.sortUserManagement=function(e){let t=$e();window.userManagementSort={key:e,direction:t.key===e&&t.direction===`asc`?`desc`:`asc`},showUserManagement()},window.showUserManagement=async function(){if(!q(`users`))return;localStorage.setItem(`currentPage`,`users`);let[e,t,n,r]=await Promise.all([fetch(`${b}/users`),Q(`${b}/customers`,[]),Q(`${b}/sites`,[]),Q(`${b}/sections`,[])]),i=await e.json();if(!e.ok){alert(i.error||`Unable to load users`);return}window.userManagementLookups={customers:t,sites:n,sections:r};let a=et(i);document.querySelector(`#page`).innerHTML=`
    <div class="user-management-page">
    <h1>User Management</h1>

    <div class="filter-card user-create-card">
      <h2>Create User</h2>
      <div class="asset-form-grid">
        <div class="form-group">
          <label>Username</label>
          <input id="newUserUsername" type="text">
        </div>
        <div class="form-group">
          <label>Email</label>
          <input id="newUserEmail" type="email">
        </div>
        <div class="form-group">
          <label>Password</label>
          <input id="newUserPassword" type="password">
        </div>
        <div class="form-group">
          <label>Full Name</label>
          <input id="newUserFullName" type="text">
        </div>
        <div class="form-group">
          <label>Role</label>
          <select id="newUserRole">
            <option value="ADMIN">ADMIN</option>
            <option value="MANAGER">MANAGER</option>
            <option value="INSPECTOR">INSPECTOR</option>
            <option value="VIEWER">VIEWER</option>
            <option value="CUSTOMER">CUSTOMER</option>
          </select>
        </div>
        <div class="form-group">
          <label>LMI Number</label>
          <input id="newUserLmi" type="text">
        </div>
        <div class="form-group">
          <label>Customer Name</label>
          <select id="newUserClientId">
            ${X(t,`clientid`,`clientname`,``,`No customer selected`)}
          </select>
        </div>
        <div class="form-group">
          <label>Site Name</label>
          <select id="newUserSiteId">
            ${X(n,`siteid`,`sitename`,``,`No site selected`)}
          </select>
        </div>
        <div class="form-group">
          <label>Section Name</label>
          <select id="newUserSectionId">
            ${X(r,`sectionid`,`sectionname`,``,`No section selected`)}
          </select>
        </div>
      </div>
      <button onclick="createUser()">Create User</button>
    </div>

    <div class="filter-card user-signature-card">
      <h2>My Signature</h2>
      <p>Upload your own inspector signature. It will be used on new inspections saved under your login.</p>
      <input id="mySignatureUpload" type="file" accept="image/*">
      <button onclick="uploadMySignature()">Upload Signature</button>
    </div>

    <div class="user-management-table-wrap">
    <table class="user-management-table">
      <thead>
        <tr>
          <th>${Z(`User`,`username`)}</th>
          <th>${Z(`Email`,`email`)}</th>
          <th>${Z(`Full Name`,`full_name`)}</th>
          <th>${Z(`Role`,`role`)}</th>
          <th>${Z(`LMI Number`,`lmi_number`)}</th>
          <th>${Z(`Customer Name`,`clientid`)}</th>
          <th>${Z(`Site Name`,`siteid`)}</th>
          <th>${Z(`Section Name`,`sectionid`)}</th>
          <th>${Z(`Active`,`is_active`)}</th>
          <th>${Z(`Signature`,`signature_image`)}</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ${a.map(e=>`
          <tr class="${e.is_active?``:`inactive-user-row`}">
            <td class="user-name-cell">${e.username}</td>
            <td><input id="user-email-${e.user_id}" value="${e.email||``}"></td>
            <td><input id="user-name-${e.user_id}" value="${e.full_name||``}"></td>
            <td>
              <select id="user-role-${e.user_id}">
                ${[`ADMIN`,`MANAGER`,`INSPECTOR`,`VIEWER`,`CUSTOMER`].map(t=>`
                  <option value="${t}" ${t===e.role?`selected`:``}>${t}</option>
                `).join(``)}
              </select>
            </td>
            <td><input id="user-lmi-${e.user_id}" value="${e.lmi_number||``}"></td>
            <td>
              <select id="user-client-${e.user_id}">
                ${X(t,`clientid`,`clientname`,e.clientid,`No customer selected`)}
              </select>
            </td>
            <td>
              <select id="user-site-${e.user_id}">
                ${X(n,`siteid`,`sitename`,e.siteid,`No site selected`)}
              </select>
            </td>
            <td>
              <select id="user-section-${e.user_id}">
                ${X(r,`sectionid`,`sectionname`,e.sectionid,`No section selected`)}
              </select>
            </td>
            <td class="user-active-cell">
              <input class="user-status-check" id="user-active-${e.user_id}" type="checkbox" ${e.is_active?`checked`:``}>
            </td>
            <td>
              <div class="user-signature-cell">
                <span class="${e.signature_image?`signature-status saved`:`signature-status`}">${e.signature_image?`Saved`:`-`}</span>
                <input id="user-signature-${e.user_id}" type="file" accept="image/*">
                <button type="button" class="secondary-small-btn" onclick="uploadUserSignature(${e.user_id})">Upload</button>
              </div>
            </td>
            <td class="user-row-actions">
              <button onclick="saveUser(${e.user_id})">Save</button>
              <button class="secondary-small-btn" onclick="resetUserPassword(${e.user_id})">Reset Password</button>
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
    </div>
    </div>
  `},window.createUser=async function(){let e=await fetch(`${b}/users`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({username:document.querySelector(`#newUserUsername`).value,email:document.querySelector(`#newUserEmail`).value,password:document.querySelector(`#newUserPassword`).value,full_name:document.querySelector(`#newUserFullName`).value,role:document.querySelector(`#newUserRole`).value,lmi_number:document.querySelector(`#newUserLmi`).value,clientid:document.querySelector(`#newUserClientId`).value,siteid:document.querySelector(`#newUserSiteId`).value,sectionid:document.querySelector(`#newUserSectionId`).value})}),t=await e.json();if(!e.ok){alert(t.error||`Unable to create user`);return}alert(`User created successfully`),showUserManagement()},window.saveUser=async function(e){if(!e||e===`null`){alert(`This user record is missing an account ID. The list will refresh now.`),showUserManagement();return}let t=await fetch(`${b}/users/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({email:document.querySelector(`#user-email-${e}`).value,full_name:document.querySelector(`#user-name-${e}`).value,role:document.querySelector(`#user-role-${e}`).value,lmi_number:document.querySelector(`#user-lmi-${e}`).value,clientid:document.querySelector(`#user-client-${e}`).value,siteid:document.querySelector(`#user-site-${e}`).value,sectionid:document.querySelector(`#user-section-${e}`).value,is_active:document.querySelector(`#user-active-${e}`).checked})}),n=await t.json();if(!t.ok){alert(n.error||`Unable to save user`);return}alert(`User saved successfully`),showUserManagement()},window.uploadUserSignature=async function(e){if(!e||e===`null`){alert(`This user record is missing an account ID. The list will refresh now.`),showUserManagement();return}let t=document.querySelector(`#user-signature-${e}`)?.files[0];if(!t){alert(`Choose a signature image for this user`);return}let n=new FormData;n.append(`signature`,t);let r=await fetch(`${b}/users/${e}/signature`,{method:`POST`,body:n}),i=await W(r);if(!r.ok){alert(i.error||`Unable to upload signature`);return}alert(`Signature saved successfully`),showUserManagement()},window.resetUserPassword=async function(e){if(!e||e===`null`){alert(`This user record is missing an account ID. The list will refresh now.`),showUserManagement();return}let t=prompt(`Enter the new password for this user. It must be at least 8 characters.`);if(t===null)return;if(t.length<8){alert(`Password must be at least 8 characters`);return}let n=prompt(`Confirm the new password`);if(n===null)return;if(t!==n){alert(`Passwords do not match`);return}let r=await fetch(`${b}/users/${e}/reset-password`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({password:t})}),i=await W(r);if(!r.ok){alert(i.error||`Unable to reset password`);return}alert(`Password reset successfully`)},window.deleteUser=async function(e){if(!confirm(`Delete this user? This will deactivate the login and keep old records safe.`))return;let t=await fetch(`${b}/users/${e}`,{method:`DELETE`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to delete user`);return}showUserManagement()},window.uploadMySignature=async function(){let e=document.querySelector(`#mySignatureUpload`)?.files[0];if(!e){alert(`Choose a signature image`);return}let t=new FormData;t.append(`signature`,e);let n=await fetch(`${b}/users/me/signature`,{method:`POST`,body:t}),r=await n.json();if(!n.ok){alert(r.error||`Unable to upload signature`);return}G=r.user,window.currentUser=G,alert(`Signature saved successfully`),showUserManagement()};async function Q(e,t){let n=await fetch(e);if(!n.ok){if([401,403].includes(n.status))return t;let r=await n.json().catch(()=>({}));throw Error(r.error||`Unable to load ${e}`)}return n.json()}function tt(e){document.querySelector(`#app`).innerHTML=`
    <div class="login-page">
      <div class="login-card">
        <img src="${x(`logo.png`)}" alt="ATEC Logo" class="login-logo">
        <h1>ATEC needs a database update</h1>
        <p>${e}</p>
        <p>
          Please run:
          <strong>database/2026-06-23-equipment-400-photos-and-critical-rule.sql</strong>
        </p>
        <button type="button" onclick="location.reload()">Reload</button>
      </div>
    </div>
  `}async function $(){let n;try{n=await fetch(`${b}/auth/me`)}catch{qe(`Cannot connect to the ATEC backend. Please check that the backend is running.`);return}if(!n.ok){qe();return}G=(await n.json()).user,window.currentUser=G;let o,s,f,m,h,g,_,v;try{o=await Q(`${b}/customers`,[]),s=await Q(`${b}/assets`,[]),f=await Q(`${b}/sites`,[]),m=await Q(`${b}/responsible-persons`,[]),h=await Q(`${b}/sections`,[]),g=await Q(`${b}/equipment-types`,[]),_=await Q(`${b}/dashboard/stats`,{}),v=await Q(`${b}/equipment-type-criteria`,[]),window.atecCriteria=v}catch(e){tt(e.message||`The database update has not been completed.`);return}document.querySelector(`#app`).innerHTML=`
    <div class="app">

     <div class="layout">

  <div class="sidebar">

          <div class="logo-container">
            <img src="${x(`logo.png`)}" alt="ATEC Logo" class="logo">
          </div>

          <div class="system-title">
            Inspection Platform
          </div>

    <div class="user-panel">
      <strong>${G.full_name}</strong>
      <span>${G.role}${G.lmi_number?` | LMI ${G.lmi_number}`:``}</span>
    </div>

    ${J(`dashboard`,`Dashboard`,`showDashboard()`)}
    ${J(`customers`,`Customer Setup`,`showCustomerSetup()`)}
    ${J(`sites`,`Sites`,`showSites()`)}
    ${J(`responsible`,`Responsible Persons`,`showResponsiblePersons()`)}
    ${J(`sections`,`Sections`,`showSections()`)}
    ${J(`assets`,`Assets`,`showAssetSetup()`)}
    ${J(`inspections`,`Inspection/Testing`,`showInspections()`)}
    ${J(`quick-inspection`,`Quick Inspection/Testing`,`showQuickInspection()`)}
    ${J(`certificates`,`Certificates`,`showCertificateSearch()`)}
    ${J(`customer-report`,`Reports`,`showCustomerDetailedReport()`)}
    ${J(`she`,`Risk Assessment / SHE`,`showRiskAssessments()`)}
    ${J(`criteria`,`Equipment Type Criteria`,`showEquipmentTypeCriteria()`)}
    ${J(`users`,`User Management`,`showUserManagement()`)}

    <button onclick="logoutUser()">Logout</button>

  </div>

  <div class="content">
    <div id="page"></div>
  </div>

</div>

</div>

  `,window.showDashboard=function(){q(`dashboard`)&&(localStorage.setItem(`currentPage`,`dashboard`),r(o,s,f,g,_),Ae(),je(),Me(),Ne())};let y=localStorage.getItem(`customerArchiveMode`)||`active`;window.showCustomerSetup=function(e=y){q(`customers`)&&(y=e,localStorage.setItem(`currentPage`,`customers`),localStorage.setItem(`customerArchiveMode`,e),c(o,y))},window.addClient=async function(){let e=prompt(`Enter Client Name`);if(!e)return;let t=prompt(`Enter Client Address`),n=await fetch(`${b}/customers`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientname:e,clientaddr:t})}),r=await n.json();if(!n.ok){alert(`Error saving client: `+r.error);return}alert(`Client saved: `+r.clientname),$()},window.editClient=function(e){let t=o.find(t=>String(t.clientid)===String(e));if(!t){alert(`Client not found`);return}document.querySelector(`#page`).innerHTML=`

    <h2>Edit Client</h2>

    <label>Client Name</label>
    <input
      id="editClientName"
      type="text"
      value="${t.clientname||``}"
    >

    <label>Address</label>
    <input
      id="editClientAddress"
      type="text"
      value="${t.clientaddr||``}"
    >

    <button onclick="saveClientChanges(${t.clientid})">
      Save Changes
    </button>

    <button onclick="showCustomerSetup()">
      Cancel
    </button>

  `},window.saveClientChanges=async function(e){let t=document.querySelector(`#editClientName`).value,n=document.querySelector(`#editClientAddress`).value,r=await fetch(`${b}/customers/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientname:t,clientaddr:n})}),i=await r.json();if(!r.ok){alert(`Error updating client: `+i.error);return}alert(`Client updated`),await $(),showCustomerSetup()},window.filterCustomers=function(e=!1){e&&(window.customerCurrentPage=1);let t=document.querySelector(`#customerSearch`).value.toLowerCase(),n=i(o.filter(e=>{let n=e.archived===!0||e.archived===`true`,r=y===`all`||y===`active`&&!n||y===`archived`&&n,i=String(e.clientid||``).includes(t)||(e.clientname||``).toLowerCase().includes(t)||(e.clientaddr||``).toLowerCase().includes(t);return r&&i}),`customerCurrentPage`,`customerRowsPerPage`),r=document.querySelector(`.report-pagination-bar`);r&&(r.outerHTML=a({...n,label:`customers`,onPage:`goToCustomerPage`,onPageSize:`setCustomerRowsPerPage`}));let s=document.querySelector(`#customerTableBody`);s.innerHTML=n.rows.map(e=>{let t=e.archived===!0||e.archived===`true`;return`
      <tr>
        <td>${e.clientid}</td>
        <td>${e.clientname||``}</td>
        <td>${e.clientaddr||``}</td>
        <td>${t?`Archived`:`Active`}</td>
        <td>
          <button onclick="editClient(${e.clientid})">Edit</button>

          ${t?`<button onclick="unarchiveClient(${e.clientid})">Restore</button>`:`<button onclick="archiveClient(${e.clientid})">Archive</button>`}
        </td>
      </tr>
    `}).join(``)},window.setCustomerRowsPerPage=function(e){window.customerRowsPerPage=Number(e)||25,window.customerCurrentPage=1,filterCustomers()},window.goToCustomerPage=function(e){window.customerCurrentPage=Math.max(1,Number(e)||1),filterCustomers()},window.archiveClient=async function(e){confirm(`Archive this client and all linked data?`)&&(await fetch(`${b}/customers/${e}/archive`,{method:`PUT`}),await $(),showCustomerSetup())},window.unarchiveClient=async function(e){await fetch(`${b}/customers/${e}/unarchive`,{method:`PUT`}),await $(),showCustomerSetup()},window.showResponsiblePersons=function(){q(`responsible`)&&(localStorage.setItem(`currentPage`,`responsible`),u(m))},window.showAddResponsiblePersonForm=function(){let e=[...o].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``));document.querySelector(`#page`).innerHTML=`
    <h2>Add Responsible Person</h2>

    <label>Client</label>
    <select id="responsibleClient">
      <option value="">Select Client</option>

      ${e.map(e=>`
        <option value="${e.clientid}">
          ${e.clientname}
        </option>
      `).join(``)}
    </select>

    <label>Responsible Person Name</label>
    <input id="responsibleName" type="text">

    <button onclick="saveResponsiblePerson()">
      Save
    </button>

    <button onclick="showResponsiblePersons()">
      Cancel
    </button>
  `},window.saveResponsiblePerson=async function(){let e=document.querySelector(`#responsibleClient`).value,t=document.querySelector(`#responsibleName`).value;if(!e||!t){alert(`Please complete all fields`);return}let n=await fetch(`${b}/responsible-persons`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:e,name:t})}),r=await n.json();if(!n.ok){alert(r.error);return}alert(`Responsible Person Saved`),await $(),showResponsiblePersons()},window.editResponsiblePerson=function(e){let t=m.find(t=>String(t.personid)===String(e));if(!t){alert(`Person not found`);return}document.querySelector(`#page`).innerHTML=`
    <h2>Edit Responsible Person</h2>

    <label>Name</label>
    <input
      id="editResponsibleName"
      type="text"
      value="${t.name||``}"
    >

    <button onclick="saveResponsiblePersonChanges(${t.personid})">
      Save Changes
    </button>

    <button onclick="showResponsiblePersons()">
      Cancel
    </button>
  `},window.saveResponsiblePersonChanges=async function(e){let t=m.find(t=>String(t.personid)===String(e)),n=document.querySelector(`#editResponsibleName`).value,r=await fetch(`${b}/responsible-persons/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:t.clientid,name:n})}),i=await r.json();if(!r.ok){alert(i.error);return}alert(`Responsible Person Updated`),await $(),showResponsiblePersons()},window.filterResponsiblePersons=function(e=!1){e&&(window.responsibleCurrentPage=1);let t=document.querySelector(`#responsibleSearch`).value.toLowerCase().trim(),n=i(m.filter(e=>String(e.personid||``).includes(t)||(e.clientname||``).toLowerCase().includes(t)||(e.name||``).toLowerCase().includes(t)),`responsibleCurrentPage`,`responsibleRowsPerPage`),r=document.querySelector(`.report-pagination-bar`);r&&(r.outerHTML=a({...n,label:`people`,onPage:`goToResponsiblePage`,onPageSize:`setResponsibleRowsPerPage`})),document.querySelector(`#responsibleTableBody`).innerHTML=n.rows.map(e=>`
      <tr>
        <td>${e.personid}</td>
        <td>${e.clientname||``}</td>
        <td>${e.name||``}</td>
        <td>
          <button onclick="editResponsiblePerson(${e.personid})">
            Edit
          </button>
        </td>
      </tr>
    `).join(``)},window.setResponsibleRowsPerPage=function(e){window.responsibleRowsPerPage=Number(e)||25,window.responsibleCurrentPage=1,filterResponsiblePersons()},window.goToResponsiblePage=function(e){window.responsibleCurrentPage=Math.max(1,Number(e)||1),filterResponsiblePersons()};let S=localStorage.getItem(`sectionArchiveMode`)||`active`;window.showSections=function(e=S){q(`sections`)&&(S=e,localStorage.setItem(`currentPage`,`sections`),localStorage.setItem(`sectionArchiveMode`,e),d(h,S))},window.showAddSectionForm=function(){let e=[...o].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``));document.querySelector(`#page`).innerHTML=`
    <h2>Add Section</h2>

    <div class="form-row">

      <div class="form-group">
        <label>Client</label>
        <select id="sectionClient" onchange="filterSectionDropdowns()">
          <option value="">Select Client</option>
          ${e.map(e=>`
            <option value="${e.clientid}">
              ${e.clientname}
            </option>
          `).join(``)}
        </select>
      </div>

      <div class="form-group">
        <label>Site</label>
        <select id="sectionSite">
          <option value="">Select Client First</option>
        </select>
      </div>

      <div class="form-group">
        <label>Responsible Person</label>
        <select id="sectionResponsible">
          <option value="">Select Client First</option>
        </select>
      </div>

      <div class="form-group">
        <label>Section Name</label>
        <input id="sectionName" type="text" placeholder="Enter section name">
      </div>

    </div>

    <button onclick="saveSectionFromForm()">Save Section</button>
    <button onclick="showSections()">Cancel</button>
  `},window.filterSectionDropdowns=function(){let e=document.querySelector(`#sectionClient`).value,t=document.querySelector(`#sectionSite`),n=document.querySelector(`#sectionResponsible`);if(!e){t.innerHTML=`<option value="">Select Client First</option>`,n.innerHTML=`<option value="">Select Client First</option>`;return}let r=f.filter(t=>String(t.clientid)===String(e)&&!(t.archived===!0||t.archived===`true`)).sort((e,t)=>(e.sitename||``).localeCompare(t.sitename||``)),i=m.filter(t=>String(t.clientid)===String(e)).sort((e,t)=>(e.name||``).localeCompare(t.name||``));t.innerHTML=`
    <option value="">Select Site</option>
    ${r.map(e=>`
      <option value="${e.siteid}">
        ${e.sitename}
      </option>
    `).join(``)}
  `,n.innerHTML=`
    <option value="">Select Responsible Person</option>
    ${i.map(e=>`
      <option value="${e.personid}">
        ${e.name}
      </option>
    `).join(``)}
  `},window.filterSections=function(e=!1){e&&(window.sectionCurrentPage=1);let t=document.querySelector(`#sectionSearchType`).value,n=document.querySelector(`#sectionSearch`).value.toLowerCase().trim(),r=i(h.filter(e=>{let r=e.archived===!0||e.archived===`true`;return S===`active`&&r||S===`archived`&&!r?!1:String(e[t]||``).toLowerCase().includes(n)}),`sectionCurrentPage`,`sectionRowsPerPage`),o=document.querySelector(`.report-pagination-bar`);o&&(o.outerHTML=a({...r,label:`sections`,onPage:`goToSectionPage`,onPageSize:`setSectionRowsPerPage`})),document.querySelector(`#sectionTableBody`).innerHTML=r.rows.map(e=>`
      <tr>
        <td>${e.sectionid}</td>
        <td>${e.clientname||``}</td>
        <td>${e.sitename||``}</td>
        <td>${e.responsiblename||``}</td>
        <td>${e.sectionname||``}</td>
        <td>${e.archived?`Archived`:`Active`}</td>
        <td>
          <button onclick="editSection(${e.sectionid})">
            Edit
          </button>
          ${e.archived?`<button onclick="unarchiveSection(${e.sectionid})">Restore</button>`:`<button onclick="archiveSection(${e.sectionid})">Archive</button>`}
        </td>
      </tr>
    `).join(``)},window.setSectionRowsPerPage=function(e){window.sectionRowsPerPage=Number(e)||25,window.sectionCurrentPage=1,filterSections()},window.goToSectionPage=function(e){window.sectionCurrentPage=Math.max(1,Number(e)||1),filterSections()},window.editSection=function(e){let t=h.find(t=>String(t.sectionid)===String(e));if(!t){alert(`Section not found`);return}let n=m.filter(e=>String(e.clientid)===String(t.clientid)).sort((e,t)=>(e.name||``).localeCompare(t.name||``));document.querySelector(`#page`).innerHTML=`
    <h2>Edit Section</h2>

    <label>Client</label>
    <input type="text" value="${t.clientname||``}" disabled>

    <label>Site</label>
    <input type="text" value="${t.sitename||``}" disabled>

    <label>Responsible Person</label>
    <select id="editSectionResponsible">
      ${n.map(e=>`
        <option
          value="${e.personid}"
          ${String(e.personid)===String(t.responsibleid)?`selected`:``}
        >
          ${e.name}
        </option>
      `).join(``)}
    </select>

    <label>Section Name</label>
    <input
      id="editSectionName"
      type="text"
      value="${t.sectionname||``}"
    >

    <button onclick="saveSectionChanges(${t.sectionid})">
      Save Changes
    </button>

    <button onclick="showSections()">
      Cancel
    </button>
  `},window.saveSectionChanges=async function(e){let t=document.querySelector(`#editSectionResponsible`).value,n=document.querySelector(`#editSectionName`).value;if(!t||!n){alert(`Please complete all fields`);return}let r=await fetch(`${b}/sections/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({responsibleid:t,sectionname:n})}),i=await r.json();if(!r.ok){alert(`Error updating section: `+i.error);return}alert(`Section updated`),await $(),showSections()},window.saveSectionFromForm=async function(){let e=document.querySelector(`#sectionClient`).value,t=document.querySelector(`#sectionSite`).value,n=document.querySelector(`#sectionResponsible`).value,r=document.querySelector(`#sectionName`).value;if(!e||!t||!n||!r){alert(`Please complete all fields`);return}let i=await fetch(`${b}/sections`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:e,siteid:t,responsibleid:n,sectionname:r})}),a=await i.json();if(!i.ok){alert(`Error saving section: `+a.error);return}alert(`Section saved: `+a.sectionname),await $(),showSections()},window.archiveSection=async function(e){if(!confirm(`Archive this section? Active assets must be moved or archived first.`))return;let t=await fetch(`${b}/sections/${e}/archive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to archive section`);return}alert(`Section archived`),await $(),showSections()},window.unarchiveSection=async function(e){let t=await fetch(`${b}/sections/${e}/unarchive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to restore section`);return}alert(`Section restored`),await $(),showSections()};let C=localStorage.getItem(`siteArchiveMode`)||`active`;window.showSites=function(e=C){q(`sites`)&&(C=e,localStorage.setItem(`currentPage`,`sites`),localStorage.setItem(`siteArchiveMode`,e),l(f,C))},window.filterSites=function(e=!1){e&&(window.siteCurrentPage=1);let t=document.querySelector(`#siteSearch`).value.toLowerCase().trim(),n=i(f.filter(e=>{let n=e.archived===!0||e.archived===`true`,r=C===`all`||C===`active`&&!n||C===`archived`&&n,i=String(e.siteid||``).includes(t)||(e.clientname||``).toLowerCase().includes(t)||(e.sitename||``).toLowerCase().includes(t);return r&&i}),`siteCurrentPage`,`siteRowsPerPage`),r=document.querySelector(`.report-pagination-bar`);r&&(r.outerHTML=a({...n,label:`sites`,onPage:`goToSitePage`,onPageSize:`setSiteRowsPerPage`})),document.querySelector(`#siteTableBody`).innerHTML=n.rows.map(e=>`
      <tr>
        <td>${e.siteid}</td>
        <td>${e.clientname||``}</td>
        <td>${e.sitename||``}</td>
        <td>${e.archived?`Archived`:`Active`}</td>
        <td>
          <button onclick="editSite(${e.siteid})">
            Edit
          </button>
          ${e.archived?`<button onclick="unarchiveSite(${e.siteid})">Restore</button>`:`<button onclick="archiveSite(${e.siteid})">Archive</button>`}
        </td>
      </tr>
    `).join(``)},window.setSiteRowsPerPage=function(e){window.siteRowsPerPage=Number(e)||25,window.siteCurrentPage=1,filterSites()},window.goToSitePage=function(e){window.siteCurrentPage=Math.max(1,Number(e)||1),filterSites()},window.editSite=function(e){let t=f.find(t=>String(t.siteid)===String(e));if(!t){alert(`Site not found`);return}document.querySelector(`#page`).innerHTML=`
    <h2>Edit Site</h2>

    <label>Client</label>
    <input
      type="text"
      value="${t.clientname||``}"
      disabled
    >

    <label>Site Name</label>
    <input
      id="editSiteName"
      type="text"
      value="${t.sitename||``}"
    >

    <button onclick="saveSiteChanges(${t.siteid})">
      Save Changes
    </button>

    <button onclick="showSites()">
      Cancel
    </button>
  `},window.saveSiteChanges=async function(e){let t=document.querySelector(`#editSiteName`).value;if(!t){alert(`Please enter a site name`);return}let n=await fetch(`${b}/sites/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({sitename:t})}),r=await n.json();if(!n.ok){alert(`Error updating site: `+r.error);return}alert(`Site updated`),await $(),showSites()},window.archiveSite=async function(e){if(!confirm(`Archive this site? Active assets must be moved or archived first.`))return;let t=await fetch(`${b}/sites/${e}/archive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to archive site`);return}alert(`Site archived`),await $(),showSites()},window.unarchiveSite=async function(e){let t=await fetch(`${b}/sites/${e}/unarchive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to restore site`);return}alert(`Site restored`),await $(),showSites()},window.showAddSiteForm=function(){let e=[...o].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``));document.querySelector(`#page`).innerHTML=`
    <h2>Add Site</h2>

    <label>Client</label>
    <select id="siteClient">
      <option value="">Select Client</option>
      ${e.map(e=>`
        <option value="${e.clientid}">
          ${e.clientname}
        </option>
      `).join(``)}
    </select>

    <label>Site Name</label>
    <input id="siteName" type="text" placeholder="Enter site name">

    <button onclick="saveSiteFromForm()">
      Save Site
    </button>

    <button onclick="showSites()">
      Cancel
    </button>
  `},window.saveSiteFromForm=async function(){let e=document.querySelector(`#siteClient`).value,t=document.querySelector(`#siteName`).value;if(!e||!t){alert(`Please complete all fields`);return}let n=await fetch(`${b}/sites`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:e,sitename:t})}),r=await n.json();if(!n.ok){alert(`Error saving site: `+r.error);return}alert(`Site saved: `+r.sitename),await $(),showSites()},window.showAssetSetup=function(){if(!q(`assets`))return;localStorage.setItem(`currentPage`,`assets`);let e=window.assetListState||{};window.assetCurrentPage=e.currentPage||window.assetCurrentPage||1,window.assetRowsPerPage=e.rowsPerPage||window.assetRowsPerPage||25,ee(s),oe()},window.showRiskAssessments=async function(){q(`she`)&&(localStorage.setItem(`currentPage`,`she`),window.canWriteRiskAssessments=[`ADMIN`,`MANAGER`,`INSPECTOR`].includes(G?.role),await Ve(s,window.canWriteRiskAssessments))},window.loadRiskAssessments=async function(){let e=await fetch(`${b}/she/risk-assessments`),t=await e.json();if(!e.ok){alert(t.error||`Unable to load risk assessments`);return}window.riskAssessments=t,He(window.riskAssessments,window.canWriteRiskAssessments)},window.filterRiskAssessments=function(){He(window.riskAssessments||[],window.canWriteRiskAssessments)},window.downloadRiskAssessments=async function(e=`pdf`){let t=new URLSearchParams,n=document.querySelector(`#riskSearch`)?.value||``,r=document.querySelector(`#riskStatusFilter`)?.value||``;n&&t.append(`search`,n),r&&t.append(`status`,r);let i=e===`xlsx`?`xlsx`:`pdf`,a=await fetch(`${b}/she/risk-assessments.${i}?${t.toString()}`);if(!a.ok){let e=await W(a);alert(e.error||`Unable to download risk assessment register`);return}let o=await a.blob(),s=URL.createObjectURL(o),c=document.createElement(`a`);c.href=s,c.download=`ATEC-SHE-Risk-Register.${i}`,document.body.appendChild(c),c.click(),c.remove(),URL.revokeObjectURL(s)},window.saveRiskAssessment=async function(){let e=document.querySelector(`#riskId`)?.value||``,t={assetid:document.querySelector(`#riskAssetId`)?.value||null,assessment_date:document.querySelector(`#riskAssessmentDate`)?.value,activity:document.querySelector(`#riskActivity`)?.value,hazard:document.querySelector(`#riskHazard`)?.value,consequence:document.querySelector(`#riskConsequence`)?.value,initial_severity:document.querySelector(`#riskInitialSeverity`)?.value,initial_likelihood:document.querySelector(`#riskInitialLikelihood`)?.value,controls:document.querySelector(`#riskControls`)?.value,residual_severity:document.querySelector(`#riskResidualSeverity`)?.value,residual_likelihood:document.querySelector(`#riskResidualLikelihood`)?.value,action_required:document.querySelector(`#riskActionRequired`)?.value,responsible_person:document.querySelector(`#riskResponsiblePerson`)?.value,due_date:document.querySelector(`#riskDueDate`)?.value||null,status:document.querySelector(`#riskStatus`)?.value||`OPEN`};if(!t.activity||!t.hazard){alert(`Activity and hazard are required`);return}let n=await fetch(e?`${b}/she/risk-assessments/${e}`:`${b}/she/risk-assessments`,{method:e?`PUT`:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(t)}),r=await n.json();if(!n.ok){alert(r.error||`Unable to save risk assessment`);return}alert(`Risk assessment saved successfully`),await showRiskAssessments()},window.editRiskAssessment=function(e){let t=(window.riskAssessments||[]).find(t=>String(t.riskid)===String(e));if(t){if(!document.querySelector(`#riskId`)){let e=document.createElement(`input`);e.type=`hidden`,e.id=`riskId`,document.querySelector(`.filter-card`).appendChild(e)}document.querySelector(`#riskId`).value=t.riskid,document.querySelector(`#riskAssetId`).value=t.assetid||``,document.querySelector(`#riskAssessmentDate`).value=t.assessment_date?t.assessment_date.split(`T`)[0]:``,document.querySelector(`#riskStatus`).value=t.status||`OPEN`,document.querySelector(`#riskActivity`).value=t.activity||``,document.querySelector(`#riskHazard`).value=t.hazard||``,document.querySelector(`#riskConsequence`).value=t.consequence||``,document.querySelector(`#riskInitialSeverity`).value=t.initial_severity||3,document.querySelector(`#riskInitialLikelihood`).value=t.initial_likelihood||3,document.querySelector(`#riskControls`).value=t.controls||``,document.querySelector(`#riskResidualSeverity`).value=t.residual_severity||2,document.querySelector(`#riskResidualLikelihood`).value=t.residual_likelihood||2,document.querySelector(`#riskActionRequired`).value=t.action_required||``,document.querySelector(`#riskResponsiblePerson`).value=t.responsible_person||``,document.querySelector(`#riskDueDate`).value=t.due_date?t.due_date.split(`T`)[0]:``,window.scrollTo({top:0,behavior:`smooth`})}},window.archiveRiskAssessment=async function(e){if(!confirm(`Archive this risk assessment?`))return;let t=await fetch(`${b}/she/risk-assessments/${e}/archive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(n.error||`Unable to archive risk assessment`);return}await window.loadRiskAssessments()},window.openAssetQrLabel=function(e){window.open(`${b}/assets/${e}/qr-label.pdf`,`_blank`)},window.showAddAssetForm=function(){if(!Y()){K();return}let e=[...o].sort((e,t)=>(e.clientname||``).localeCompare(t.clientname||``)),t=[...g].sort((e,t)=>(e.description||``).localeCompare(t.description||``));document.querySelector(`#page`).innerHTML=`
    <h2>Add Asset</h2>

    <div class="filter-card">

     <div class="asset-form-grid">

  <div class="form-group">
    <label>Client</label>
    <select id="assetClient" onchange="filterAssetDropdowns()">
      <option value="">Select Client</option>
      ${e.map(e=>`
        <option value="${e.clientid}">
          ${e.clientname}
        </option>
      `).join(``)}
    </select>
  </div>

  <div class="form-group">
    <label>Site</label>
    <select id="assetSite" onchange="filterAssetSections()">
      <option value="">Select Client First</option>
    </select>
  </div>

  <div class="form-group">
    <label>Section</label>
    <select id="assetSection" onchange="autoFillResponsibleFromSection()">
      <option value="">Select Site First</option>
    </select>
  </div>

  <div class="form-group">
    <label>Responsible Person</label>
    <input id="assetResponsibleName" type="text" placeholder="Auto-filled from Section" disabled>
    <input id="assetResponsible" type="hidden">
  </div>

  <div class="form-group">
    <label>Equipment Type</label>
    <select id="assetEquipType" onchange="handleAssetEquipmentTypeChange()">
      <option value="">Select Equipment Type</option>
      ${t.map(e=>`
        <option value="${e.equiptypeid}">
          ${e.description}
        </option>
      `).join(``)}
    </select>
  </div>

  <div id="dynamicAssetFields" class="dynamic-asset-fields"></div>

    <div class="form-group">
    <label>Serial No</label>
    <input id="assetSerialNo" type="text">
  </div>

  <div class="form-group">
    <label>Asset Tag Number <span class="optional-label">(Optional)</span></label>
    <input id="assetTagNo" type="text" placeholder="Customer tag / plant number if available">
  </div>

  <div class="form-group">
    <label>Manufacturer</label>
    <input id="assetManufacturer" type="text">
  </div>

  <div class="form-group asset-description">
    <label>Description</label>
    <textarea id="assetDescription" rows="4" placeholder="Enter full asset description..."></textarea>
  </div>

  <div class="form-group" id="manufactureDateRow" style="display:none;">
    <label>Manufacture Date</label>
    <input id="assetManufactDate" type="date">
  </div>

  <div class="asset-photo-row">
    <div class="form-group">
      <label>Asset Photo 1</label>
      <input id="newAssetPhoto1" type="file" accept="image/*">
    </div>

    <div class="form-group">
      <label>Asset Photo 2</label>
      <input id="newAssetPhoto2" type="file" accept="image/*">
    </div>
  </div>

  <div class="form-actions">
    <button onclick="saveAssetFromForm()">Save Asset</button>
    <button onclick="showAssetSetup()">Cancel</button>
  </div>

</div>

  `},window.toggleManufactureDate=function(){let e=document.querySelector(`#assetEquipType`).value,t=g.find(t=>String(t.equiptypeid)===String(e)),n=document.querySelector(`#manufactureDateRow`),r=document.querySelector(`#assetManufactDate`);t&&String(t.equipgroupid)===`400`?n.style.display=`flex`:(n.style.display=`none`,r.value=``)},window.handleAssetEquipmentTypeChange=function(){toggleManufactureDate(),loadDynamicAssetFields()},window.loadDynamicAssetFields=function(){let e=document.querySelector(`#assetEquipType`).value,t=document.querySelector(`#dynamicAssetFields`);t.innerHTML=``;let n=g.find(t=>String(t.equiptypeid)===String(e));if(!n)return;let r=String(n.equipgroupid),i=``;r===`100`&&(i=`
      <div class="form-group"><label>WLL(kg)</label><input id="assetWLL" type="number"></div>
      <div class="form-group"><label>Height of Lift(mm)</label><input id="assetHeightOfLift" type="number"></div>
      <div class="form-group"><label>Number of Chain Falls</label><input id="assetNumberOfChainFalls" type="number"></div>
      <div class="form-group"><label>OEM Top Hook Size(mm)</label><input id="assetOEMTopHookSize" type="number"></div>
      <div class="form-group"><label>OEM Bottom Hook Size(mm)</label><input id="assetOEMBottomHookSize" type="number"></div>
      <div class="form-group"><label>Load Chain Diameter(mm)</label><input id="assetLoadChainDiameter" type="number"></div>
    `),r===`200`&&(i=`
      <div class="form-group"><label>WLL(kg)</label><input id="assetWLL" type="number"></div>
      <div class="form-group"><label>Effective Length(mm)</label><input id="assetEffectiveLength" type="number"></div>
    `),(r===`300`||r===`600`)&&(i=`
      <div class="form-group"><label>WLL(kg)</label><input id="assetWLL" type="number"></div>
    `),r===`400`&&(i=`
      <div class="form-group"><label>Main Hoist WLL(kg)</label><input id="assetWLL" type="number"></div>
      <div class="form-group"><label>Auxiliary Hoist WLL(kg)</label><input id="assetAuxHoistWLL" type="number"></div>
      <div class="form-group"><label>Span(mm)</label><input id="assetSpan" type="number"></div>
      <div class="form-group"><label>Permissible Deflection(mm)</label><input id="assetPermissibleDeflection" type="number"></div>
      <div class="form-group"><label>Main Hoist Description</label><input id="assetHoistDescription" type="text"></div>
      <div class="form-group"><label>Main Hoist Serial No</label><input id="assetHoistSerialNo" type="text"></div>
      <div class="form-group"><label>Auxiliary Hoist Description</label><input id="assetAuxHoistDescription" type="text"></div>
      <div class="form-group"><label>Auxiliary Hoist Serial No</label><input id="assetAuxHoistSerialNo" type="text"></div>
      <div class="form-group"><label>Main Hoist Hook Size(mm)</label><input id="assetHookSize" type="number"></div>
      <div class="form-group"><label>Auxiliary Hoist Hook Size(mm)</label><input id="assetAuxHoistHookSize" type="number"></div>
      <div class="form-group"><label>Height of Lift(mm)</label><input id="assetHeightOfLift" type="number"></div>
      <div class="form-group"><label>Main Hoist Steel Wire Rope(mm)</label><input id="assetSteelWireRopeMM" type="number"></div>
      <div class="form-group"><label>Auxiliary Hoist Steel Wire Rope(mm)</label><input id="assetAuxHoistRopeMM" type="number"></div>
    `),r===`500`&&(i=`
      <div class="form-group"><label>WLL(kg)</label><input id="assetWLL" type="number"></div>
      <div class="form-group"><label>Span(mm)</label><input id="assetSpan" type="number"></div>
      <div class="form-group"><label>Permissible Deflection(mm)</label><input id="assetPermissibleDeflection" type="number"></div>
      <div class="form-group"><label>Hook Size(mm)</label><input id="assetHookSize" type="number"></div>
      <div class="form-group"><label>Hoist Description</label><input id="assetHoistDescription" type="text"></div>
      <div class="form-group"><label>Hoist Serial No</label><input id="assetHoistSerialNo" type="text"></div>
    `),t.innerHTML=i},window.filterAssetDropdowns=function(){let e=document.querySelector(`#assetClient`).value,t=document.querySelector(`#assetSite`);if(document.querySelector(`#assetSection`).innerHTML=`<option value="">Select Site First</option>`,document.querySelector(`#assetResponsibleName`).value=``,document.querySelector(`#assetResponsible`).value=``,!e){t.innerHTML=`<option value="">Select Client First</option>`;return}t.innerHTML=`
    <option value="">Select Site</option>

    ${f.filter(t=>String(t.clientid)===String(e)&&!(t.archived===!0||t.archived===`true`)).sort((e,t)=>(e.sitename||``).localeCompare(t.sitename||``)).map(e=>`
      <option value="${e.siteid}">
        ${e.sitename}
      </option>
    `).join(``)}
  `},window.filterAssetSections=function(){let e=document.querySelector(`#assetSite`).value,t=document.querySelector(`#assetSection`);if(document.querySelector(`#assetResponsibleName`).value=``,document.querySelector(`#assetResponsible`).value=``,!e){t.innerHTML=`<option value="">Select Site First</option>`;return}t.innerHTML=`
    <option value="">Select Section</option>

    ${h.filter(t=>String(t.siteid)===String(e)&&!(t.archived===!0||t.archived===`true`)).sort((e,t)=>(e.sectionname||``).localeCompare(t.sectionname||``)).map(e=>`
      <option value="${e.sectionid}">
        ${e.sectionname}
      </option>
    `).join(``)}
  `},window.autoFillResponsibleFromSection=function(){let e=document.querySelector(`#assetSection`).value,t=document.querySelector(`#assetResponsibleName`),n=document.querySelector(`#assetResponsible`);if(t.value=``,n.value=``,!e)return;let r=h.find(t=>String(t.sectionid)===String(e));r&&(t.value=r.responsiblename||``,n.value=r.responsibleid||``)};let ae=new Set([`image/jpeg`,`image/png`,`image/webp`]);function w(e){for(let t of e.filter(Boolean)){if(!ae.has(t.type))return alert(`Asset photos must be JPG, PNG or WebP images.`),!1;if(t.size>15728640)return alert(`Asset photos must be 15 MB or smaller.`),!1}return!0}window.saveAssetFromForm=async function(){if(!Y()){alert(`You do not have permission to add assets.`);return}let e=document.querySelector(`#assetClient`).value,t=document.querySelector(`#assetSite`).value,n=document.querySelector(`#assetSection`).value,r=document.querySelector(`#assetResponsible`).value,i=document.querySelector(`#assetEquipType`).value,a=document.querySelector(`#assetTagNo`)?.value||``,o=document.querySelector(`#assetSerialNo`).value,s=document.querySelector(`#assetManufacturer`).value,c=document.querySelector(`#assetDescription`).value,l=document.querySelector(`#assetManufactDate`)?.value||``;if(!e||!t||!n||!r||!i||!c){alert(`Please complete Client, Site, Section, Responsible Person, Equipment Type, and Description`);return}let u=document.querySelector(`#newAssetPhoto1`)?.files[0],d=document.querySelector(`#newAssetPhoto2`)?.files[0];if(!w([u,d]))return;let f=await fetch(`${b}/assets`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({clientid:e,siteid:t,sectionid:n,responsibleid:r,equiptypeid:i,assettagno:a,serialno:o,manufacturer:s,description:c,manufactdate:l,wll:document.querySelector(`#assetWLL`)?.value||null,heightoflift:document.querySelector(`#assetHeightOfLift`)?.value||null,numberofchainfalls:document.querySelector(`#assetNumberOfChainFalls`)?.value||null,oemtophooksize:document.querySelector(`#assetOEMTopHookSize`)?.value||null,oembottomhooksize:document.querySelector(`#assetOEMBottomHookSize`)?.value||null,loadchaindiameter:document.querySelector(`#assetLoadChainDiameter`)?.value||null,effectivelength:document.querySelector(`#assetEffectiveLength`)?.value||null,span:document.querySelector(`#assetSpan`)?.value||null,permissibledeflection:document.querySelector(`#assetPermissibleDeflection`)?.value||null,hooksize:document.querySelector(`#assetHookSize`)?.value||null,steelwireropemm:document.querySelector(`#assetSteelWireRopeMM`)?.value||null,hoistdescription:document.querySelector(`#assetHoistDescription`)?.value||null,hoistserialno:document.querySelector(`#assetHoistSerialNo`)?.value||null,auxhoistdescription:document.querySelector(`#assetAuxHoistDescription`)?.value||null,auxhoistserialno:document.querySelector(`#assetAuxHoistSerialNo`)?.value||null,auxhoistwll:document.querySelector(`#assetAuxHoistWLL`)?.value||null,auxhoisthooksize:document.querySelector(`#assetAuxHoistHookSize`)?.value||null,auxhoistropemm:document.querySelector(`#assetAuxHoistRopeMM`)?.value||null})}),p=await f.json();if(!f.ok){alert(`Error saving asset: `+p.error);return}if(u||d){let e=new FormData;u&&e.append(`photo1`,u),d&&e.append(`photo2`,d);let t=await fetch(`${b}/assets/${p.assetid}/photos`,{method:`POST`,body:e}),n=await t.json();if(!t.ok){alert(`Asset saved, but photo upload failed: `+n.error),await $(),showAssetSetup();return}}alert(`Asset saved successfully`),await $(),showAssetSetup()},window.filterAssets=function(e=!1){e&&(window.assetCurrentPage=1);let t=document.querySelector(`#assetSearchType`),n=document.querySelector(`#assetSearch`);if(!t||!n)return;let r=t.value,i=n.value.toLowerCase().trim(),a=[`assetid`,`assettagno`,`serialno`,`hoistserialno`,`clientname`,`sitename`,`sectionname`,`equipmenttype`,`description`,`qrcode`],o=s.filter(e=>r===`all`?a.some(t=>String(e[t]||``).toLowerCase().includes(i)):String(e[r]||``).toLowerCase().includes(i)),c=window.assetRowsPerPage||25,l=Math.max(1,Math.ceil(o.length/c));window.assetCurrentPage=Math.min(window.assetCurrentPage||1,l);let u=window.assetCurrentPage,d=(u-1)*c,f=o.slice(d,d+c),ee=o.length===0?0:d+f.length;E(o.length,d,ee,u,l,c);let m=document.querySelector(`#assetTableBody`);m.innerHTML=f.map(p).join(``),T()};function T(){let e=document.querySelector(`#assetSearchType`),t=document.querySelector(`#assetSearch`),n=document.querySelector(`#assetRowsPerPage`);window.assetListState={searchType:e?.value||window.assetListState?.searchType||`all`,search:t?.value||window.assetListState?.search||``,currentPage:window.assetCurrentPage||window.assetListState?.currentPage||1,rowsPerPage:Number(n?.value||window.assetRowsPerPage||window.assetListState?.rowsPerPage||25)}}function oe(){let e=window.assetListState||{},t=document.querySelector(`#assetSearchType`),n=document.querySelector(`#assetSearch`),r=document.querySelector(`#assetRowsPerPage`);window.assetRowsPerPage=Number(e.rowsPerPage||window.assetRowsPerPage||25),window.assetCurrentPage=Number(e.currentPage||window.assetCurrentPage||1),t&&(t.value=e.searchType||`all`),n&&(n.value=e.search||``),r&&(r.value=String(window.assetRowsPerPage)),filterAssets(!1)}function E(e,t,n,r,i,a){let o=document.querySelectorAll(`#assetPaginationControls, .asset-pagination-bottom`);if(!o.length)return;let s=ce(r,i),c=`
    <div class="report-page-controls">
      <button type="button" onclick="changeAssetPage(-1)" ${r<=1?`disabled`:``}>
        Previous
      </button>
      ${s}
      <button type="button" onclick="changeAssetPage(1)" ${r>=i?`disabled`:``}>
        Next
      </button>
      <span>Showing ${e===0?0:t+1} to ${n} of ${e} assets - Page ${r} of ${i}</span>
    </div>
  `;o.forEach(e=>{if(e.id===`assetPaginationControls`){e.innerHTML=`
        <div class="report-page-size">
          <label for="assetRowsPerPage">Rows per page</label>
          <select id="assetRowsPerPage" onchange="setAssetRowsPerPage(this.value)">
            ${[25,50,100,250].map(e=>`
              <option value="${e}" ${e===a?`selected`:``}>
                ${e}
              </option>
            `).join(``)}
          </select>
        </div>

        ${c}
      `;return}e.innerHTML=`<div></div>${c}`})}function se(e,t){let n=[];if(t<=7){for(let e=1;e<=t;e+=1)n.push(e);return n}n.push(1),e>4&&n.push(`...`);let r=Math.max(2,e-1),i=Math.min(t-1,e+1);for(let e=r;e<=i;e+=1)n.push(e);return e<t-3&&n.push(`...`),n.push(t),n}function ce(e,t){return se(e,t).map(t=>t===`...`?`<span class="pagination-ellipsis">...</span>`:`
      <button
        type="button"
        class="pagination-page-btn ${t===e?`active`:``}"
        onclick="goToAssetPage(${t})"
        ${t===e?`disabled`:``}
      >
        ${t}
      </button>
    `).join(``)}window.setAssetRowsPerPage=function(e){window.assetRowsPerPage=Number(e)||25,window.assetCurrentPage=1,filterAssets()},window.changeAssetPage=function(e){window.assetCurrentPage=Math.max(1,(window.assetCurrentPage||1)+e),filterAssets()},window.goToAssetPage=function(e){window.assetCurrentPage=Math.max(1,Number(e)||1),filterAssets()},window.setAssetFilterKey=function(e){let t=document.querySelector(`#assetSearchType`);t&&(t.value=e,window.assetCurrentPage=1,filterAssets())},window.showMoveAssetForm=function(e){if(!Y()){K();return}T();let t=s.find(t=>String(t.assetid)===String(e));if(!t){alert(`Asset not found`);return}let n=f.filter(e=>String(e.clientid)===String(t.clientid)&&!(e.archived===!0||e.archived===`true`)).sort((e,t)=>(e.sitename||``).localeCompare(t.sitename||``));document.querySelector(`#page`).innerHTML=`
    <h2>Move Asset ${t.assetid}</h2>

    <div class="filter-card">
      <div class="asset-form-grid">
        <div class="form-group">
          <label>Customer</label>
          <input type="text" value="${t.clientname||``}" disabled>
        </div>

        <div class="form-group">
          <label>Current Site</label>
          <input type="text" value="${t.sitename||`-`}" disabled>
        </div>

        <div class="form-group">
          <label>Current Section</label>
          <input type="text" value="${t.sectionname||`-`}" disabled>
        </div>

        <div class="form-group">
          <label>New Site</label>
          <select id="moveAssetSite" onchange="filterMoveAssetSections()">
            <option value="">Select Site</option>
            ${n.map(e=>`
              <option value="${e.siteid}" ${String(e.siteid)===String(t.siteid)?`selected`:``}>
                ${e.sitename}
              </option>
            `).join(``)}
          </select>
        </div>

        <div class="form-group">
          <label>New Section</label>
          <select id="moveAssetSection">
            <option value="">Select Site First</option>
          </select>
        </div>
      </div>

      <div class="form-actions">
        <button onclick="saveAssetMove(${t.assetid})">Move Asset</button>
        <button onclick="showAssetSetup()">Cancel</button>
      </div>
    </div>
  `,filterMoveAssetSections(t.sectionid)},window.filterMoveAssetSections=function(e=``){let t=document.querySelector(`#moveAssetSite`)?.value||``,n=document.querySelector(`#moveAssetSection`);if(n){if(!t){n.innerHTML=`<option value="">Select Site First</option>`;return}n.innerHTML=`
    <option value="">Select Section</option>
    ${h.filter(e=>String(e.siteid)===String(t)&&!(e.archived===!0||e.archived===`true`)).sort((e,t)=>(e.sectionname||``).localeCompare(t.sectionname||``)).map(t=>`
      <option value="${t.sectionid}" ${String(t.sectionid)===String(e)?`selected`:``}>
        ${t.sectionname}
      </option>
    `).join(``)}
  `}},window.saveAssetMove=async function(e){if(!Y()){alert(`You do not have permission to move assets.`);return}let t=document.querySelector(`#moveAssetSite`)?.value||``,n=document.querySelector(`#moveAssetSection`)?.value||``;if(!t||!n){alert(`Please select the new site and section`);return}let r=await fetch(`${b}/assets/${e}/move`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({siteid:t,sectionid:n})}),i=await r.json();if(!r.ok){alert(i.error||`Unable to move asset`);return}alert(`Asset moved successfully`),await $(),showAssetSetup()};function le(e,t={}){let n=``;return e===`100`&&(n=`
      <div class="form-group"><label>WLL(kg)</label><input id="editAssetWLL" type="number" value="${t.wll||``}"></div>
      <div class="form-group"><label>Height of Lift(mm)</label><input id="editAssetHeightOfLift" type="number" value="${t.heightoflift||``}"></div>
      <div class="form-group"><label>Number of Chain Falls</label><input id="editAssetNumberOfChainFalls" type="number" value="${t.numberofchainfalls||``}"></div>
      <div class="form-group"><label>OEM Top Hook Size(mm)</label><input id="editAssetOEMTopHookSize" type="number" value="${t.oemtophooksize||``}"></div>
      <div class="form-group"><label>OEM Bottom Hook Size(mm)</label><input id="editAssetOEMBottomHookSize" type="number" value="${t.oembottomhooksize||``}"></div>
      <div class="form-group"><label>Load Chain Diameter(mm)</label><input id="editAssetLoadChainDiameter" type="number" value="${t.loadchaindiameter||``}"></div>
    `),e===`200`&&(n=`
      <div class="form-group"><label>WLL(kg)</label><input id="editAssetWLL" type="number" value="${t.wll||``}"></div>
      <div class="form-group"><label>Effective Length(mm)</label><input id="editAssetEffectiveLength" type="number" value="${t.effectivelength||``}"></div>
    `),(e===`300`||e===`600`)&&(n=`
      <div class="form-group"><label>WLL(kg)</label><input id="editAssetWLL" type="number" value="${t.wll||``}"></div>
    `),e===`400`&&(n=`
      <div class="form-group"><label>Main Hoist WLL(kg)</label><input id="editAssetWLL" type="number" value="${t.wll||``}"></div>
      <div class="form-group"><label>Auxiliary Hoist WLL(kg)</label><input id="editAssetAuxHoistWLL" type="number" value="${t.auxhoistwll||``}"></div>
      <div class="form-group"><label>Span(mm)</label><input id="editAssetSpan" type="number" value="${t.span||``}"></div>
      <div class="form-group"><label>Permissible Deflection(mm)</label><input id="editAssetPermissibleDeflection" type="number" value="${t.permissibledeflection||``}"></div>
      <div class="form-group"><label>Main Hoist Description</label><input id="editAssetHoistDescription" type="text" value="${t.hoistdescription||``}"></div>
      <div class="form-group"><label>Main Hoist Serial No</label><input id="editAssetHoistSerialNo" type="text" value="${t.hoistserialno||``}"></div>
      <div class="form-group"><label>Auxiliary Hoist Description</label><input id="editAssetAuxHoistDescription" type="text" value="${t.auxhoistdescription||``}"></div>
      <div class="form-group"><label>Auxiliary Hoist Serial No</label><input id="editAssetAuxHoistSerialNo" type="text" value="${t.auxhoistserialno||``}"></div>
      <div class="form-group"><label>Main Hoist Hook Size(mm)</label><input id="editAssetHookSize" type="number" value="${t.hooksize||``}"></div>
      <div class="form-group"><label>Auxiliary Hoist Hook Size(mm)</label><input id="editAssetAuxHoistHookSize" type="number" value="${t.auxhoisthooksize||``}"></div>
      <div class="form-group"><label>Height of Lift(mm)</label><input id="editAssetHeightOfLift" type="number" value="${t.heightoflift||``}"></div>
      <div class="form-group"><label>Main Hoist Steel Wire Rope(mm)</label><input id="editAssetSteelWireRopeMM" type="number" value="${t.steelwireropemm||``}"></div>
      <div class="form-group"><label>Auxiliary Hoist Steel Wire Rope(mm)</label><input id="editAssetAuxHoistRopeMM" type="number" value="${t.auxhoistropemm||``}"></div>
    `),e===`500`&&(n=`
      <div class="form-group"><label>WLL(kg)</label><input id="editAssetWLL" type="number" value="${t.wll||``}"></div>
      <div class="form-group"><label>Span(mm)</label><input id="editAssetSpan" type="number" value="${t.span||``}"></div>
      <div class="form-group"><label>Permissible Deflection(mm)</label><input id="editAssetPermissibleDeflection" type="number" value="${t.permissibledeflection||``}"></div>
      <div class="form-group"><label>Hook Size(mm)</label><input id="editAssetHookSize" type="number" value="${t.hooksize||``}"></div>
      <div class="form-group"><label>Hoist Description</label><input id="editAssetHoistDescription" type="text" value="${t.hoistdescription||``}"></div>
      <div class="form-group"><label>Hoist Serial No</label><input id="editAssetHoistSerialNo" type="text" value="${t.hoistserialno||``}"></div>
    `),n}function ue(e={}){let t=(t,n)=>document.querySelector(t)?.value??e[n]??``;return{manufactdate:((t,n)=>{let r=document.querySelector(t)?.value??e[n]??``;return String(r||``).slice(0,10)})(`#editAssetManufactDate`,`manufactdate`),wll:t(`#editAssetWLL`,`wll`),heightoflift:t(`#editAssetHeightOfLift`,`heightoflift`),numberofchainfalls:t(`#editAssetNumberOfChainFalls`,`numberofchainfalls`),oemtophooksize:t(`#editAssetOEMTopHookSize`,`oemtophooksize`),oembottomhooksize:t(`#editAssetOEMBottomHookSize`,`oembottomhooksize`),loadchaindiameter:t(`#editAssetLoadChainDiameter`,`loadchaindiameter`),effectivelength:t(`#editAssetEffectiveLength`,`effectivelength`),span:t(`#editAssetSpan`,`span`),permissibledeflection:t(`#editAssetPermissibleDeflection`,`permissibledeflection`),hooksize:t(`#editAssetHookSize`,`hooksize`),steelwireropemm:t(`#editAssetSteelWireRopeMM`,`steelwireropemm`),hoistdescription:t(`#editAssetHoistDescription`,`hoistdescription`),hoistserialno:t(`#editAssetHoistSerialNo`,`hoistserialno`),auxhoistdescription:t(`#editAssetAuxHoistDescription`,`auxhoistdescription`),auxhoistserialno:t(`#editAssetAuxHoistSerialNo`,`auxhoistserialno`),auxhoistwll:t(`#editAssetAuxHoistWLL`,`auxhoistwll`),auxhoisthooksize:t(`#editAssetAuxHoistHookSize`,`auxhoisthooksize`),auxhoistropemm:t(`#editAssetAuxHoistRopeMM`,`auxhoistropemm`)}}window.refreshEditAssetDynamicFields=function(){let e=document.querySelector(`#editAssetEquipType`)?.value,t=g.find(t=>String(t.equiptypeid)===String(e)),n=String(t?.equipgroupid||``),r=document.querySelector(`#editDynamicAssetFields`),i=document.querySelector(`#editManufactureDateRow`),a=document.querySelector(`#editAssetManufactDate`);r&&(r.innerHTML=le(n,ue()),i&&(i.style.display=n===`400`?`flex`:`none`),a&&n!==`400`&&(a.value=``))},window.editAsset=function(e){if(!Y()){K();return}T();let t=s.find(t=>String(t.assetid)===String(e));if(!t){alert(`Asset not found`);return}let n=g.find(e=>String(e.equiptypeid)===String(t.equiptypeid)),r=String(n?.equipgroupid||``),i=le(r,t),a=r===`400`,o=[...g].sort((e,t)=>(e.description||``).localeCompare(t.description||``)).map(e=>`
      <option value="${e.equiptypeid}" ${String(e.equiptypeid)===String(t.equiptypeid)?`selected`:``}>
        ${e.description}
      </option>
    `).join(``);document.querySelector(`#page`).innerHTML=`
    <h2>Edit Asset ${t.assetid}</h2>

    <div class="filter-card">
      <div class="asset-form-grid">

        <div class="form-group">
          <label>Equipment Type</label>
          <select id="editAssetEquipType" onchange="refreshEditAssetDynamicFields()">
            <option value="">Select Equipment Type</option>
            ${o}
          </select>
        </div>

        <div class="form-group">
          <label>Serial No</label>
          <input id="editAssetSerialNo" type="text" value="${t.serialno||``}">
        </div>

        <div class="form-group">
          <label>Asset Tag Number <span class="optional-label">(Optional)</span></label>
          <input id="editAssetTagNo" type="text" value="${t.assettagno||``}" placeholder="Customer tag / plant number if available">
        </div>

        <div class="form-group">
          <label>Manufacturer</label>
          <input id="editAssetManufacturer" type="text" value="${t.manufacturer||``}">
        </div>

        <div class="form-group" id="editManufactureDateRow" style="${a?``:`display:none;`}">
          <label>Manufacture Date</label>
          <input id="editAssetManufactDate" type="date" value="${String(t.manufactdate||``).slice(0,10)}">
        </div>

        <div id="editDynamicAssetFields" class="dynamic-asset-fields">
          ${i}
        </div>

        <div class="form-group asset-description">
          <label>Description</label>
          <textarea id="editAssetDescription" rows="4">${t.description||``}</textarea>
        </div>

        <div class="asset-photo-row">
          <div class="form-group">
            <label>Replace Photo 1</label>
            <input id="assetPhoto1" type="file" accept="image/*">
          </div>

          <div class="form-group">
            <label>Replace Photo 2</label>
            <input id="assetPhoto2" type="file" accept="image/*">
          </div>
        </div>

        <div class="form-actions">
          <button onclick="saveAssetChanges(${t.assetid})">
            Save Changes
          </button>

          <button onclick="uploadAssetPhotos(${t.assetid})">
            Upload Photos
          </button>

          <button onclick="showAssetSetup()">
            Cancel
          </button>

          <button class="danger-btn" onclick="archiveAsset(${t.assetid})">
            Archive
          </button>
        </div>

      </div>
    </div>

    <div class="photo-preview-grid">
      ${t.media1?`
        <div class="photo-card">
          <h3>Photo 1</h3>
          <img src="${b}${t.media1}">
          <button
            type="button"
            class="danger-btn photo-delete-btn"
            onclick="deleteAssetPhoto(${t.assetid}, 1)"
          >
            Delete Photo 1
          </button>
        </div>
      `:``}

      ${t.media2?`
        <div class="photo-card">
          <h3>Photo 2</h3>
          <img src="${b}${t.media2}">
          <button
            type="button"
            class="danger-btn photo-delete-btn"
            onclick="deleteAssetPhoto(${t.assetid}, 2)"
          >
            Delete Photo 2
          </button>
        </div>
      `:``}
    </div>
  `},window.saveAssetChanges=async function(e){if(!Y()){alert(`You do not have permission to edit assets.`);return}let t=document.querySelector(`#editAssetEquipType`)?.value||null,n=document.querySelector(`#editAssetSerialNo`).value,r=document.querySelector(`#editAssetTagNo`)?.value||``,i=document.querySelector(`#editAssetManufacturer`).value,a=document.querySelector(`#editAssetManufactDate`)?.value||``,o=document.querySelector(`#editAssetDescription`).value,s=await fetch(`${b}/assets/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify({equiptypeid:t,serialno:n,assettagno:r,manufacturer:i,manufactdate:a,description:o,wll:document.querySelector(`#editAssetWLL`)?.value||null,heightoflift:document.querySelector(`#editAssetHeightOfLift`)?.value||null,numberofchainfalls:document.querySelector(`#editAssetNumberOfChainFalls`)?.value||null,oemtophooksize:document.querySelector(`#editAssetOEMTopHookSize`)?.value||null,oembottomhooksize:document.querySelector(`#editAssetOEMBottomHookSize`)?.value||null,loadchaindiameter:document.querySelector(`#editAssetLoadChainDiameter`)?.value||null,effectivelength:document.querySelector(`#editAssetEffectiveLength`)?.value||null,span:document.querySelector(`#editAssetSpan`)?.value||null,permissibledeflection:document.querySelector(`#editAssetPermissibleDeflection`)?.value||null,hooksize:document.querySelector(`#editAssetHookSize`)?.value||null,steelwireropemm:document.querySelector(`#editAssetSteelWireRopeMM`)?.value||null,hoistdescription:document.querySelector(`#editAssetHoistDescription`)?.value||null,hoistserialno:document.querySelector(`#editAssetHoistSerialNo`)?.value||null,auxhoistdescription:document.querySelector(`#editAssetAuxHoistDescription`)?.value||null,auxhoistserialno:document.querySelector(`#editAssetAuxHoistSerialNo`)?.value||null,auxhoistwll:document.querySelector(`#editAssetAuxHoistWLL`)?.value||null,auxhoisthooksize:document.querySelector(`#editAssetAuxHoistHookSize`)?.value||null,auxhoistropemm:document.querySelector(`#editAssetAuxHoistRopeMM`)?.value||null})}),c=await s.json();if(!s.ok){alert(`Error updating asset: `+c.error);return}alert(`Asset updated: `+c.assetid),await $(),showAssetSetup()},window.archiveAsset=async function(e){if(!Y()){alert(`You do not have permission to archive assets.`);return}if(!confirm(`Archive asset `+e+`? It will be hidden but its inspection history will remain.`))return;let t=await fetch(`${b}/assets/${e}/archive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(`Error archiving asset: `+n.error);return}alert(`Asset archived: `+n.assetid),await $(),showAssetSetup()},window.unarchiveAsset=async function(e){if(!Y()){alert(`You do not have permission to restore assets.`);return}if(!confirm(`Restore asset `+e+`?`))return;let t=await fetch(`${b}/assets/${e}/unarchive`,{method:`PUT`}),n=await t.json();if(!t.ok){alert(`Error restoring asset: `+n.error);return}alert(`Asset restored: `+n.assetid),await $(),showAssetSetup()},window.uploadAssetPhotos=async function(e){if(!Y()){alert(`You do not have permission to update asset photos.`);return}let t=document.querySelector(`#assetPhoto1`).files[0],n=document.querySelector(`#assetPhoto2`).files[0];if(!t&&!n){alert(`Please choose at least one photo`);return}if(!w([t,n]))return;let r=new FormData;t&&r.append(`photo1`,t),n&&r.append(`photo2`,n);let i=await fetch(`${b}/assets/${e}/photos`,{method:`POST`,body:r}),a=await W(i);if(!i.ok){alert(`Error uploading photos: `+a.error);return}alert(`Photos uploaded for asset `+a.assetid),await $(),editAsset(e)},window.deleteAssetPhoto=async function(e,t){if(!Y()){alert(`You do not have permission to delete asset photos.`);return}if(!confirm(`Delete asset photo ${t}?`))return;let n=await fetch(`${b}/assets/${e}/photos/${t}`,{method:`DELETE`}),r=await W(n);if(!n.ok){alert(`Error deleting photo: `+r.error);return}alert(`Asset photo ${t} deleted successfully`),await $(),editAsset(e)},window.showEquipmentTypeCriteria=function(){q(`criteria`)&&(localStorage.setItem(`currentPage`,`criteria`),window.criteriaEquipmentFilter=window.criteriaEquipmentFilter||``,ne(g,v))},window.filterEquipmentCriteria=function(){window.criteriaEquipmentFilter=document.querySelector(`#criteriaEquipmentFilter`)?.value||``,window.criteriaCurrentPage=1,showEquipmentTypeCriteria()},window.setCriteriaRowsPerPage=function(e){window.criteriaRowsPerPage=Number(e)||25,window.criteriaCurrentPage=1,showEquipmentTypeCriteria()},window.goToCriteriaPage=function(e){window.criteriaCurrentPage=Math.max(1,Number(e)||1),showEquipmentTypeCriteria()};function D(e){return String(e??``).replace(/&/g,`&amp;`).replace(/"/g,`&quot;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`)}function de(e={}){let t=[...g].sort((e,t)=>(e.description||``).localeCompare(t.description||``)),n=e.equiptypeid||window.criteriaEquipmentFilter||t[0]?.equiptypeid||``,r=e.inspectioncategory||`VISUAL`,i=e.fieldtype||`PASS_FAIL`,a=e.resulttype||(i===`NUMBER`?`MEASURED`:`PASS_FAIL`),o=e.inspection_category||`PERIODIC_THOROUGH_INSPECTION`,s=e.severity||`MINOR`;document.querySelector(`#criteriaPopup`)?.remove(),document.body.insertAdjacentHTML(`beforeend`,`
    <div
      id="criteriaPopup"
      class="criteria-modal-overlay"
      onclick="closeCriteriaPopupOnBackdrop(event)"
    >
      <div class="criteria-modal" role="dialog" aria-modal="true" aria-labelledby="criteriaPopupTitle">
        <div class="criteria-modal-header">
          <h2 id="criteriaPopupTitle">
            ${e.criteriaid?`Edit Criteria`:`Add Criteria`}
          </h2>

          <button type="button" onclick="cancelCriteriaEdit()">
            Close
          </button>
        </div>

        <div class="criteria-modal-body">
          <input id="editingCriteriaId" type="hidden" value="${e.criteriaid||``}">

          <div class="form-row">
            <div class="form-group">
              <label>Equipment Type</label>
              <select id="criteriaEquipType">
                ${t.map(e=>`
                  <option
                    value="${e.equiptypeid}"
                    ${String(e.equiptypeid)===String(n)?`selected`:``}
                  >
                    ${e.description}
                  </option>
                `).join(``)}
              </select>
            </div>

            <div class="form-group">
              <label>Inspection Type</label>
              <select id="criteriaCategory">
                <option value="VISUAL" ${r===`VISUAL`?`selected`:``}>
                  Visual Inspection
                </option>
                <option value="LOADTEST" ${r===`LOADTEST`?`selected`:``}>
                  Load Test
                </option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group form-group-wide">
              <label>Criteria Name</label>
              <input id="criteriaName" type="text" value="${D(e.criteriadescription||e.criterianame)}">
            </div>

            <div class="form-group">
              <label>Field Type</label>
              <select id="criteriaFieldType">
                <option value="PASS_FAIL" ${i===`PASS_FAIL`||i===`PASSFAIL`?`selected`:``}>Pass / Fail / N/A</option>
                <option value="TEXT" ${i===`TEXT`?`selected`:``}>Text Input</option>
                <option value="NUMBER" ${i===`NUMBER`?`selected`:``}>Number Input</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Result Type</label>
              <select id="criteriaResultType">
                <option value="PASS_FAIL" ${a===`PASS_FAIL`?`selected`:``}>PASS / FAIL</option>
                <option value="MEASURED" ${a===`MEASURED`?`selected`:``}>Measured</option>
                <option value="YES_NO" ${a===`YES_NO`?`selected`:``}>YES / NO</option>
              </select>
            </div>

            <div class="form-group">
              <label>Inspection Category</label>
              <select id="criteriaInspectionGroup">
                <option value="FREQUENT_INSPECTION" ${o===`FREQUENT_INSPECTION`?`selected`:``}>
                  Frequent Inspection
                </option>
                <option value="PERIODIC_THOROUGH_INSPECTION" ${o===`PERIODIC_THOROUGH_INSPECTION`?`selected`:``}>
                  Periodic Thorough Inspection
                </option>
              </select>
            </div>

            <div class="form-group">
              <label>Severity</label>
              <select id="criteriaSeverity">
                <option value="CRITICAL" ${s===`CRITICAL`?`selected`:``}>Critical</option>
                <option value="MAJOR" ${s===`MAJOR`?`selected`:``}>Major</option>
                <option value="MINOR" ${s===`MINOR`?`selected`:``}>Minor</option>
                <option value="OBSERVATION" ${s===`OBSERVATION`?`selected`:``}>Observation</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Display Order</label>
              <input id="criteriaDisplayOrder" type="number" min="1" value="${D(e.displayorder||e.sortorder||1)}">
            </div>

            <div class="form-group">
              <label>Active</label>
              <select id="criteriaActive">
                <option value="true" ${e.active===!1?``:`selected`}>Active</option>
                <option value="false" ${e.active===!1?`selected`:``}>Inactive</option>
              </select>
            </div>
          </div>
        </div>

        <div class="criteria-modal-footer">
          <button type="button" onclick="cancelCriteriaEdit()">
            Cancel
          </button>

          <button type="button" onclick="saveCriteria()">
            Save Criteria
          </button>
        </div>
      </div>
    </div>
  `),document.querySelector(`#criteriaName`)?.focus()}window.openCriteriaPopup=function(){de()},window.closeCriteriaPopupOnBackdrop=function(e){e.target.id===`criteriaPopup`&&cancelCriteriaEdit()},window.saveCriteria=async function(){let e=document.querySelector(`#editingCriteriaId`)?.value||``,t=document.querySelector(`#criteriaEquipType`).value,n=document.querySelector(`#criteriaCategory`).value,r=document.querySelector(`#criteriaName`).value;if(!r){alert(`Please enter a criteria name`);return}let i={equiptypeid:t,criterianame:r,criteriadescription:r,fieldtype:document.querySelector(`#criteriaFieldType`).value,resulttype:document.querySelector(`#criteriaResultType`).value,required:!0,sortorder:Number(document.querySelector(`#criteriaDisplayOrder`)?.value||1),displayorder:Number(document.querySelector(`#criteriaDisplayOrder`)?.value||1),inspectioncategory:n,inspection_category:document.querySelector(`#criteriaInspectionGroup`).value,severity:document.querySelector(`#criteriaSeverity`).value,active:document.querySelector(`#criteriaActive`).value===`true`},a=await fetch(e?`${b}/equipment-type-criteria/${e}`:`${b}/equipment-type-criteria`,{method:e?`PUT`:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(i)}),o=await a.json();if(!a.ok){alert(`Error saving criteria: `+o.error);return}alert(e?`Criteria updated`:`Criteria saved`),await $(),cancelCriteriaEdit(),showEquipmentTypeCriteria()},window.editCriteria=function(e){let t=v.find(t=>String(t.criteriaid)===String(e));if(!t){alert(`Criteria not found`);return}de(t)},window.cancelCriteriaEdit=function(){document.querySelector(`#criteriaPopup`)?.remove()},window.deleteCriteria=async function(e){let t=v.find(t=>String(t.criteriaid)===String(e));if(!t){alert(`Criteria not found`);return}if(!confirm(`Delete this criteria?\n\n${t.criterianame}\n\nThis removes it from future inspection/load test forms.`))return;let n=await fetch(`${b}/equipment-type-criteria/${e}`,{method:`DELETE`}),r=await n.json();if(!n.ok){alert(`Error deleting criteria: `+r.error);return}alert(`Criteria deleted`),await $(),showEquipmentTypeCriteria()},window.showInspections=function(){q(`inspections`)&&(localStorage.setItem(`currentPage`,`inspections`),te(s))},window.showCertificateSearch=function(){q(`certificates`)&&(localStorage.setItem(`currentPage`,`certificates`),ie(o,f,h))},window.showCustomerDetailedReport=function(){q(`customer-report`)&&(localStorage.setItem(`currentPage`,`customer-report`),Te(o,g))},window.handleCertificateEnter=function(e){e.key===`Enter`&&searchCertificates()},window.filterCertificateSites=function(){let e=document.querySelector(`#certClient`).value,t=document.querySelector(`#certSite`),n=document.querySelector(`#certSection`);n.innerHTML=`<option value="">All Sections</option>`,t.innerHTML=`
    <option value="">All Sites</option>
    ${(e?f.filter(t=>String(t.clientid)===String(e)):f).map(e=>`
      <option value="${e.siteid}">
        ${e.sitename}
      </option>
    `).join(``)}
  `},window.filterCertificateSections=function(){let e=document.querySelector(`#certSite`).value,t=document.querySelector(`#certSection`);t.innerHTML=`
    <option value="">All Sections</option>
    ${(e?h.filter(t=>String(t.siteid)===String(e)):h).map(e=>`
      <option value="${e.sectionid}">
        ${e.sectionname}
      </option>
    `).join(``)}
  `},window.clearCertificateSearch=function(){document.querySelector(`#certSearch`).value=``,document.querySelector(`#certInspectionType`).value=``,document.querySelector(`#certStatus`).value=``,document.querySelector(`#certClient`).value=``,document.querySelector(`#certSite`).innerHTML=`<option value="">All Sites</option>`,document.querySelector(`#certSection`).innerHTML=`<option value="">All Sections</option>`,document.querySelector(`#certDateFrom`).value=``,document.querySelector(`#certDateTo`).value=``,window.certCurrentPage=1,searchCertificates()},window.searchCertificates=async function(e=!0){e&&(window.certCurrentPage=1);let t=new URLSearchParams;t.append(`search`,document.querySelector(`#certSearch`)?.value||``),t.append(`inspectiontype`,document.querySelector(`#certInspectionType`)?.value||``),t.append(`status`,document.querySelector(`#certStatus`)?.value||``),t.append(`clientid`,document.querySelector(`#certClient`)?.value||``),t.append(`siteid`,document.querySelector(`#certSite`)?.value||``),t.append(`sectionid`,document.querySelector(`#certSection`)?.value||``),t.append(`datefrom`,document.querySelector(`#certDateFrom`)?.value||``),t.append(`dateto`,document.querySelector(`#certDateTo`)?.value||``);let n=await fetch(`${b}/certificates/search?${t.toString()}`),r=await n.json();if(!n.ok){alert(`Error searching certificates: `+r.error);return}let i=r.filter(e=>e.status===`SAFE`).length,a=r.filter(e=>e.status===`NOT SAFE`).length,o=r.filter(e=>e.inspectiontype===`LOADTEST`).length,s=r.filter(e=>e.inspectiontype===`VISUAL`).length;if(document.querySelector(`#certificateStats`).innerHTML=`
    <p><strong>Total:</strong> ${r.length}</p>
    <p><strong>Safe:</strong> ${i}</p>
    <p><strong>Not Safe:</strong> ${a}</p>
    <p><strong>Visual:</strong> ${s}</p>
    <p><strong>Load Tests:</strong> ${o}</p>
  `,r.length===0){document.querySelector(`#certificateResults`).innerHTML=`
      <p>No certificates found.</p>
    `;return}window.currentCertificateResults=r,k(r)};function O(t,n){let r=e(`certificates`,`testid`),i=r.key===n,a=i?r.direction===`desc`?`v`:`^`:`^v`;return`
    <span class="certificate-sort-heading">
      <span>${t}</span>
      <button
        type="button"
        class="certificate-sort-btn ${i?`active`:``}"
        onclick="sortTable('certificates', '${n}', 'rerenderCertificateResults')"
        aria-label="Sort ${t}"
        title="Sort ${t}"
      >${a}</button>
    </span>
  `}window.rerenderCertificateResults=function(){k(window.currentCertificateResults||[])};function k(e){let n=i(t(e,`certificates`,{testid:e=>e.testid,tagnumber:e=>e.tagnumber,clientname:e=>e.clientname,sitename:e=>e.sitename,description:e=>e.description,serialno:e=>e.serialno,inspectiontype:e=>e.inspectiontype,testdate:e=>e.testdate,status:e=>e.status,inspector:e=>e.inspector},`testid`),`certCurrentPage`,`certRowsPerPage`);document.querySelector(`#certificateResults`).innerHTML=`
    ${a({...n,label:`certificates`,onPage:`goToCertificatePage`,onPageSize:`setCertificateRowsPerPage`})}

    <table>
      <thead>
        <tr>
          <th>${O(`Test ID`,`testid`)}</th>
          <th>${O(`Tag No`,`tagnumber`)}</th>
          <th>${O(`Client`,`clientname`)}</th>
          <th>${O(`Site`,`sitename`)}</th>
          <th>${O(`Asset`,`description`)}</th>
          <th>${O(`Serial No`,`serialno`)}</th>
          <th>${O(`Type`,`inspectiontype`)}</th>
          <th>${O(`Date`,`testdate`)}</th>
          <th>${O(`Status`,`status`)}</th>
          <th>${O(`Inspector`,`inspector`)}</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody>
        ${n.rows.map(e=>`
          <tr>
            <td>${e.testid}</td>
            <td>${e.tagnumber||`-`}</td>
            <td>${e.clientname||``}</td>
            <td>${e.sitename||``}</td>
            <td>${e.description||``}</td>
            <td>${e.serialno||``}</td>
            <td>${e.inspectiontype||``}</td>
            <td>${e.testdate?e.testdate.split(`T`)[0]:``}</td>
            <td>
              <strong class="${e.status===`SAFE`?`status-safe`:`status-unsafe`}">
                ${e.status||``}
              </strong>
            </td>
            <td>${e.inspector||`-`}</td>
            <td>
              <button onclick="previewCertificate(${e.testid})">Preview</button>
              <button onclick="openCertificateModal(${e.testid})">View</button>
              <a
                class="cert-action-link"
                href="${b}/inspections/${e.testid}/certificate.pdf"
                download="certificate-${e.testid}.pdf"
              >
                Download PDF
              </a>
              <button onclick="mailCertificate(${e.testid})">Mail</button>
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `}window.setCertificateRowsPerPage=function(e){window.certRowsPerPage=Number(e)||25,window.certCurrentPage=1,k(window.currentCertificateResults||[])},window.goToCertificatePage=function(e){window.certCurrentPage=Math.max(1,Number(e)||1),k(window.currentCertificateResults||[])},window.openCertificateFromSearch=function(){let e=document.querySelector(`#certificateSearch`).value.trim();if(!e){alert(`Enter a certificate number`);return}openCertificateModal(e)},window.showQuickInspection=function(){q(`quick-inspection`)&&(localStorage.setItem(`currentPage`,`quick-inspection`),re())},window.handleQuickInspectionEnter=function(e){e.key===`Enter`&&quickFindAsset()},window.quickFindAsset=async function(){let e=document.querySelector(`#quickAssetSearch`).value.toLowerCase().trim(),t=document.querySelector(`#quickInspectionResult`);if(!e){t.innerHTML=`
      <p>Please scan or enter an asset number.</p>
    `;return}let n=s.filter(t=>String(t.assetid||``).toLowerCase().includes(e)||(t.assettagno||``).toLowerCase().includes(e)||(t.serialno||``).toLowerCase().includes(e)||(t.hoistserialno||``).toLowerCase().includes(e)||(t.qrcode||``).toLowerCase().includes(e));if(n.length===0){try{let t=await fetch(`${b}/assets/qr/${encodeURIComponent(e)}`);if(t.ok){let e=await t.json();quickOpenAsset(e.assetid);return}}catch(e){console.error(`QR lookup failed:`,e)}t.innerHTML=`
      <div class="filter-card">
        <h3>No Asset Found</h3>
        <p>No asset matched: <strong>${e}</strong></p>
      </div>
    `;return}if(n.length>1){t.innerHTML=`
      <div class="filter-card">
        <h3>Multiple Assets Found</h3>
        <p>Please select the correct asset.</p>

        <table>
          <thead>
            <tr>
              <th>Asset ID</th>
              <th>Asset Tag</th>
              <th>Serial No</th>
              <th>Description</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            ${n.map(e=>`
              <tr>
                <td>${e.assetid}</td>
                <td>${e.assettagno||``}</td>
                <td>${e.serialno||``}</td>
                <td>${e.description||``}</td>
                <td>
                  <button onclick="quickOpenAsset(${e.assetid})">
                    Select
                  </button>
                </td>
              </tr>
            `).join(``)}
          </tbody>
        </table>
      </div>
    `;return}quickOpenAsset(n[0].assetid)},window.quickOpenAsset=async function(e){let t=document.querySelector(`#quickInspectionResult`)||document.querySelector(`#dashboardAssetSearchResult`);if(!t){alert(`No asset result panel found`);return}let n=(t.id,`quick`),r=await fetch(`${b}/assets/${e}/quick-details`),i=await r.json();if(!r.ok){alert(`Asset details not found: `+i.error);return}t.innerHTML=`
    <div class="filter-card">
      <h3>Asset Found</h3>

      <div class="quick-asset-grid">

        <div>
          <p><strong>Asset ID:</strong> ${i.assetid}</p>
          <p><strong>Asset Tag:</strong> ${i.assettagno||``}</p>
          <p><strong>Serial No:</strong> ${i.serialno||``}</p>
          <p><strong>Description:</strong> ${i.description||``}</p>
          <p><strong>Equipment Type:</strong> ${i.equipmenttype||``}</p>
          <p><strong>Client:</strong> ${i.clientname||``}</p>
          <p><strong>Site:</strong> ${i.sitename||``}</p>
          <p><strong>Section:</strong> ${i.sectionname||``}</p>
        </div>

        <div>
          <h4>Inspection History</h4>

          <p>
            <strong>Last Visual:</strong>
      ${i.lastvisualdate?i.lastvisualdate.split(`T`)[0]:`No record`}
            -
            ${i.lastvisualstatus||``}
          </p>

          <p>
            <strong>Last Load Test:</strong>
    ${i.lastloadtestdate?i.lastloadtestdate.split(`T`)[0]:`No record`}          
            -
            ${i.lastloadteststatus||``}
          </p>
        </div>

      </div>

      <div class="quick-photo-grid">
        ${i.media1?`
          <div class="quick-photo-card">
            <h4>Photo 1</h4>
            <img src="${b}${i.media1}">
          </div>
        `:``}

        ${i.media2?`
          <div class="quick-photo-card">
            <h4>Photo 2</h4>
            <img src="${b}${i.media2}">
          </div>
        `:``}
      </div>

      <div class="form-actions">
<button onclick="startInspection(${i.assetid}, 'VISUAL', '${n}')">Visual Inspection
        </button>

<button class="load-test-btn" onclick="startInspection(${i.assetid}, 'LOADTEST', '${n}')">Load Test
        </button>

<button onclick="openAssetQrLabel(${i.assetid})">QR Label
        </button>

      </div>
    </div>
  `},window.startQuickInspection=function(e,t){startInspection(e,t,`quick`)},window.filterInspectionAssets=function(e=!1){e&&(window.inspectionCurrentPage=1);let t=document.querySelector(`#inspectionSearchType`)?.value||`all`,n=document.querySelector(`#inspectionAssetSearch`).value.toLowerCase().trim(),r=[`assetid`,`assettagno`,`serialno`,`clientname`,`sitename`,`sectionname`,`equipmenttype`,`description`,`qrcode`],o=i([...s.filter(e=>t===`all`?r.some(t=>String(e[t]||``).toLowerCase().includes(n)):String(e[t]||``).toLowerCase().includes(n))].reverse(),`inspectionCurrentPage`,`inspectionRowsPerPage`),c=document.querySelector(`.report-pagination-bar`);c&&(c.outerHTML=a({...o,label:`assets`,onPage:`goToInspectionPage`,onPageSize:`setInspectionRowsPerPage`}));let l=document.querySelector(`#inspectionAssetTableBody`);l.innerHTML=o.rows.map(e=>`
    <tr>
      <td>${e.assetid}</td>
      <td>${e.assettagno||``}</td>
      <td>${e.serialno||``}</td>
      <td>${e.clientname||``}</td>
      <td>${e.sitename||``}</td>
      <td>${e.sectionname||``}</td>
      <td>${e.description||``}</td>
      <td>${e.equipmenttype||``}</td>
      <td>
        <div class="action-buttons">

          <button onclick="startInspection(${e.assetid}, 'VISUAL', 'inspections')">
            New Inspection
          </button>

          ${Se(e)?`
              <button
                class="load-test-btn"
                onclick="startInspection(${e.assetid}, 'LOADTEST', 'inspections')"
              >
                Load Test
              </button>
            `:``}

        </div>
      </td>
    </tr>
  `).join(``)},window.setInspectionFilterKey=function(e){let t=document.querySelector(`#inspectionSearchType`);t&&(t.value=e,filterInspectionAssets(!0))},window.setInspectionRowsPerPage=function(e){window.inspectionRowsPerPage=Number(e)||25,window.inspectionCurrentPage=1,filterInspectionAssets()},window.goToInspectionPage=function(e){window.inspectionCurrentPage=Math.max(1,Number(e)||1),filterInspectionAssets()};function fe(e){return e!=null&&String(e).trim()!==``&&String(e).trim()!==`-`}function A(e,t,n=``){return fe(t)?`<div><span>${e}</span><strong>${t}${n?` ${n}`:``}</strong></div>`:``}let pe={"Top Hook Dimensions":`oemtophooksize`,"Bottom Hook Dimensions":`oembottomhooksize`,"Load Chain Diameter":`loadchaindiameter`,"Hook Size mm":`hooksize`,"Hoist Serial Number":`hoistserialno`,"WLL Main Hoist - Load Mass kg":`wll`,"WLL Auxiliary Hoist - Load Mass kg":`auxhoistwll`,"SWL of Beam - Load Mass kg":`wll`,"SWL Installed Hoist - Load Mass kg":`wll`,"SWL of Beam - Length Span mm":`span`,"WLL Main Hoist - Length Span/Jib mm":`span`,"WLL Auxiliary Hoist - Length Span/Jib mm":`span`,"Permissible Deflection mm":`permissibledeflection`,"WLL Main Hoist - Deflection mm":`permissibledeflection`,"WLL Auxiliary Hoist - Deflection mm":`permissibledeflection`,"Steel Wire Rope mm":`steelwireropemm`};function j(e=``){return String(e).toLowerCase().replace(/\s+/g,` `).trim()}function me(e){let t=Number(e);return Number.isFinite(t)?String(Number.isInteger(t)?t:Number(t.toFixed(2))):``}function M(e=new Date){let t=new Date(e);return t.setMinutes(t.getMinutes()-t.getTimezoneOffset()),t.toISOString().split(`T`)[0]}function he(e,t=`VISUAL`){let n=e?new Date(`${e}T00:00:00`):new Date,r=new Date(n);return t===`LOADTEST`?r.setFullYear(r.getFullYear()+1):r.setMonth(r.getMonth()+3),M(r)}window.updateInspectionValidDateFromTestDate=function(e=`VISUAL`){let t=document.querySelector(`#inspectionTestDate`)?.value||``,n=document.querySelector(`#inspectionValidDate`);!n||!t||(n.value=he(t,e))};function N(e){return j([e?.criterianame,e?.criteriadescription].filter(Boolean).join(` `)).includes(`proof load`)}function ge(e){let t=j([e?.criterianame,e?.criteriadescription].filter(Boolean).join(` `));return t.includes(`hook measured size`)||t.includes(`measured hook throat opening`)}function _e(e){let t=Number(e?.wll);return Number.isFinite(t)&&t>0?me(t*1.1):``}function ve(e,t){let n=t?.criterianame||t?.criteriadescription||``,r=j(n),i=pe[n],a=r.includes(`auxiliary hoist`);return i?e?.[i]||``:N(t)||ge(t)?``:r.includes(`top hook`)?e?.oemtophooksize||e?.hooksize||``:r.includes(`bottom hook`)?e?.oembottomhooksize||e?.hooksize||``:r.includes(`load chain`)||r.includes(`chain diameter`)?e?.loadchaindiameter||``:r.includes(`load mass`)||r.includes(`swl installed hoist`)||r.includes(`swl of beam`)?a?e?.auxhoistwll||``:e?.wll||``:r.includes(`span`)||r.includes(`length span`)||r.includes(`span/jib`)?e?.span||``:r.includes(`deflection`)?e?.permissibledeflection||``:r.includes(`wire rope`)?a?e?.auxhoistropemm||``:e?.steelwireropemm||``:r.includes(`hook opening`)||r.includes(`hook size`)?a?e?.auxhoisthooksize||``:e?.hooksize||``:r.includes(`hoist serial`)?a?e?.auxhoistserialno||``:e?.hoistserialno||``:``}function ye(e,t,n){return N(t)?_e(e):ge(t)?e?.hooksize||``:n||``}let be=new Set([`WLL Main Hoist - Deflection mm`,`WLL Main Hoist - Length Span/Jib mm`,`WLL Auxiliary Hoist - Deflection mm`,`WLL Auxiliary Hoist - Length Span/Jib mm`]);function xe(e){return[`WLL Main Hoist - Load Mass kg`,`WLL Auxiliary Hoist - Load Mass kg`,`SWL of Beam - Load Mass kg`,`SWL Installed Hoist - Load Mass kg`,`Hoist Proof Load Test kg`].includes(e)}function Se(e){return[`100`,`400`,`500`].includes(String(e?.equipgroupid||``))?!0:(window.atecCriteria||[]).some(t=>String(t.equiptypeid)===String(e?.equiptypeid)&&String(t.inspectioncategory||t.inspection_category||``).toUpperCase()===`LOADTEST`&&t.active!==!1&&t.active!==`false`)}function P(e,t,n){if(n!==`LOADTEST`||!j(e?.equipmenttype||``).includes(`crawl beam`))return!1;let r=j([t?.criterianame,t?.criteriadescription].filter(Boolean).join(` `));return r.includes(`serial number`)&&r.includes(`hoist`)&&(r.includes(`trolley`)||r.includes(`beam`))}function Ce(e){let t=(e.criterianame||``).toLowerCase();return e.fieldtype===`TEXT`||t.includes(`defects and recommendations`)}function we(e){if(String(e.fieldtype||``).toUpperCase()!==`TEXT`)return!1;let t=[e.criterianame,e.criteriadescription].filter(Boolean).join(` `).toLowerCase().trim();return t.includes(`any defects noted`)||t.includes(`comments`)||t.includes(`remarks`)}function F(e,t=``){let n=String(t??``);return n.trim()?n:we(e)?`None`:``}function I(e){return(e.criterianame||``).toLowerCase()===`safe for service`}function L(e){return j([e?.criterianame,e?.criteriadescription].filter(Boolean).join(` `)).includes(`hook wear does not exceed allowable limits`)}function Ee(e,t){return e.filter(e=>t!==`LOADTEST`||!be.has(e.criterianame)).filter(e=>!L(e)).sort((e,t)=>I(e)?1:I(t)?-1:0)}function R(e=`quick`){if(e===`quick`){showQuickInspection();return}if(e===`assets`){showAssetSetup();return}showInspections()}window.returnToInspectionOrigin=R;function De(e){let t=(e||``).toLowerCase();return t.includes(`diameter`)?{assetLabel:`Standard Diameter (mm)`,measuredLabel:`Measured Diameter (mm)`}:t.includes(`dimension`)||t.includes(`hook`)?{assetLabel:`Standard Dimension`,measuredLabel:`Measured Dimension`}:t.includes(`length`)||t.includes(`span`)?{assetLabel:`Standard Length (mm)`,measuredLabel:`Measured Length (mm)`}:t.includes(`deflection`)?{assetLabel:`Permissible Deflection (mm)`,measuredLabel:`Measured Deflection (mm)`}:t.includes(`rope`)?{assetLabel:`Standard Rope Diameter (mm)`,measuredLabel:`Measured Rope Diameter (mm)`}:t.includes(`wll`)||t.includes(`load mass`)?{assetLabel:`Rated Load (kg)`,measuredLabel:`Test Load / Measured Load (kg)`}:{assetLabel:`Standard Value`,measuredLabel:`Measured Value`}}window.toggleFailRemark=function(e){let t=document.querySelector(`#result-${e}`)?.value,n=document.querySelector(`#fail-remarks-${e}`);n&&(n.style.display=t===`FAIL`||t===`NO`?`block`:`none`)};function z(e){let t=String(e?.criteriadescription||e?.criterianame||``).trim().toUpperCase();return t===`SAFE FOR CONTINUED OPERATION`||t===`SAFE FOR SERVICE`}function Oe(e){return String(e?.severity||``).toUpperCase()===`CRITICAL`}window.updateInspectionSafetyWarning=function(){let e=window.currentInspectionCriteria||[],t=e.filter(e=>{let t=document.querySelector(`#result-${e.criteriaid}`)?.value;return Oe(e)&&!z(e)&&[`FAIL`,`NO`].includes(t)}),n=document.querySelector(`#inspectionCriticalWarning`),r=e.find(z);if(r&&t.length){let e=document.querySelector(`#result-${r.criteriaid}`);e&&(e.value=e.querySelector(`option[value="NO"]`)?`NO`:`FAIL`,e.disabled=!0,toggleFailRemark(r.criteriaid))}if(r&&t.length===0){let e=document.querySelector(`#result-${r.criteriaid}`);e&&(e.disabled=!1)}n&&(n.style.display=t.length?`block`:`none`,n.innerHTML=t.length?`<strong>NOT SAFE rule applied:</strong> ${t.length} critical item failed. SAFE FOR CONTINUED OPERATION is forced to NO and the certificate will be NOT SAFE.`:``)},window.pendingInspectionPhotos=[];function B(e=`GENERAL`){return[`GENERAL`,`DEFECT`,`REPAIR`,`LOAD_TEST`,`NAMEPLATE`,`HOOK`,`WIRE_ROPE`,`STRUCTURE`,`ELECTRICAL`].map(t=>`
    <option value="${t}" ${e===t?`selected`:``}>
      ${t.replaceAll(`_`,` `)}
    </option>
  `).join(``)}window.handleInspectionPhotoSelection=function(e){Array.from(e.target.files||[]).forEach(e=>{window.pendingInspectionPhotos.push({id:`${Date.now()}-${Math.random()}`,file:e,caption:``,photoType:`GENERAL`,previewUrl:URL.createObjectURL(e)})}),e.target.value=``,ke()},window.updateInspectionPhotoMeta=function(e,t,n){let r=window.pendingInspectionPhotos.find(t=>t.id===e);r&&(r[t]=n)},window.removeInspectionPhoto=function(e){let t=window.pendingInspectionPhotos.find(t=>t.id===e);t?.previewUrl&&URL.revokeObjectURL(t.previewUrl),window.pendingInspectionPhotos=window.pendingInspectionPhotos.filter(t=>t.id!==e),ke()};function ke(){let e=document.querySelector(`#inspectionPhotoPreview`);if(e){if(!window.pendingInspectionPhotos.length){e.innerHTML=`<p class="muted-text">No inspection photos selected.</p>`;return}e.innerHTML=window.pendingInspectionPhotos.map(e=>`
    <div class="inspection-photo-preview-card">
      <img src="${e.previewUrl}" alt="Inspection photo preview">
      <div class="inspection-photo-preview-fields">
        <label>
          Photo Type
          <select onchange="updateInspectionPhotoMeta('${e.id}', 'photoType', this.value)">
            ${B(e.photoType)}
          </select>
        </label>
        <label>
          Caption
          <input
            type="text"
            value="${D(e.caption)}"
            placeholder="Optional caption"
            oninput="updateInspectionPhotoMeta('${e.id}', 'caption', this.value)"
          >
        </label>
        <button type="button" class="secondary-btn" onclick="removeInspectionPhoto('${e.id}')">
          Remove
        </button>
      </div>
    </div>
  `).join(``)}}window.startInspection=async function(e,t=`VISUAL`,n=`quick`){if(!Ke()){alert(`You do not have permission to create inspections or load tests.`);return}n===`assets`&&T();let r=s.find(t=>String(t.assetid)===String(e)),i=await fetch(`${b}/assets/${e}/quick-details`),a=M(),o=he(a,t),c=await i.json();if(!r){alert(`Asset not found`);return}window.scrollTo(0,0),window.pendingInspectionPhotos=[];let l=Ee(v.filter(e=>String(e.equiptypeid)===String(r.equiptypeid)&&String(e.inspectioncategory)===String(t)&&e.active!==!1),t);l=l.filter(e=>!P(r,e,t));let u=l.filter(e=>e.fieldtype===`NUMBER`),d=l.filter(e=>e.fieldtype!==`NUMBER`);window.currentInspectionCriteria=l,document.querySelector(`#page`).innerHTML=`
    <h2>${t} - Asset ${r.assetid}</h2>

    <div class="filter-card">
      <div class="inspection-asset-summary">
        <div class="inspection-asset-title">
          <strong>${r.description||``}</strong>
          <span>Asset ${r.assetid}</span>
        </div>

        <div class="inspection-asset-details">
          <div><span>Serial No</span><strong>${r.serialno||`-`}</strong></div>
          <div><span>Equipment Type</span><strong>${r.equipmenttype||`-`}</strong></div>
          <div><span>WLL</span><strong>${r.wll||`-`} kg</strong></div>
          ${A(`Span/Jib`,r.span,`mm`)}
          ${A(`Permissible Deflection`,r.permissibledeflection,`mm`)}
        </div>

        <div class="inspection-asset-actions">
          <button onclick="passAllCriteria(${r.assetid}, '${t}', '${n}')">
            Pass All & Save
          </button>

          <button onclick="returnToInspectionOrigin('${n}')">
            Cancel
          </button>
        </div>
      </div>
    </div>

    <div class="quick-photo-grid">

  ${r.media1?`
    <div class="quick-photo-card">
      <img src="${b}${r.media1}">
    </div>
  `:``}

  ${r.media2?`
    <div class="quick-photo-card">
      <img src="${b}${r.media2}">
    </div>
  `:``}

</div>

<div class="filter-card">

  <h3>Inspection Photos</h3>

  <input
    id="inspectionPhotoFiles"
    type="file"
    accept="image/*"
    multiple
    onchange="handleInspectionPhotoSelection(event)"
  >

  <div id="inspectionPhotoPreview" class="inspection-photo-preview-grid">
    <p class="muted-text">No inspection photos selected.</p>
  </div>

</div>

<div id="inspectionCriticalWarning" class="inspection-critical-warning" style="display:none;"></div>

<div class="inspection-tag-card">

  <div class="inspection-tag-title">
    INSPECTION DETAILS
  </div>

  <div class="inspector-identity-card">
    <div>
      <span>Logged-in Inspector</span>
      <strong>${G?.full_name||`-`}</strong>
    </div>
    <div>
      <span>LMI Number</span>
      <strong>${G?.lmi_number||`-`}</strong>
    </div>
  </div>

  <div class="form-row">

    <div class="form-group">
      <label>${t===`LOADTEST`?`Load Test Date`:`Inspection Date`}</label>
      <input
        id="inspectionTestDate"
        type="date"
        value="${a}"
        onchange="updateInspectionValidDateFromTestDate('${t}')"
      >
    </div>

    <div class="form-group">
      <label>Inspection Tag No</label>
      <input
        id="inspectionTagNo"
        class="inspection-tag-input"
        type="text"
        placeholder="ENTER TAG NUMBER"
      >
    </div>

    <div class="form-group">
      <label>Certificate Expiry Date</label>
      <input
        id="inspectionValidDate"
        type="date"
        value="${o}"
      >
    </div>

  </div>

</div>
      <div class="inspection-history-card">

        <div class="inspection-history-title">
          LAST INSPECTION
        </div>

        <div class="inspection-history-grid">

          <div>
            <strong>Date:</strong><br>
            ${c.lastinspectiondate||`Never Inspected`}
          </div>

          <div>
            <strong>Tag Number:</strong><br>
            ${c.lastinspectiontag||`-`}
          </div>

          <div>
            <strong>Type:</strong><br>
            ${c.lastinspectiontype||`-`}
          </div>

          <div>
            <strong>Status:</strong><br>
           <span class="${c.lastinspectionstatus===`SAFE`?`status-safe`:`status-unsafe`}">
              ${c.lastinspectionstatus||`-`}
            </span>
          </div>

          <div>
            <strong>Inspector:</strong><br>
            ${c.lastinspector||`-`}
          </div>

        </div>

      </div>

<div class="inspection-list">
<div class="inspection-list">

${u.length?`
    <div class="inspection-section-title">
        Measurements
    </div>

    <div class="inspection-header measurements ${t===`LOADTEST`?`loadtest-measurements`:``}">

        <div>Criteria</div>
        <div>Standard Dimension</div>
        <div>Measured Dimension</div>
        ${t===`LOADTEST`?`<div>Comments / Remarks</div>`:``}

    </div>

    

  ${u.map(e=>{let n=ve(r,e),i=ye(r,e,n);return De(e.criterianame),`
      <div class="inspection-row compact-row ${t===`LOADTEST`?`loadtest-measurement-row`:``}">

        <div class="inspection-criteria">
          ${e.criterianame}
        </div>

<div class="comparison-grid">

    ${n?`
      <input
          type="text"
          value="${n}"
          readonly
          class="readonly-value"
      >
    `:`
      <div class="readonly-value readonly-value-empty"></div>
    `}

    <input
        id="measured-${e.criteriaid}"
        type="text"
        value="${i}"
    >

</div>
        ${t===`LOADTEST`&&xe(e.criterianame)?`
          <div class="inspection-remarks">
            <input
              id="remarks-${e.criteriaid}"
              type="text"
              placeholder="Comments / Remarks"
            >
          </div>
        `:t===`LOADTEST`?`<div></div>`:``}
      </div>
    `}).join(``)}
`:``}

<div class="inspection-section-title">
    Visual Inspection
</div>

<div class="inspection-header visual">

    <div>Criteria</div>
    <div>Result</div>
    <div>Reason for FAIL (required)</div>

</div>

  ${d.map(e=>Ce(e)?`
    <div class="inspection-row compact-row">

      <div class="inspection-criteria">
        ${e.criteriadescription||e.criterianame}
        ${e.severity?`<span class="inspection-criteria-badge ${String(e.severity).toLowerCase()}">${e.severity}</span>`:``}
      </div>

      <div class="inspection-result inspection-text-result">
        <textarea
          id="remarks-${e.criteriaid}"
          rows="3"
          placeholder="${e.criterianame}"
        >${D(F(e))}</textarea>
      </div>

    </div>
  `:`
    <div class="inspection-row compact-row">

      <div class="inspection-criteria">
        ${e.criteriadescription||e.criterianame}
        ${e.severity?`<span class="inspection-criteria-badge ${String(e.severity).toLowerCase()}">${e.severity}</span>`:``}
      </div>

      <div class="inspection-result">
        <select
          id="result-${e.criteriaid}"
          onchange="toggleFailRemark(${e.criteriaid}); updateInspectionSafetyWarning()"
        >
          ${e.resulttype===`YES_NO`||z(e)?`
                <option value="YES">YES</option>
                <option value="NO">NO</option>
                <option value="N/A">N/A</option>
              `:`
                <option value="PASS">PASS</option>
                <option value="FAIL">FAIL</option>
                <option value="N/A">N/A</option>
              `}
        </select>
      </div>

      <div
        class="inspection-remarks"
        id="fail-remarks-${e.criteriaid}"
        style="display:none;"
      >
        <input
          id="remarks-${e.criteriaid}"
          type="text"
          placeholder="Reason for FAIL"
        >
      </div>

    </div>
  `).join(``)}

</div>

    <div class="filter-card">
      <button type="button" onclick="window.saveInspection(${r.assetid}, '${t}', '${n}')">
        Save ${t}
      </button>

      <button onclick="returnToInspectionOrigin('${n}')">
        Cancel
      </button>
    </div>

        <div class="filter-card">

        <button onclick="showInspectionHistory(${r.assetid})">
          Show Inspection History
        </button>

        <div id="inspectionHistoryPanel"></div>

      </div>

  `},window.showInspectionHistory=async function(e){let t=await fetch(`${b}/assets/${e}/inspection-history`),n=await t.json();if(!t.ok){alert(`Error loading inspection history: `+n.error);return}let r=n.map(e=>`
    <tr>
      <td>${e.testdate||``}</td>
      <td>${e.inspectiontype||``}</td>
      <td><strong>${e.tagnumber||`-`}</strong></td>
      <td>${e.status||``}</td>
      <td>${e.inspector||`-`}</td>
      <td>
          <button onclick="openCertificateModal(${e.testid})">
            View Certificate
          </button>
      </td>
    </tr>
  `).join(``);document.querySelector(`#inspectionHistoryPanel`).innerHTML=`
    <h3>Inspection History</h3>

    <table>
      <thead>
        <tr>
          <th>Date</th>
          <th>Type</th>
          <th>Tag No</th>
          <th>Status</th>
          <th>Inspector</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ${r||`
          <tr>
            <td colspan="5">No inspection history found</td>
          </tr>
        `}
      </tbody>
    </table>
  `},window.showAssetHistoryFromSetup=async function(e){T();let t=await fetch(`${b}/assets/${e}/inspection-history`),n=await t.json();if(!t.ok){alert(`Error loading inspection history: `+n.error);return}document.querySelector(`#page`).innerHTML=`
    <h2>Inspection History - Asset ${e}</h2>

    <div class="filter-card">
      <button onclick="showAssetSetup()">Back to Asset Setup</button>
    </div>

    <div class="filter-card">
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Type</th>
            <th>Tag No</th>
            <th>Status</th>
            <th>Inspector</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          ${n.length?n.map(e=>`
            <tr>
              <td>${e.testdate||``}</td>
              <td>${e.inspectiontype||``}</td>
              <td><strong>${e.tagnumber||`-`}</strong></td>
              <td>${e.status||``}</td>
              <td>${e.inspector||`-`}</td>
              <td>
              <button onclick="openCertificateModal(${e.testid})">
                View Certificate
              </button>
              </td>
            </tr>
          `).join(``):`
            <tr>
              <td colspan="6">No inspection history found</td>
            </tr>
          `}
        </tbody>
      </table>
    </div>
  `},window.passAllCriteria=function(e,t,n=`quick`){confirm(`Are you sure you want to mark all visual criteria as PASS and save this inspection?`)&&(document.querySelectorAll(`select[id^="result-"]`).forEach(e=>{e.value=Array.from(e.options).some(e=>e.value===`YES`)?`YES`:`PASS`}),updateInspectionSafetyWarning(),document.querySelectorAll(`input[id^="measured-"]`).forEach(e=>{e.value||=e.defaultValue||``}),saveInspection(e,t,n))},window.handleDashboardSearchEnter=function(e){e.key===`Enter`&&dashboardFindAsset()},window.dashboardFindAsset=function(){let e=document.querySelector(`#dashboardAssetSearch`).value.toLowerCase().trim(),t=document.querySelector(`#dashboardAssetSearchResult`);if(!e){t.innerHTML=`<p>Please enter an asset number, tag, serial number or QR code.</p>`;return}let n=s.filter(t=>String(t.assetid||``).toLowerCase().includes(e)||String(t.assettagno||``).toLowerCase().includes(e)||String(t.serialno||``).toLowerCase().includes(e)||String(t.hoistserialno||``).toLowerCase().includes(e)||String(t.qrcode||``).toLowerCase().includes(e)||String(t.description||``).toLowerCase().includes(e));if(n.length===0){t.innerHTML=`
      <p>No asset found for <strong>${e}</strong>.</p>
    `;return}t.innerHTML=`
    <table>
      <thead>
        <tr>
          <th>Asset ID</th>
          <th>Tag No</th>
          <th>Serial No</th>
          <th>Description</th>
          <th>Equipment Type</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody>
        ${n.slice(0,10).map(e=>`
          <tr>
            <td>${e.assetid}</td>
            <td>${e.assettagno||`-`}</td>
            <td>${e.serialno||e.hoistserialno||`-`}</td>
            <td>${e.description||``}</td>
            <td>${e.equipmenttype||``}</td>
            <td>
              <button onclick="startInspection(${e.assetid}, 'VISUAL', 'quick')">
                Inspect
              </button>

              ${Se(e)?`<button class="load-test-btn" onclick="startInspection(${e.assetid}, 'LOADTEST', 'quick')">Load Test</button>`:``}
            </td>
          </tr>
        `).join(``)}
      </tbody>
    </table>
  `};async function Ae(){try{let e=await(await fetch(`${b}/dashboard/alerts`)).json(),t=document.querySelector(`#dashboardAlerts`);if(!t)return;let n=``;Number(e.overdue)>0&&(n+=`
        <div class="alert-card danger">
          ALERT: ${e.overdue} Assets Overdue
        </div>
      `),Number(e.expiring)>0&&(n+=`
        <div class="alert-card warning">
          WARNING: ${e.expiring} Certificates Expiring Within 30 Days
        </div>
      `),Number(e.failed)>0&&(n+=`
        <div class="alert-card danger">
          ALERT: ${e.failed} Failed Assets
        </div>
      `),n===``&&(n=`
        <div class="alert-card success">
          OK: No operational alerts
        </div>
      `),t.innerHTML=n}catch(e){console.error(`Failed to load dashboard alerts:`,e)}}async function je(){try{let e=await(await fetch(`${b}/dashboard/attention`)).json(),n=document.getElementById(`attentionTableBody`);if(!e.length){n.innerHTML=`
        <tr>
          <td colspan="7" class="empty-row">No assets require attention</td>
        </tr>
      `;return}n.innerHTML=t(e,`dashboardAttention`,{assettagno:e=>e.assettagno,clientname:e=>e.clientname,sitename:e=>e.sitename,equipmenttype:e=>e.equipmenttype,reason:e=>e.reason,daysoverdue:e=>e.daysoverdue},`daysoverdue`).map(e=>`
      <tr>
        <td>
          <strong>${e.assettagno||`No Tag`}</strong><br>
          <small>${e.serialno||``}</small>
        </td>
        <td>${e.clientname||``}</td>
        <td>${e.sitename||``}</td>
        <td>${e.equipmenttype||``}</td>
        <td><span class="status-badge warning">${e.reason}</span></td>
        <td>${e.daysoverdue??`-`}</td>
        <td>
          <button class="small-btn" onclick="quickOpenAsset(${e.assetid})">
            Open
          </button>
        </td>
      </tr>
    `).join(``)}catch(e){console.error(`Failed to load dashboard attention:`,e)}}async function Me(){try{let e=await(await fetch(`${b}/dashboard/failed-equipment`)).json(),n=document.querySelector(`#failedEquipmentTableBody`);if(!n)return;if(!e.length){n.innerHTML=`
        <tr>
          <td colspan="7" class="empty-row">
            No failed equipment found
          </td>
        </tr>
      `;return}n.innerHTML=t(e,`dashboardFailed`,{assettagno:e=>e.assettagno,clientname:e=>e.clientname,sitename:e=>e.sitename,equipmenttype:e=>e.equipmenttype,testdate:e=>e.testdate,inspector:e=>e.inspector},`testdate`).map(e=>`
      <tr>
        <td>
          <strong>${e.assettagno||`No Tag`}</strong><br>
          <small>Asset ID: ${e.assetid}</small><br>
          <small>Serial: ${e.serialno||`-`}</small>
        </td>
        <td>${e.clientname||``}</td>
        <td>${e.sitename||``}</td>
        <td>${e.equipmenttype||``}</td>
        <td>${e.testdate?e.testdate.split(`T`)[0]:``}</td>
        <td>${e.inspector||`-`}</td>
        <td>
          <button
            class="small-btn"
            onclick="openCertificateModal(${e.testid})"
          >
            View
          </button>
        </td>
      </tr>
    `).join(``)}catch(e){console.error(`Failed to load failed equipment:`,e)}}async function Ne(){try{let e=await(await fetch(`${b}/dashboard/upcoming-expiries`)).json(),n=document.querySelector(`#upcomingExpiriesTableBody`);if(!n)return;if(!e.length){n.innerHTML=`
        <tr>
          <td colspan="8" class="empty-row">
            No upcoming certificate expiries
          </td>
        </tr>
      `;return}n.innerHTML=t(e,`dashboardExpiries`,{assettagno:e=>e.assettagno,clientname:e=>e.clientname,sitename:e=>e.sitename,equipmenttype:e=>e.equipmenttype,inspectiontype:e=>e.inspectiontype,validdate:e=>e.validdate,daysremaining:e=>e.daysremaining},`daysremaining`).map(e=>`
      <tr>
        <td>
          <strong>${e.assettagno||`No Tag`}</strong><br>
          <small>Asset ID: ${e.assetid}</small><br>
          <small>Serial: ${e.serialno||`-`}</small>
        </td>
        <td>${e.clientname||``}</td>
        <td>${e.sitename||``}</td>
        <td>${e.equipmenttype||``}</td>
        <td>${e.inspectiontype||``}</td>
        <td>${e.validdate?e.validdate.split(`T`)[0]:``}</td>
        <td><strong>${e.daysremaining}</strong></td>
        <td>
          <button
            class="small-btn"
            onclick="openCertificateModal(${e.testid})"
          >
            View
          </button>
        </td>
      </tr>
    `).join(``)}catch(e){console.error(`Failed to load upcoming expiries:`,e)}}window.saveInspection=async function(e,t=`VISUAL`,n=`quick`){let r=document.querySelector(`#inspectionTagNo`)?.value.trim()||``,i=document.querySelector(`#inspectionTestDate`)?.value||M(),a=s.find(t=>String(t.assetid)===String(e));if(!a){alert(`Asset not found`);return}let o=Ee(v.filter(e=>String(e.equiptypeid)===String(a.equiptypeid)&&String(e.inspectioncategory)===String(t)&&e.active!==!1),t);o=o.filter(e=>!P(a,e,t));let c=[],l=`SAFE`;for(let e of o){let n=document.querySelector(`#result-${e.criteriaid}`),r=document.querySelector(`#measured-${e.criteriaid}`),i=n?n.value:`RECORDED`,o=document.querySelector(`#remarks-${e.criteriaid}`),s=Ce(e)||t===`LOADTEST`?o?.value||``:i===`FAIL`&&o?.value||``;z(e)&&![`PASS`,`YES`].includes(i)&&(l=`NOT SAFE`),Oe(e)&&!z(e)&&[`FAIL`,`NO`].includes(i)&&(l=`NOT SAFE`);let u=ve(a,e)||null,d=r?r.value:null;c.push({criteriaid:e.criteriaid,criterianame:e.criterianame,assetvalue:u,measuredvalue:d,result:i,remarks:s})}let u=new FormData;u.append(`assetid`,e),u.append(`testdate`,i),u.append(`validdate`,document.querySelector(`#inspectionValidDate`)?.value||``),u.append(`comments`,``),u.append(`status`,l),u.append(`inspectiontype`,t),u.append(`tagnumber`,r),u.append(`results`,JSON.stringify(c)),u.append(`updateassetphotos`,document.querySelector(`#updateAssetPhotos`)?.checked||!1),(window.pendingInspectionPhotos||[]).forEach(e=>{u.append(`inspectionPhotos`,e.file),u.append(`photoCaptions`,e.caption||``),u.append(`photoTypes`,e.photoType||`GENERAL`)});let d,f;try{d=await fetch(`${b}/inspections`,{method:`POST`,body:u}),f=await d.json()}catch(e){alert(`Error saving inspection: `+e.message);return}if(!d.ok){alert(`Error saving inspection: `+f.error);return}alert(`Inspection saved. Status: `+(f.status||l)),await $(),R(n)};let V=localStorage.getItem(`currentPage`)||`dashboard`;switch(Ge(V)||(V=G.role===`CUSTOMER`?`certificates`:`dashboard`,localStorage.setItem(`currentPage`,V)),V){case`dashboard`:showDashboard();break;case`customers`:showCustomerSetup();break;case`sites`:showSites();break;case`responsible`:showResponsiblePersons();break;case`sections`:showSections();break;case`assets`:showAssetSetup();break;case`inspections`:showInspections();break;case`quick-inspection`:showQuickInspection();break;case`criteria`:showEquipmentTypeCriteria();break;case`certificates`:showCertificateSearch();break;case`customer-report`:showCustomerDetailedReport();break;case`she`:showRiskAssessments();break;case`users`:showUserManagement();break;default:showDashboard();break}}$();