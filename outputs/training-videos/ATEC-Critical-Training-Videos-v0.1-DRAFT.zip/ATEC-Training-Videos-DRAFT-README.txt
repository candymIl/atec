ATEC CRITICAL TRAINING VIDEO DRAFTS
Version: 0.1 DRAFT - LOCAL UAT - APPROVAL PENDING
Date: 10 August 2026

Included modules:
1. Creating and assigning a job card
2. Capturing time and travel
3. Timesheet submission and approval

These are playable, captioned MP4 review drafts. They are intentionally silent because external text-to-speech transmission has not been approved. Operational employee and asset identities have been redacted. The videos must not be issued as final controlled employee training until role-based production UAT, approved synthetic screenshots, narration/caption review and process-owner sign-off are complete.

Approved workflow source:
ATEC Employee Training & User Manual v0.96 and aligned Tutorial Video Production Plan.
